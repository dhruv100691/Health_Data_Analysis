#' ADAS-Cognitive
#'
#'
#'
#' @author \email{adni-data@googlegroups.com}
#' @references Rosen WG, Mohs RC, & Davis KL. (1984). A new rating scale for Alzheimer's disease. \emph{The American Journal of Psychiatry}. 141 (11), 1356-64. \url{http://www.ncbi.nlm.nih.gov/pubmed/6496779}
#' @seealso \code{\link{adasscores}}
#' @description Raw Alzheimer's Disease Assessment Scale-Cognitive (ADAS-Cog) data from the electronic case report form (eCRF). More information is available at \url{http://adni.loni.usc.edu/data-samples/data-faq/}.
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item DONE N NA Was Assessment/Procedure Done?
#'   \item NDREASON N NA If No, Reason Not Done:
#'   \item Q1TRIT N NA Trial 1 Total
#'   \item Q1TR2T N NA Trial 2 Total
#'   \item Q1TRT N NA Trial 3 Total
#'   \item Q5NAME1 N NA Flower
#'   \item Q5NAME2 N NA Bed
#'   \item Q5NAME3 N NA Whistle
#'   \item Q5NAME4 N NA Pencil
#'   \item Q5NAME5 N NA Rattle
#'   \item Q5NAME6 N NA Mask
#'   \item Q5NAME7 N NA Scissors
#'   \item Q5NAME8 N NA Comb
#'   \item Q5NAME9 N NA Wallet
#'   \item Q5NAME10 N NA Harmonica
#'   \item Q5NAME11 N NA Stethoscope
#'   \item Q5NAME12 N NA Tongs
#'   \item Q5FINGER N NA Naming Fingers
#'   \item COMM T NA Comments:
#'   \item Q5SCORE_CUE N  ADAS Score Component Q5 Naming Objects and Fingers (with cue when necessary) 
#'   \item TIMEEND T HHMM Time Ended:
#'   \item TIMEBEGAN T HHMM Time Began:
#'   \item TOTSCORE N NA Total Score (ADAS 11)
#'   \item WORDLIST N NA Word Recall and Recognition Tasks List Number
#'   \item Q1UNABLE N NA 1. Word Recall
#'   \item Q1TR1 T NA Trial 1
#'   \item Q1TR2 T NA Trial 2
#'   \item Q1TR3 T NA Trial 3
#'   \item Q1SCORE N NA Score Component
#'   \item Q2UNABLE N NA 2. Commands
#'   \item Q2TASK T NA <!--2. Commands-->
#'   \item Q2SCORE N NA Score Component
#'   \item Q3UNABLE N NA 3. Constructional Praxis
#'   \item Q3TASK1 N NA Circle
#'   \item Q3TASK2 N NA Two overlapping rectangles
#'   \item Q3TASK3 N NA Rhombus(Diamond)
#'   \item Q3TASK4 N NA Cube
#'   \item Q3SCORE N NA Score Component
#'   \item Q4UNABLE N NA 4.  Delayed Word Recall
#'   \item Q4TASK T NA <!--4.  Delayed Word Recall-->
#'   \item Q4SCORE N NA Score Component
#'   \item Q5UNABLE N NA 5. Naming Objects and Fingers
#'   \item Q5TASK T NA <!--5. Naming Objects and Fingers-->
#'   \item Q5SCORE N NA Score Component
#'   \item Q6UNABLE N NA 6. Ideational Praxis
#'   \item Q6TASK T NA <!--6. Ideational Praxis-->
#'   \item Q6SCORE N NA Score Component
#'   \item Q7UNABLE N NA 7. Orientation
#'   \item Q7TASK T NA <!--7. Orientation-->
#'   \item Q7SCORE N NA Score Component
#'   \item Q8UNABLE N NA 8. Word Recognition
#'   \item Q8WORD1 N NA Word 1
#'   \item Q8WORD1R T NA <!--Reminder given?-->
#'   \item Q8WORD2 N NA Word 2
#'   \item Q8WORD2R T NA <!--Reminder given?-->
#'   \item Q8WORD3 N NA Word 3
#'   \item Q8WORD3R T NA <!--Reminder given?-->
#'   \item Q8WORD4 N NA Word 4
#'   \item Q8WORD4R T NA <!--Reminder given?-->
#'   \item Q8WORD5 N NA Word 5
#'   \item Q8WORD5R T NA <!--Reminder given?-->
#'   \item Q8WORD6 N NA Word 6
#'   \item Q8WORD6R T NA <!--Reminder given?-->
#'   \item Q8WORD7 N NA Word 7
#'   \item Q8WORD7R T NA <!--Reminder given?-->
#'   \item Q8WORD8 N NA Word 8
#'   \item Q8WORD8R T NA <!--Reminder given?-->
#'   \item Q8WORD9 N NA Word 9
#'   \item Q8WORD9R T NA <!--Reminder given?-->
#'   \item Q8WORD10 N NA Word 10
#'   \item Q8WORD10R T NA <!--Reminder given?-->
#'   \item Q8WORD11 N NA Word 11
#'   \item Q8WORD11R T NA <!--Reminder given?-->
#'   \item Q8WORD12 N NA Word 12
#'   \item Q8WORD12R T NA <!--Reminder given?-->
#'   \item Q8WORD13 N NA Word 13
#'   \item Q8WORD13R T NA <!--Reminder given?-->
#'   \item Q8WORD14 N NA Word 14
#'   \item Q8WORD14R T NA <!--Reminder given?-->
#'   \item Q8WORD15 N NA Word 15
#'   \item Q8WORD15R T NA <!--Reminder given?-->
#'   \item Q8WORD16 N NA Word 16
#'   \item Q8WORD16R T NA <!--Reminder given?-->
#'   \item Q8WORD17 N NA Word 17
#'   \item Q8WORD17R T NA <!--Reminder given?-->
#'   \item Q8WORD18 N NA Word 18
#'   \item Q8WORD18R T NA <!--Reminder given?-->
#'   \item Q8WORD19 N NA Word 19
#'   \item Q8WORD19R T NA <!--Reminder given?-->
#'   \item Q8WORD20 N NA Word 20
#'   \item Q8WORD20R T NA <!--Reminder given?-->
#'   \item Q8WORD21 N NA Word 21
#'   \item Q8WORD21R T NA <!--Reminder given?-->
#'   \item Q8WORD22 N NA Word 22
#'   \item Q8WORD22R T NA <!--Reminder given?-->
#'   \item Q8WORD23 N NA Word 23
#'   \item Q8WORD23R T NA <!--Reminder given?-->
#'   \item Q8WORD24 N NA Word 24
#'   \item Q8WORD24R T NA <!--Reminder given?-->
#'   \item Q8SCORE N NA Score Component
#'   \item Q9TASK N NA 9. Remembering Test Instructions (this item is calculated based on responses recorded in Item 8.)
#'   \item Q9SCORE N NA Score Component
#'   \item Q10TASK N NA 10. Comprehension of Spoken Language
#'   \item Q10SCORE N NA Score Component
#'   \item Q11TASK N NA 11. Word-finding Difficulty
#'   \item Q11SCORE N NA Score Component
#'   \item Q12TASK N NA 12. Language
#'   \item Q12SCORE N NA Score Component
#'   \item Q13UNABLE N NA 13. Number Cancellation (Time limit: 45 seconds)
#'   \item Q13TASKA N NA 13.a Number of targets hit (range = 0-49)
#'   \item Q13TASKB N NA 13b. Number of errors
#'   \item Q13TASKC N NA 13c. Number of times reminded of task
#'   \item Q13SCORE N NA Score Component
#'   \item TOTAL13 N NA Total Score (ADAS 13)
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item EXAMDATE D  Examination Date
#'   \item COT1LIST T  Trial 1
#'   \item COT2LIST T  Trial 2
#'   \item COT3LIST T  Trial 3
#'   \item COT1SCOR N  Total <!--Trial 1-->
#'   \item COT2SCOR N  Total <!--Trial 2-->
#'   \item COT3SCOR N  Total <!--Trial 1-->
#'   \item COP1COMP N  If any trial not administered, check one:
#'   \item COCOMND T  Check each command performed correctly.
#'   \item COP2COMP N  If task not administered, check one:
#'   \item COCONSTR T  Check each figure drawn correctly.
#'   \item COP3COMP N  If task not administered, check one:
#'   \item COT4LIST T  Check each word correctly recalled.
#'   \item COT4TOTL N  Total
#'   \item COP4COMP N  If task not completed, check one:
#'   \item CONAME T  Check each object and finger named correctly.
#'   \item COP5COMP N  If task not administered, check one:
#'   \item COIDEA T  Check each step completed correctly.
#'   \item COP6COMP N  If task not administered, check one:
#'   \item COORIEN T  Check each item answered correctly.
#'   \item COP7COMP N  If task not administered, check one:
#'   \item CO8NURSE N  NURSE - Participant Response
#'   \item CO8MAGAZ N  MAGAZINE - Participant Response
#'   \item CO8WIZRD N  WIZARD - Participant Response
#'   \item CO8WIZRR T  Reminder given?
#'   \item CO8VAN N  VAN - Participant Response
#'   \item CO8VANR T  Reminder given?
#'   \item CO8LEPRD N  LEOPARD - Participant Response
#'   \item CO8LEPRR T  Reminder given?
#'   \item CO8SALE N  SALE - Participant Response
#'   \item CO8SALER T  Reminder given?
#'   \item CO8SEA N  SEA - Participant Response
#'   \item CO8SEAR T  Reminder given?
#'   \item CO8TRAIN N  TRAIN - Participant Response
#'   \item CO8TRAIR T  Reminder given?
#'   \item CO8COIN N  COIN - Participant Response
#'   \item CO8COINR T  Reminder given?
#'   \item CO8SHIP N  SHIP - Participant Response
#'   \item CO8SHIPR T  Reminder given?
#'   \item CO8INST N  INSTITUTION - Participant Response
#'   \item CO8INSTR T  Reminder given?
#'   \item CO8MAP N  MAP - Participant Response
#'   \item CO8MAPR T  Reminder given?
#'   \item CO8AXE N  AXE - Participant Response
#'   \item CO8AXER T  Reminder given?
#'   \item CO8BOARD N  BOARD - Participant Response
#'   \item CO8BOARR T  Reminder given?
#'   \item CO8CARRT N  CARROT - Participant Response
#'   \item CO8CARRR T  Reminder given?
#'   \item CO8MILK N  MILK - Participant Response
#'   \item CO8MILKR T  Reminder given?
#'   \item CO8VOL N  VOLUME - Participant Response
#'   \item CO8VOLR T  Reminder given?
#'   \item CO8FORST N  FOREST - Participant Response
#'   \item CO8FORSR T  Reminder given?
#'   \item CO8ANCHR N  ANCHOR - Participant Response
#'   \item CO8ANCRR T  Reminder given?
#'   \item CO8GEM N  GEM - Participant Response
#'   \item CO8GEMR T  Reminder given?
#'   \item CO8CAT N  CAT - Participant Response
#'   \item CO8CATR T  Reminder given?
#'   \item CO8FUND N  FUND - Participant Response
#'   \item CO8FUNDR T  Reminder given?
#'   \item CO8EDGE N  EDGE - Participant Response
#'   \item CO8EDGER T  Reminder given?
#'   \item CO8CAKE N  CAKE - Participant Response
#'   \item CO8CAKER T  Reminder given?
#'   \item COP8COMP N  If task not administered, check one:
#'   \item COINSTRC N  Check level of impairment.  Base your answer only on observations made during Word Recognition task (Question #8).
#'   \item COCOMPRE N  Check level of impairment.
#'   \item COWRDFND N  Check one response
#'   \item COLANG N  Check level of impairment.
#'   \item CONMCXLA N  14a. Number of targets hit (range = 0-49)
#'   \item CONMCXLB N  14b. Number of errors
#'   \item CONMCXLC N  14c. Number of times reminded of task
#'   \item COP14CMP N  If task not administered, check one:
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name adas
#' @usage data(adas)
#' @format A data frame with 9364 rows and 210 variables
NULL

#' Additional Comments
#'
#'
#'
#' @author \email{adni-data@googlegroups.com}
#'
#'
#' @description See \url{http://adni.loni.usc.edu}.
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item RECNO N  Record Number
#'   \item EXAMDATE D  Examination Date
#'   \item CAAPPLY N  This Additional Comment applies to:
#'   \item CASPECIF T  One form/assessment (specify)
#'   \item CACOMM T  Comments:
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name addcomm
#' @usage data(addcomm)
#' @format A data frame with 5485 rows and 12 variables
NULL

#' AD Metabolomics Consortium Barcelona Purines
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item RECNO -4 -4 Record number (2 indicates replicate sample)
#'   \item Comments -4 -4 -4
#'   \item L.Glutamine -4 -4 L-Glutamine
#'   \item Taurine -4 -4 Taurine
#'   \item Glycine -4 -4 Glycine
#'   \item Inosine -4 -4 Inosine
#'   \item Hypoxanthine -4 -4 Hypoxanthine
#'   \item Xanthine -4 -4 Xanthine
#'   \item Xanthosine -4 -4 Xanthosine
#'   \item Uric.acid -4 -4 Uric acid
#' }
#'
#' @examples
#' \donotrun{
#' describe(admcbarcelonapurine)
#' }
#' @docType data
#' @keywords datasets
#' @name admcbarcelonapurine
#' @usage data(admcbarcelonapurine)
#' @format A data frame with 890 rows and 12 variables
NULL

#' AD Metabolomics Consortium Bile Acids
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/ADMCBA/ADMC%20Bile_Acids_Method_Description.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item Sample.Type -4 -4 Study samples are Sample.  Biocrates QCs are QC Level 1, 2 or 3.
#'   \item Species -4 -4 Species of sample
#'   \item Material -4 -4 For this study the samples are serum
#'   \item Well.Position -4 -4 Well number in the 96-well plate from which the sample was injected
#'   \item Sample.Volume -4 -4 The volume of sample injected in microliters
#'   \item Run.Number -4 -4 Generated by the Biocrates MetIDQ software for every plate indicating the run number for a particular plate.  For this study, all plates were injected only once.  Therefore, all Run Numbers are 1.
#'   \item Injection.Number -4 -4 Generated by the Biocrates MetIDQ software for every sample on a plate indicating whether a sample was injected more than once.  All study samples were injected only once for every plate.  Therefore, all Injection Numbers for study samples is 1.  QC samples are injected three times for every plate resulting in a 1, 2, or 3 listing.
#'   \item CA -4 -4 Cholic acid [M]
#'   \item CA.Status -4 -4 Status of Cholic acid result
#'   \item CDCA -4 -4 Chenodeoxycholic acid [M]
#'   \item CDCA.Status -4 -4 Status of Chenodeoxycholic acid result
#'   \item DCA -4 -4 Deoxycholic acid [M]
#'   \item DCA.Status -4 -4 Status of Deoxycholic acid result
#'   \item GCA -4 -4 Glycocholic acid [M]
#'   \item GCA.Status -4 -4 Status of Glycocholic acid result
#'   \item GCDCA -4 -4 Glycochenodeoxycholic acid [M]
#'   \item GCDCA.Status -4 -4 Status of Glycochenodeoxycholic acid result
#'   \item GDCA -4 -4 Glycodeoxycholic acid [M]
#'   \item GDCA.Status -4 -4 Status of Glycodeoxycholic acid
#'   \item GLCA -4 -4 Glycolithocholic acid [M]
#'   \item GLCA.Status -4 -4 Status of Glycolithocholic acid result
#'   \item GLCAS -4 -4 Glycolithocholic acid sulphate [M]
#'   \item GLCAS.Status -4 -4 Status of Glycolithocholic acid sulphate
#'   \item GUDCA -4 -4 Glycoursodeoxycholic acid [M]
#'   \item GUDCA.Status -4 -4 Status of Glycoursodeoxycholic acid result
#'   \item HDCA -4 -4 Hyodeoxycholic acid [M]
#'   \item HDCA.Status -4 -4 Status of Hyodeoxycholic acid result
#'   \item LCA -4 -4 Lithocholic acid [M]
#'   \item LCA.Status -4 -4 Status of Lithocholic acid result
#'   \item MCA.a. -4 -4 -4
#'   \item MCA.a.Status -4 -4 -4
#'   \item MCA.b. -4 -4 -4
#'   \item MCA.b.Status -4 -4 -4
#'   \item MCA.o. -4 -4 -4
#'   \item MCA.o.Status -4 -4 -4
#'   \item TCA -4 -4 Taurocholic acid [M]
#'   \item TCA.Status -4 -4 Status of Taurocholic acid result
#'   \item TCDCA -4 -4 Taurochenodeoxycholic acid [M]
#'   \item TCDCA.Status -4 -4 Status of Taurochenodeoxycholic acid result
#'   \item TDCA -4 -4 Taurodeoxycholic acid [M]
#'   \item TDCA.Status -4 -4 Status of Taurodeoxycholic acid result
#'   \item TLCA -4 -4 Taurolithocholic acid [M]
#'   \item TLCA.Status -4 -4 Status of Taurolithocholic acid result
#'   \item TLCAS -4 -4 Taurolithocholic acid sulphate [M]
#'   \item TLCAS.Status -4 -4 Status of Taurolithocholic acid sulphate result
#'   \item TMCA.a.b. -4 -4 -4
#'   \item TMCA.a.b.Status -4 -4 -4
#'   \item TUDCA -4 -4 Tauroursodeoxycholic acid [M]
#'   \item TUDCA.Status -4 -4 Status ofTauroursodeoxycholic acid result
#'   \item UDCA -4 -4 Ursodeoxycholic acid [M]
#'   \item UDCA.Status -4 -4 Status of Ursodeoxycholic acid result
#' }
#'
#' @examples
#' \donotrun{
#' describe(admcba)
#' }
#' @docType data
#' @keywords datasets
#' @name admcba
#' @usage data(admcba)
#' @format A data frame with 866 rows and 53 variables
NULL

#' ADMC Duke p180 Flow Injection Analysis [ADNI GO,2]
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item Customer.Sample.Identification -4 -4 -4
#'   \item OTHERSPECID -4 -4 -4
#'   \item SITE -4 -4 -4
#'   \item PRIM -4 -4 -4
#'   \item DER -4 -4 -4
#'   \item ADDV -4 -4 -4
#'   \item GRP -4 -4 -4
#'   \item PROT -4 -4 -4
#'   \item VOL -4 -4 -4
#'   \item DRAWDTE -4 -4 -4
#'   \item DRAWTIME -4 -4 -4
#'   \item RECDTE -4 -4 -4
#'   \item CONDITION -4 -4 -4
#'   \item Plate.Bar.Code -4 -4 Unique identifier for every plate generated by the Biocrates MetIDQ software
#'   \item Sample.Bar.Code -4 -4 Unique identifier for every sample registered in the Biocrates MetIDQ software
#'   \item Sample.Type -4 -4 -4
#'   \item Sample.Identification -4 -4 Unique identifier for every sample entered in the Duke Proteomics Sample Sumbission System.
#'   \item Species -4 -4 Species of sample origin
#'   \item Material -4 -4 For this study the samples are serum
#'   \item Well.Position -4 -4 Well number in the 96-well plate from which the sample was injected
#'   \item Sample.Volume -4 -4 The volume of sample injected in microliters
#'   \item Run.Number -4 -4 -4
#'   \item Injection.Number -4 -4 -4
#'   \item C0 -4 -4 Carnitine
#'   \item C10 -4 -4 Decanoylcarnitine
#'   \item C10.1 -4 -4 Decenoylcarnitine
#'   \item C10.2 -4 -4 Decadienylcarnitine
#'   \item C12 -4 -4 Dodecanoylcarnitine
#'   \item C12.DC -4 -4 Dodecanedioylcarnitine
#'   \item C12.1 -4 -4 Dodecenoylcarnitine
#'   \item C14 -4 -4 Tetradecanoylcarnitine
#'   \item C14.1 -4 -4 Tetradecenoylcarnitine
#'   \item C14.1.OH -4 -4 Hydroxytetradecenoylcarnitine
#'   \item C14.2 -4 -4 Tetradecadienylcarnitine
#'   \item C14.2.OH -4 -4 Hydroxytetradecadienylcarnitine
#'   \item C16 -4 -4 Hexadecanoylcarnitine
#'   \item C16.OH -4 -4 Hydroxyhexadecanoylcarnitine
#'   \item C16.1 -4 -4 Hexadecenoylcarnitine
#'   \item C16.1.OH -4 -4 Hydroxyhexadecenoylcarnitine
#'   \item C16.2 -4 -4 Hexadecadienylcarnitine
#'   \item C16.2.OH -4 -4 Hydroxyhexadecadienylcarnitine
#'   \item C18 -4 -4 Octadecanoylcarnitine
#'   \item C18.1 -4 -4 Octadecenoylcarnitine
#'   \item C18.1.OH -4 -4 Hydroxyoctadecenoylcarnitine
#'   \item C18.2 -4 -4 Octadecadienylcarnitine
#'   \item C2 -4 -4 Acetylcarnitine
#'   \item C3 -4 -4 Propionylcarnitine
#'   \item C5.OH..C3.DC.M. -4 -4 Hydroxyvalerylcarnitine (Methylmalonylcarnitine)
#'   \item C3.OH -4 -4 Hydroxypropionylcarnitine
#'   \item C3.1 -4 -4 Propenylcarnitine
#'   \item C4 -4 -4 Butyrylcarnitine (Isobutyrylcarnitine)
#'   \item C3.DC..C4.OH. -4 -4 Malonylcarnitine (Hydroxybutyrylcarnitine)
#'   \item C4.1 -4 -4 Butenylcarnitine
#'   \item C5 -4 -4 Isovalerylcarnitine (Methylbutylcarnitine, Valerylcarnitine)
#'   \item C5.DC..C6.OH. -4 -4 Glutarylcarnitine (Hydroxyhexanoylcarnitine)
#'   \item C5.M.DC -4 -4 Methylglutarylcarnitine
#'   \item C5.1 -4 -4 Tiglylcarnitine
#'   \item C5.1.DC -4 -4 Glutaconylcarnitine
#'   \item C6..C4.1.DC. -4 -4 Hexanoylcarnitine (Fumarylcarnitine)
#'   \item C6.1 -4 -4 Hexenoylcarnitine
#'   \item C7.DC -4 -4 Pimelylcarnitine
#'   \item C8 -4 -4 Octanoylcarnitine
#'   \item C9 -4 -4 Nonanoylcarnitine
#'   \item lysoPC.a.C14.0 -4 -4 lysoPhosphatidylcholine a C14:0
#'   \item lysoPC.a.C16.0 -4 -4 lysoPhosphatidylcholine a C16:0
#'   \item lysoPC.a.C16.1 -4 -4 lysoPhosphatidylcholine a C16:1
#'   \item lysoPC.a.C17.0 -4 -4 lysoPhosphatidylcholine a C17:0
#'   \item lysoPC.a.C18.0 -4 -4 lysoPhosphatidylcholine a C18:0
#'   \item lysoPC.a.C18.1 -4 -4 lysoPhosphatidylcholine a C18:1
#'   \item lysoPC.a.C18.2 -4 -4 lysoPhosphatidylcholine a C18:2
#'   \item lysoPC.a.C20.3 -4 -4 lysoPhosphatidylcholine a C20:3
#'   \item lysoPC.a.C20.4 -4 -4 lysoPhosphatidylcholine a C20:4
#'   \item lysoPC.a.C24.0 -4 -4 lysoPhosphatidylcholine a C24:0
#'   \item lysoPC.a.C26.0 -4 -4 lysoPhosphatidylcholine a C26:0
#'   \item lysoPC.a.C26.1 -4 -4 lysoPhosphatidylcholine a C26:1
#'   \item lysoPC.a.C28.0 -4 -4 lysoPhosphatidylcholine a C28:0
#'   \item lysoPC.a.C28.1 -4 -4 lysoPhosphatidylcholine a C28:1
#'   \item PC.aa.C24.0 -4 -4 PC aa C24:0
#'   \item PC.aa.C26.0 -4 -4 PC aa C26:0
#'   \item PC.aa.C28.1 -4 -4 PC aa C28:1
#'   \item PC.aa.C30.0 -4 -4 PC aa C30:0
#'   \item PC.aa.C32.0 -4 -4 PC aa C32:0
#'   \item PC.aa.C32.1 -4 -4 PC aa C32:1
#'   \item PC.aa.C32.3 -4 -4 PC aa C32:3
#'   \item PC.aa.C34.1 -4 -4 PC aa C34:1
#'   \item PC.aa.C34.2 -4 -4 PC aa C34:2
#'   \item PC.aa.C34.3 -4 -4 PC aa C34:3
#'   \item PC.aa.C34.4 -4 -4 PC aa C34:4
#'   \item PC.aa.C36.0 -4 -4 PC aa C36:0
#'   \item PC.aa.C36.1 -4 -4 PC aa C36:1
#'   \item PC.aa.C36.2 -4 -4 PC aa C36:2
#'   \item PC.aa.C36.3 -4 -4 PC aa C36:3
#'   \item PC.aa.C36.4 -4 -4 PC aa C36:4
#'   \item PC.aa.C36.5 -4 -4 PC aa C36:5
#'   \item PC.aa.C36.6 -4 -4 PC aa C36:6
#'   \item PC.aa.C38.0 -4 -4 PC aa C38:0
#'   \item PC.aa.C38.3 -4 -4 PC aa C38:3
#'   \item PC.aa.C38.4 -4 -4 PC aa C38:4
#'   \item PC.aa.C38.5 -4 -4 PC aa C38:5
#'   \item PC.aa.C38.6 -4 -4 PC aa C38:6
#'   \item PC.aa.C40.1 -4 -4 PC aa C40:1
#'   \item PC.aa.C40.2 -4 -4 PC aa C40:2
#'   \item PC.aa.C40.3 -4 -4 PC aa C40:3
#'   \item PC.aa.C40.4 -4 -4 PC aa C40:4
#'   \item PC.aa.C40.5 -4 -4 PC aa C40:5
#'   \item PC.aa.C40.6 -4 -4 PC aa C40:6
#'   \item PC.aa.C42.0 -4 -4 PC aa C42:0
#'   \item PC.aa.C42.1 -4 -4 PC aa C42:1
#'   \item PC.aa.C42.2 -4 -4 PC aa C42:2
#'   \item PC.aa.C42.4 -4 -4 PC aa C42:4
#'   \item PC.aa.C42.5 -4 -4 PC aa C42:5
#'   \item PC.aa.C42.6 -4 -4 PC aa C42:6
#'   \item PC.ae.C30.0 -4 -4 PC ae C30:0
#'   \item PC.ae.C30.1 -4 -4 PC ae C30:1
#'   \item PC.ae.C30.2 -4 -4 PC ae C30:2
#'   \item PC.ae.C32.1 -4 -4 PC ae C32:1
#'   \item PC.ae.C32.2 -4 -4 PC ae C32:2
#'   \item PC.ae.C34.0 -4 -4 PC ae C34:0
#'   \item PC.ae.C34.1 -4 -4 PC ae C34:1
#'   \item PC.ae.C34.2 -4 -4 PC ae C34:2
#'   \item PC.ae.C34.3 -4 -4 PC ae C34:3
#'   \item PC.ae.C36.0 -4 -4 PC ae C36:0
#'   \item PC.ae.C36.1 -4 -4 PC ae C36:1
#'   \item PC.ae.C36.2 -4 -4 PC ae C36:2
#'   \item PC.ae.C36.3 -4 -4 PC ae C36:3
#'   \item PC.ae.C36.4 -4 -4 PC ae C36:4
#'   \item PC.ae.C36.5 -4 -4 PC ae C36:5
#'   \item PC.ae.C38.0 -4 -4 PC ae C38:0
#'   \item PC.ae.C38.1 -4 -4 PC ae C38:1
#'   \item PC.ae.C38.2 -4 -4 PC ae C38:2
#'   \item PC.ae.C38.3 -4 -4 PC ae C38:3
#'   \item PC.ae.C38.4 -4 -4 PC ae C38:4
#'   \item PC.ae.C38.5 -4 -4 PC ae C38:5
#'   \item PC.ae.C38.6 -4 -4 PC ae C38:6
#'   \item PC.ae.C40.1 -4 -4 PC ae C40:1
#'   \item PC.ae.C40.2 -4 -4 PC ae C40:2
#'   \item PC.ae.C40.3 -4 -4 PC ae C40:3
#'   \item PC.ae.C40.4 -4 -4 PC ae C40:4
#'   \item PC.ae.C40.5 -4 -4 PC ae C40:5
#'   \item PC.ae.C40.6 -4 -4 PC ae C40:6
#'   \item PC.ae.C42.0 -4 -4 PC ae C42:0
#'   \item PC.ae.C42.1 -4 -4 PC ae C42:1
#'   \item PC.ae.C42.2 -4 -4 PC ae C42:2
#'   \item PC.ae.C42.3 -4 -4 PC ae C42:3
#'   \item PC.ae.C42.4 -4 -4 PC ae C42:4
#'   \item PC.ae.C42.5 -4 -4 PC ae C42:5
#'   \item PC.ae.C44.3 -4 -4 PC ae C44:3
#'   \item PC.ae.C44.4 -4 -4 PC ae C44:4
#'   \item PC.ae.C44.5 -4 -4 PC ae C44:5
#'   \item PC.ae.C44.6 -4 -4 PC ae C44:6
#'   \item SM..OH..C14.1 -4 -4 SM (OH) C14:1
#'   \item SM..OH..C16.1 -4 -4 SM (OH) C16:1
#'   \item SM..OH..C22.1 -4 -4 SM (OH) C22:1
#'   \item SM..OH..C22.2 -4 -4 SM (OH) C22:2
#'   \item SM..OH..C24.1 -4 -4 SM (OH) C24:1
#'   \item SM.C16.0 -4 -4 SM C16:0
#'   \item SM.C16.1 -4 -4 SM C16:1
#'   \item SM.C18.0 -4 -4 SM C18:0
#'   \item SM.C18.1 -4 -4 SM C18:1
#'   \item SM.C20.2 -4 -4 SM C20:2
#'   \item SM.C24.0 -4 -4 SM C24:0
#'   \item SM.C24.1 -4 -4 SM C24:1
#'   \item SM.C26.0 -4 -4 SM C26:0
#'   \item SM.C26.1 -4 -4 SM C26:1
#' }
#'
#' @examples
#' \donotrun{
#' describe(admcdukep180fiaadni2go)
#' }
#' @docType data
#' @keywords datasets
#' @name admcdukep180fiaadni2go
#' @usage data(admcdukep180fiaadni2go)
#' @format A data frame with 941 rows and 167 variables
NULL

#' AD Metabolomics Consortium Duke Biocrates P180 Kit Flow injection analysis
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/ADMCDUKEP180FIA/ADMC_Duke_Biocrates_p180_Methods_Summary.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item Plate.Bar.Code -4 -4 Unique identifier for every plate generated by the Biocrates MetIDQ software
#'   \item Sample.Bar.Code -4 -4 Unique identifier for every sample registered in the Biocrates MetIDQ software
#'   \item Sample.Identification -4 -4 Unique identifier for every sample entered in the Duke Proteomics Sample Sumbission System.
#'   \item Species -4 -4 Species of sample origin
#'   \item Material -4 -4 For this study the samples are serum
#'   \item Well.Position -4 -4 Well number in the 96-well plate from which the sample was injected
#'   \item Sample.Volume -4 -4 The volume of sample injected in microliters
#'   \item C0 -4 -4 Carnitine
#'   \item C10 -4 -4 Decanoylcarnitine
#'   \item C10.1 -4 -4 Decenoylcarnitine
#'   \item C10.2 -4 -4 Decadienylcarnitine
#'   \item C12 -4 -4 Dodecanoylcarnitine
#'   \item C12.DC -4 -4 Dodecanedioylcarnitine
#'   \item C12.1 -4 -4 Dodecenoylcarnitine
#'   \item C14 -4 -4 Tetradecanoylcarnitine
#'   \item C14.1 -4 -4 Tetradecenoylcarnitine
#'   \item C14.1.OH -4 -4 Hydroxytetradecenoylcarnitine
#'   \item C14.2 -4 -4 Tetradecadienylcarnitine
#'   \item C14.2.OH -4 -4 Hydroxytetradecadienylcarnitine
#'   \item C16 -4 -4 Hexadecanoylcarnitine
#'   \item C16.OH -4 -4 Hydroxyhexadecanoylcarnitine
#'   \item C16.1 -4 -4 Hexadecenoylcarnitine
#'   \item C16.1.OH -4 -4 Hydroxyhexadecenoylcarnitine
#'   \item C16.2 -4 -4 Hexadecadienylcarnitine
#'   \item C16.2.OH -4 -4 Hydroxyhexadecadienylcarnitine
#'   \item C18 -4 -4 Octadecanoylcarnitine
#'   \item C18.1 -4 -4 Octadecenoylcarnitine
#'   \item C18.1.OH -4 -4 Hydroxyoctadecenoylcarnitine
#'   \item C18.2 -4 -4 Octadecadienylcarnitine
#'   \item C2 -4 -4 Acetylcarnitine
#'   \item C3 -4 -4 Propionylcarnitine
#'   \item C3.DC..C4.OH. -4 -4 Malonylcarnitine (Hydroxybutyrylcarnitine)
#'   \item C3.OH -4 -4 Hydroxypropionylcarnitine
#'   \item C3.1 -4 -4 Propenylcarnitine
#'   \item C4 -4 -4 Butyrylcarnitine (Isobutyrylcarnitine)
#'   \item C4.1 -4 -4 Butenylcarnitine
#'   \item C6..C4.1.DC. -4 -4 Hexanoylcarnitine (Fumarylcarnitine)
#'   \item C5 -4 -4 Isovalerylcarnitine (Methylbutylcarnitine, Valerylcarnitine)
#'   \item C5.M.DC -4 -4 Methylglutarylcarnitine
#'   \item C5.OH..C3.DC.M. -4 -4 Hydroxyvalerylcarnitine (Methylmalonylcarnitine)
#'   \item C5.1 -4 -4 Tiglylcarnitine
#'   \item C5.1.DC -4 -4 Glutaconylcarnitine
#'   \item C5.DC..C6.OH. -4 -4 Glutarylcarnitine (Hydroxyhexanoylcarnitine)
#'   \item C6.1 -4 -4 Hexenoylcarnitine
#'   \item C7.DC -4 -4 Pimelylcarnitine
#'   \item C8 -4 -4 Octanoylcarnitine
#'   \item C9 -4 -4 Nonanoylcarnitine
#'   \item lysoPC.a.C14.0 -4 -4 lysoPhosphatidylcholine a C14:0
#'   \item lysoPC.a.C16.0 -4 -4 lysoPhosphatidylcholine a C16:0
#'   \item lysoPC.a.C16.1 -4 -4 lysoPhosphatidylcholine a C16:1
#'   \item lysoPC.a.C17.0 -4 -4 lysoPhosphatidylcholine a C17:0
#'   \item lysoPC.a.C18.0 -4 -4 lysoPhosphatidylcholine a C18:0
#'   \item lysoPC.a.C18.1 -4 -4 lysoPhosphatidylcholine a C18:1
#'   \item lysoPC.a.C18.2 -4 -4 lysoPhosphatidylcholine a C18:2
#'   \item lysoPC.a.C20.3 -4 -4 lysoPhosphatidylcholine a C20:3
#'   \item lysoPC.a.C20.4 -4 -4 lysoPhosphatidylcholine a C20:4
#'   \item lysoPC.a.C24.0 -4 -4 lysoPhosphatidylcholine a C24:0
#'   \item lysoPC.a.C26.0 -4 -4 lysoPhosphatidylcholine a C26:0
#'   \item lysoPC.a.C26.1 -4 -4 lysoPhosphatidylcholine a C26:1
#'   \item lysoPC.a.C28.0 -4 -4 lysoPhosphatidylcholine a C28:0
#'   \item lysoPC.a.C28.1 -4 -4 lysoPhosphatidylcholine a C28:1
#'   \item PC.aa.C24.0 -4 -4 PC aa C24:0
#'   \item PC.aa.C26.0 -4 -4 PC aa C26:0
#'   \item PC.aa.C28.1 -4 -4 PC aa C28:1
#'   \item PC.aa.C30.0 -4 -4 PC aa C30:0
#'   \item PC.aa.C32.0 -4 -4 PC aa C32:0
#'   \item PC.aa.C32.1 -4 -4 PC aa C32:1
#'   \item PC.aa.C32.3 -4 -4 PC aa C32:3
#'   \item PC.aa.C34.1 -4 -4 PC aa C34:1
#'   \item PC.aa.C34.2 -4 -4 PC aa C34:2
#'   \item PC.aa.C34.3 -4 -4 PC aa C34:3
#'   \item PC.aa.C34.4 -4 -4 PC aa C34:4
#'   \item PC.aa.C36.0 -4 -4 PC aa C36:0
#'   \item PC.aa.C36.1 -4 -4 PC aa C36:1
#'   \item PC.aa.C36.2 -4 -4 PC aa C36:2
#'   \item PC.aa.C36.3 -4 -4 PC aa C36:3
#'   \item PC.aa.C36.4 -4 -4 PC aa C36:4
#'   \item PC.aa.C36.5 -4 -4 PC aa C36:5
#'   \item PC.aa.C36.6 -4 -4 PC aa C36:6
#'   \item PC.aa.C38.0 -4 -4 PC aa C38:0
#'   \item PC.aa.C38.3 -4 -4 PC aa C38:3
#'   \item PC.aa.C38.4 -4 -4 PC aa C38:4
#'   \item PC.aa.C38.5 -4 -4 PC aa C38:5
#'   \item PC.aa.C38.6 -4 -4 PC aa C38:6
#'   \item PC.aa.C40.1 -4 -4 PC aa C40:1
#'   \item PC.aa.C40.2 -4 -4 PC aa C40:2
#'   \item PC.aa.C40.3 -4 -4 PC aa C40:3
#'   \item PC.aa.C40.4 -4 -4 PC aa C40:4
#'   \item PC.aa.C40.5 -4 -4 PC aa C40:5
#'   \item PC.aa.C40.6 -4 -4 PC aa C40:6
#'   \item PC.aa.C42.0 -4 -4 PC aa C42:0
#'   \item PC.aa.C42.1 -4 -4 PC aa C42:1
#'   \item PC.aa.C42.2 -4 -4 PC aa C42:2
#'   \item PC.aa.C42.4 -4 -4 PC aa C42:4
#'   \item PC.aa.C42.5 -4 -4 PC aa C42:5
#'   \item PC.aa.C42.6 -4 -4 PC aa C42:6
#'   \item PC.ae.C30.0 -4 -4 PC ae C30:0
#'   \item PC.ae.C30.1 -4 -4 PC ae C30:1
#'   \item PC.ae.C30.2 -4 -4 PC ae C30:2
#'   \item PC.ae.C32.1 -4 -4 PC ae C32:1
#'   \item PC.ae.C32.2 -4 -4 PC ae C32:2
#'   \item PC.ae.C34.0 -4 -4 PC ae C34:0
#'   \item PC.ae.C34.1 -4 -4 PC ae C34:1
#'   \item PC.ae.C34.2 -4 -4 PC ae C34:2
#'   \item PC.ae.C34.3 -4 -4 PC ae C34:3
#'   \item PC.ae.C36.0 -4 -4 PC ae C36:0
#'   \item PC.ae.C36.1 -4 -4 PC ae C36:1
#'   \item PC.ae.C36.2 -4 -4 PC ae C36:2
#'   \item PC.ae.C36.3 -4 -4 PC ae C36:3
#'   \item PC.ae.C36.4 -4 -4 PC ae C36:4
#'   \item PC.ae.C36.5 -4 -4 PC ae C36:5
#'   \item PC.ae.C38.0 -4 -4 PC ae C38:0
#'   \item PC.ae.C38.1 -4 -4 PC ae C38:1
#'   \item PC.ae.C38.2 -4 -4 PC ae C38:2
#'   \item PC.ae.C38.3 -4 -4 PC ae C38:3
#'   \item PC.ae.C38.4 -4 -4 PC ae C38:4
#'   \item PC.ae.C38.5 -4 -4 PC ae C38:5
#'   \item PC.ae.C38.6 -4 -4 PC ae C38:6
#'   \item PC.ae.C40.1 -4 -4 PC ae C40:1
#'   \item PC.ae.C40.2 -4 -4 PC ae C40:2
#'   \item PC.ae.C40.3 -4 -4 PC ae C40:3
#'   \item PC.ae.C40.4 -4 -4 PC ae C40:4
#'   \item PC.ae.C40.5 -4 -4 PC ae C40:5
#'   \item PC.ae.C40.6 -4 -4 PC ae C40:6
#'   \item PC.ae.C42.0 -4 -4 PC ae C42:0
#'   \item PC.ae.C42.1 -4 -4 PC ae C42:1
#'   \item PC.ae.C42.2 -4 -4 PC ae C42:2
#'   \item PC.ae.C42.3 -4 -4 PC ae C42:3
#'   \item PC.ae.C42.4 -4 -4 PC ae C42:4
#'   \item PC.ae.C42.5 -4 -4 PC ae C42:5
#'   \item PC.ae.C44.3 -4 -4 PC ae C44:3
#'   \item PC.ae.C44.4 -4 -4 PC ae C44:4
#'   \item PC.ae.C44.5 -4 -4 PC ae C44:5
#'   \item PC.ae.C44.6 -4 -4 PC ae C44:6
#'   \item SM..OH..C14.1 -4 -4 SM (OH) C14:1
#'   \item SM..OH..C16.1 -4 -4 SM (OH) C16:1
#'   \item SM..OH..C22.1 -4 -4 SM (OH) C22:1
#'   \item SM..OH..C22.2 -4 -4 SM (OH) C22:2
#'   \item SM..OH..C24.1 -4 -4 SM (OH) C24:1
#'   \item SM.C16.0 -4 -4 SM C16:0
#'   \item SM.C16.1 -4 -4 SM C16:1
#'   \item SM.C18.0 -4 -4 SM C18:0
#'   \item SM.C18.1 -4 -4 SM C18:1
#'   \item SM.C20.2 -4 -4 SM C20:2
#'   \item SM.C24.0 -4 -4 SM C24:0
#'   \item SM.C24.1 -4 -4 SM C24:1
#'   \item SM.C26.0 -4 -4 SM C26:0
#'   \item SM.C26.1 -4 -4 SM C26:1
#'   \item update_stamp -4 -4 -4
#' }
#'
#' @examples
#' \donotrun{
#' describe(admcdukep180fia)
#' }
#' @docType data
#' @keywords datasets
#' @name admcdukep180fia
#' @usage data(admcdukep180fia)
#' @format A data frame with 849 rows and 151 variables
NULL

#' ADMC Duke p180 Ultra Performance Liquid Chromatography [ADNI GO,2]
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/ADMCDUKEP180UPLCADNI2GO/ADNI%20GO-2%20p180%20Methods%20Summary.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item Customer.Sample.Identification -4 -4 -4
#'   \item OTHERSPECID -4 -4 -4
#'   \item SITE -4 -4 -4
#'   \item PRIM -4 -4 -4
#'   \item DER -4 -4 -4
#'   \item ADDV -4 -4 -4
#'   \item GRP -4 -4 -4
#'   \item PROT -4 -4 -4
#'   \item VOL -4 -4 -4
#'   \item DRAWDTE -4 -4 -4
#'   \item DRAWTIME -4 -4 -4
#'   \item RECDTE -4 -4 -4
#'   \item CONDITION -4 -4 -4
#'   \item Plate.Bar.Code -4 -4 Unique identifier for every plate generated by the Biocrates MetIDQ software
#'   \item Sample.Bar.Code -4 -4 Unique identifier for every sample registered in the Biocrates MetIDQ software
#'   \item Sample.Type -4 -4 -4
#'   \item Sample.Identification -4 -4 Unique identifier for every sample entered in the Duke Proteomics Sample Sumbission System.
#'   \item Species -4 -4 Species of sample origin
#'   \item Material -4 -4 For this study the samples are serum
#'   \item Well.Position -4 -4 Well number in the 96-well plate from which the sample was injected
#'   \item Sample.Volume -4 -4 The volume of sample injected in microliters
#'   \item Run.Number -4 -4 -4
#'   \item Injection.Number -4 -4 -4
#'   \item Ala -4 -4 Alanine
#'   \item Arg -4 -4 Arginine
#'   \item Asn -4 -4 Asparagine
#'   \item Asp -4 -4 Aspartic Acid
#'   \item Cit -4 -4 Citrulline
#'   \item Gln -4 -4 Glutamine
#'   \item Glu -4 -4 Glutamic Acid
#'   \item Gly -4 -4 Glycine
#'   \item His -4 -4 Histidine
#'   \item Ile -4 -4 Isoleucine
#'   \item Lys -4 -4 Lysine
#'   \item Met -4 -4 Methionine
#'   \item Orn -4 -4 Ornithine
#'   \item Phe -4 -4 Phenylalanine
#'   \item Pro -4 -4 Proline
#'   \item Ser -4 -4 Serine
#'   \item Thr -4 -4 Threonine
#'   \item Trp -4 -4 Tryptophan
#'   \item Tyr -4 -4 Tyrosine
#'   \item Val -4 -4 Valine
#'   \item Ac.Orn -4 -4 Acetylornithine
#'   \item ADMA -4 -4 Asymmetric dimethylarginine
#'   \item alpha.AAA -4 -4 alpha-Aminoadipic acid
#'   \item c4.OH.Pro -4 -4 c4-OH-proline 
#'   \item Carnosine -4 -4 Carnosine
#'   \item Creatinine -4 -4 Creatinine
#'   \item DOPA -4 -4 Dihydroxyphenylalanine
#'   \item Dopamine -4 -4 Dopamine
#'   \item Histamine -4 -4 Histamine
#'   \item Kynurenine -4 -4 Kynurenine
#'   \item Met.SO -4 -4 Methionine-Sulfoxide
#'   \item Nitro.Tyr -4 -4 Nitrotyrosine
#'   \item PEA -4 -4 Phenylethylamine
#'   \item Putrescine -4 -4 Putrescine
#'   \item Sarcosine -4 -4 Sarcosine
#'   \item Serotonin -4 -4 Serotonin
#'   \item Spermidine -4 -4 Spermidine
#'   \item Spermine -4 -4 Spermine
#'   \item t4.OH.Pro -4 -4 trans isomer of 4-hydroxyproline 
#'   \item Taurine -4 -4 Taurine
#'   \item SDMA -4 -4 Symmetric dimethylarginine
#' }
#'
#' @examples
#' \donotrun{
#' describe(admcdukep180uplcadni2go)
#' }
#' @docType data
#' @keywords datasets
#' @name admcdukep180uplcadni2go
#' @usage data(admcdukep180uplcadni2go)
#' @format A data frame with 941 rows and 67 variables
NULL

#' AD Metabolomics Consortium Duke Biocrates P180 Kit Ultra Performance Liquid Chromatography
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/ADMCDUKEP180UPLC/ADMC_Duke_Biocrates_p180_Methods_Summary.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item Plate.Bar.Code -4 -4 Unique identifier for every plate generated by the Biocrates MetIDQ software
#'   \item Sample.Bar.Code -4 -4 Unique identifier for every sample registered in the Biocrates MetIDQ software
#'   \item Sample.Identification -4 -4 Unique identifier for every sample entered in the Duke Proteomics Sample Sumbission System.
#'   \item Species -4 -4 Species of sample origin
#'   \item Material -4 -4 For this study the samples are serum
#'   \item Well.Position -4 -4 Well number in the 96-well plate from which the sample was injected
#'   \item Sample.Volume -4 -4 The volume of sample injected in microliters
#'   \item Ala -4 -4 Alanine
#'   \item Arg -4 -4 Arginine
#'   \item Asn -4 -4 Asparagine
#'   \item Asp -4 -4 Aspartic Acid
#'   \item Cit -4 -4 Citrulline
#'   \item Gln -4 -4 Glutamine
#'   \item Glu -4 -4 Glutamic Acid
#'   \item Gly -4 -4 Glycine
#'   \item His -4 -4 Histidine
#'   \item Ile -4 -4 Isoleucine
#'   \item Lys -4 -4 Lysine
#'   \item Met -4 -4 Methionine
#'   \item Orn -4 -4 Ornithine
#'   \item Phe -4 -4 Phenylalanine
#'   \item Pro -4 -4 Proline
#'   \item Ser -4 -4 Serine
#'   \item Thr -4 -4 Threonine
#'   \item Trp -4 -4 Tryptophan
#'   \item Tyr -4 -4 Tyrosine
#'   \item Val -4 -4 Valine
#'   \item Ac.Orn -4 -4 Acetylornithine
#'   \item ADMA -4 -4 Asymmetric dimethylarginine
#'   \item alpha.AAA -4 -4 alpha-Aminoadipic acid
#'   \item c4.OH.Pro -4 -4 c4-OH-proline 
#'   \item Carmosine -4 -4 -4
#'   \item Creatinine -4 -4 Creatinine
#'   \item DOPA -4 -4 Dihydroxyphenylalanine
#'   \item Dopamine -4 -4 Dopamine
#'   \item Histamine -4 -4 Histamine
#'   \item Kynurenine -4 -4 Kynurenine
#'   \item Met.So -4 -4 -4
#'   \item Nitro.Tyr -4 -4 Nitrotyrosine
#'   \item PEA -4 -4 Phenylethylamine
#'   \item Putrescine -4 -4 Putrescine
#'   \item Sarcosine -4 -4 Sarcosine
#'   \item Serotonin -4 -4 Serotonin
#'   \item Spermidine -4 -4 Spermidine
#'   \item Spermine -4 -4 Spermine
#'   \item t4.OH.Pro -4 -4 trans isomer of 4-hydroxyproline 
#'   \item Taurine -4 -4 Taurine
#'   \item SDMA -4 -4 Symmetric dimethylarginine
#'   \item update_stamp -4 -4 -4
#' }
#'
#' @examples
#' \donotrun{
#' describe(admcdukep180uplc)
#' }
#' @docType data
#' @keywords datasets
#' @name admcdukep180uplc
#' @usage data(admcdukep180uplc)
#' @format A data frame with 849 rows and 51 variables
NULL

#' ADMC Metabolomic Analysis by Gas chromatography time of flight mass spectrometry (GCTOF) Data [ADNI1]
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/ADMCGCTOF/ADNI_Methods_GC-TOF_MS_metabolomics_UC_Davis_10-2016.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item COMMENTS -4 -4 -4
#'   \item Z.C30.FAME.INTERNAL.STANDARD -4 -4 -4
#'   \item Z.C28.FAME.INTERNAL.STANDARD -4 -4 -4
#'   \item Z.C26.FAME.INTERNAL.STANDARD -4 -4 -4
#'   \item Z.C24.FAME.INTERNAL.STANDARD -4 -4 -4
#'   \item Z.C22.FAME.INTERNAL.STANDARD -4 -4 -4
#'   \item Z.C20.FAME.INTERNAL.STANDARD -4 -4 -4
#'   \item Z.C18.FAME.INTERNAL.STANDARD -4 -4 -4
#'   \item Z.C16.FAME.INTERNAL.STANDARD -4 -4 -4
#'   \item Z.C14.FAME.INTERNAL.STANDARD -4 -4 -4
#'   \item Z.C12.FAME.INTERNAL.STANDARD -4 -4 -4
#'   \item Z.C10.FAME.INTERNAL.STANDARD -4 -4 -4
#'   \item Z.C09.FAME.INTERNAL.STANDARD -4 -4 -4
#'   \item Z.C08.FAME.INTERNAL.STANDARD -4 -4 -4
#'   \item XYLULOSE.NIST -4 -4 -4
#'   \item XYLOSE -4 -4 -4
#'   \item XYLITOL -4 -4 -4
#'   \item XANTHINE -4 -4 -4
#'   \item VALINE -4 -4 -4
#'   \item URIDINE -4 -4 -4
#'   \item URIC.ACID -4 -4 -4
#'   \item UREA -4 -4 -4
#'   \item UDP.GLUCURONIC.ACID -4 -4 -4
#'   \item TYROSINE -4 -4 -4
#'   \item TRYPTOPHAN -4 -4 -4
#'   \item TRANS.4.HYDROXYPROLINE -4 -4 -4
#'   \item TOCOPHEROL.GAMMA. -4 -4 -4
#'   \item TOCOPHEROL.ALPHA. -4 -4 -4
#'   \item THREONINE -4 -4 -4
#'   \item THREONIC.ACID -4 -4 -4
#'   \item THREITOL -4 -4 -4
#'   \item TAURINE -4 -4 -4
#'   \item TARTARIC.ACID -4 -4 -4
#'   \item TAGATOSE -4 -4 -4
#'   \item SUCROSE -4 -4 -4
#'   \item SUCCINIC.ACID -4 -4 -4
#'   \item STEARIC.ACID -4 -4 -4
#'   \item SHIKIMIC.ACID -4 -4 -4
#'   \item SERINE -4 -4 -4
#'   \item SALICYLIC.ACID -4 -4 -4
#'   \item RIBOSE -4 -4 -4
#'   \item RIBONIC.ACID -4 -4 -4
#'   \item RIBITOL -4 -4 -4
#'   \item QUINIC.ACID -4 -4 -4
#'   \item PYRUVIC.ACID -4 -4 -4
#'   \item PYROPHOSPHATE -4 -4 -4
#'   \item PSEUDO.URIDINE -4 -4 -4
#'   \item PROLINE -4 -4 -4
#'   \item PIPECOLINIC.ACID -4 -4 -4
#'   \item PHOSPHATE -4 -4 -4
#'   \item PHENYLETHYLAMINE -4 -4 -4
#'   \item PHENYLALANINE -4 -4 -4
#'   \item PELARGONIC.ACID -4 -4 -4
#'   \item PARABANIC.ACID.NIST -4 -4 -4
#'   \item PALMITOLEIC.ACID -4 -4 -4
#'   \item PALMITIC.ACID -4 -4 -4
#'   \item OXOPROLINE -4 -4 -4
#'   \item ORNITHINE -4 -4 -4
#'   \item OLEIC.ACID -4 -4 -4
#'   \item OCTADECANOL -4 -4 -4
#'   \item NAPROXEN -4 -4 -4
#'   \item N.METHYLALANINE -4 -4 -4
#'   \item N.ACETYLMANNOSAMINE -4 -4 -4
#'   \item N.ACETYLGLUTAMATE -4 -4 -4
#'   \item MYRISTIC.ACID -4 -4 -4
#'   \item MYO.INOSITOL -4 -4 -4
#'   \item METHIONINE.SULFOXIDE -4 -4 -4
#'   \item METHANOLPHOSPHATE -4 -4 -4
#'   \item MANNOSE -4 -4 -4
#'   \item MALTOSE -4 -4 -4
#'   \item MALIC.ACID -4 -4 -4
#'   \item MALEIMIDE -4 -4 -4
#'   \item LYXITOL -4 -4 -4
#'   \item LYSINE -4 -4 -4
#'   \item LINOLEIC.ACID -4 -4 -4
#'   \item LEVOGLUCOSAN -4 -4 -4
#'   \item LEUCINE -4 -4 -4
#'   \item LAURIC.ACID -4 -4 -4
#'   \item LACTIC.ACID -4 -4 -4
#'   \item ISOTHREONIC.ACID -4 -4 -4
#'   \item ISOLEUCINE -4 -4 -4
#'   \item ISOHEXONIC.ACID -4 -4 -4
#'   \item ISODEOXYTETRONIC.ACID.NIST -4 -4 -4
#'   \item ISOCITRIC.ACID -4 -4 -4
#'   \item INOSINE -4 -4 -4
#'   \item INDOLE.3.LACTATE -4 -4 -4
#'   \item INDOLE.3.ACETATE -4 -4 -4
#'   \item IBUPROFEN -4 -4 -4
#'   \item HYPOXANTHINE -4 -4 -4
#'   \item HYDROXYPROLINE.DIPEPTIDE.NIST -4 -4 -4
#'   \item HYDROXYLAMINE -4 -4 -4
#'   \item HISTIDINE -4 -4 -4
#'   \item HEXURONIC.ACID2 -4 -4 -4
#'   \item HEXITOL -4 -4 -4
#'   \item HEPTADECANOIC.ACID -4 -4 -4
#'   \item GLYCOLIC.ACID -4 -4 -4
#'   \item GLYCINE -4 -4 -4
#'   \item GLYCEROL.ALPHA.PHOSPHATE -4 -4 -4
#'   \item GLYCEROL.3.GALACTOSIDE -4 -4 -4
#'   \item GLYCEROL -4 -4 -4
#'   \item GLYCERIC.ACID -4 -4 -4
#'   \item GLUTAMINE -4 -4 -4
#'   \item GLUTAMIC.ACID -4 -4 -4
#'   \item GLUCOSE -4 -4 -4
#'   \item GLUCONIC.ACID -4 -4 -4
#'   \item GLUCOHEPTULOSE -4 -4 -4
#'   \item FUMARIC.ACID -4 -4 -4
#'   \item FUCOSE -4 -4 -4
#'   \item FRUCTOSE -4 -4 -4
#'   \item ETHANOLAMINE -4 -4 -4
#'   \item ERYTHRITOL -4 -4 -4
#'   \item EPSILON.CAPROLACTAM -4 -4 -4
#'   \item DODECANOL -4 -4 -4
#'   \item DIGLYCEROL -4 -4 -4
#'   \item DEOXYPENTITOL -4 -4 -4
#'   \item CYSTINE -4 -4 -4
#'   \item CYSTEINE -4 -4 -4
#'   \item CREATININE -4 -4 -4
#'   \item CONDURITOL.BETA.EPOXIDE -4 -4 -4
#'   \item CITRULLINE -4 -4 -4
#'   \item CITRIC.ACID -4 -4 -4
#'   \item CHOLESTEROL -4 -4 -4
#'   \item CELLOBIOSE -4 -4 -4
#'   \item CAPRYLIC.ACID -4 -4 -4
#'   \item CAPRIC.ACID -4 -4 -4
#'   \item CAFFEINE -4 -4 -4
#'   \item BETA.SITOSTEROL -4 -4 -4
#'   \item BETA.ALANINE -4 -4 -4
#'   \item BENZYLAMINE -4 -4 -4
#'   \item BENZYLALCOHOL -4 -4 -4
#'   \item BENZOIC.ACID -4 -4 -4
#'   \item BEHENIC.ACID -4 -4 -4
#'   \item ASPARTIC.ACID -4 -4 -4
#'   \item ASPARAGINE -4 -4 -4
#'   \item ARACHIDONIC.ACID -4 -4 -4
#'   \item ARACHIDIC.ACID -4 -4 -4
#'   \item ARABITOL -4 -4 -4
#'   \item AMINOMALONATE -4 -4 -4
#'   \item ALTROSE -4 -4 -4
#'   \item ALLANTOIC.ACID -4 -4 -4
#'   \item ALANINE.ALANINE -4 -4 -4
#'   \item ALANINE -4 -4 -4
#'   \item ADIPIC.ACID -4 -4 -4
#'   \item ACONITIC.ACID -4 -4 -4
#'   \item ACETAMINOPHEN -4 -4 -4
#'   \item X5.METHOXYTRYPTAMINE -4 -4 -4
#'   \item X5.HYDROXYNORVALINE.NIST -4 -4 -4
#'   \item X3.HYDROXYBUTYRIC.ACID -4 -4 -4
#'   \item X3.AMINOISOBUTYRIC.ACID -4 -4 -4
#'   \item X2.3.DIHYDROXYBUTANOIC.ACID.NIST -4 -4 -4
#'   \item X2.HYDROXYVALERIC.ACID -4 -4 -4
#'   \item X2.HYDROXYHIPPURIC.ACID -4 -4 -4
#'   \item X2.HYDROXYGLUTARIC.ACID -4 -4 -4
#'   \item X2.HYDROXYBUTANOIC.ACID -4 -4 -4
#'   \item X2.DEOXYTETRONIC.ACID -4 -4 -4
#'   \item X1.5.ANHYDROGLUCITOL -4 -4 -4
#'   \item X1.MONOSTEARIN -4 -4 -4
#'   \item X1.MONOPALMITIN -4 -4 -4
#'   \item X1.MONOOLEIN -4 -4 -4
#'   \item X102978 -4 -4 -4
#'   \item X16591 -4 -4 -4
#'   \item X130462 -4 -4 -4
#'   \item X130461 -4 -4 -4
#'   \item X4879 -4 -4 -4
#'   \item X130479 -4 -4 -4
#'   \item X130465 -4 -4 -4
#'   \item X130466 -4 -4 -4
#'   \item X130478 -4 -4 -4
#'   \item X153 -4 -4 -4
#'   \item X1862 -4 -4 -4
#'   \item X68 -4 -4 -4
#'   \item X490 -4 -4 -4
#'   \item X130463 -4 -4 -4
#'   \item X125662 -4 -4 -4
#'   \item X130470 -4 -4 -4
#'   \item X134 -4 -4 -4
#'   \item X130483 -4 -4 -4
#'   \item X105164 -4 -4 -4
#'   \item X130468 -4 -4 -4
#'   \item X85651 -4 -4 -4
#'   \item X108052 -4 -4 -4
#'   \item X12768 -4 -4 -4
#'   \item X1675 -4 -4 -4
#'   \item X6491 -4 -4 -4
#'   \item X130464 -4 -4 -4
#'   \item X1700 -4 -4 -4
#'   \item X31559 -4 -4 -4
#'   \item X16757 -4 -4 -4
#'   \item X130713 -4 -4 -4
#'   \item X124293 -4 -4 -4
#'   \item X18157 -4 -4 -4
#'   \item X4550 -4 -4 -4
#'   \item X3902 -4 -4 -4
#'   \item X131089 -4 -4 -4
#'   \item X39 -4 -4 -4
#'   \item X106936 -4 -4 -4
#'   \item X124880 -4 -4 -4
#'   \item X4871 -4 -4 -4
#'   \item X87756 -4 -4 -4
#'   \item X103476 -4 -4 -4
#'   \item X4533 -4 -4 -4
#'   \item X130716 -4 -4 -4
#'   \item X3286 -4 -4 -4
#'   \item X25321 -4 -4 -4
#'   \item X9320 -4 -4 -4
#'   \item X88583 -4 -4 -4
#'   \item X257 -4 -4 -4
#'   \item X6767 -4 -4 -4
#'   \item X458 -4 -4 -4
#'   \item X1909 -4 -4 -4
#'   \item X98 -4 -4 -4
#'   \item X21502 -4 -4 -4
#'   \item X43763 -4 -4 -4
#'   \item X137 -4 -4 -4
#'   \item X22735 -4 -4 -4
#'   \item X130396 -4 -4 -4
#'   \item X473 -4 -4 -4
#'   \item X462 -4 -4 -4
#'   \item X1873 -4 -4 -4
#'   \item X31756 -4 -4 -4
#'   \item X1941 -4 -4 -4
#'   \item X494 -4 -4 -4
#'   \item X105122 -4 -4 -4
#'   \item X3258 -4 -4 -4
#'   \item X168 -4 -4 -4
#'   \item X54 -4 -4 -4
#'   \item X11831 -4 -4 -4
#'   \item X12330 -4 -4 -4
#'   \item X915 -4 -4 -4
#'   \item X1709 -4 -4 -4
#'   \item X131325 -4 -4 -4
#'   \item X573 -4 -4 -4
#'   \item X812 -4 -4 -4
#'   \item X87877 -4 -4 -4
#'   \item X307 -4 -4 -4
#'   \item X109401 -4 -4 -4
#'   \item X89383 -4 -4 -4
#'   \item X110501 -4 -4 -4
#'   \item X3143 -4 -4 -4
#'   \item X9489 -4 -4 -4
#'   \item X61 -4 -4 -4
#'   \item X4887 -4 -4 -4
#'   \item X4605 -4 -4 -4
#'   \item X112556 -4 -4 -4
#'   \item X4929 -4 -4 -4
#'   \item X4898 -4 -4 -4
#'   \item X4937 -4 -4 -4
#'   \item X5396 -4 -4 -4
#'   \item X4577 -4 -4 -4
#'   \item X119167 -4 -4 -4
#'   \item X4536 -4 -4 -4
#'   \item X4863 -4 -4 -4
#'   \item X43729 -4 -4 -4
#'   \item X1704 -4 -4 -4
#'   \item X11523 -4 -4 -4
#'   \item X97743 -4 -4 -4
#'   \item X120562 -4 -4 -4
#'   \item X228 -4 -4 -4
#'   \item X1981 -4 -4 -4
#'   \item X101742 -4 -4 -4
#'   \item X97708 -4 -4 -4
#'   \item X8270 -4 -4 -4
#'   \item X592 -4 -4 -4
#'   \item X119023 -4 -4 -4
#'   \item X45378 -4 -4 -4
#'   \item X7403 -4 -4 -4
#'   \item X5290 -4 -4 -4
#'   \item X121467 -4 -4 -4
#'   \item X4579 -4 -4 -4
#'   \item X1872 -4 -4 -4
#'   \item X33282 -4 -4 -4
#'   \item X119026 -4 -4 -4
#'   \item X5930 -4 -4 -4
#'   \item X4264 -4 -4 -4
#'   \item X4548 -4 -4 -4
#'   \item X4945 -4 -4 -4
#'   \item X120526 -4 -4 -4
#'   \item X4600 -4 -4 -4
#'   \item X110008 -4 -4 -4
#'   \item X106629 -4 -4 -4
#'   \item X1912 -4 -4 -4
#'   \item X17664 -4 -4 -4
#'   \item X2430 -4 -4 -4
#'   \item X2011 -4 -4 -4
#'   \item X236 -4 -4 -4
#'   \item X46292 -4 -4 -4
#'   \item X6381 -4 -4 -4
#'   \item X110 -4 -4 -4
#'   \item X18488 -4 -4 -4
#'   \item X41833 -4 -4 -4
#'   \item X5259 -4 -4 -4
#'   \item X6324 -4 -4 -4
#'   \item X1875 -4 -4 -4
#'   \item X5471 -4 -4 -4
#'   \item X97891 -4 -4 -4
#'   \item X99 -4 -4 -4
#'   \item X107960 -4 -4 -4
#'   \item X109923 -4 -4 -4
#'   \item X62 -4 -4 -4
#'   \item X104901 -4 -4 -4
#'   \item X31359 -4 -4 -4
#'   \item X2039 -4 -4 -4
#'   \item X4546 -4 -4 -4
#'   \item X41808 -4 -4 -4
#'   \item X31664 -4 -4 -4
#'   \item X5990 -4 -4 -4
#'   \item X50367 -4 -4 -4
#'   \item X126423 -4 -4 -4
#'   \item X110013 -4 -4 -4
#'   \item X125664 -4 -4 -4
#'   \item X10176 -4 -4 -4
#'   \item X41811 -4 -4 -4
#'   \item X1064 -4 -4 -4
#'   \item X4263 -4 -4 -4
#'   \item X49400 -4 -4 -4
#'   \item X124996 -4 -4 -4
#'   \item X448 -4 -4 -4
#'   \item X5276 -4 -4 -4
#'   \item X16788 -4 -4 -4
#'   \item X4986 -4 -4 -4
#'   \item X5269 -4 -4 -4
#'   \item X22863 -4 -4 -4
#'   \item X100666 -4 -4 -4
#'   \item X20903 -4 -4 -4
#'   \item X121002 -4 -4 -4
#'   \item X119129 -4 -4 -4
#'   \item X1029 -4 -4 -4
#'   \item X2936 -4 -4 -4
#'   \item X117141 -4 -4 -4
#'   \item X124963 -4 -4 -4
#'   \item X47358 -4 -4 -4
#'   \item X91 -4 -4 -4
#'   \item X103102 -4 -4 -4
#'   \item X46138 -4 -4 -4
#'   \item X44509 -4 -4 -4
#'   \item X17651 -4 -4 -4
#'   \item X443 -4 -4 -4
#'   \item X5346 -4 -4 -4
#'   \item X1996 -4 -4 -4
#'   \item X62263 -4 -4 -4
#'   \item X87822 -4 -4 -4
#'   \item X129225 -4 -4 -4
#'   \item X657 -4 -4 -4
#'   \item X122191 -4 -4 -4
#'   \item X4746 -4 -4 -4
#'   \item X47221 -4 -4 -4
#'   \item X610256 -4 -4 -4
#'   \item X4609 -4 -4 -4
#'   \item X3228 -4 -4 -4
#'   \item X1878 -4 -4 -4
#'   \item X2900 -4 -4 -4
#'   \item X46131 -4 -4 -4
#'   \item X4292 -4 -4 -4
#'   \item X110612 -4 -4 -4
#'   \item X109386 -4 -4 -4
#'   \item X21885 -4 -4 -4
#'   \item X6646 -4 -4 -4
#'   \item X17068 -4 -4 -4
#'   \item X2476 -4 -4 -4
#'   \item X47 -4 -4 -4
#'   \item X46362 -4 -4 -4
#'   \item X4793 -4 -4 -4
#'   \item X112264 -4 -4 -4
#'   \item X121890 -4 -4 -4
#'   \item X3781 -4 -4 -4
#'   \item X110321 -4 -4 -4
#'   \item X119066 -4 -4 -4
#'   \item X5085 -4 -4 -4
#'   \item X103390 -4 -4 -4
#'   \item X21666 -4 -4 -4
#'   \item X1922 -4 -4 -4
#'   \item X130475 -4 -4 -4
#'   \item X31285 -4 -4 -4
#'   \item X120744 -4 -4 -4
#'   \item X4529 -4 -4 -4
#'   \item X479 -4 -4 -4
#'   \item X124283 -4 -4 -4
#'   \item X98027 -4 -4 -4
#'   \item X118071 -4 -4 -4
#'   \item X892 -4 -4 -4
#'   \item X31357 -4 -4 -4
#'   \item X108309 -4 -4 -4
#'   \item X34135 -4 -4 -4
#'   \item X4901 -4 -4 -4
#'   \item X6300 -4 -4 -4
#'   \item X23635 -4 -4 -4
#'   \item X47170 -4 -4 -4
#'   \item X5121 -4 -4 -4
#'   \item X33993 -4 -4 -4
#'   \item X95410 -4 -4 -4
#'   \item X18176 -4 -4 -4
#'   \item X42357 -4 -4 -4
#'   \item X7444 -4 -4 -4
#'   \item X102223 -4 -4 -4
#'   \item X2061 -4 -4 -4
#'   \item X18403 -4 -4 -4
#'   \item X120781 -4 -4 -4
#'   \item X2674 -4 -4 -4
#'   \item X453 -4 -4 -4
#'   \item X106427 -4 -4 -4
#' }
#'
#' @examples
#' \donotrun{
#' describe(admcgctof)
#' }
#' @docType data
#' @keywords datasets
#' @name admcgctof
#' @usage data(admcgctof)
#' @format A data frame with 916 rows and 402 variables
NULL

#' Targeted UHPLC-MS analysis of High-Value Metabolites in Serum Samples
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/ADMCHIVALMETAB/ADMC_high_value_high_abundance%20metabolites.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item RECNO -4 -4 Record number (2 indicates replicate sample)
#'   \item Samples.Metabolites -4 -4 -4
#'   \item Comments -4 -4 -4
#'   \item ADMA -4 -4 -4
#'   \item Betaine -4 -4 -4
#'   \item Choline -4 -4 -4
#'   \item Creatinine -4 -4 -4
#'   \item Glutamic.acid -4 -4 -4
#'   \item Leucine -4 -4 -4
#'   \item Methionine -4 -4 -4
#'   \item Phenylalanine -4 -4 -4
#'   \item Serine -4 -4 -4
#'   \item Taurine -4 -4 -4
#'   \item TMAO -4 -4 -4
#'   \item Tryptophan -4 -4 -4
#'   \item Tyrosine -4 -4 -4
#'   \item Glutamine -4 -4 -4
#'   \item beta.hydroxybutyrate -4 -4 -4
#'   \item Glucose -4 -4 -4
#'   \item Lactate -4 -4 -4
#' }
#'
#' @examples
#' \donotrun{
#' describe(admchivalmetab)
#' }
#' @docType data
#' @keywords datasets
#' @name admchivalmetab
#' @usage data(admchivalmetab)
#' @format A data frame with 829 rows and 22 variables
NULL

#' ADMC Lipidomics Measured Lipid Molecules
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/ADMCLIPIDOMICS/ADMC%20Lipidomics%20methods.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item RECNO -4 -4 Record number (2 indicates replicate sample)
#'   \item VARID -4 -4 -4
#'   \item UCD.Lipid.1 -4 -4 AC (8:0)
#'   \item UCD.Lipid.2 -4 -4 AC (8:1)
#'   \item UCD.Lipid.3 -4 -4 AC (10:1)
#'   \item UCD.Lipid.4 -4 -4 AC (12:0)
#'   \item UCD.Lipid.5 -4 -4 AC (16:0)
#'   \item UCD.Lipid.6 -4 -4 AC (18:0)
#'   \item UCD.Lipid.7 -4 -4 AC (18:1)
#'   \item UCD.Lipid.8 -4 -4 AC (18:2)
#'   \item UCD.Lipid.9 -4 -4 AC (18:3)
#'   \item UCD.Lipid.10 -4 -4 CE (16:1)
#'   \item UCD.Lipid.11 -4 -4 CE (18:1)
#'   \item UCD.Lipid.12 -4 -4 CE (18:2)
#'   \item UCD.Lipid.13 -4 -4 CE (18:3)
#'   \item UCD.Lipid.14 -4 -4 CE (20:3)
#'   \item UCD.Lipid.15 -4 -4 CE (20:4)
#'   \item UCD.Lipid.16 -4 -4 CE (20:5)
#'   \item UCD.Lipid.17 -4 -4 CE (22:6)
#'   \item UCD.Lipid.18 -4 -4 Cer (41:1)
#'   \item UCD.Lipid.19 -4 -4 Cer (42:2)
#'   \item UCD.Lipid.20 -4 -4 Cholesterol
#'   \item UCD.Lipid.21 -4 -4 CSH_posESI #002
#'   \item UCD.Lipid.22 -4 -4 CSH_posESI #003
#'   \item UCD.Lipid.23 -4 -4 CSH_posESI #004
#'   \item UCD.Lipid.24 -4 -4 CSH_posESI #006
#'   \item UCD.Lipid.25 -4 -4 CSH_posESI #015
#'   \item UCD.Lipid.26 -4 -4 CSH_posESI #017
#'   \item UCD.Lipid.27 -4 -4 CSH_posESI #022
#'   \item UCD.Lipid.28 -4 -4 CSH_posESI #025
#'   \item UCD.Lipid.29 -4 -4 CSH_posESI #027
#'   \item UCD.Lipid.30 -4 -4 CSH_posESI #033
#'   \item UCD.Lipid.31 -4 -4 CSH_posESI #034
#'   \item UCD.Lipid.32 -4 -4 CSH_posESI #036
#'   \item UCD.Lipid.33 -4 -4 CSH_posESI #037
#'   \item UCD.Lipid.34 -4 -4 CSH_posESI #040
#'   \item UCD.Lipid.35 -4 -4 CSH_posESI #041
#'   \item UCD.Lipid.36 -4 -4 CSH_posESI #042
#'   \item UCD.Lipid.37 -4 -4 CSH_posESI #043
#'   \item UCD.Lipid.38 -4 -4 CSH_posESI #056
#'   \item UCD.Lipid.39 -4 -4 CSH_posESI #057
#'   \item UCD.Lipid.40 -4 -4 CSH_posESI #058
#'   \item UCD.Lipid.41 -4 -4 CSH_posESI #061
#'   \item UCD.Lipid.42 -4 -4 CSH_posESI #079
#'   \item UCD.Lipid.43 -4 -4 CSH_posESI #081
#'   \item UCD.Lipid.44 -4 -4 CSH_posESI #091
#'   \item UCD.Lipid.45 -4 -4 CSH_posESI #098
#'   \item UCD.Lipid.46 -4 -4 CSH_posESI #103
#'   \item UCD.Lipid.47 -4 -4 CSH_posESI #104
#'   \item UCD.Lipid.48 -4 -4 CSH_posESI #106
#'   \item UCD.Lipid.49 -4 -4 CSH_posESI #109
#'   \item UCD.Lipid.50 -4 -4 CSH_posESI #116
#'   \item UCD.Lipid.51 -4 -4 CSH_posESI #117
#'   \item UCD.Lipid.52 -4 -4 CSH_posESI #121
#'   \item UCD.Lipid.53 -4 -4 CSH_posESI #122
#'   \item UCD.Lipid.54 -4 -4 CSH_posESI #124
#'   \item UCD.Lipid.55 -4 -4 CSH_posESI #125
#'   \item UCD.Lipid.56 -4 -4 CSH_posESI #127
#'   \item UCD.Lipid.57 -4 -4 CSH_posESI #130
#'   \item UCD.Lipid.58 -4 -4 CSH_posESI #134
#'   \item UCD.Lipid.59 -4 -4 CSH_posESI #137
#'   \item UCD.Lipid.60 -4 -4 CSH_posESI #141
#'   \item UCD.Lipid.61 -4 -4 CSH_posESI #142
#'   \item UCD.Lipid.62 -4 -4 CSH_posESI #155
#'   \item UCD.Lipid.63 -4 -4 CSH_posESI #156
#'   \item UCD.Lipid.64 -4 -4 CSH_posESI #159
#'   \item UCD.Lipid.65 -4 -4 CSH_posESI #164
#'   \item UCD.Lipid.66 -4 -4 CSH_posESI #165
#'   \item UCD.Lipid.67 -4 -4 CSH_posESI #168
#'   \item UCD.Lipid.68 -4 -4 CSH_posESI #170
#'   \item UCD.Lipid.69 -4 -4 CSH_posESI #176
#'   \item UCD.Lipid.70 -4 -4 CSH_posESI #187
#'   \item UCD.Lipid.71 -4 -4 CSH_posESI #192
#'   \item UCD.Lipid.72 -4 -4 CSH_posESI #196
#'   \item UCD.Lipid.73 -4 -4 CSH_posESI #197
#'   \item UCD.Lipid.74 -4 -4 CSH_posESI #201
#'   \item UCD.Lipid.75 -4 -4 CSH_posESI #203
#'   \item UCD.Lipid.76 -4 -4 CSH_posESI #205
#'   \item UCD.Lipid.77 -4 -4 CSH_posESI #211
#'   \item UCD.Lipid.78 -4 -4 CSH_posESI #214
#'   \item UCD.Lipid.79 -4 -4 CSH_posESI #215
#'   \item UCD.Lipid.80 -4 -4 CSH_posESI #230
#'   \item UCD.Lipid.81 -4 -4 CSH_posESI #231
#'   \item UCD.Lipid.82 -4 -4 CSH_posESI #232
#'   \item UCD.Lipid.83 -4 -4 CSH_posESI #270
#'   \item UCD.Lipid.84 -4 -4 CSH_posESI #275
#'   \item UCD.Lipid.85 -4 -4 CSH_posESI #282
#'   \item UCD.Lipid.86 -4 -4 CSH_posESI #285
#'   \item UCD.Lipid.87 -4 -4 CSH_posESI #286
#'   \item UCD.Lipid.88 -4 -4 CSH_posESI #288
#'   \item UCD.Lipid.89 -4 -4 CSH_posESI #290
#'   \item UCD.Lipid.90 -4 -4 CSH_posESI #293
#'   \item UCD.Lipid.91 -4 -4 CSH_posESI #296
#'   \item UCD.Lipid.92 -4 -4 CSH_posESI #298
#'   \item UCD.Lipid.93 -4 -4 CSH_posESI #301
#'   \item UCD.Lipid.94 -4 -4 CSH_posESI #303
#'   \item UCD.Lipid.95 -4 -4 CSH_posESI #304
#'   \item UCD.Lipid.96 -4 -4 CSH_posESI #307
#'   \item UCD.Lipid.97 -4 -4 CSH_posESI #308
#'   \item UCD.Lipid.98 -4 -4 CSH_posESI #310
#'   \item UCD.Lipid.99 -4 -4 CSH_posESI #336
#'   \item UCD.Lipid.100 -4 -4 CSH_posESI #359
#'   \item UCD.Lipid.101 -4 -4 CSH_posESI #362
#'   \item UCD.Lipid.102 -4 -4 CSH_posESI #363
#'   \item UCD.Lipid.103 -4 -4 CSH_posESI #364
#'   \item UCD.Lipid.104 -4 -4 DG (32:1)
#'   \item UCD.Lipid.105 -4 -4 DG (34:1)
#'   \item UCD.Lipid.106 -4 -4 DG (34:2)
#'   \item UCD.Lipid.107 -4 -4 DG (34:3)
#'   \item UCD.Lipid.108 -4 -4 DG (36:1)
#'   \item UCD.Lipid.109 -4 -4 DG (36:2)
#'   \item UCD.Lipid.110 -4 -4 DG (36:3)
#'   \item UCD.Lipid.111 -4 -4 DG (36:4)
#'   \item UCD.Lipid.112 -4 -4 DG (36:5)
#'   \item UCD.Lipid.113 -4 -4 DG (38:0)
#'   \item UCD.Lipid.114 -4 -4 DG (38:3)
#'   \item UCD.Lipid.115 -4 -4 DG (38:5)
#'   \item UCD.Lipid.116 -4 -4 DG (38:6)
#'   \item UCD.Lipid.117 -4 -4 Hex2Cer (34:1)
#'   \item UCD.Lipid.118 -4 -4 LacCer (42:2)
#'   \item UCD.Lipid.119 -4 -4 LPC (14:0)
#'   \item UCD.Lipid.120 -4 -4 LPC (15:0)
#'   \item UCD.Lipid.121 -4 -4 LPC (17:1)
#'   \item UCD.Lipid.122 -4 -4 LPC (18:0)
#'   \item UCD.Lipid.123 -4 -4 LPC (18:3)
#'   \item UCD.Lipid.124 -4 -4 LPC (20:0)
#'   \item UCD.Lipid.125 -4 -4 LPC (20:4)
#'   \item UCD.Lipid.126 -4 -4 LPC (20:5)
#'   \item UCD.Lipid.127 -4 -4 LPC (22:4)
#'   \item UCD.Lipid.128 -4 -4 LPC (22:6)
#'   \item UCD.Lipid.129 -4 -4 LPC (o-16:0)
#'   \item UCD.Lipid.130 -4 -4 LPC (p-16:0) or LPC (o-16:1)
#'   \item UCD.Lipid.131 -4 -4 LPC (p-18:0) or LPC (o-18:1)
#'   \item UCD.Lipid.132 -4 -4 PC (25:0(CHO))
#'   \item UCD.Lipid.133 -4 -4 PC (28:0)
#'   \item UCD.Lipid.134 -4 -4 PC (30:0)
#'   \item UCD.Lipid.135 -4 -4 PC (30:1)
#'   \item UCD.Lipid.136 -4 -4 PC (31:0)
#'   \item UCD.Lipid.137 -4 -4 PC (31:1)
#'   \item UCD.Lipid.138 -4 -4 PC (32:3)
#'   \item UCD.Lipid.139 -4 -4 PC (33:0)
#'   \item UCD.Lipid.140 -4 -4 PC (35:3)
#'   \item UCD.Lipid.141 -4 -4 PC (36:3)
#'   \item UCD.Lipid.142 -4 -4 PC (36:4)
#'   \item UCD.Lipid.143 -4 -4 PC (36:6)
#'   \item UCD.Lipid.144 -4 -4 PC (37:3)
#'   \item UCD.Lipid.145 -4 -4 PC (37:6)
#'   \item UCD.Lipid.146 -4 -4 PC (38:4)
#'   \item UCD.Lipid.147 -4 -4 PC (38:5)
#'   \item UCD.Lipid.148 -4 -4 PC (38:6)
#'   \item UCD.Lipid.149 -4 -4 PC (38:7)
#'   \item UCD.Lipid.150 -4 -4 PC (39:6)
#'   \item UCD.Lipid.151 -4 -4 PC (40:5)
#'   \item UCD.Lipid.152 -4 -4 PC (40:6)
#'   \item UCD.Lipid.153 -4 -4 PC (42:5)
#'   \item UCD.Lipid.154 -4 -4 PC (42:6)
#'   \item UCD.Lipid.155 -4 -4 PC (o-34:0)
#'   \item UCD.Lipid.156 -4 -4 PC (p-32:1) or PC (o-32:2)
#'   \item UCD.Lipid.157 -4 -4 PC (p-34:1) or PC (o-34:2)
#'   \item UCD.Lipid.158 -4 -4 PC (p-38:2) or PC (o-38:3)
#'   \item UCD.Lipid.159 -4 -4 PC (p-38:4) or PC (o-38:5)
#'   \item UCD.Lipid.160 -4 -4 PC (p-40:1) or PC (o-40:2)
#'   \item UCD.Lipid.161 -4 -4 PC (p-40:5) or PC (o-40:6)
#'   \item UCD.Lipid.162 -4 -4 PC (p-40:6) or PC (o-40:7) A
#'   \item UCD.Lipid.163 -4 -4 PC (p-40:6) or PC (o-40:7) B
#'   \item UCD.Lipid.164 -4 -4 PC (p-40:7) or PC (o-40:8)
#'   \item UCD.Lipid.165 -4 -4 PC (p-42:3) or PC (o-42:4)
#'   \item UCD.Lipid.166 -4 -4 PE (36:4)
#'   \item UCD.Lipid.167 -4 -4 PE (38:4)
#'   \item UCD.Lipid.168 -4 -4 PE (p-34:1) or PE (o-34:2)
#'   \item UCD.Lipid.169 -4 -4 SM (30:1)
#'   \item UCD.Lipid.170 -4 -4 SM (34:0)
#'   \item UCD.Lipid.171 -4 -4 SM (40:2)
#'   \item UCD.Lipid.172 -4 -4 SM (42:2)
#'   \item UCD.Lipid.173 -4 -4 TG (42:0)
#'   \item UCD.Lipid.174 -4 -4 TG (40:0)
#'   \item UCD.Lipid.175 -4 -4 TG (40:1)
#'   \item UCD.Lipid.176 -4 -4 TG (42:1)
#'   \item UCD.Lipid.177 -4 -4 TG (42:2)
#'   \item UCD.Lipid.178 -4 -4 TG (42:3)
#'   \item UCD.Lipid.179 -4 -4 TG (44:0)
#'   \item UCD.Lipid.180 -4 -4 TG (44:1)
#'   \item UCD.Lipid.181 -4 -4 TG (44:2)
#'   \item UCD.Lipid.182 -4 -4 TG (46:0)
#'   \item UCD.Lipid.183 -4 -4 TG (46:1)
#'   \item UCD.Lipid.184 -4 -4 TG (46:2)
#'   \item UCD.Lipid.185 -4 -4 TG (46:3)
#'   \item UCD.Lipid.186 -4 -4 TG (46:4)
#'   \item UCD.Lipid.187 -4 -4 TG (48:0)
#'   \item UCD.Lipid.188 -4 -4 TG (48:1)
#'   \item UCD.Lipid.189 -4 -4 TG (48:2)
#'   \item UCD.Lipid.190 -4 -4 TG (48:3)
#'   \item UCD.Lipid.191 -4 -4 TG (48:4)
#'   \item UCD.Lipid.192 -4 -4 TG (49:0)
#'   \item UCD.Lipid.193 -4 -4 TG (49:1)
#'   \item UCD.Lipid.194 -4 -4 TG (49:2)
#'   \item UCD.Lipid.195 -4 -4 TG (49:3)
#'   \item UCD.Lipid.196 -4 -4 TG (50:0)
#'   \item UCD.Lipid.197 -4 -4 TG (50:1)
#'   \item UCD.Lipid.198 -4 -4 TG (50:2)
#'   \item UCD.Lipid.199 -4 -4 TG (50:3)
#'   \item UCD.Lipid.200 -4 -4 TG (50:4)
#'   \item UCD.Lipid.201 -4 -4 TG (50:5)
#'   \item UCD.Lipid.202 -4 -4 TG (50:6)
#'   \item UCD.Lipid.203 -4 -4 TG (51:1)
#'   \item UCD.Lipid.204 -4 -4 TG (51:2)
#'   \item UCD.Lipid.205 -4 -4 TG (51:3)
#'   \item UCD.Lipid.206 -4 -4 TG (51:4)
#'   \item UCD.Lipid.207 -4 -4 TG (51:5)
#'   \item UCD.Lipid.208 -4 -4 TG (52:0)
#'   \item UCD.Lipid.209 -4 -4 TG (52:1)
#'   \item UCD.Lipid.210 -4 -4 TG (52:2)
#'   \item UCD.Lipid.211 -4 -4 TG (52:3)
#'   \item UCD.Lipid.212 -4 -4 TG (52:4)
#'   \item UCD.Lipid.213 -4 -4 TG (52:5)
#'   \item UCD.Lipid.214 -4 -4 TG (52:6)
#'   \item UCD.Lipid.215 -4 -4 TG (53:1)
#'   \item UCD.Lipid.216 -4 -4 TG (53:2)
#'   \item UCD.Lipid.217 -4 -4 TG (53:3)
#'   \item UCD.Lipid.218 -4 -4 TG (53:4)
#'   \item UCD.Lipid.219 -4 -4 TG (53:5)
#'   \item UCD.Lipid.220 -4 -4 TG (54:0)
#'   \item UCD.Lipid.221 -4 -4 TG (54:1)
#'   \item UCD.Lipid.222 -4 -4 TG (54:2)
#'   \item UCD.Lipid.223 -4 -4 TG (54:3)
#'   \item UCD.Lipid.224 -4 -4 TG (54:4)
#'   \item UCD.Lipid.225 -4 -4 TG (54:5)
#'   \item UCD.Lipid.226 -4 -4 TG (54:6)
#'   \item UCD.Lipid.227 -4 -4 TG (54:8)
#'   \item UCD.Lipid.228 -4 -4 TG (56:1)
#'   \item UCD.Lipid.229 -4 -4 TG (56:2)
#'   \item UCD.Lipid.230 -4 -4 TG (56:3)
#'   \item UCD.Lipid.231 -4 -4 TG (56:4)
#'   \item UCD.Lipid.232 -4 -4 TG (56:5)
#'   \item UCD.Lipid.233 -4 -4 TG (56:6)
#'   \item UCD.Lipid.234 -4 -4 TG (56:7)
#'   \item UCD.Lipid.235 -4 -4 TG (56:8)
#'   \item UCD.Lipid.236 -4 -4 TG (56:9)
#'   \item UCD.Lipid.237 -4 -4 TG (57:1)
#'   \item UCD.Lipid.238 -4 -4 TG (57:2)
#'   \item UCD.Lipid.239 -4 -4 TG (58:1)
#'   \item UCD.Lipid.240 -4 -4 TG (58:10)
#'   \item UCD.Lipid.241 -4 -4 TG (58:2)
#'   \item UCD.Lipid.242 -4 -4 TG (58:3)
#'   \item UCD.Lipid.243 -4 -4 TG (58:4)
#'   \item UCD.Lipid.244 -4 -4 TG (58:6)
#'   \item UCD.Lipid.245 -4 -4 TG (58:8)
#'   \item UCD.Lipid.246 -4 -4 TG (58:9)
#'   \item UCD.Lipid.247 -4 -4 TG (59:2)
#'   \item UCD.Lipid.248 -4 -4 TG (59:3)
#'   \item UCD.Lipid.249 -4 -4 TG (60:11)
#'   \item UCD.Lipid.250 -4 -4 TG (60:2)
#'   \item UCD.Lipid.251 -4 -4 TG (60:3)
#'   \item UCD.Lipid.252 -4 -4 TG (60:4)
#'   \item UCD.Lipid.253 -4 -4 TG (60:6)
#'   \item UCD.Lipid.254 -4 -4 TG (62:3)
#'   \item UCD.Lipid.255 -4 -4 TG (62:4)
#'   \item UCD.Lipid.256 -4 -4 TG (64:4)
#'   \item UCD.Lipid.257 -4 -4 Cer (32:1)
#'   \item UCD.Lipid.258 -4 -4 Cer (33:1)
#'   \item UCD.Lipid.259 -4 -4 Cer (34:0)
#'   \item UCD.Lipid.260 -4 -4 Cer (34:1)
#'   \item UCD.Lipid.261 -4 -4 Cer (34:2)
#'   \item UCD.Lipid.262 -4 -4 Cer (36:1)
#'   \item UCD.Lipid.263 -4 -4 Cer (38:1)
#'   \item UCD.Lipid.264 -4 -4 Cer (39:1)
#'   \item UCD.Lipid.265 -4 -4 Cer (40:0)
#'   \item UCD.Lipid.266 -4 -4 Cer (40:1)
#'   \item UCD.Lipid.267 -4 -4 Cer (40:2)
#'   \item UCD.Lipid.268 -4 -4 Cer (41:1)
#'   \item UCD.Lipid.269 -4 -4 Cer (42:0)
#'   \item UCD.Lipid.270 -4 -4 Cer (42:1)
#'   \item UCD.Lipid.271 -4 -4 Cer (42:2)
#'   \item UCD.Lipid.272 -4 -4 Cer (43:1)
#'   \item UCD.Lipid.273 -4 -4 Cer (44:1)
#'   \item UCD.Lipid.274 -4 -4 CSH_negESI #014
#'   \item UCD.Lipid.275 -4 -4 CSH_negESI #056
#'   \item UCD.Lipid.276 -4 -4 CSH_negESI #109
#'   \item UCD.Lipid.277 -4 -4 CSH_negESI #113
#'   \item UCD.Lipid.278 -4 -4 CSH_negESI #130
#'   \item UCD.Lipid.279 -4 -4 CSH_negESI #131
#'   \item UCD.Lipid.280 -4 -4 CSH_negESI #223
#'   \item UCD.Lipid.281 -4 -4 CSH_negESI #293
#'   \item UCD.Lipid.282 -4 -4 CSH_negESI #377
#'   \item UCD.Lipid.283 -4 -4 CSH_negESI #378
#'   \item UCD.Lipid.284 -4 -4 CSH_negESI #387
#'   \item UCD.Lipid.285 -4 -4 CSH_negESI #405
#'   \item UCD.Lipid.286 -4 -4 CSH_negESI #413
#'   \item UCD.Lipid.287 -4 -4 CSH_negESI #414
#'   \item UCD.Lipid.288 -4 -4 CSH_negESI #420
#'   \item UCD.Lipid.289 -4 -4 CSH_negESI #501
#'   \item UCD.Lipid.290 -4 -4 CSH_negESI #502
#'   \item UCD.Lipid.291 -4 -4 CSH_negESI #504
#'   \item UCD.Lipid.292 -4 -4 CSH_negESI #510
#'   \item UCD.Lipid.293 -4 -4 CSH_negESI #511
#'   \item UCD.Lipid.294 -4 -4 CSH_negESI #520
#'   \item UCD.Lipid.295 -4 -4 CSH_negESI #524
#'   \item UCD.Lipid.296 -4 -4 CSH_negESI #527
#'   \item UCD.Lipid.297 -4 -4 CSH_negESI #528
#'   \item UCD.Lipid.298 -4 -4 CSH_negESI #530
#'   \item UCD.Lipid.299 -4 -4 CSH_negESI #550
#'   \item UCD.Lipid.300 -4 -4 CSH_negESI #564
#'   \item UCD.Lipid.301 -4 -4 CSH_negESI #565
#'   \item UCD.Lipid.302 -4 -4 CSH_negESI #569
#'   \item UCD.Lipid.303 -4 -4 CSH_negESI #573
#'   \item UCD.Lipid.304 -4 -4 CSH_negESI #579
#'   \item UCD.Lipid.305 -4 -4 CSH_negESI #580
#'   \item UCD.Lipid.306 -4 -4 CSH_negESI #581
#'   \item UCD.Lipid.307 -4 -4 CSH_negESI #586
#'   \item UCD.Lipid.308 -4 -4 CSH_negESI #587
#'   \item UCD.Lipid.309 -4 -4 CSH_negESI #589
#'   \item UCD.Lipid.310 -4 -4 CSH_negESI #590
#'   \item UCD.Lipid.311 -4 -4 CSH_negESI #591
#'   \item UCD.Lipid.312 -4 -4 CSH_negESI #592
#'   \item UCD.Lipid.313 -4 -4 CSH_negESI #593
#'   \item UCD.Lipid.314 -4 -4 CSH_negESI #598
#'   \item UCD.Lipid.315 -4 -4 CSH_negESI #599
#'   \item UCD.Lipid.316 -4 -4 CSH_negESI #600
#'   \item UCD.Lipid.317 -4 -4 CSH_negESI #612
#'   \item UCD.Lipid.318 -4 -4 CSH_negESI #615
#'   \item UCD.Lipid.319 -4 -4 CSH_negESI #617
#'   \item UCD.Lipid.320 -4 -4 CSH_negESI #624
#'   \item UCD.Lipid.321 -4 -4 CSH_negESI #627
#'   \item UCD.Lipid.322 -4 -4 CSH_negESI #628
#'   \item UCD.Lipid.323 -4 -4 CSH_negESI #631
#'   \item UCD.Lipid.324 -4 -4 CSH_negESI #633
#'   \item UCD.Lipid.325 -4 -4 CSH_negESI #638
#'   \item UCD.Lipid.326 -4 -4 CSH_negESI #639
#'   \item UCD.Lipid.327 -4 -4 CSH_negESI #644
#'   \item UCD.Lipid.328 -4 -4 CSH_negESI #648
#'   \item UCD.Lipid.329 -4 -4 CSH_negESI #650
#'   \item UCD.Lipid.330 -4 -4 CSH_negESI #653
#'   \item UCD.Lipid.331 -4 -4 CSH_negESI #658
#'   \item UCD.Lipid.332 -4 -4 CSH_negESI #668
#'   \item UCD.Lipid.333 -4 -4 CSH_negESI #670
#'   \item UCD.Lipid.334 -4 -4 CSH_negESI #678
#'   \item UCD.Lipid.335 -4 -4 CSH_negESI #682
#'   \item UCD.Lipid.336 -4 -4 CSH_negESI #683
#'   \item UCD.Lipid.337 -4 -4 CSH_negESI #690
#'   \item UCD.Lipid.338 -4 -4 CSH_negESI #691
#'   \item UCD.Lipid.339 -4 -4 CSH_negESI #693
#'   \item UCD.Lipid.340 -4 -4 CSH_negESI #695
#'   \item UCD.Lipid.341 -4 -4 CSH_negESI #698
#'   \item UCD.Lipid.342 -4 -4 CSH_negESI #701
#'   \item UCD.Lipid.343 -4 -4 CSH_negESI #706
#'   \item UCD.Lipid.344 -4 -4 CSH_negESI #709
#'   \item UCD.Lipid.345 -4 -4 CSH_negESI #710
#'   \item UCD.Lipid.346 -4 -4 CSH_negESI #713
#'   \item UCD.Lipid.347 -4 -4 CSH_negESI #716
#'   \item UCD.Lipid.348 -4 -4 CSH_negESI #722
#'   \item UCD.Lipid.349 -4 -4 CSH_negESI #723
#'   \item UCD.Lipid.350 -4 -4 CSH_negESI #724
#'   \item UCD.Lipid.351 -4 -4 CSH_negESI #728
#'   \item UCD.Lipid.352 -4 -4 CSH_negESI #733
#'   \item UCD.Lipid.353 -4 -4 CSH_negESI #735
#'   \item UCD.Lipid.354 -4 -4 CSH_negESI #743
#'   \item UCD.Lipid.355 -4 -4 CSH_negESI #744
#'   \item UCD.Lipid.356 -4 -4 CSH_negESI #749
#'   \item UCD.Lipid.357 -4 -4 CSH_negESI #750
#'   \item UCD.Lipid.358 -4 -4 CSH_negESI #762
#'   \item UCD.Lipid.359 -4 -4 CSH_negESI #764
#'   \item UCD.Lipid.360 -4 -4 CSH_negESI #767
#'   \item UCD.Lipid.361 -4 -4 CSH_negESI #770
#'   \item UCD.Lipid.362 -4 -4 CSH_negESI #773
#'   \item UCD.Lipid.363 -4 -4 HexCer (38:1)
#'   \item UCD.Lipid.364 -4 -4 HexCer (40:1)
#'   \item UCD.Lipid.365 -4 -4 HexCer (41:1)
#'   \item UCD.Lipid.366 -4 -4 HexCer (42:1)
#'   \item UCD.Lipid.367 -4 -4 HexCer (42:2)
#'   \item UCD.Lipid.368 -4 -4 HexCer (34:1(2OH))
#'   \item UCD.Lipid.369 -4 -4 LPC (16:0)
#'   \item UCD.Lipid.370 -4 -4 LPC (16:1)
#'   \item UCD.Lipid.371 -4 -4 LPC (18:0)
#'   \item UCD.Lipid.372 -4 -4 LPC (18:1)
#'   \item UCD.Lipid.373 -4 -4 LPC (18:2)
#'   \item UCD.Lipid.374 -4 -4 LPC (20:1)
#'   \item UCD.Lipid.375 -4 -4 LPC (20:2)
#'   \item UCD.Lipid.376 -4 -4 LPC (20:3)
#'   \item UCD.Lipid.377 -4 -4 LPC (22:5)
#'   \item UCD.Lipid.378 -4 -4 LPE (16:0)
#'   \item UCD.Lipid.379 -4 -4 LPE (18:2)
#'   \item UCD.Lipid.380 -4 -4 LPE (20:4)
#'   \item UCD.Lipid.381 -4 -4 LPE (22:6)
#'   \item UCD.Lipid.382 -4 -4 PC (32:0)
#'   \item UCD.Lipid.383 -4 -4 PC (32:1)
#'   \item UCD.Lipid.384 -4 -4 PC (32:2)
#'   \item UCD.Lipid.385 -4 -4 PC (33:1)
#'   \item UCD.Lipid.386 -4 -4 PC (33:2)
#'   \item UCD.Lipid.387 -4 -4 PC (34:0)
#'   \item UCD.Lipid.388 -4 -4 PC (34:1)
#'   \item UCD.Lipid.389 -4 -4 PC (34:2)
#'   \item UCD.Lipid.390 -4 -4 PC (34:3)
#'   \item UCD.Lipid.391 -4 -4 PC (34:4)
#'   \item UCD.Lipid.392 -4 -4 PC (35:1)
#'   \item UCD.Lipid.393 -4 -4 PC (35:2)
#'   \item UCD.Lipid.394 -4 -4 PC (35:4)
#'   \item UCD.Lipid.395 -4 -4 PC (36:1)
#'   \item UCD.Lipid.396 -4 -4 PC (36:2)
#'   \item UCD.Lipid.397 -4 -4 PC (36:3)
#'   \item UCD.Lipid.398 -4 -4 PC (36:4)
#'   \item UCD.Lipid.399 -4 -4 PC (36:5)
#'   \item UCD.Lipid.400 -4 -4 PC (37:2)
#'   \item UCD.Lipid.401 -4 -4 PC (37:4)
#'   \item UCD.Lipid.402 -4 -4 PC (38:2)
#'   \item UCD.Lipid.403 -4 -4 PC (38:3)
#'   \item UCD.Lipid.404 -4 -4 PC (38:4)
#'   \item UCD.Lipid.405 -4 -4 PC (38:5)
#'   \item UCD.Lipid.406 -4 -4 PC (38:6)
#'   \item UCD.Lipid.407 -4 -4 PC (40:4)
#'   \item UCD.Lipid.408 -4 -4 PC (40:5)
#'   \item UCD.Lipid.409 -4 -4 PC (40:6)
#'   \item UCD.Lipid.410 -4 -4 PC (40:7)
#'   \item UCD.Lipid.411 -4 -4 PC (40:8)
#'   \item UCD.Lipid.412 -4 -4 PC (o-32:0)
#'   \item UCD.Lipid.413 -4 -4 PC (p-32:0) or PC (o-32:1)
#'   \item UCD.Lipid.414 -4 -4 PC (p-34:0) or PC (o-34:1)
#'   \item UCD.Lipid.415 -4 -4 PC (p-34:1) or PC (o-34:2)
#'   \item UCD.Lipid.416 -4 -4 PC (p-34:2) or PC (o-34:3)
#'   \item UCD.Lipid.417 -4 -4 PC (p-36:1) or PC (o-36:2)
#'   \item UCD.Lipid.418 -4 -4 PC (p-36:2) or PC (o-36:3)
#'   \item UCD.Lipid.419 -4 -4 PC (p-36:3) or PC (o-36:4)
#'   \item UCD.Lipid.420 -4 -4 PC (p-36:4) or PC (o-36:5)
#'   \item UCD.Lipid.421 -4 -4 PC (p-38:3) or PC (o-38:4)
#'   \item UCD.Lipid.422 -4 -4 PC (p-38:4) or PC (o-38:5)
#'   \item UCD.Lipid.423 -4 -4 PC (p-38:5) or PC (o-38:6)
#'   \item UCD.Lipid.424 -4 -4 PC (p-40:3) or PC (o-40:4)
#'   \item UCD.Lipid.425 -4 -4 PC (p-40:4) or PC (o-40:5)
#'   \item UCD.Lipid.426 -4 -4 PC (p-42:4) or PC (o-42:5)
#'   \item UCD.Lipid.427 -4 -4 PC (p-42:5) or PC (o-42:6)
#'   \item UCD.Lipid.428 -4 -4 PC (p-44:4) or PC (o-44:5)
#'   \item UCD.Lipid.429 -4 -4 PE (34:1)
#'   \item UCD.Lipid.430 -4 -4 PE (34:2)
#'   \item UCD.Lipid.431 -4 -4 PE (36:1)
#'   \item UCD.Lipid.432 -4 -4 PE (36:2)
#'   \item UCD.Lipid.433 -4 -4 PE (36:3)
#'   \item UCD.Lipid.434 -4 -4 PE (38:2)
#'   \item UCD.Lipid.435 -4 -4 PE (38:4)
#'   \item UCD.Lipid.436 -4 -4 PE (38:6)
#'   \item UCD.Lipid.437 -4 -4 PE (40:6)
#'   \item UCD.Lipid.438 -4 -4 PE (p-34:2) or PE (o-34:3)
#'   \item UCD.Lipid.439 -4 -4 PE (p-36:1) or PE (o-36:2)
#'   \item UCD.Lipid.440 -4 -4 PE (p-36:2) or PE (o-36:3)
#'   \item UCD.Lipid.441 -4 -4 PE (p-36:4) or PE (o-36:5)
#'   \item UCD.Lipid.442 -4 -4 PE (p-36:5) or PE (o-36:6)
#'   \item UCD.Lipid.443 -4 -4 PE (p-38:2) or PE (o-38:3)
#'   \item UCD.Lipid.444 -4 -4 PE (p-38:3) or PE (o-38:4)
#'   \item UCD.Lipid.445 -4 -4 PE (p-38:4) or PE (o-38:5)
#'   \item UCD.Lipid.446 -4 -4 PE (p-38:5) or PE (o-38:6)
#'   \item UCD.Lipid.447 -4 -4 PE (p-38:6) or PE (o-38:7)
#'   \item UCD.Lipid.448 -4 -4 PE (p-40:4) or PE (o-40:5)
#'   \item UCD.Lipid.449 -4 -4 PE (p-40:5) or PE (o-40:6)
#'   \item UCD.Lipid.450 -4 -4 PE (p-40:6) or PE (o-40:7)
#'   \item UCD.Lipid.451 -4 -4 PE (p-40:7) or PE (o-40:8)
#'   \item UCD.Lipid.452 -4 -4 PI (32:1)
#'   \item UCD.Lipid.453 -4 -4 PI (34:1)
#'   \item UCD.Lipid.454 -4 -4 PI (34:2)
#'   \item UCD.Lipid.455 -4 -4 PI (36:1)
#'   \item UCD.Lipid.456 -4 -4 PI (36:2)
#'   \item UCD.Lipid.457 -4 -4 PI (36:3)
#'   \item UCD.Lipid.458 -4 -4 PI (36:4)
#'   \item UCD.Lipid.459 -4 -4 PI (38:3)
#'   \item UCD.Lipid.460 -4 -4 PI (38:4)
#'   \item UCD.Lipid.461 -4 -4 PI (38:5)
#'   \item UCD.Lipid.462 -4 -4 PI (40:6)
#'   \item UCD.Lipid.463 -4 -4 SM (32:0)
#'   \item UCD.Lipid.464 -4 -4 SM (32:1)
#'   \item UCD.Lipid.465 -4 -4 SM (32:2)
#'   \item UCD.Lipid.466 -4 -4 SM (33:1)
#'   \item UCD.Lipid.467 -4 -4 SM (34:1)
#'   \item UCD.Lipid.468 -4 -4 SM (34:2)
#'   \item UCD.Lipid.469 -4 -4 SM (36:0)
#'   \item UCD.Lipid.470 -4 -4 SM (36:1)
#'   \item UCD.Lipid.471 -4 -4 SM (36:2)
#'   \item UCD.Lipid.472 -4 -4 SM (36:3)
#'   \item UCD.Lipid.473 -4 -4 SM (37:1)
#'   \item UCD.Lipid.474 -4 -4 SM (38:0)
#'   \item UCD.Lipid.475 -4 -4 SM (38:1)
#'   \item UCD.Lipid.476 -4 -4 SM (38:2)
#'   \item UCD.Lipid.477 -4 -4 SM (39:1)
#'   \item UCD.Lipid.478 -4 -4 SM (39:2)
#'   \item UCD.Lipid.479 -4 -4 SM (40:0)
#'   \item UCD.Lipid.480 -4 -4 SM (40:1)
#'   \item UCD.Lipid.481 -4 -4 SM (40:2) A
#'   \item UCD.Lipid.482 -4 -4 SM (40:2) B
#'   \item UCD.Lipid.483 -4 -4 SM (40:3)
#'   \item UCD.Lipid.484 -4 -4 SM (41:1)
#'   \item UCD.Lipid.485 -4 -4 SM (41:2)
#'   \item UCD.Lipid.486 -4 -4 SM (42:0)
#'   \item UCD.Lipid.487 -4 -4 SM (42:1)
#'   \item UCD.Lipid.488 -4 -4 SM (42:2)
#'   \item UCD.Lipid.489 -4 -4 SM (42:3)
#'   \item UCD.Lipid.490 -4 -4 SM (43:1)
#'   \item UCD.Lipid.491 -4 -4 SM (43:2)
#'   \item UCD.Lipid.492 -4 -4 SM (44:2)
#'   \item UCD.Lipid.493 -4 -4 FA (11:0)
#'   \item UCD.Lipid.494 -4 -4 FA (12:0)
#'   \item UCD.Lipid.495 -4 -4 FA (13:0)
#'   \item UCD.Lipid.496 -4 -4 FA (14:0)
#'   \item UCD.Lipid.497 -4 -4 FA (14:1)
#'   \item UCD.Lipid.498 -4 -4 FA (15:0)
#'   \item UCD.Lipid.499 -4 -4 FA (15:1)
#'   \item UCD.Lipid.500 -4 -4 FA (16:0)
#'   \item UCD.Lipid.501 -4 -4 FA (16:1)
#'   \item UCD.Lipid.502 -4 -4 FA (17:0)
#'   \item UCD.Lipid.503 -4 -4 FA (17:1)
#'   \item UCD.Lipid.504 -4 -4 FA (18:0)
#'   \item UCD.Lipid.505 -4 -4 FA (18:1)
#'   \item UCD.Lipid.506 -4 -4 FA (18:2)
#'   \item UCD.Lipid.507 -4 -4 FA (18:3)
#'   \item UCD.Lipid.508 -4 -4 FA (20:0)
#'   \item UCD.Lipid.509 -4 -4 FA (20:1)
#'   \item UCD.Lipid.510 -4 -4 FA (20:2)
#'   \item UCD.Lipid.511 -4 -4 FA (20:3)
#'   \item UCD.Lipid.512 -4 -4 FA (20:4)
#'   \item UCD.Lipid.513 -4 -4 FA (20:5)
#'   \item UCD.Lipid.514 -4 -4 FA (22:0)
#'   \item UCD.Lipid.515 -4 -4 FA (22:1)
#'   \item UCD.Lipid.516 -4 -4 FA (22:2)
#'   \item UCD.Lipid.517 -4 -4 FA (22:6)
#'   \item UCD.Lipid.518 -4 -4 FA (24:0)
#'   \item UCD.Lipid.519 -4 -4 FA (24:1)
#'   \item UCD.Lipid.520 -4 -4 FA (26:0)
#'   \item UCD.Lipid.521 -4 -4 FA (28:0)
#' }
#'
#' @examples
#' \donotrun{
#' describe(admclipidomics)
#' }
#' @docType data
#' @keywords datasets
#' @name admclipidomics
#' @usage data(admclipidomics)
#' @format A data frame with 910 rows and 525 variables
NULL

#' ADMC M2OVE-AD ADNIGO-2 Bile Acids
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item CUSTOMER.SAMPLE.IDENTIFICATION -4 -4 This is the number listed on every tube of the study samples
#'   \item PLATE.BAR.CODE -4 -4 Unique identifier for every plate generated by the Biocrates MetIDQ software
#'   \item SAMPLE.BAR.CODE -4 -4 Unique identifier for every sample registered in the Biocrates MetIDQ software
#'   \item SAMPLE.TYPE -4 -4 Study samples are Sample.  Biocrates QCs are QC Level 1, 2 or 3.
#'   \item SAMPLE.IDENTIFICATION -4 -4 Unique identifier for every sample entered in the Duke Proteomics Sample Sumbission System
#'   \item SPECIES -4 -4 Species of sample
#'   \item MATERIAL -4 -4 For this study the samples are serum
#'   \item WELL.POSITION -4 -4 Well number in the 96-well plate from which the sample was injected
#'   \item SAMPLE.VOLUME -4 -4 The volume of sample injected in microliters
#'   \item RUN.NUMBER -4 -4 Generated by the Biocrates MetIDQ software for every plate indicating the run number for a particular plate.  For this study, all plates were injected only once.  Therefore, all Run Numbers are 1.
#'   \item INJECTION.NUMBER -4 -4 Generated by the Biocrates MetIDQ software for every sample on a plate indicating whether a sample was injected more than once.  All study samples were injected only once for every plate.  Therefore, all Injection Numbers for study samples is 1.  QC samples are injected three times for every plate resulting in a 1, 2, or 3 listing.
#'   \item CA -4 -4 Cholic acid [M]
#'   \item CDCA -4 -4 Chenodeoxycholic acid [M]
#'   \item DCA -4 -4 Deoxycholic acid [M]
#'   \item GCA -4 -4 Glycocholic acid [M]
#'   \item GCDCA -4 -4 Glycochenodeoxycholic acid [M]
#'   \item GDCA -4 -4 Glycodeoxycholic acid [M]
#'   \item GLCA -4 -4 Glycolithocholic acid [M]
#'   \item GUDCA -4 -4 Glycoursodeoxycholic acid [M]
#'   \item HDCA -4 -4 Hyodeoxycholic acid [M]
#'   \item LCA -4 -4 Lithocholic acid [M]
#'   \item MCA.A. -4 -4 ?-Muricholic acid [M]
#'   \item MCA.B. -4 -4 Muricholic acid, beta [M]
#'   \item MCA.O. -4 -4 Muricholic acid, omega [M]
#'   \item TCA -4 -4 Taurocholic acid [M]
#'   \item TCDCA -4 -4 Taurochenodeoxycholic acid [M]
#'   \item TDCA -4 -4 Taurodeoxycholic acid [M]
#'   \item TLCA -4 -4 Taurolithocholic acid [M]
#'   \item TMCA.A.B. -4 -4 Tauromuricholic acid (alpha+beta) [M]
#'   \item TUDCA -4 -4 Tauroursodeoxycholic acid [M]
#'   \item UDCA -4 -4 Ursodeoxycholic acid [M]
#' }
#'
#' @examples
#' \donotrun{
#' describe(admcm2oveba)
#' }
#' @docType data
#' @keywords datasets
#' @name admcm2oveba
#' @usage data(admcm2oveba)
#' @format A data frame with 940 rows and 33 variables
NULL

#' AD Metabolomics Consortium Phenomenome Phosphatidylcholine (PtdCho), Lysophosphatidylcholine (LPtdCho) Flow Injection Negative Ionization LC-MS/MS Internal Standard Ratios
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/ADMCPDINESIPCISRATIOS/ADMC_DMC_Phenomenome_Phosphatidylcholine_Lysophosphatidylcholine_Flow_Injection_Negative_Ionization_LC-MS-MS_Protocol.pdf}, \url{https://adni.bitbucket.io/reference/docs/ADMCPDINESIPCISRATIOS/ADMC_Phenomenome_Phosphatidylethanolamine_Plasmenylethanolamine_Flow_Injection_LC-MS-MS_Protocol.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item RECNO -4 -4 Record number (2 indicates replicate sample)
#'   \item PC.16.0_18.0 -4 -4 PtdCho 16:0/18:0
#'   \item PC.18.0_18.0 -4 -4 PtdCho 18:0/18:0
#'   \item PC.16.0_18.1 -4 -4 PtdCho 16:0/18:1
#'   \item PC.18.0_18.1 -4 -4 PtdCho 18:0/18:1
#'   \item PC.18.1_18.1 -4 -4 PtdCho 18:1/18:1
#'   \item PC.16.0_18.2 -4 -4 PtdCho 16:0/18:2
#'   \item PC.18.0_18.2 -4 -4 PtdCho 18:0/18:2
#'   \item PC.18.1_18.2 -4 -4 PtdCho 18:1/18:2
#'   \item PC.16.0_18.3 -4 -4 PtdCho 16:0/18:3
#'   \item PC.18.0_18.3 -4 -4 PtdCho 18:0/18:3
#'   \item PC.18.1_18.3 -4 -4 PtdCho 18:1/18:3
#'   \item PC.16.0_20.4 -4 -4 PtdCho 16:0/20:4
#'   \item PC.18.0_20.4 -4 -4 PtdCho 18:0/20:4
#'   \item PC.18.1_20.4 -4 -4 PtdCho 18:1/20:4
#'   \item PC.16.0_20.5 -4 -4 PtdCho 16:0/20:5
#'   \item PC.18.0_20.5 -4 -4 PtdCho 18:0/20:5
#'   \item PC.18.1_20.5 -4 -4 PtdCho 18:1/20:5
#'   \item PC.16.0_22.4 -4 -4 PtdCho 16:0/22:4
#'   \item PC.18.0_22.4 -4 -4 PtdCho 18:0/22:4
#'   \item PC.18.1_22.4 -4 -4 PtdCho 18:1/22:4
#'   \item PC.16.0_22.6 -4 -4 PtdCho 16:0/22:6
#'   \item PC.16.1_22.6 -4 -4 PtdCho 16:1/22:6
#'   \item PC.18.0_22.6 -4 -4 PtdCho 18:0/22:6
#'   \item PC.18.1_22.6 -4 -4 PtdCho 18:1/22:6
#'   \item LPC.16.0 -4 -4 LPtdCho 16:0/OH
#'   \item LPC.16.1 -4 -4 LPtdCho 16:1/OH
#'   \item LPC.18.0 -4 -4 LPtdCho 18:0/OH
#'   \item LPC.18.1 -4 -4 LPtdCho 18:1/OH
#'   \item LPC.18.2 -4 -4 LPtdCho 18:2/OH
#'   \item LPC.18.3 -4 -4 LysoPtdCho 18:3
#'   \item LPC.20.4 -4 -4 LPtdCho 20:4/OH
#'   \item LPC.20.5 -4 -4 LysoPtdCho 20:5
#'   \item LPC.22.6 -4 -4 LPtdCho 22:6/OH
#'   \item LPC.22.4 -4 -4 LysoPtdCho 22:4
#'   \item update_stamp -4 -4 -4
#' }
#'
#' @examples
#' \donotrun{
#' describe(admcpdinesipcisratios)
#' }
#' @docType data
#' @keywords datasets
#' @name admcpdinesipcisratios
#' @usage data(admcpdinesipcisratios)
#' @format A data frame with 829 rows and 38 variables
NULL

#' AD Metabolomics Consortium Phenomenome Phosphatidylethanolamine (PtdEtn), Plasmenylethanolamine (PlsEtn) Flow Injection LC-MS/MS Internal Standard Ratios
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/ADMCPDIPEISRATIOS/ADMC_DMC_Phenomenome_Phosphatidylcholine_Lysophosphatidylcholine_Flow_Injection_Negative_Ionization_LC-MS-MS_Protocol.pdf}, \url{https://adni.bitbucket.io/reference/docs/ADMCPDIPEISRATIOS/ADMC_Phenomenome_Phosphatidylethanolamine_Plasmenylethanolamine_Flow_Injection_LC-MS-MS_Protocol.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item RECNO -4 -4 -4
#'   \item PE.P.16.0.18.2 -4 -4 PlsEtn 16:0/18:2
#'   \item PE.P.18.0.20.5 -4 -4 PlsEtn 18:0/20:5
#'   \item PE.P.16.0.22.4 -4 -4 PlsEtn 16:0/22:4
#'   \item PE.P.16.0.22.6 -4 -4 PlsEtn 16:0/22:6
#'   \item PE.16.0.18.3 -4 -4 PtdEtn 16:0/18:3
#'   \item PE.16.0.22.6 -4 -4 PtdEtn 16:0/22:6
#'   \item PE.18.0.20.5 -4 -4 PtdEtn 18:0/20:5
#'   \item PE.18.0.22.4 -4 -4 PtdEtn 18:0/22:4
#'   \item UPDATE.STAMP -4 -4 -4
#'   \item BATCH.ID -4 -4 -4
#'   \item SAMPLE.TYPE -4 -4 -4
#'   \item C13.PE.P.16.0.22.6 -4 -4 13C Labeled PlsEtn 16:0/22:6
#'   \item C13.PE.16.0.22.6 -4 -4 13C Labeled PtdEtn 16:0/22:6
#'   \item PE.P.16.0.18.0 -4 -4 PlsEtn 16:0/18:0
#'   \item PE.P.16.0.18.1 -4 -4 PlsEtn 16:0/18:1
#'   \item PE.P.16.0.18.3 -4 -4 PlsEtn 16:0/18:3
#'   \item PE.P.16.0.20.4 -4 -4 PlsEtn 16:0/20:4
#'   \item PE.P.18.0.18.0 -4 -4 PlsEtn 18:0/18:0
#'   \item PE.P.18.0.18.1 -4 -4 PlsEtn 18:0/18:1
#'   \item PE.P.18.0.18.2 -4 -4 PlsEtn 18:0/18:2
#'   \item PE.P.18.0.18.3 -4 -4 PlsEtn 18:0/18:3
#'   \item PE.P.18.0.22.4 -4 -4 PlsEtn 18:0/22:4
#'   \item PE.P.18.0.22.6 -4 -4 PlsEtn 18:0/22:6
#'   \item PE.P.16.0.20.5 -4 -4 PlsEtn 16:0/20:5
#'   \item PE.P.18.0.20.4 -4 -4 PlsEtn 18:0/20:4
#'   \item PE.16.0.18.0 -4 -4 PtdEtn 16:0/18:0
#'   \item PE.16.0.18.1 -4 -4 PtdEtn 16:0/18:1
#'   \item PE.16.0.18.2 -4 -4 PtdEtn 16:0/18:2
#'   \item PE.16.0.20.4 -4 -4 PtdEtn 16:0/20:4
#'   \item PE.16.0.22.4 -4 -4 PtdEtn 16:0/22:4
#'   \item PE.16.0.24.6 -4 -4 PtdEtn 16:0/24:6
#'   \item PE.18.0.18.1 -4 -4 PtdEtn 18:0/18:1
#'   \item PE.18.0.18.2 -4 -4 PtdEtn 18:0/18:2
#'   \item PE.18.0.18.3 -4 -4 PtdEtn 18:0/18:3
#'   \item PE.18.0.20.4 -4 -4 PtdEtn 18:0/20:4
#'   \item PE.18.0.22.6 -4 -4 PtdEtn 18:0/22:6
#'   \item PE.18.0.24.6 -4 -4 PtdEtn 18:0/24:6
#'   \item PE.16.0.20.5 -4 -4 PtdEtn 16:0/20:5
#' }
#'
#' @examples
#' \donotrun{
#' describe(admcpdipeisratios)
#' }
#' @docType data
#' @keywords datasets
#' @name admcpdipeisratios
#' @usage data(admcpdipeisratios)
#' @format A data frame with 1734 rows and 41 variables
NULL

#' AD Metabolomics Consortium Phenomenome Phosphatidylethanolamine (PtdEtn), Plasmenylethanolamine (PlsEtn) Flow Injection LC-MS/MS Internal Standard Ratios
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item BATCH.ID -4 -4 -4
#'   \item PDI.ID -4 -4 -4
#'   \item C13.PE.P.16.0.22.6 -4 -4 13C Labeled PlsEtn 16:0/22:6
#'   \item C13.PE.16.0.22.6 -4 -4 13C Labeled PtdEtn 16:0/22:6
#'   \item PE.16.0.18.3 -4 -4 PtdEtn 16:0/18:3
#'   \item PE.16.0.22.6 -4 -4 PtdEtn 16:0/22:6
#'   \item PE.18.0.20.5 -4 -4 PtdEtn 18:0/20:5
#'   \item PE.18.0.22.4 -4 -4 PtdEtn 18:0/22:4
#'   \item PE.P.16.0.18.2 -4 -4 PlsEtn 16:0/18:2
#'   \item PE.P.18.0.20.5 -4 -4 PlsEtn 18:0/20:5
#'   \item PE.P.16.0.22.4 -4 -4 PlsEtn 16:0/22:4
#'   \item PE.P.16.0.22.6 -4 -4 PlsEtn 16:0/22:6
#'   \item SAMPLE.TYPE -4 -4 -4
#'   \item PE.16.0.18.0 -4 -4 PtdEtn 16:0/18:0
#'   \item PE.16.0.18.1 -4 -4 PtdEtn 16:0/18:1
#'   \item PE.16.0.18.2 -4 -4 PtdEtn 16:0/18:2
#'   \item PE.16.0.20.4 -4 -4 PtdEtn 16:0/20:4
#'   \item PE.16.0.22.4 -4 -4 PtdEtn 16:0/22:4
#'   \item PE.16.0.24.6 -4 -4 PtdEtn 16:0/24:6
#'   \item PE.18.0.18.1 -4 -4 PtdEtn 18:0/18:1
#'   \item PE.18.0.18.2 -4 -4 PtdEtn 18:0/18:2
#'   \item PE.18.0.18.3 -4 -4 PtdEtn 18:0/18:3
#'   \item PE.18.0.20.4 -4 -4 PtdEtn 18:0/20:4
#'   \item PE.18.0.22.6 -4 -4 PtdEtn 18:0/22:6
#'   \item PE.18.0.24.6 -4 -4 PtdEtn 18:0/24:6
#'   \item PE.P.16.0.18.0 -4 -4 PlsEtn 16:0/18:0
#'   \item PE.P.16.0.18.1 -4 -4 PlsEtn 16:0/18:1
#'   \item PE.P.16.0.18.3 -4 -4 PlsEtn 16:0/18:3
#'   \item PE.P.16.0.20.4 -4 -4 PlsEtn 16:0/20:4
#'   \item PE.P.18.0.18.0 -4 -4 PlsEtn 18:0/18:0
#'   \item PE.P.18.0.18.1 -4 -4 PlsEtn 18:0/18:1
#'   \item PE.P.18.0.18.2 -4 -4 PlsEtn 18:0/18:2
#'   \item PE.P.18.0.18.3 -4 -4 PlsEtn 18:0/18:3
#'   \item PE.P.18.0.22.4 -4 -4 PlsEtn 18:0/22:4
#'   \item PE.P.18.0.22.6 -4 -4 PlsEtn 18:0/22:6
#'   \item PE.16.0.20.5 -4 -4 PtdEtn 16:0/20:5
#'   \item PE.P.16.0.20.5 -4 -4 PlsEtn 16:0/20:5
#'   \item PE.P.18.0.20.4 -4 -4 PlsEtn 18:0/20:4
#'   \item COMMENTS -4 -4 -4
#' }
#'
#' @examples
#' \donotrun{
#' describe(admcpdipepeakheights)
#' }
#' @docType data
#' @keywords datasets
#' @name admcpdipepeakheights
#' @usage data(admcpdipepeakheights)
#' @format A data frame with 1734 rows and 41 variables
NULL

#' AD Metabolomics Consortium Phenomenome Phosphatidylcholine (PtdCho), Lysophosphatidylcholine (LPtdCho), Sphingomyeline (SM) Flow Injection Positive Ionization LC-MS/MS Internal Standard Ratios
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/ADMCPDIPESIPCISRATIOS/ADMC_DMC_Phenomenome_Phosphatidylcholine_Lysophosphatidylcholine_Flow_Injection_Negative_Ionization_LC-MS-MS_Protocol.pdf}, \url{https://adni.bitbucket.io/reference/docs/ADMCPDIPESIPCISRATIOS/ADMC_Phenomenome_Phosphatidylethanolamine_Plasmenylethanolamine_Flow_Injection_LC-MS-MS_Protocol.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item RECNO -4 -4 Record number (2 indicates replicate sample)
#'   \item PC.34.3 -4 -4 diacyl-PtdCho  16:0/18:3; 14:0/20:3; 16:1/18:2
#'   \item PC.34.0 -4 -4 diacyl-PtdCho 16:0/18:0; 14:0/20:0
#'   \item PC.34.1 -4 -4 diacyl PtdCho 16:0/18:1; 14:0/20:1; 16:1/18:0
#'   \item PC.34.2 -4 -4 diacyl PtdCho 16:0/18:2; 14:0/20:2; 16:1/18:1
#'   \item PC.36.4 -4 -4 diacyl PtdCho 16:0/20:4; 18:1/18:3; 14:0/22:4; 18:2/18:2; 16:1/20:3
#'   \item PC.36.5 -4 -4 diacyl PtdCho 16:0/20:5; 14:0/22:5; 18:2/18:3; 18:2/18:3
#'   \item PC.38.4 -4 -4 diacyl PtdCho 16:0/22:4, 18:0/20:4; 14:0/24:4; 18:1/20:3
#'   \item PC.38.6 -4 -4 diacyl PtdCho 16:0/22:6, 18:1/20:5; 14:0/24:6; 18:2/20:4
#'   \item PC.38.7 -4 -4 diacyl PtdCho 16:1/22:6; 14:1/24:6; 18:2/20:5
#'   \item PC.36.2 -4 -4 diacyl PtdCho 18:0/18:2; 18:1/18:1; 14:0/22:2; 16:0/20:2; 16:1/20:1
#'   \item PC.36.3 -4 -4 diacyl PtdCho 18:0/18:3, 18:1/18:2; 14:0/22:3; 16:0/20:3; 16:1/20:2
#'   \item PC.38.5 -4 -4 diacyl PtdCho 18:0/20:5, 18:1/20:4; 14:0/24:5; 16:0/22:5; 16:1/22:4
#'   \item PC.40.4 -4 -4 diacyl PtdCho 18:0/22:4; 16:0/24:4; 16:1/24:3; 20:0/20:4
#'   \item PC.40.6 -4 -4 diacyl PtdCho 18:0/22:6; 16:0/24:6; 18:1/22:5
#'   \item PC.40.5 -4 -4 diacyl PtdCho 18:1/22:4; 16:0/24:5; 18:0/22:5; 20:0/20:5; 20:1/20:4
#'   \item PC.40.7 -4 -4 diacyl PtdCho 18:1/22:6; 16:0/24:6
#'   \item PC.36.6 -4 -4 diacyl PtdCho 14:0/22:6; 16:1/20:5; 18:3/18:3
#'   \item PC.38.0 -4 -4 diacyl PtdCho 18:0/20:0;16:0/22:0
#'   \item PC.40.1 -4 -4 diacyl PtdCho 18:0/22:1; 18:1/22:0; 16:0/24:1; 16:1/24:0
#'   \item PC.40.2 -4 -4 diacyl PtdCho 18:1/22:1; 18:0/22:2; 16:0/24:2; 16:1/24:1
#'   \item LPC.16.0 -4 -4 LPtdCho 16:0/OH
#'   \item LPC.16.1 -4 -4 LPtdCho 16:1/OH
#'   \item LPC.18.0 -4 -4 LPtdCho 18:0/OH
#'   \item LPC.18.1 -4 -4 LPtdCho 18:1/OH
#'   \item LPC.18.2 -4 -4 LPtdCho 18:2/OH
#'   \item LPC.20.4 -4 -4 LPtdCho 20:4/OH
#'   \item LPC.22.6 -4 -4 LPtdCho 22:6/OH
#'   \item SM.34.1 -4 -4 SphMyelin (d18:1/16:0), SphMyelin (d18:0/16:1)
#'   \item SM.36.1 -4 -4 SphMyelin (d18:1/18:0), SphMyelin (d18:0/18:1)
#'   \item SM.36.2 -4 -4 SphMyelin (d18:1/18:1)
#'   \item SM.42.1 -4 -4 SphMyelin (d18:1/24:0)
#'   \item SM.42.2 -4 -4 SphMyelin (d18:1/24:1)
#'   \item update_stamp -4 -4 -4
#' }
#'
#' @examples
#' \donotrun{
#' describe(admcpdipesipcisratios)
#' }
#' @docType data
#' @keywords datasets
#' @name admcpdipesipcisratios
#' @usage data(admcpdipesipcisratios)
#' @format A data frame with 829 rows and 36 variables
NULL

#' Key ADNI tables merged into one table
#'
#'
#'
#' @author \email{adni-data@googlegroups.com}
#'
#' @seealso \code{\link{adnimerger}}
#' @description Key ADNI tables merged into one table
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID  NA Participant roster ID
#'   \item COLPROT  NA Study protocol of data collection
#'   \item ORIGPROT  NA Original study protocol
#'   \item PTID  NA Original study protocol
#'   \item SITE  NA Site
#'   \item VISCODE  NA Visit code
#'   \item EXAMDATE  NA Date
#'   \item DX.bl  NA Baseline Dx
#'   \item AGE  NA Age
#'   \item PTGENDER  NA Sex
#'   \item PTEDUCAT  NA Education
#'   \item PTETHCAT  NA Ethnicity
#'   \item PTRACCAT  NA Race
#'   \item PTMARRY  NA Marital
#'   \item APOE4  NA ApoE4
#'   \item FDG  NA Average FDG-PET of angular, temporal, and posterior cingulate
#'   \item PIB  NA Average PIB SUVR of frontal cortex, anterior cingulate, precuneus cortex, and parietal cortex
#'   \item AV45  NA Reference region - florbetapir mean of whole cerebellum.  Regions defined by Freesurfer; see Jagust lab PDF on LONI for details
#'   \item ABETA  NA CSF ABETA
#'   \item TAU  NA CSF TAU
#'   \item PTAU  NA CSF PTAU
#'   \item CDRSB  NA CDR-SB
#'   \item ADAS11  NA ADAS 11
#'   \item ADAS13  NA ADAS 13
#'   \item ADASQ4  NA ADAS Delayed Word Recall
#'   \item MMSE  NA MMSE
#'   \item RAVLT.immediate  NA RAVLT Immediate (sum of 5 trials)
#'   \item RAVLT.learning  NA RAVLT Learning (trial 5 - trial 1)
#'   \item RAVLT.forgetting  NA RAVLT Forgetting (trial 5 - delayed)
#'   \item RAVLT.perc.forgetting  NA RAVLT Percent Forgetting
#'   \item LDELTOTAL  NA Logical Memory - Delayed Recall
#'   \item DIGITSCOR  NA Digit Symbol Substitution
#'   \item TRABSCOR  NA Trails B
#'   \item FAQ  NA FAQ
#'   \item MOCA  NA MOCA
#'   \item EcogPtMem  NA Pt ECog - Mem
#'   \item EcogPtLang  NA Pt ECog - Lang
#'   \item EcogPtVisspat  NA Pt ECog - Vis/Spat
#'   \item EcogPtPlan  NA Pt ECog - Plan
#'   \item EcogPtOrgan  NA Pt ECog - Organ
#'   \item EcogPtDivatt  NA Pt ECog - Div atten
#'   \item EcogPtTotal  NA Pt ECog - Total
#'   \item EcogSPMem  NA SP ECog - Mem
#'   \item EcogSPLang  NA SP ECog - Lang
#'   \item EcogSPVisspat  NA SP ECog - Vis/Spat
#'   \item EcogSPPlan  NA SP ECog - Plan
#'   \item EcogSPOrgan  NA SP ECog - Organ
#'   \item EcogSPDivatt  NA SP ECog - Div atten
#'   \item EcogSPTotal  NA SP ECog - Total
#'   \item FLDSTRENG  NA MRI Field Strength
#'   \item FSVERSION  NA FreeSurfer Software Version
#'   \item IMAGEUID  NA LONI Image ID
#'   \item Ventricles  NA UCSF Ventricles
#'   \item Hippocampus  NA UCSF Hippocampus
#'   \item WholeBrain  NA UCSF WholeBrain
#'   \item Entorhinal  NA UCSF Entorhinal
#'   \item Fusiform  NA UCSF Fusiform
#'   \item MidTemp  NA UCSF Med Temp
#'   \item ICV  NA UCSF ICV
#'   \item DX  NA Diagnosis
#'   \item mPACCdigit  NA ADNI modified Preclinical Alzheimer's Cognitive Composite (PACC) with Digit Symbol Substitution
#'   \item mPACCtrailsB  NA ADNI modified Preclinical Alzheimer's Cognitive Composite (PACC) with Trails B
#'   \item EXAMDATE.bl  NA Date
#'   \item CDRSB.bl  NA CDR-SB
#'   \item ADAS11.bl  NA ADAS 11
#'   \item ADAS13.bl  NA ADAS 13
#'   \item ADASQ4.bl  NA ADAS Delayed Word Recall
#'   \item MMSE.bl  NA MMSE
#'   \item RAVLT.immediate.bl  NA RAVLT Immediate (sum of 5 trials)
#'   \item RAVLT.learning.bl  NA RAVLT Learning (trial 5 - trial 1)
#'   \item RAVLT.forgetting.bl  NA RAVLT Forgetting (trial 5 - delayed)
#'   \item RAVLT.perc.forgetting.bl  NA RAVLT Percent Forgetting
#'   \item LDELTOTAL.bl  NA Logical Memory - Delayed Recall
#'   \item DIGITSCOR.bl  NA Digit Symbol Substitution
#'   \item TRABSCOR.bl  NA Trails B
#'   \item FAQ.bl  NA FAQ
#'   \item mPACCdigit.bl  NA ADNI modified Preclinical Alzheimer's Cognitive Composite (PACC) with Digit Symbol Substitution
#'   \item mPACCtrailsB.bl  NA ADNI modified Preclinical Alzheimer's Cognitive Composite (PACC) with Trails B
#'   \item FLDSTRENG.bl  NA MRI Field Strength
#'   \item FSVERSION.bl  NA FreeSurfer Software Version
#'   \item IMAGEUID.bl  NA LONI Image ID
#'   \item Ventricles.bl  NA UCSF Ventricles
#'   \item Hippocampus.bl  NA UCSF Hippocampus
#'   \item WholeBrain.bl  NA UCSF WholeBrain
#'   \item Entorhinal.bl  NA UCSF Entorhinal
#'   \item Fusiform.bl  NA UCSF Fusiform
#'   \item MidTemp.bl  NA UCSF Med Temp
#'   \item ICV.bl  NA UCSF ICV
#'   \item MOCA.bl  NA MOCA
#'   \item EcogPtMem.bl  NA Pt ECog - Mem
#'   \item EcogPtLang.bl  NA Pt ECog - Lang
#'   \item EcogPtVisspat.bl  NA Pt ECog - Vis/Spat
#'   \item EcogPtPlan.bl  NA Pt ECog - Plan
#'   \item EcogPtOrgan.bl  NA Pt ECog - Organ
#'   \item EcogPtDivatt.bl  NA Pt ECog - Div atten
#'   \item EcogPtTotal.bl  NA Pt ECog - Total
#'   \item EcogSPMem.bl  NA SP ECog - Mem
#'   \item EcogSPLang.bl  NA SP ECog - Lang
#'   \item EcogSPVisspat.bl  NA SP ECog - Vis/Spat
#'   \item EcogSPPlan.bl  NA SP ECog - Plan
#'   \item EcogSPOrgan.bl  NA SP ECog - Organ
#'   \item EcogSPDivatt.bl  NA SP ECog - Div atten
#'   \item EcogSPTotal.bl  NA SP ECog - Total
#'   \item ABETA.bl  NA CSF ABETA
#'   \item TAU.bl  NA CSF TAU
#'   \item PTAU.bl  NA CSF PTAU
#'   \item FDG.bl  NA Average FDG-PET of angular, temporal, and posterior cingulate
#'   \item PIB.bl  NA Average PIB SUVR of frontal cortex, anterior cingulate, precuneus cortex, and parietal cortex
#'   \item AV45.bl  NA Reference region - florbetapir mean of whole cerebellum.  Regions defined by Freesurfer; see Jagust lab PDF on LONI for details
#'   \item Years.bl  NA 
#'   \item Month.bl  NA 
#'   \item Month  NA Months since baseline
#'   \item M  NA Month since baseline
#' }
#'
#' @examples
#' dd <- adnimerge
#' covariates <- c('CDRSB', 'ADAS11', 'ADAS13', 'MMSE', 'RAVLT.immediate', 'FAQ', 'Ventricles', 'Hippocampus', 'WholeBrain', 'Entorhinal', 'MOCA')
#' 
#' dd$Age.c <- dd$AGE - mean(dd$AGE[dd$VISCODE == 'bl'], na.rm = TRUE)
#' 
#' dd[, paste(covariates, '.bl.c', sep='')] <- sweep(dd[, paste(covariates, '.bl', sep='')], 2, 
#'                                                   colMeans(dd[, paste(covariates, '.bl', sep='')], na.rm=TRUE), '-')
#' 
#' dd[, paste(c('EXAMDATE', covariates), '.ch', sep='')] <- dd[, c('EXAMDATE', covariates)] - 
#'   dd[, paste(c('EXAMDATE', covariates), '.bl', sep='')]
#' 
#' dd$Dx <- unlist(lapply(strsplit(as.character(dd$DX), ' to ', fixed = TRUE), function(x) x[length(x)]))
#' 
#' label(dd$Age.c) <- 'Centered Age'
#' 
#' @docType data
#' @keywords datasets
#' @name adnimerge
#' @usage data(adnimerge)
#' @format A data frame with 13196 rows and 113 variables
NULL

#' DDE analysis summary
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/ADRC_EMORY_DDE/Levey_Walker_ADNI_Methods_Submission_v2.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item VERSION -4  Version number
#'   \item RUNDATE -4  Analysis date
#'   \item STATUS -4  Analysis status
#'   \item ANALYSIS_BATCH -4  Batch number
#'   \item DDE_RECOVER_13C_PERCENT -4 percent Recovery percent
#'   \item DDE_PLASMA_CONCENTRATION -4 ng/L Plasma concentration
#'   \item DETECTION_LIMIT -4  Above detection limit
#' }
#'
#' @examples
#' \donotrun{
#' describe(adrc_emory_dde)
#' }
#' @docType data
#' @keywords datasets
#' @name adrc_emory_dde
#' @usage data(adrc_emory_dde)
#' @format A data frame with 218 rows and 10 variables
NULL

#' Diagnosis and Symptoms Checklist
#'
#'
#'
#' @author \email{adni-data@googlegroups.com}
#'
#'
#' @description See \url{http://adni.loni.usc.edu}.
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item EXAMDATE D  Examination Date
#'   \item AXNAUSEA N  1. Nausea
#'   \item AXVOMIT N  2. Vomiting
#'   \item AXDIARRH N  3. Diarrhea
#'   \item AXCONSTP N  4. Constipation
#'   \item AXABDOMN N  5. Abdominal discomfort
#'   \item AXSWEATN N  6. Sweating
#'   \item AXDIZZY N  7. Dizziness
#'   \item AXENERGY N  8. Low energy
#'   \item AXDROWSY N  9. Drowsiness
#'   \item AXVISION N  10. Blurred vision
#'   \item AXHDACHE N  11. Headache
#'   \item AXDRYMTH N  12. Dry mouth
#'   \item AXBREATH N  13. Shortness of breath
#'   \item AXCOUGH N  14. Coughing
#'   \item AXPALPIT N  15. Palpitations
#'   \item AXCHEST N  16. Chest pain
#'   \item AXURNDIS N  17. Urinary discomfort (e.g., burning)
#'   \item AXURNFRQ N  18. Urinary frequency
#'   \item AXANKLE N  19. Ankle swelling
#'   \item AXMUSCLE N  20. Muscloskeletal pain
#'   \item AXRASH N  21. Rash
#'   \item AXINSOMN N  22. Insomnia
#'   \item AXDPMOOD N  23. Depressed mood
#'   \item AXCRYING N  24. Crying
#'   \item AXELMOOD N  25. Elevated mood
#'   \item AXWANDER N  26. Wandering
#'   \item AXFALL N  27. Fall
#'   \item AXOTHER N  28. Other/Diagnosis
#'   \item AXSPECIF T  If Other symptoms/diagnosis, specify:
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name adsxlist
#' @usage data(adsxlist)
#' @format A data frame with 4884 rows and 37 variables
NULL

#' Adverse Events Log
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item AENUMBER N NA Adverse event number
#'   \item AEHEVNT T NA Event diagnosis (or medical term if diagnosis is unknown)
#'   \item AEHCOMM T NA Provide a full description of event:
#'   \item AECHANGE N NA Is this event a:
#'   \item AEPENUM N NA Initial Health Assessment Condition Number:
#'   \item AECOMPOUND N NA Is this event part of a compound event?
#'   \item AERELAES T NA If yes, provide related adverse event number(s):
#'   \item AEHONSDT D YYYY-MM-DD Event onset date
#'   \item AEOUTCOME N NA Event outcome
#'   \item AEUNK T NA If Unknown, please clarify reason outcome is unknown:
#'   \item AEHCSDT D YYYY-MM-DD Event cease date
#'   \item AEHDTHDT D YYYY-MM-DD Date of death
#'   \item AEHDCAUS T NA Cause of death:
#'   \item AEHCHRON N NA Initial Chronicity
#'   \item AEHSEVR N NA Initial Severity
#'   \item AERELAD N NA Related to symptoms associated with the development of early stage AD or progression of AD
#'   \item AERELCM N NA Related to concomitant therapy
#'   \item AERELFLRBTBN N NA Related to Florbetaben tracer
#'   \item AERELFLRBPR N NA Related to Florbetapir tracer
#'   \item AEHIMG N NA Related to PET/MRI imaging procedure
#'   \item AERELTAU N NA Related to AV-1451 (Tau) tracer
#'   \item AEHLUMB N NA Related to lumbar puncture
#'   \item AERELATESP N NA Related to other study procedure(s)
#'   \item AEHCMEDS N NA Was treatment (medication) for AE required?
#'   \item AESERIOUS N NA Was event serious at any time during the trial?
#'   \item AESERDATE D YYYY-MM-DD Date event became serious:
#'   \item AEDTSITE D YYYY-MM-DD Date site became aware that the event is serious:
#'   \item SAELIFE N NA Is this an SAE because event was life-threatening?
#'   \item SAEHOSPIT N NA Is this an SAE because it lead to  hospitalization?
#'   \item SAEPROLONG N NA Is this an SAE because it lead to  prolongation of hospitalization?
#'   \item SAEDEATH N NA Is this an SAE because it lead to  death?
#'   \item SAECONGEN N NA Is this an SAE because it lead to a congenital anomaly or birth defect?
#'   \item SAEDISAB N NA Is this an SAE because it caused  persistent or significant disability/incapacity?
#'   \item SAEOTHER N NA Is this an SAE because it lead to another medically important condition?
#'   \item AEOTHERHX T NA SAE Narrative:  Relevant medical history, Relationship of this event to other events, and all other applicable information
#'   \item AECHANGE1 N NA Is there a change to report?
#'   \item AEDATE1 D YYYY-MM-DD Change 1.  Date
#'   \item AESEV1 N NA Change 1: Severity
#'   \item AECHRON1 N NA Change 1: Chronicity
#'   \item AECHANGE2 N NA Is there a 2nd change to report?
#'   \item AEDATE2 D YYYY-MM-DD Change 2.  Date
#'   \item AESEV2 N NA Change 2: Severity
#'   \item AECHRON2 N NA Change 2: Chronicity
#'   \item AECHANGE3 N NA Is there a 3rd change to report?
#'   \item AEDATE3 D YYYY-MM-DD Change 3.  Date
#'   \item AESEV3 N NA Change 3: Severity
#'   \item AECHRON3 N NA Change 3: Chronicity
#'   \item AECHANGE4 N NA Is there a 4th change to report?
#'   \item AEDATE4 D YYYY-MM-DD Change 4.  Date
#'   \item AESEV4 N NA Change 4: Severity
#'   \item AECHRON4 N NA Change 4: Chronicity
#'   \item AECHANGE5 N NA Is there a 5th change to report?
#'   \item AEDATE5 D YYYY-MM-DD Change 5.  Date
#'   \item AESEV5 N NA Change 5: Severity
#'   \item AECHRON5 N NA Change 5: Chronicity
#'   \item AECHANGE6 N NA Is there a 6th change to report?
#'   \item AEDATE6 D YYYY-MM-DD Change 6.  Date
#'   \item AESEV6 N NA Change 6: Severity
#'   \item AECHRON6 N NA Change 6: Chronicity
#'   \item AECHANGE7 N NA Is there a 7th change to report?
#'   \item AEDATE7 D YYYY-MM-DD Change 7.  Date
#'   \item AESEV7 N NA Change 7: Severity
#'   \item AECHRON7 N NA Change 7: Chronicity
#'   \item AECHANGE8 N NA Is there a 8th change to report?
#'   \item AEDATE8 D YYYY-MM-DD Change 8.  Date
#'   \item AESEV8 N NA Change 8: Severity
#'   \item AECHRON8 N NA Change 8: Chronicity
#'   \item AECHANGE9 N NA Is there a 9th change to report?
#'   \item AEDATE9 D YYYY-MM-DD Change 9.  Date
#'   \item AESEV9 N NA Change 9: Severity
#'   \item AECHRON9 N NA Change 9: Chronicity
#'   \item AECHANGE10 N NA Is there a 10th change to report?
#'   \item AEDATE10 D YYYY-MM-DD Change 10.  Date
#'   \item AESEV10 N NA Change 10: Severity
#'   \item AECHRON10 N NA Change 10: Chronicity
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' \donotrun{
#' describe(adverse)
#' }
#' @docType data
#' @keywords datasets
#' @name adverse
#' @usage data(adverse)
#' @format A data frame with 140 rows and 82 variables
NULL

#' Adverse Event Checklist
#'
#'
#'
#'
#'
#'
#' @description See \url{http://adni.loni.usc.edu}.
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#'   \item AENAUSEA N  1. Nausea
#'   \item AEVOMIT N  2. Vomiting
#'   \item AEDIARRH N  3. Diarrhea
#'   \item AECONSTP N  4. Constipation
#'   \item AEABDOMN N  5. Abdominal discomfort
#'   \item AESWEATN N  6. Sweating
#'   \item AEDIZZY N  7. Dizziness
#'   \item AEENERGY N  8. Low energy
#'   \item AEDROWSY N  9. Drowsiness
#'   \item AEVISION N  10. Blurred vision
#'   \item AEHDACHE N  11. Headache
#'   \item AEDRYMTH N  12. Dry mouth
#'   \item AEBREATH N  13. Shortness of breath
#'   \item AECOUGH N  14. Coughing
#'   \item AEPALPIT N  15. Palpitations
#'   \item AECHEST N  16. Chest pain
#'   \item AEURNDIS N  17. Urinary discomfort (e.g., burning)
#'   \item AEURNFRQ N  18. Urinary frequency
#'   \item AEANKLE N  19. Ankle swelling
#'   \item AEMUSCLE N  20. Musculoskeletal pain
#'   \item AERASH N  21. Rash
#'   \item AEINSOMN N  22. Insomnia
#'   \item AEDPMOOD N  23. Depressed mood
#'   \item AECRYING N  24. Crying
#'   \item AEELMOOD N  25. Elevated mood
#'   \item AEWANDER N  26. Wandering
#'   \item AEFALL N  27. Fall
#'   \item AEOTHER N  28. Other Symptoms
#'   \item AESPECIF T  If Other, specify:
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name aecheck
#' @usage data(aecheck)
#' @format A data frame with 5734 rows and 36 variables
NULL

#' Aliquot count in the LDMS database
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/ALIQUOT_LIST/CSF%20Aliquot%20Inventory%20Description%203feb2015.pdf}, \url{https://adni.bitbucket.io/reference/docs/ALIQUOT_LIST/PLA%20Aliquot%20Inventory%20Description%203feb2015.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4  Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item VISCODE2 -4 -4 Translated visit code
#'   \item EXAMDATE -4 -4 Examination Date
#'   \item VID -4  Visit number from sample tube
#'   \item PLA -4  Count of pristine Plasma aliquots
#'   \item PLAVOL -4 mL Volume of pristine Plasma aliquots
#'   \item SER -4  Count of pristine Serum aliquots
#'   \item SERVOL -4 mL Volume of pristine Serum aliquots
#'   \item CSF -4  Count of pristine CSF aliquots
#'   \item CSFVOL -4 mL Volume of pristine CSF aliquots
#'   \item URN -4  Count of pristine Urine aliquots
#'   \item URNVOL -4 mL Volume of pristine Urine aliquots
#'   \item QUERYDATE -4 MM/DD/YYYY Date of LDMS database query
#'   \item USED_PLA -4  Count of Plasma aliquots used for analysis at Biomarker Core Lab
#'   \item USED_SER -4  Count of Serum aliquots used for analysis at Biomarker Core Lab
#'   \item USED_CSF -4  Count of CSF aliquots used for analysis at Biomarker Core Lab
#'   \item USED_URN -4  Count of Urine aliquots used for analysis at Biomarker Core Lab
#'   \item SENT_PLA -4  Count of Plasma aliquots shipped out to other investigators
#'   \item SENT_SER -4  Count of Serum aliquots shipped out to other investigators
#'   \item SENT_CSF -4  Count of CSF aliquots shipped out to other investigators
#'   \item SENT_URN -4  Count of Urine aliquots shipped out to other investigators
#' }
#'
#' @examples
#' \donotrun{
#' describe(aliquot_list)
#' }
#' @docType data
#' @keywords datasets
#' @name aliquot_list
#' @usage data(aliquot_list)
#' @format A data frame with 9516 rows and 22 variables
NULL

#' Amyloid PET Scan Information
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item DONE N NA Was the scan conducted?
#'   \item NDREASON N NA If No, reason not done
#'   \item NDSPECIFY T NA If Other, specify
#'   \item RADTRACER N NA If scan not done, was radiotracer administered?
#'   \item TRACERTYPE N NA Amyloid Imaging radiotracer used
#'   \item SCANDATE D YYYY-MM-DD Scan Date/Dose Date
#'   \item QCTIME T HHMM Time of today's Scanner QC
#'   \item ASSAYTIME T HHMM Time of dose assay
#'   \item DOSEFLRBTBN N mCi Florbetaben (Neuraceq):  Injected dose assay
#'   \item DOSEFLRBTPR N mCi Florbetapir (Amyvid):  Injected dose assay
#'   \item INJTIME T HHMM Time of injection
#'   \item SCANTIME T HHMM Emission Scan Start Time
#'   \item SCANDIFF T NA Provide an explanation if start time is not at optimal start time for amyloid imaging compound.
#'   \item VARIAT N NA Any variations from protocol during uptake?
#'   \item VARIATSPEC T NA If Yes, describe
#'   \item PROTID T NA Predefined Acquisition Protocol Name
#'   \item MOTION N NA Participant motion problems
#'   \item OTHERVAR N NA Other protocol variations
#'   \item RECON N NA Select reconstruction used
#'   \item SHARP N NA For Phillips scanners:  was "smooth" parameter set to "sharp"?
#'   \item ARCHIVE N NA Data archived locally?
#'   \item LONI N NA Data transferred to LONI?
#'   \item TRANDATE D YYYY-MM-DD Transfer Date
#'   \item COMM T NA Comments
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' \donotrun{
#' describe(amymeta)
#' }
#' @docType data
#' @keywords datasets
#' @name amymeta
#' @usage data(amymeta)
#' @format A data frame with 335 rows and 31 variables
NULL

#' Amyloid PET QC
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item SCANDATE D YYYY-MM-DD Scan Date
#'   \item LONIUPDT D YYYY-MM-DD Date uploaded to LONI
#'   \item LONIUID T NA LONI Unique Series ID
#'   \item REVDT D YYYY-MM-DD Date Reviewed
#'   \item ALLFRAME N NA Were all frames acceptable?
#'   \item UNUSABL T NA If No, indicate which frames were unacceptable
#'   \item UNRSN N NA If No, indicate why frames were unacceptable
#'   \item UNRSNSPEC T NA If Other, Specify
#'   \item SCANQLTY N NA Scan Pass QC?
#'   \item REPROCREQ N NA Reprocessing requested?
#'   \item PROCERR T NA If Yes, select processing error(s)
#'   \item PROCERRSPEC T NA If Other, Specify
#'   \item RESCANREQ N NA Rescan requested?
#'   \item COMM T NA Comments
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' \donotrun{
#' describe(amyqc)
#' }
#' @docType data
#' @keywords datasets
#' @name amyqc
#' @usage data(amyqc)
#' @format A data frame with 328 rows and 21 variables
NULL

#' ADNI GO & 2 APOE Genotypes
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N NA Participant roster ID
#'   \item SITEID N NA Site ID
#'   \item VISCODE T NA Visit code
#'   \item USERDATE S NA Date record created
#'   \item USERDATE2 S NA Date record last updated
#'   \item APTESTDT D NA Date Test Performed
#'   \item APGEN1 N NA Genotype - Allele 1
#'   \item APGEN2 N NA Genotype - Allele 2
#'   \item APVOLUME N NA Volume of Blood Shipped in Lavendar Top Tube
#'   \item APRECEIVE N NA Sample recieved within 24 hours of blood draw?
#'   \item APAMBTEMP N NA Sample shipped at ambient temperature?
#'   \item APRESAMP N NA Request Resample?
#'   \item APUSABLE N NA Sample Useable?
#' }
#'
#' @examples
#' \donotrun{
#' describe(apoego2)
#' }
#' @docType data
#' @keywords datasets
#' @name apoego2
#' @usage data(apoego2)
#' @format A data frame with 908 rows and 14 variables
NULL

#' ApoE Genotyping - Draw Data
#'
#'
#'
#'
#'
#'
#' @description See \url{http://adni.loni.usc.edu}.
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item APCOLLECT N NA Was DNA sample collected?
#'   \item RNACOLL N NA Was RNA sample collected?
#'   \item RNADATE D NA Date of RNA collection:
#'   \item RNATIME N NA Time of RNA collection:
#'   \item RNAVOL N NA Total Volume of Blood Drawn into 3 x 2.5 mL PAXgene RNA Tubes
#'   \item RNASHIP N NA Was the same shipment date and Fedex Tracking Number used to ship the RNA sample?
#'   \item RNAFEDEXDT D NA Date Fedexed
#'   \item RNAFEDEX N NA Fedex Tracking Number
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item EXAMDATE D  Examination Date
#'   \item APTIME T  Time of Blood Draw
#'   \item APFEDEXDT D  Date Fedexed
#'   \item APFEDEX N  Fedex Tracking Number
#'   \item APVOLUME N  Volume of Blood Drawn into Lavendar Top Tube
#'   \item APLICENSE N  6 digit License Plate Number
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name apoe
#' @usage data(apoe)
#' @format A data frame with 1513 rows and 21 variables
NULL

#' ApoE Genotyping - Results
#'
#'
#'
#'
#'
#'
#' @description See \url{http://adni.loni.usc.edu}.
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item APTESTDT D  Date Test Performed
#'   \item APGEN1 N  Genotype - Allele 1
#'   \item APGEN2 N  Genotype - Allele 2
#'   \item APVOLUME N  Volume of Blood Shipped in Lavendar Top Tube
#'   \item APRECEIVE N  Sample recieved within 24 hours of blood draw?
#'   \item APAMBTEMP N  Sample shipped at ambient temperature?
#'   \item APRESAMP N  Request Resample?
#'   \item APUSABLE N  Sample Useable?
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' apoeres$ApoE4 <- apply(apoeres[, c('APGEN1', 'APGEN2')]==4, 1, sum)>=1 
#' @docType data
#' @keywords datasets
#' @name apoeres
#' @usage data(apoeres)
#' @format A data frame with 1159 rows and 15 variables
NULL

#' Diagnosis and scan category assignment at screen
#'
#'
#'
#' @author \email{adni-data@googlegroups.com}
#'
#'
#' @description See \url{http://adni.loni.usc.edu}.
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item PTNO T  4 digit Participant Number
#'   \item TYPE T  ID Type
#'   \item ARM N  Diagnosis/Scan Category Assignment
#'   \item ENROLLED N  Enrollment Status
#'   \item USERDATE S  Date record created
#'   \item RANDDATE S  Randomization Date
#'   \item MAPPDATE S  Monitor Approval Date
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name arm
#' @usage data(arm)
#' @format A data frame with 4730 rows and 13 variables
NULL

#' AV-45 24-48 Hour Follow-Up
#'
#'
#'
#'
#'
#'
#' @description See \url{http://adni.loni.usc.edu}.
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N NA Participant roster ID
#'   \item SITEID N NA Site ID
#'   \item VISCODE T NA Visit code
#'   \item USERDATE S NA Date record created
#'   \item USERDATE2 S NA Date record last updated
#'   \item CONTACT N NA Was 24-48 hours post imaging follow-up telephone contact made?
#'   \item REASON T NA If No, please comment:
#'   \item CALLDATE D NA Date of telephone contact:
#'   \item CALLTIME N NA Time of telephone contact:
#'   \item CONTACTED N NA Person who was contacted:
#'   \item CALLAE N NA Were any Adverse Events reported?
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name av45follow
#' @usage data(av45follow)
#' @format A data frame with 1744 rows and 13 variables
NULL

#' AV-45 PET Scan Information
#'
#'
#'
#'
#'
#'
#' @description See \url{http://adni.loni.usc.edu}.
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RADTRACER N  If no, was radiotracer administered?
#'   \item PMAODONE N  Was scan started at time of injection?
#'   \item PMAOND N  If no, why?
#'   \item PMAONDOTH T  If other, specify:
#'   \item PMAOTIME T HH:MM:SS Early add on sequence start time:
#'   \item PMAOCOM T  Target start time for the early add on sequence is at the point of injection.  If more than 10 seconds after time of Florbetapir F18 injection, then please explain:
#'   \item AORECON N  Were all reconstruction parameters the same for the early add on sequence as the standard scan?
#'   \item AORECONDIF T  If no, please explain:
#'   \item RID N NA Participant roster ID
#'   \item SITEID N NA Site ID
#'   \item VISCODE T NA Visit code
#'   \item USERDATE S NA Date record created
#'   \item USERDATE2 S NA Date record last updated
#'   \item RECNO N NA 
#'   \item PMCONDCT N NA Was the scan conducted?
#'   \item PMREASON N NA Reason why the scan was not conducted:
#'   \item PMOTHSPE T NA If Other, specify:
#'   \item EXAMDATE D NA Examination Date
#'   \item PMSCANNER T NA GE
#'   \item PMGEMODEL N NA If GE, Scanner Model:
#'   \item PMSIEMENS T NA Siemens
#'   \item PMSIEMODEL N NA If Siemens, Scanner Model:
#'   \item PMPHILLIPS T NA Phillips
#'   \item PMPHMODEL N NA If Phillips, Scanner Model:
#'   \item PMQCTIME T NA Time of today's Scanner QC
#'   \item PMFDGTIME T NA Time of AV-45 dose assay
#'   \item PMFDGDOS N NA AV-45 dose assay
#'   \item PMFDGVOL N NA AV-45 Volume
#'   \item PMINJTIME T NA Time of AV-45 injection
#'   \item PMSCTIME T NA Emission Scan Start Time
#'   \item PMSCANCOM T NA <b>Target start time is 50 min AV-45 post-injection.</b>  Provide an explanation if start time is not between <b>48</b> and <b>52</b> min post-injection.
#'   \item PMVARIAT N NA Any variations from protocol during AV-45 uptake?
#'   \item PMVARSP T NA If Yes, describe:
#'   \item PMPROTID T NA Predefined Acquisition Protocol ID
#'   \item PMFRAME N NA Which framing rate was used?
#'   \item PMDEVIAT T NA If any deviations, describe:
#'   \item PMMOTION N NA Subject motion problems:
#'   \item PMMOTSP T NA If yes, describe:
#'   \item PMMALFUN N NA Scanner malfunction
#'   \item PMMALSP T NA If yes, describe:
#'   \item PMOTHER N NA Other protocol variations:
#'   \item PMOTHSP T NA If yes, describe:
#'   \item PMRECON N NA Check which of the following reconstructions was used:
#'   \item PMSUBSET N NA # subsets:
#'   \item PMSUBSPE N NA If Other, specify
#'   \item PMITERAT N NA # iterations:
#'   \item PMITERSPE N NA If Other, specify:
#'   \item PMRAMLA N NA If 3D-Ramla, Lambda=
#'   \item PMFILTER T NA If 3D Back-Projection, Ramp filter?
#'   \item PMMODEON N NA If FORE/2D-OSEM select one of the following:
#'   \item PMSMOOTH T NA No post-process smoothing:
#'   \item PMATTEN N NA Attenuation Correction:
#'   \item PMTRNSFR N NA Was data transferred to LONI within 24 hours of scan?
#'   \item PMTRNDATE D NA Transfer Date
#'   \item PMTRNCOM T NA Comments
#'   \item PMARCHIVE N NA Was all raw PET data archived locally to be able to do complete reconstruction of PET Scan if needed?
#'   \item PMARCMED T NA Archive Medium
#'   \item PMARCCOM T NA Comments
#'   \item PMLPDONE N NA Was a Lumbar Puncture completed prior to the AV-45 scan?
#'   \item PMLPINTER N NA If Yes, What was the interval between LP and AV-45?
#'   \item PMSHARP T NA Was "Smooth" parameter set to "Sharp"?
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name av45meta
#' @usage data(av45meta)
#' @format A data frame with 3389 rows and 63 variables
NULL

#' AV-45 PET QC Tracking
#'
#'
#'
#'
#'
#'
#' @description See \url{http://adni.loni.usc.edu}.
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N NA Participant roster ID
#'   \item SITEID N NA Site ID
#'   \item VISCODE T NA Visit code
#'   \item USERDATE S NA Date record created
#'   \item USERDATE2 S NA Date record last updated
#'   \item RECNO N NA 
#'   \item EXAMDATE D NA Examination Date
#'   \item PQFILENO N NA Upload Number
#'   \item PQDATTRA D NA Date images uploaded to LONI
#'   \item LONIUID T NA LONI Unique Series ID
#'   \item PQDATE D NA Date reviewed
#'   \item PQACQFR N NA Acquisition
#'   \item PQCORALG N NA Correct Reconstruction Algorithm?
#'   \item PQRECON N NA Check which of the following reconstruction algorithms was used
#'   \item PQCORNUM N NA If FORE/2D-OSEM, OSEM3D, or 3D Iterative, correct # subsets and iterations?
#'   \item PQCORFIL N NA Correct Filters/TRIM?
#'   \item PQCORTHI N NA Correct Slice Thickness (PET/CT systems)?
#'   \item PQVOXEL N NA Acceptable Voxel Size?
#'   \item PQALLFRAME N NA Were all frames acceptable?
#'   \item PQUNUSABLE T NA Indicate which frames were unacceptable:
#'   \item PQREASON T NA Indicate why frames were unacceptable:
#'   \item PQREASSP T NA If Other, Specify:
#'   \item PASS N NA Pass QC?
#'   \item PQPROERR T NA A. Processing Error(s)
#'   \item PQERRSP T NA Specify
#'   \item PQACTION N NA B. QC outcome
#'   \item PQISSUES T NA Imaging issues
#'   \item PQISSOTH T NA Other, specify
#'   \item COMMENTS T NA Additional QC Comments
#'   \item QUARANTINE N NA Release from quarantine?
#'   \item PAYSITE N NA Pay Site?
#'   \item SCAN N NA Scan
#'   \item PQNONESP T NA If unusable, reason for not rescanning
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name av45qc
#' @usage data(av45qc)
#' @format A data frame with 2707 rows and 35 variables
NULL

#' AV-45 Pre and Post Injection Vitals
#'
#'
#'
#'
#'
#'
#' @description See \url{http://adni.loni.usc.edu}.
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RECNO N  
#'   \item RID N NA Participant roster ID
#'   \item SITEID N NA Site ID
#'   \item VISCODE T NA Visit code
#'   \item USERDATE S NA Date record created
#'   \item USERDATE2 S NA Date record last updated
#'   \item SCANDONE N NA Was scan conducted?
#'   \item SCANDATE D NA AV-45 Scan Date:
#'   \item PREHEART N NA Heart Rate (bpm):
#'   \item PRERESP N NA Respiration (per minute):
#'   \item PRESYSTBP N NA Systolic Blood Pressure (mmHg):
#'   \item PREDIABP N NA Diastolic Blood Pressure (mmHg):
#'   \item PRETEMP N NA Temperature:
#'   \item POSTHEART N NA Heart Rate (bpm):
#'   \item POSTRESP N NA Respiration (per minute):
#'   \item POSTSYSTBP N NA Systolic Blood Pressure (mmHg):
#'   \item POSTDIABP N NA Diastolic Blood Pressure (mmHg):
#'   \item POSTTEMP N NA Temperature:
#'   \item PRETEMPU N NA Temperature Units:
#'   \item POSTTEMPU N NA Temperature Units:
#'   \item PRETEMPS N NA Temperature Source:
#'   \item POSTTEMPS N NA Temperature Source:
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name av45vitals
#' @usage data(av45vitals)
#' @format A data frame with 1801 rows and 24 variables
NULL

#' Average Jacobian - Temporal (Paul Thompson's Lab)
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/AVGJACOB/LONI_TBM_Protocol.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N -4 Participant roster ID
#'   \item SITEID N -4 Site ID
#'   \item VISCODE T -4 Visit code
#'   \item USERDATE S -4 Date record created
#'   \item RECNO N -4 
#'   \item EXAMDATE D -4 Examination Date
#'   \item IMAGEUID N -4 imageUID
#'   \item MEAN.ATROPHY.RATE.TEMPORAL.ROI N -4 
#'   \item PERCENT.CHANGE.TEMPORAL.ROI N -4 
#'   \item PERCENT.CHANGE.STAT.ROI N -4 
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name avgjacob
#' @usage data(avgjacob)
#' @format A data frame with 3760 rows and 11 variables
NULL

#' Biomarkers Consortium ADNI CSF BACE activity and sAPPbeta
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/BACEAPPBETA/Biomarkers_Consortium_Data_Primer_for_ADNI_CSF_BACE_activity_and_sAPPbeta_2012April10.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item USERDATE -4  Date record created
#'   \item GROUP -4  Group
#'   \item RID -4  Participant roster ID
#'   \item LICENSEPLATE -4  License Plate #
#'   \item SPECIMENID -4  Specimen ID
#'   \item GLOBALSPECID -4  Global Spec ID
#'   \item VISCODE -4  Visit code
#'   \item SPECDATE -4  Spec Date
#'   \item RECEIVEDDATE -4  Received Date
#'   \item CSFBACE -4 pM CSF BACE
#'   \item CSFSAPPBETA -4 pM CSF sAPP Beta
#' }
#'
#' @examples
#' \donotrun{
#' describe(baceappbeta)
#' }
#' @docType data
#' @keywords datasets
#' @name baceappbeta
#' @usage data(baceappbeta)
#' @format A data frame with 402 rows and 12 variables
NULL

#' Key Background Medications
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N NA Participant roster ID
#'   \item SITEID N NA Site ID
#'   \item VISCODE T NA Visit code
#'   \item USERDATE S NA Date record created
#'   \item USERDATE2 S NA Date record last updated
#'   \item KEYMED T NA At this visit, is participant on any of the following medication?
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name backmeds
#' @usage data(backmeds)
#' @format A data frame with 8818 rows and 8 variables
NULL

#' Banner Alzheimer's Institute MRI NMRC Summaries
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item VISCODE2 -4 -4 Translated visit code
#'   \item EXAMDATE -4 -4 Examination Date
#'   \item VERSION -4  Version of Table
#'   \item LONIUID -4 -4 -4
#'   \item RUNDATE -4  DATE analysis performed
#'   \item STATUS -4  Complete/Incomplete
#'   \item IPCA -4 Percentage  percent annualized whole brain atrophy detected by Iterative Principal component Analysis (IPCA) 
#'   \item IPCA2 -4 unitless whole brain atrophy measured from T1 weighted MRI using iterative pincipal component analysis 
#' }
#'
#' @examples
#' \donotrun{
#' describe(baimrinmrc)
#' }
#' @docType data
#' @keywords datasets
#' @name baimrinmrc
#' @usage data(baimrinmrc)
#' @format A data frame with 726 rows and 10 variables
NULL

#' Banner Alzheimer's Institute PET NMRC Summaries
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/BAIPETNMRC/BAI_HCI.pdf}, \url{https://adni.bitbucket.io/reference/docs/BAIPETNMRC/Banner_HCIsROI%20trajectories%20prior%20to%20disease%20onset%202016%2008.pdf}, \url{https://adni.bitbucket.io/reference/docs/BAIPETNMRC/Banner_SUVRwithCerebralWMRefROI_forLongitudinalFlorbetapirPET%202016%2008.pdf}, \url{https://adni.bitbucket.io/reference/docs/BAIPETNMRC/Banner_SUVRwithCerebralWMRefROI_forLongitudinalFlorbetapirPET.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4  Participant roster ID
#'   \item VISCODE -4  Visit code
#'   \item VISCODE2 -4 -4 Translated visit code
#'   \item EXAMDATE -4  Examination Date
#'   \item VERSION -4  Version of Table
#'   \item LONIUID -4  LONI Unique Image Identifier
#'   \item RUNDATE -4  DATE analysis performed
#'   \item STATUS -4  Complete/Incomplete
#'   \item MODALITY -4  AV45/FDG/TAU
#'   \item HIPPL01 -4 Normalized Counts Globally normalized CMRgl from Hippocampus_L
#'   \item FRTSUPL01 -4 Normalized Counts Globally normalized CMRgl from Frontal_sup_L
#'   \item FRTMIDL01 -4 Normalized Counts Globally normalized CMRgl from Frontal_mid_L
#'   \item PARAHIPL01 -4 Normalized Counts Globally normalized CMRgl from ParaHippocampal_L
#'   \item FUSFRML01 -4 Normalized Counts Globally normalized CMRgl from Fusiform_L
#'   \item OCCMIDL01 -4 Normalized Counts Globally normalized CMRgl from Occipital_mid_L
#'   \item ANGULL01 -4 Normalized Counts Globally normalized CMRgl from Angular_L
#'   \item PARIINFL01 -4 Normalized Counts Globally normalized CMRgl from Parietal_Inf_L
#'   \item SUPMRGL01 -4 Normalized Counts Globally normalized CMRgl from SupraMarginal_L
#'   \item TMPMIDL01 -4 Normalized Counts Globally normalized CMRgl from Temporal _mid_L
#'   \item PRECUNL01 -4 Normalized Counts Globally normalized CMRgl from Precuneus_L
#'   \item CINGPSTL01 -4 Normalized Counts Globally normalized CMRgl from Cingulum_Post_L
#'   \item PARAHIPR01 -4 Normalized Counts Globally normalized CMRgl from ParaHippocampal_R
#'   \item FRTSUPR01 -4 Normalized Counts Globally normalized CMRgl from Frontal_Sup_R
#'   \item OCCMIDR01 -4 Normalized Counts Globally normalized CMRgl from Occipital_mid_R
#'   \item FUSFRMR01 -4 Normalized Counts Globally normalized CMRgl from Fusiform_R
#'   \item FRTMIDR01 -4 Normalized Counts Globally normalized CMRgl from Frontal_mid_R
#'   \item ANGULR01 -4 Normalized Counts Globally normalized CMRgl from Angular_R
#'   \item PARIINFR01 -4 Normalized Counts Globally normalized CMRgl from Parietal_Inf_R
#'   \item TMPMIDR01 -4 Normalized Counts Globally normalized CMRgl from Temporal_mid_R
#'   \item SUPMRGR01 -4 Normalized Counts Globally normalized CMRgl from SupraMarginal_R
#'   \item PRCUNSR01 -4 Normalized Counts Globally normalized CMRgl from Prcuneus_R
#'   \item HIPPR01 -4 Normalized Counts Globally normalized CMRgl from Hippocampus_R
#'   \item LINGUALL01 -4 Normalized Counts Globally normalized CMRgl from Lingual_L
#'   \item LINGUALR01 -4 Normalized Counts Globally normalized CMRgl from Lingual_R
#'   \item CINGPSTR01 -4 Normalized Counts Globally normalized CMRgl from Cingulum_Post_R
#'   \item FRTINFL01 -4 Normalized Counts Globally normalized CMRgl from Frontal_Inf_L
#'   \item FRTINFR01 -4 Normalized Counts Globally normalized CMRgl from Frontal_Inf_R
#'   \item PARISUPL01 -4 Normalized Counts Globally normalized CMRgl from Parietal_Sup_L
#'   \item PARISUPR01 -4 Normalized Counts Globally normalized CMRgl from Parietal_Sup_R
#'   \item INSULAL01 -4 Normalized Counts Globally normalized CMRgl from Insula_L
#'   \item INSULAR01 -4 Normalized Counts Globally normalized CMRgl from Insula_R
#'   \item CINGANTL01 -4 Normalized Counts Globally normalized CMRgl from Cingulum_Ant_L
#'   \item CINGANTR01 -4 Normalized Counts Globally normalized CMRgl from Cingulum_Ant_R
#'   \item CINGMIDL01 -4 Normalized Counts Globally normalized CMRgl from Cingulum_Mid_L
#'   \item CINGMIDR01 -4 Normalized Counts Globally normalized CMRgl from Cingulum_Mid_R
#'   \item TMPSUPL01 -4 Normalized Counts Globally normalized CMRgl from Temporal _Sup_L
#'   \item TMPSUPR01 -4 Normalized Counts Globally normalized CMRgl from Temporal _Sup_R
#'   \item TMPINFL01 -4 Normalized Counts Globally normalized CMRgl from Temporal_Inf_L
#'   \item TMPINFR01 -4 Normalized Counts Globally normalized CMRgl from Temporal_Inf_R
#'   \item FRTSUPL02 -4 Normalized Counts Globally normalized CMRgl from Frontal_Sup_L
#'   \item FRTMIDL02 -4 Normalized Counts Globally normalized CMRgl from Frontal_Mid_L
#'   \item CINGPSTL02 -4 Normalized Counts Globally normalized CMRgl from Cingulum_Post_L
#'   \item CINGMIDL02 -4 Normalized Counts Globally normalized CMRgl from Cingulum_Mid_L
#'   \item FRTSMEDL02 -4 Normalized Counts Globally normalized CMRgl from Frontal_Sup_Medial_L
#'   \item FUSFRML02 -4 Normalized Counts Globally normalized CMRgl from Fusiform_L
#'   \item TMPMIDL02 -4 Normalized Counts Globally normalized CMRgl from Temporal_Mid_L
#'   \item OCCMIDL02 -4 Normalized Counts Globally normalized CMRgl from Occipital_Mid_L
#'   \item TMPINFL02 -4 Normalized Counts Globally normalized CMRgl from Temporal_Inf_L
#'   \item PRECUNL02 -4 Normalized Counts Globally normalized CMRgl from Precuneus_L
#'   \item CINGANTL02 -4 Normalized Counts Globally normalized CMRgl from Cingulum_Ant_L
#'   \item FRTMIDOR02 -4 Normalized Counts Globally normalized CMRgl from Frontal_Mid_Orb_R
#'   \item FRTMIDR02 -4 Normalized Counts Globally normalized CMRgl from Frontal_Mid_R
#'   \item FRTSUPR02 -4 Normalized Counts Globally normalized CMRgl from Frontal_Sup_R
#'   \item ANGULR02 -4 Normalized Counts Globally normalized CMRgl from Angular_R
#'   \item ANGULL02 -4 Normalized Counts Globally normalized CMRgl from Angular_L
#'   \item PARIINFR02 -4 Normalized Counts Globally normalized CMRgl from Parietal_Inf_R
#'   \item TMPMIDR02 -4 Normalized Counts Globally normalized CMRgl from Temporal_Mid_R
#'   \item INSULAR02 -4 Normalized Counts Globally normalized CMRgl from Insula_R
#'   \item TMPPOSR02 -4 Normalized Counts Globally normalized CMRgl from Temporal_Pole_Sup_R
#'   \item CINGANTR02 -4 Normalized Counts Globally normalized CMRgl from Cingulum_Ant_R
#'   \item CINGMIDR02 -4 Normalized Counts Globally normalized CMRgl from Cingulum_Mid_R
#'   \item PRECUNR02 -4 Normalized Counts Globally normalized CMRgl from Precuneus_R
#'   \item RECTUSR02 -4 Normalized Counts Globally normalized CMRgl from Rectus_R
#'   \item CINGPSTR02 -4 Normalized Counts Globally normalized CMRgl from Cingulum_Post_R
#'   \item PARIINFL02 -4 Normalized Counts Globally normalized CMRgl from Parietal_Inf_L
#'   \item INSULAL02 -4 Normalized Counts Globally normalized CMRgl from Insula_L
#'   \item FRTINFL02 -4 Normalized Counts Globally normalized CMRgl from Frontal_Inf_L
#'   \item FRTINFR02 -4 Normalized Counts Globally normalized CMRgl from Frontal_Inf_R
#'   \item OCCMIDR02 -4 Normalized Counts Globally normalized CMRgl from Occipital_Mid_R
#'   \item FRTMIDOL02 -4 Normalized Counts Globally normalized CMRgl from Frontal_Mid_Orb_Right
#'   \item FRTSMEDR02 -4 Normalized Counts Globally normalized CMRgl from Frontal_Sup_Medial_R
#'   \item FUSFMR02 -4 Normalized Counts Globally normalized CMRgl from Fusiform_R
#'   \item RECTUSL02 -4 Normalized Counts Globally normalized CMRgl from Rectus_L
#'   \item TMPPOSL02 -4 Normalized Counts Globally normalized CMRgl from Temporal_Pole_Sup_L
#'   \item PARISUPL02 -4 Normalized Counts Globally normalized CMRgl from Parietal_Sup_L
#'   \item PARISUPR02 -4 Normalized Counts Globally normalized CMRgl from Parietal_Sup_L
#'   \item SUPMRGL02 -4 Normalized Counts Globally normalized CMRgl from SupraMarginal_L
#'   \item SUPMRGR02 -4 Normalized Counts Globally normalized CMRgl from SupraMarginal_R
#'   \item TMPINFR02 -4 Normalized Counts Globally normalized CMRgl from Temporal_Inf_L
#'   \item FRTMIDL03 -4 Normalized Counts Frontal_Mid_L
#'   \item FRTMIDR03 -4 Normalized Counts Frontal_Mid_R
#'   \item FRTSUPL03 -4 Normalized Counts Frontal_Sup_L
#'   \item FRTSUPR03 -4 Normalized Counts Frontal_Sup_R
#'   \item FRTSMEDL03 -4 Normalized Counts Frontal_Sup_Medial_L
#'   \item FRTSMEDR03 -4 Normalized Counts Frontal_Sup_Medial_R
#'   \item TMPSUPL03 -4 Normalized Counts Temporal_Sup_L
#'   \item TMPSUPR03 -4 Normalized Counts Temporal_Sup_R
#'   \item TMPMIDL03 -4 Normalized Counts Temporal_Mid_L
#'   \item TMPMIDR03 -4 Normalized Counts Temporal_Mid_R
#'   \item TMPINFL03 -4 Normalized Counts Temporal_Inf_L
#'   \item TMPINFR03 -4 Normalized Counts Temporal_Inf_R
#'   \item FUSFRML03 -4 Normalized Counts Fusiform_L
#'   \item FUSFRMR03 -4 Normalized Counts Fusiform_R
#'   \item LINGUALL03 -4 Normalized Counts Lingual_L
#'   \item LINGUALR03 -4 Normalized Counts Lingual_R
#'   \item PARAHIPL03 -4 Normalized Counts ParaHippocampal_L
#'   \item PARAHIPR03 -4 Normalized Counts ParaHippocampal_R
#'   \item PARISUPL03 -4 Normalized Counts Parietal_Sup_L
#'   \item PARISUPR03 -4 Normalized Counts Parietal_Sup_R
#'   \item PARIINFL03 -4 Normalized Counts Parietal_Inf_L
#'   \item PARIINFR03 -4 Normalized Counts Parietal_Inf_R
#'   \item PRECUNL03 -4 Normalized Counts Precuneus_L
#'   \item PRECUNR03 -4 Normalized Counts Precuneus_R
#'   \item CINGANT03 -4 Normalized Counts Cingulum_Ant
#'   \item CINGMID03 -4 Normalized Counts Cingulum_Mid
#'   \item CINGPST03 -4 Normalized Counts Cingulum_Post
#'   \item ANGULR03 -4 Normalized Counts Angular_R
#'   \item OCCMIDL03 -4 Normalized Counts Occipital_Mid_L
#'   \item OCCMIDR03 -4 Normalized Counts Occipital_Mid_R
#'   \item OCCSUPL03 -4 Normalized Counts Occipital_Sup_L
#'   \item OCCSUPR03 -4 Normalized Counts Occipital_Sup_R
#'   \item OCCINFL03 -4 Normalized Counts Occipital_Inf_L
#'   \item OCCINFR03 -4 Normalized Counts Occipital_Inf_R
#'   \item THALAML03 -4 Normalized Counts Thalamus_L
#'   \item THALAMR03 -4 Normalized Counts Thalamus_R
#'   \item FRTMEDL03 -4 Normalized Counts Frontal_Medial_Left
#'   \item FRTMEDR03 -4 Normalized Counts Frontal_Medial_Right
#'   \item SUPMRGL03 -4 Normalized Counts SupraMarginal_L
#'   \item SUPMRGR03 -4 Normalized Counts SupraMarginal_R
#'   \item FRTMIDL04 -4 Normalized Counts Frontal_Mid_L
#'   \item FRTMIDR04 -4 Normalized Counts Frontal_Mid_R
#'   \item FRTSUPL04 -4 Normalized Counts Frontal_Sup_L
#'   \item FRTSUPR04 -4 Normalized Counts Frontal_Sup_R
#'   \item FRTSMEDL04 -4 Normalized Counts Frontal_Sup_Medial_L
#'   \item FRTSMEDR04 -4 Normalized Counts Frontal_Sup_Medial_R
#'   \item TMPSUPL04 -4 Normalized Counts Temporal_Sup_L
#'   \item TMPSUPR04 -4 Normalized Counts Temporal_Sup_R
#'   \item TMPMIDL04 -4 Normalized Counts Temporal_Mid_L
#'   \item TMPMIDR04 -4 Normalized Counts Temporal_Mid_R
#'   \item TMPINFL04 -4 Normalized Counts Temporal_Inf_L
#'   \item TMPINFR04 -4 Normalized Counts Temporal_Inf_R
#'   \item FUSFRML04 -4 Normalized Counts Fusiform_L
#'   \item FUSFRMR04 -4 Normalized Counts Fusiform_R
#'   \item LINGUALL04 -4 Normalized Counts Lingual_L
#'   \item LINGUALR04 -4 Normalized Counts Lingual_R
#'   \item PARAHIPL04 -4 Normalized Counts ParaHippocampal_L
#'   \item PARAHIPR04 -4 Normalized Counts ParaHippocampal_R
#'   \item PARISUPL04 -4 Normalized Counts Parietal_Sup_L
#'   \item PARISUPR04 -4 Normalized Counts Parietal_Sup_R
#'   \item PARIINFL04 -4 Normalized Counts Parietal_Inf_L
#'   \item PARIINFR04 -4 Normalized Counts Parietal_Inf_R
#'   \item PRECUNL04 -4 Normalized Counts Precuneus_L
#'   \item PRECUNR04 -4 Normalized Counts Precuneus_R
#'   \item CINGANT04 -4 Normalized Counts Cingulum_Ant
#'   \item CINGMID04 -4 Normalized Counts Cingulum_Mid
#'   \item CINGPST04 -4 Normalized Counts Cingulum_Post
#'   \item OCCMIDL04 -4 Normalized Counts Occipital_Mid_L
#'   \item OCCMIDR04 -4 Normalized Counts Occipital_Mid_R
#'   \item OCCSUPL04 -4 Normalized Counts Occipital_Sup_L
#'   \item OCCSUPR04 -4 Normalized Counts Occipital_Sup_R
#'   \item OCCINFL04 -4 Normalized Counts Occipital_Inf_L
#'   \item OCCINFR04 -4 Normalized Counts Occipital_Inf_R
#'   \item THALAML04 -4 Normalized Counts Thalamus_L
#'   \item THALAMR04 -4 Normalized Counts Thalamus_R
#'   \item FRTMEDL04 -4 Normalized Counts Frontal_Medial_Left
#'   \item FRTMEDR04 -4 Normalized Counts Frontal_Medial_Right
#'   \item SUPMRGL04 -4 Normalized Counts SupraMarginal_L
#'   \item SUPMRGR04 -4 Normalized Counts SupraMarginal_R
#'   \item ANGULL04 -4 Normalized Counts Angular_L
#'   \item ANGULR04 -4 Normalized Counts Angular_R
#'   \item FRTMIDL05 -4 Normalized Counts Frontal_Mid_L
#'   \item FRTMIDR05 -4 Normalized Counts Frontal_Mid_R
#'   \item FRTSUPL05 -4 Normalized Counts Frontal_Sup_L
#'   \item FRTSUPR05 -4 Normalized Counts Frontal_Sup_R
#'   \item FRTSMEDL05 -4 Normalized Counts Frontal_Sup_Medial_L
#'   \item FRTSMEDR05 -4 Normalized Counts Frontal_Sup_Medial_R
#'   \item TMPSUPL05 -4 Normalized Counts Temporal_Sup_L
#'   \item TMPSUPR05 -4 Normalized Counts Temporal_Sup_R
#'   \item TMPMIDL05 -4 Normalized Counts Temporal_Mid_L
#'   \item TMPMIDR05 -4 Normalized Counts Temporal_Mid_R
#'   \item TMPINFL05 -4 Normalized Counts Temporal_Inf_L
#'   \item TMPINFR05 -4 Normalized Counts Temporal_Inf_R
#'   \item FUSFRML05 -4 Normalized Counts Fusiform_L
#'   \item FUSFRMR05 -4 Normalized Counts Fusiform_R
#'   \item PARAHIPL05 -4 Normalized Counts ParaHippocampal_L
#'   \item PARAHIPR05 -4 Normalized Counts ParaHippocampal_R
#'   \item PARISUPL05 -4 Normalized Counts Parietal_Sup_L
#'   \item PARISUPR05 -4 Normalized Counts Parietal_Sup_R
#'   \item PARIINFL05 -4 Normalized Counts Parietal_Inf_L
#'   \item PARIINFR05 -4 Normalized Counts Parietal_Inf_R
#'   \item PRECUNL05 -4 Normalized Counts Precuneus_L
#'   \item PRECUNR05 -4 Normalized Counts Precuneus_R
#'   \item CINGANT05 -4 Normalized Counts Cingulum_Ant
#'   \item CINGMID05 -4 Normalized Counts Cingulum_Mid
#'   \item CINGPST05 -4 Normalized Counts Cingulum_Post
#'   \item OCCMIDL05 -4 Normalized Counts Occipital_Mid_L
#'   \item OCCMIDR05 -4 Normalized Counts Occipital_Mid_R
#'   \item OCCSUPL05 -4 Normalized Counts Occipital_Sup_L
#'   \item OCCSUPR05 -4 Normalized Counts Occipital_Sup_R
#'   \item OCCINFL05 -4 Normalized Counts Occipital_Inf_L
#'   \item OCCINFR05 -4 Normalized Counts Occipital_Inf_R
#'   \item THALAML05 -4 Normalized Counts Thalamus_L
#'   \item THALAMR05 -4 Normalized Counts Thalamus_R
#'   \item FRTMEDL05 -4 Normalized Counts Frontal_Medial_Left
#'   \item FRTMEDR05 -4 Normalized Counts Frontal_Medial_Right
#'   \item ANGULR05 -4 Normalized Counts Angular_Right
#'   \item ANGULL05 -4 Normalized Counts Angular_Left
#'   \item CALCARL05 -4 Normalized Counts Calcarine_L
#'   \item CALCARR05 -4 Normalized Counts Calcarine_R
#'   \item LINGUALL05 -4 Normalized Counts Lingual_L
#'   \item LINGUALR05 -4 Normalized Counts Lingual_R
#'   \item CEREB8L05 -4 Normalized Counts Cerebelum_8_L
#'   \item CEREB8R05 -4 Normalized Counts Cerebelum_8_R
#'   \item CERBCR2L05 -4 Normalized Counts Cerebelum_Crus2_L
#'   \item CERBCR2R05 -4 Normalized Counts Cerebelum_Crus2_R
#'   \item SUPMRGL05 -4 Normalized Counts SupraMarginal_L
#'   \item SUPMRGR05 -4 Normalized Counts SupraMarginal_R
#'   \item FRTMIDL06 -4 Normalized Counts Frontal_Mid_L
#'   \item FRTMIDR06 -4 Normalized Counts Frontal_Mid_R
#'   \item FRTSUPL06 -4 Normalized Counts Frontal_Sup_L
#'   \item FRTSUPR06 -4 Normalized Counts Frontal_Sup_R
#'   \item FRTSMEDL06 -4 Normalized Counts Frontal_Sup_Medial_L
#'   \item FRTSMEDR06 -4 Normalized Counts Frontal_Sup_Medial_R
#'   \item TMPSUPL06 -4 Normalized Counts Temporal_Sup_L
#'   \item TMPSUPR06 -4 Normalized Counts Temporal_Sup_R
#'   \item TMPMIDL06 -4 Normalized Counts Temporal_Mid_L
#'   \item TMPMIDR06 -4 Normalized Counts Temporal_Mid_R
#'   \item TMPINFL06 -4 Normalized Counts Temporal_Inf_L
#'   \item TMPINFR06 -4 Normalized Counts Temporal_Inf_R
#'   \item FUSFRML06 -4 Normalized Counts Fusiform_L
#'   \item FUSFRMR06 -4 Normalized Counts Fusiform_R
#'   \item LINGUALL06 -4 Normalized Counts Lingual_L
#'   \item LINGUALR06 -4 Normalized Counts Lingual_R
#'   \item PARAHIPL06 -4 Normalized Counts ParaHippocampal_L
#'   \item PARAHIPR06 -4 Normalized Counts ParaHippocampal_R
#'   \item PARISUPL06 -4 Normalized Counts Parietal_Sup_L
#'   \item PARISUPR06 -4 Normalized Counts Parietal_Sup_R
#'   \item PARIINFL06 -4 Normalized Counts Parietal_Inf_L
#'   \item PARIINFR06 -4 Normalized Counts Parietal_Inf_R
#'   \item PRECUNL06 -4 Normalized Counts Precuneus_L
#'   \item PRECUNR06 -4 Normalized Counts Precuneus_R
#'   \item CINGANT06 -4 Normalized Counts Cingulum_Ant
#'   \item CINGMID06 -4 Normalized Counts Cingulum_Mid
#'   \item CINGPST06 -4 Normalized Counts Cingulum_Post
#'   \item OCCMIDL06 -4 Normalized Counts Occipital_Mid_L
#'   \item OCCMIDR06 -4 Normalized Counts Occipital_Mid_R
#'   \item OCCSUPL06 -4 Normalized Counts Occipital_Sup_L
#'   \item OCCSUPR06 -4 Normalized Counts Occipital_Sup_R
#'   \item OCCINFL06 -4 Normalized Counts Occipital_Inf_L
#'   \item OCCINFR06 -4 Normalized Counts Occipital_Inf_R
#'   \item THALAML06 -4 Normalized Counts Thalamus_L
#'   \item THALAMR06 -4 Normalized Counts Thalamus_R
#'   \item FRTMEDL06 -4 Normalized Counts Frontal_Medial_Left
#'   \item FRTMEDR06 -4 Normalized Counts Frontal_Medial_Right
#'   \item HIPPL06 -4 Normalized Counts Hippocampus_L
#'   \item HIPPR06 -4 Normalized Counts Hippocampus_R
#'   \item INDGLBNDX -4 Percentage Individualized Global Index
#'   \item INDTEPNDX -4 Percentage Individualized Temporal index 
#'   \item PRECUNL07 -4 Normalized Counts Precuneus_L
#'   \item CINGPST07 -4 Normalized Counts Cingulum_Post
#'   \item PARIINFR07 -4 Normalized Counts Parietal_Inf_R
#'   \item TMPMIDL07 -4 Normalized Counts Temporal_Mid_L
#'   \item CUNEUSL08 -4 Normalized Counts Cuneus_L
#'   \item TMPMIDR08 -4 Normalized Counts Temporal_Mid_R
#'   \item TMPINFL09 -4 Normalized Counts Temporal_Inf_L
#'   \item CINGPST09 -4 Normalized Counts Cingulum_Post
#'   \item PRECUNL09 -4 Normalized Counts Precuneus_L
#'   \item PARIINFR09 -4 Normalized Counts Parietal_Inf_R
#'   \item TMPINFL10 -4 Normalized Counts Temporal_Inf_L
#'   \item PRECUNL10 -4 Normalized Counts Precuneus_L
#'   \item TMPINFL11 -4 Normalized Counts Temporal_Inf_L
#'   \item OCCMIDL11 -4 Normalized Counts Occipital_Mid_L
#'   \item CINGPST11 -4 Normalized Counts Cingulum_Post_L
#'   \item CINGMID11 -4 Normalized Counts Cingulum_Post_R/Cingulum_Mid_R
#'   \item TMPPOSR12 -4 Normalized Counts Temporal_Pole_Sup_R
#'   \item CINGPSTR12 -4 Normalized Counts Cingulum_Post_R/Cingulum_Mid_R
#'   \item FROITRN001 -4 Normalized Counts Training group, all subjects
#'   \item FROITRN002 -4 Normalized Counts Training group, exclude HRRT and BioGraph HiRez
#'   \item FROITST001 -4 Normalized Counts Testing group, all scans
#'   \item FROITST002 -4 Normalized Counts Testing group, exclude HRRT and BioGraph HiRez
#'   \item FROIWHL001 -4 Normalized Counts All subjects
#'   \item FROIWHL002 -4 Normalized Counts Exclude HRRT and BioGraph HiRez
#'   \item FRPMSK001 -4 Normalized Counts Exclude HRRT and BioGraph HiRez
#'   \item FRPMSK002 -4 Normalized Counts All subjects
#'   \item FRTMSK003 -4 Normalized Counts Exclude HRRT and BioGraph HiRez
#'   \item FRTMSK004 -4 Normalized Counts All subjects
#'   \item FRTMSK005 -4 Normalized Counts All subjects
#'   \item FRTMSK006 -4 Normalized Counts All subjects
#'   \item FRTMSK007 -4 Normalized Counts All subjects
#'   \item FRTMSK008 -4 Normalized Counts Exclude HRRT and BioGraph HiRez
#'   \item FRTMSK009 -4 Normalized Counts All subjects
#'   \item FRTMSK010 -4 Normalized Counts Exclude HRRT and BioGraph HiRez
#'   \item FRTMSK011 -4 Normalized Counts All subjects
#'   \item HCISUB1 -4 unitless hypometabolic convergence index for 74 AD subjects
#'   \item HCI99 -4 unitless hypometabolic convergence index for normal controls, stable MCI, MCI converter and ADs
#'   \item HCI -4 unitless hypometabolic convergence index for ADNI1/ADNI2/ADNIGO subjects
#'   \item NL1HIPP -4 Normalized Counts difference of globally normalized CMRgl from Baseline to 12 months and 12 months to 24 months from Hippocampus for 58 AD patients
#'   \item NL1PTEMP -4 Normalized Counts difference of globally normalized CMRgl from Baseline to 12 months and 12 months to 24 months from the parietotemporal region for 58 AD patients
#'   \item NL1PSTCG -4 Normalized Counts difference of globally normalized CMRgl from Baseline to 12 months and 12 months to 24 months from the posterior cingulate for for 58 AD patients
#'   \item NL2PSTCG -4 Normalized Counts difference of globally normalized CMRgl from Baseline to 12 months and 12 months to 24 months from Posterior Cingulate in 129 MCIs.
#'   \item NL2PARI -4 Normalized Counts difference of globally normalized CMRgl from 12 months to 24 months from the inferior parietal region in 129 MCI subjects
#'   \item NL3FRONT -4 Normalized Counts difference of globally normalized CMRgl from Baseline to 12 months and 12 months to 24 months from superior frontal region of 74 normal controls.
#'   \item DECLADFR -4 Normalized Counts difference of globally normalized CMRgl from Baseline to 12 months from the superior frontal region of 74 AD patients
#'   \item DECLADTMP -4 Normalized Counts CMRgl from Baseline from the inferior temporal region of 74 AD patients
#'   \item LONGHCI -4 unitless Extension of HCI to longitudinal data
#'   \item BSLVBM -4 unitless VBManalysis of structural MRI data
#'   \item ACI -4 unitless amyloid convergence index for AV-45 subjects
#'   \item MCSUVR -4 unitless mean cortical standard uptake value ratio
#'   \item FNMPREC -4 unitless precuneus FDG measure
#'   \item FNAPREC -4 unitless precuneus FDG measure
#'   \item FNAPC -4 unitless posterior cingulate FDG measure
#'   \item FEAPREC -4 unitless precuneus FDG measure
#'   \item FMAPREC -4 unitless precuneus FDG measure
#'   \item FMAPC -4 unitless posterior cingulate FDG measure
#'   \item AVNEFRONT -4 unitless frontal AV-45 measure
#'   \item AVNMFRONT -4 unitless frontal AV-45 measure
#'   \item AVNAFRONT -4 unitless frontal AV-45 measure
#'   \item AVEMTEMP -4 unitless temporal AV-45 measure
#'   \item AVEATEMP -4 unitless temporal AV-45 measure 
#'   \item AVMAOCCIP -4 unitless occipital AV-45 measure
#'   \item FEAPC2 -4 unitless posterior cingulate FDG measure
#'   \item FEMPC2 -4 unitless posterior cingulate FDG measure
#'   \item FMAPREC2 -4 unitless precuneus FDG measure
#'   \item FNAPARI2 -4 unitless parietal FDG measure
#'   \item FNEHC2 -4 unitless hippocampal FDG measure
#'   \item FNMTEMP2 -4 unitless temporal FDG measure
#'   \item AVEATEMP2 -4 unitless temporal AV-45 measure
#'   \item AVEMTEMP2 -4 unitless temporal AV-45 measure
#'   \item AVMAFRNT2 -4 unitless frontal AV-45 measure
#'   \item AVNATEMP2 -4 unitless temporal AV-45 measure
#'   \item AVNEFRNT2 -4 unitless frontal AV-45 measure
#'   \item AVNMPREC2 -4 unitless precuneus AV-45 measure
#'   \item MMPLS -4 unitless AVfdgPLS
#'   \item ICA -4 unitless AV_ICA
#'   \item PCA2 -4 unitless AV_SSM
#'   \item PLSFDG01 -4 unitless PLS for FDG PET
#'   \item HCI001 -4 unitless Hypometabolic Convergence Index
#'   \item MCSUVRWM -4 unitless Mean Cortical SUVR Corpus Callosum and Centrum Semiovale Combined
#'   \item MCSUVRWM2 -4 unitless Mean Cortical SUVR Corpus Callosum and Centrum Semiovale Combined
#'   \item HCI_2014 -4 unitless Hypometabolic Convergence Index
#'   \item SROI -4 unitless statistical region of interest (sROI) developed and validated for optimal longitudinal FDG-PET CMRgl changes
#'   \item MCSUVRWM3 -4 unitless Mean Cortical SUVR with Corpus Callosum and Centrum Semiovale Combined as reference region
#'   \item MCSUVRCERE -4 unitless Mean Cortical SUVR with Cerebellum as reference region
#' }
#'
#' @examples
#' \donotrun{
#' describe(baipetnmrc)
#' }
#' @docType data
#' @keywords datasets
#' @name baipetnmrc
#' @usage data(baipetnmrc)
#' @format A data frame with 5537 rows and 343 variables
NULL

#' Brain Health Registry
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item DONE N NA Was BHR brochure given to participant and BHR Study Partner Flyer given to the study partner?
#'   \item NDREASON N NA If No, reason not done:
#'   \item EXAMDATE D YYYY-MM-DD Examination Date
#'   \item WRITTEN N NA If Yes, was the ADNI Online ID written down on the participant's brochure?
#'   \item CBBCOMM T NA Comments:
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' \donotrun{
#' describe(bhr)
#' }
#' @docType data
#' @keywords datasets
#' @name bhr
#' @usage data(bhr)
#' @format A data frame with 343 rows and 12 variables
NULL

#' Biomarker Samples Tracking and QC
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item DRAWDATE D YYYY-MM-DD Sample Collection Date
#'   \item RECPLASMA N NA Plasma received?
#'   \item PLASMAQC N NA If yes, quality
#'   \item RECSERUM N NA Serum received?
#'   \item SERUMQC N NA If yes, quality
#'   \item RECCSF N NA CSF received?
#'   \item CSFQC N NA If yes, quality
#'   \item REDRAW N NA Notify the Monitor (e.g. to request redraw or other quality issues)?
#'   \item COMM T NA Comments
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' \donotrun{
#' describe(biomarkqc)
#' }
#' @docType data
#' @keywords datasets
#' @name biomarkqc
#' @usage data(biomarkqc)
#' @format A data frame with 408 rows and 16 variables
NULL

#' Biomarker Samples
#'
#'
#'
#' @author \email{adni-data@googlegroups.com}
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item BILPOTPROC N NA Check if any of the following was performed
#'   \item REASON N  If no, please provide reason why the LP was not conducted
#'   \item REASONO T  If other, specify
#'   \item NEEDLESIZE N  Needle Gauge
#'   \item COLTUBETYP N  Type of collection tube used
#'   \item SHPTUBETYP N  Type of tube used for shipping
#'   \item TUBEMIN N minutes If collected in polystyrene and shipped in polypropylene, please provide estimated amount of time CSF remained in polystyrene collection tube
#'   \item INTERSPACE N  LP performed at the
#'   \item PTPOSITION N  Patient Position
#'   \item BLREASON N  If no, please provide reason why blood was not collected
#'   \item BLREASONO T  If other, specify
#'   \item PTPOSOTH T  If other, specify
#'   \item BICSFFAST N  Was participant fasting for at least 6 hours?
#'   \item NOCSF T  If no CSF was collected, provide explanation
#'   \item NEELDEOTH T  accident
#'   \item NEEDLEOTH T  If other, specify
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item RECNO N  
#'   \item BIBLOOD N  Which of the following was collected at this visit?
#'   \item BIURINE N  
#'   \item BICSF N  
#'   \item BINONE N  
#'   \item BINEEDLE N  Needle Used:
#'   \item BIMETHOD N  Method of Collection:
#'   \item BIFAST N  Overnight fast from midnight?
#'   \item EXAMDATE D  Examination Date
#'   \item BITIME T  Time of Collection
#'   \item BIREDTIME T  Time Collected  <!--Red Top-->
#'   \item BIREDAMT N  Amount Collected  <!--Serum-->
#'   \item BIREDCENT T  Centrifuged Time  <!--Serum-->
#'   \item BIREDTRNS T  Transfer Time  <!--Serum-->
#'   \item BIREDVOL N  Volume of Serum Transferred  <!--Serum-->
#'   \item BIREDFROZ T  Time Frozen  <!--Serum-->
#'   \item BILAVTIME T  Time Collected <!--Plasma-->
#'   \item BILAVAMT N  Amount Collected  <!--Plasma-->
#'   \item BILAVCENT T  Centrifuged Time <!--Plasma-->
#'   \item BILAVTRNS T  Transfer Time  <!--Plasma-->
#'   \item BILAVVOL N  Volume of Plasma Transferred  <!--Plasma-->
#'   \item BILAVFROZ T  Time Frozen  <!--Plasma-->
#'   \item BIURITIME T  Time Collected  <!--Urine-->
#'   \item BIURIAMT N  Amount Collected  <!--Urine-->
#'   \item BIURITRNS T  Transfer Time  <!--Urine-->
#'   \item BIURIVOL N  Volume of Urine Transfered  <!--Urine-->
#'   \item BIURIFROZ T  Time Frozen  <!--Urine-->
#'   \item BICSFTIME T  Time Collected  <!--CSF-->
#'   \item BICSFAMT N  Amount Collected  <!--CSF-->
#'   \item BICSFTRNS T  Transfer Time  <!--CSF-->
#'   \item BICSFVOL N  Volume of CSF Transferred  <!--CSF-->
#'   \item BICSFFROZ T  Time Frozen  <!--CSF-->
#'   \item BILPPATCH N  Check if any of the following was performed:
#'   \item BILPFLURO N  
#'   \item BILPSPFILM N  
#'   \item BILPPADATE D  Date of Blood Patch
#'   \item BILPFLDATE D  Date of Fluoroscopy
#'   \item BILPFLCOM T  If Fluoroscopy performed, but no CSF was collected, provide explanation
#'   \item BILPSPDATE D  Date of Spine Film
#'   \item BILPSPCOM T  If Spine Film performed, but no CSF was collected, provide explanation
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name biomark
#' @usage data(biomark)
#' @format A data frame with 10216 rows and 63 variables
NULL

#' Diagnostic Summary - Baseline Changes
#'
#'
#'
#' @author \email{adni-data@googlegroups.com}
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item EXAMDATE D  Examination Date
#'   \item BCPREDX N  Pre-visit Diagnosis
#'   \item BCADAS N  1. Clinically relevant worsening on ADAS?
#'   \item BCMMSE N  2. Clinically relevant worsening on MMSE?
#'   \item BCMMSREC N  3. Clinically relevant worsening on MMSE recall?
#'   \item BCNMMMS N  4. Clinically relevant worsening on non-memory MMSE items?
#'   \item BCNEUPSY N  5. Clinically relevant worsening in memory on neuropsych testing?
#'   \item BCNONMEM N  6. Clinically relevant impairment/worsening in non-memory cognitive domains on neuropsych testing?
#'   \item BCFAQ N  7. Clinically relevant worsening in activities of daily living (FAQ)?
#'   \item BCCDR N  8. Clinically relevant deterioration on CDR Sum of Boxes or Overall CDR rating?
#'   \item BCDEPRES N  9. Clinically relevant depression based on clinical judgement or GDS?
#'   \item BCSTROKE N  10. Did subject have a stroke?
#'   \item BCDELIR N  11. Is there evidence of a delirium (medication effect, toxic or metabolic encephalopathy)?
#'   \item BCEXTCIR N  12. Has extenuating circumstance (such as a physical health problem, change in residence, charge in support network, death of a family member, etc.) contributed to a change in the subject's cognitive or functional performance?
#'   \item BCEXTSP T  If yes, describe:
#'   \item BCCORADL N  13. Is the change in clinical status corroborated by informant report of changes in ADL?
#'   \item BCCORCOG N  14. Is the change in clinical status corroborated by informant report of changes in cognition?
#'   \item BCSUMM T  15. Narrative Summary
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name blchange
#' @usage data(blchange)
#' @format A data frame with 10499 rows and 25 variables
NULL

#' Blennow Lab ADNI1 CSF NFL
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/BLENNOWCSFNFL/Blennow%20Lab%20-%20ADNI-1%20-%20Method%20-%20CSF%20NFL.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item USERDATE -4 -4 Date record created
#'   \item EXAMDATE -4 -4 Examination Date
#'   \item VOLUME -4  Volume
#'   \item CSFNFL -4 ng/L -4
#'   \item COMMENTS -4  Comments
#' }
#'
#' @examples
#' \donotrun{
#' describe(blennowcsfnfl)
#' }
#' @docType data
#' @keywords datasets
#' @name blennowcsfnfl
#' @usage data(blennowcsfnfl)
#' @format A data frame with 416 rows and 8 variables
NULL

#' Blennow Lab ADNI1 CSF Ng
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/BLENNOWCSFNG/Blennow%20Lab%20-%20ADNI-1%20-%20Method%20-%20CSF%20Ng.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4  Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item USERDATE -4 -4 Date record created
#'   \item EXAMDATE -4  Examination Date
#'   \item CSFNG -4 pg/mL CSFNG
#'   \item COMMENTS -4  Comments
#'   \item GOTCOMMENT -4 -4 -4
#' }
#'
#' @examples
#' \donotrun{
#' describe(blennowcsfng)
#' }
#' @docType data
#' @keywords datasets
#' @name blennowcsfng
#' @usage data(blennowcsfng)
#' @format A data frame with 416 rows and 8 variables
NULL

#' Blennow Lab ADNI1 Plasma neurofilament light (NFL)
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/BLENNOWPLASMANFL/Blennow%20Lab%20-%20ADNI-1%20-%20Method%20-%20Plasma%20NFL.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item VISCODE2 -4 -4 Translated visit code
#'   \item EXAMDATE -4 -4 Examination Date
#'   \item BOX_POS -4  Box position
#'   \item VOL -4  Sample volume
#'   \item PLASMA_NFL -4 pg/ml Plasma NFL
#'   \item COMMENTS -4  Comments
#' }
#'
#' @examples
#' \donotrun{
#' describe(blennowplasmanfl)
#' }
#' @docType data
#' @keywords datasets
#' @name blennowplasmanfl
#' @usage data(blennowplasmanfl)
#' @format A data frame with 598 rows and 8 variables
NULL

#' Blennow Lab ADNI1 Plasma Tau
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/BLENNOWPLASMATAU/Blennow%20Lab%20-%20ADNI-1%20-%20Method%20-%20Plasma%20tau.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item USERDATE -4 -4 Date record created
#'   \item EXAMDATE -4 -4 Examination Date
#'   \item VOL -4  Volume
#'   \item PLASMATAU -4 pg/mL -4
#'   \item COMMENT -4  Comments
#' }
#'
#' @examples
#' \donotrun{
#' describe(blennowplasmatau)
#' }
#' @docType data
#' @keywords datasets
#' @name blennowplasmatau
#' @usage data(blennowplasmatau)
#' @format A data frame with 598 rows and 8 variables
NULL

#' Baseline Symptoms Checklist
#'
#'
#'
#' @author \email{adni-data@googlegroups.com}
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item BCSPECIF T  If Other symptoms/diagnosis, specify:
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item EXAMDATE D  Examination Date
#'   \item BCNAUSEA N  1. Nausea
#'   \item BCVOMIT N  2. Vomiting
#'   \item BCDIARRH N  3. Diarrhea
#'   \item BCCONSTP N  4. Constipation
#'   \item BCABDOMN N  5. Abdominal discomfort
#'   \item BCSWEATN N  6. Sweating
#'   \item BCDIZZY N  7. Dizziness
#'   \item BCENERGY N  8. Low energy
#'   \item BCDROWSY N  9. Drowsiness
#'   \item BCVISION N  10. Blurred vision
#'   \item BCHDACHE N  11. Headache
#'   \item BCDRYMTH N  12. Dry mouth
#'   \item BCBREATH N  13. Shortness of breath
#'   \item BCCOUGH N  14. Coughing
#'   \item BCPALPIT N  15. Palpitations
#'   \item BCCHEST N  16. Chest pain
#'   \item BCURNDIS N  17. Urinary discomfort (e.g., burning)
#'   \item BCURNFRQ N  18. Urinary frequency
#'   \item BCANKLE N  19. Ankle swelling
#'   \item BCMUSCLE N  20. Musculoskeletal pain
#'   \item BCRASH N  21. Rash
#'   \item BCINSOMN N  22. Insomnia
#'   \item BCDPMOOD N  23. Depressed mood
#'   \item BCCRYING N  24. Crying
#'   \item BCELMOOD N  25. Elevated mood
#'   \item BCWANDER N  26. Wandering
#'   \item BCFALL N  27. Fall
#'   \item BCOTHER N  28. Other
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name blscheck
#' @usage data(blscheck)
#' @format A data frame with 2549 rows and 37 variables
NULL

#' Boundary Shift Integral Summaries (Nick Fox's lab)
#'
#'
#'
#' @author \email{adni-data@googlegroups.com}
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item RECNO N  
#'   \item EXAMDATE D  Examination Date
#'   \item IMAGEUID N  imageUID
#'   \item FLDSTRENG N  Field Strength
#'   \item BBSI N ml Boundary Shift Integral from baseline
#'   \item DBCBBSI N ml Differential Bias Corrected Boundary Shift Integral from baseline
#'   \item VBSI N  Ventricular BSI
#'   \item BRAINVOL N ml Segmented brain volume. Not to be used as a measure of intracranial volume.
#'   \item VENTVOL N ml Segmented ventricular volume
#'   \item REGCOMMENT T  
#'   \item REGRATING N  
#'   \item VENTACCEPT N  A boolean to indicate whether or not we have confidence in the VBSI value. Similar purpose to the REGRATING.
#'   \item KMNDBCBBSI N  An improved version of the Differential Bias Corrected Boundary Shift Integral from baseline, which: a) Has a new intensity normalisation step that normalises scan intensity by matching the intensities by tissue type (cerebrospinal fluid, grey matter, white mater) instead of being just based on the average whole brain intensity. This helps reduce artefactual change in the BSI that might be caused by change in contrasts between scans (e.g scanner changes) b) Automatically calculates the BSI window based on k-means clustering of tissue intensities for each scan pair
#'   \item KMNREGCOMMENT T  
#'   \item KMNREGRATING N  
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name bsi
#' @usage data(bsi)
#' @format A data frame with 3602 rows and 20 variables
NULL

#' Cogstate Brief Battery
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item ONLINEID T NA Online ID
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#'   \item RECNO N  
#'   \item CBBLOC N  Administration Type:
#'   \item DONE N  Was assessment/procedure done?
#'   \item NDREASON N  If No, reason not done:
#'   \item EXAMDATE D MM/DD/YYYY Examination Date
#'   \item CBBPTCOMM T  Participant Comments:
#'   \item CBBCOMM T  Comments:
#' }
#'
#' @examples
#' \donotrun{
#' describe(cbbcomp)
#' }
#' @docType data
#' @keywords datasets
#' @name cbbcomp
#' @usage data(cbbcomp)
#' @format A data frame with 595 rows and 15 variables
NULL

#' Cogstate Battery Results
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item EXAMDATE -4  Examination Date
#'   \item TestTime -4  Time at the start of the test session.
#'   \item Session -4 Text/numbers (max characters 21)  Label for the session/visit.
#'   \item SessionAttempt -4 Number The number of attempts of the current session to-date (including the current assessment).
#'   \item SessionDuration -4 Seconds (number up to 7 digits) The total duration of the current session.
#'   \item SessionCompletion -4 Number Session completion criteria (0 = all tests in session met completion criteria; 1 = at least one test in the session did not meet completion criteria).
#'   \item TaskCode -4 Text and numbers Full code for the individual test.
#'   \item TaskAttempt -4 Number The number of attempts of the test in the current session.
#'   \item TaskCompletionScore -4 Number The completion score for the test. 
#'   \item TaskIntegrityScore -4 Number The performance score for the test.
#'   \item PrimaryOutcome -4 Number The score on the primary outcome measure for this test (e.g., ReactionTime for Detection, Identification and One Back; Accuracy for One Card Learning).
#'   \item ReactionTime -4 Number (log10 milliseconds) Reaction time; mean of the log10 transformed reaction times for correct responses.
#'   \item RTVariability -4 Number (log10 milliseconds) Consistency of performance; standard deviation of the log10 transformed reaction times for correct responses.
#'   \item Accuracy -4 Number (arcsine square root proportion correct) Accuracy of performance.
#'   \item TotalCorrect -4 Count (number up to 3 digits) Number of correct responses.
#'   \item TotalErrors -4 Count (number up to 3 digits) Number of errors.
#'   \item TotalResponses -4 Count (number up to 3 digits) Number of responses (TotalCorrect + TotalErrors).
#'   \item TotalTrials -4 Count Number of trials.
#' }
#'
#' @examples
#' \donotrun{
#' describe(cbb_results)
#' }
#' @docType data
#' @keywords datasets
#' @name cbb_results
#' @usage data(cbb_results)
#' @format A data frame with 1004 rows and 20 variables
NULL

#' Cognitive Change Index
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#'   \item CCI1 N  1. Recalling information when I really try
#'   \item CCI2 N  2. Remembering names and faces of new people I meet
#'   \item CCI3 N  3. Remembering things that have happened recently
#'   \item CCI4 N  4. Recalling conversations a few days later
#'   \item CCI5 N  5. Remembering where things are usually kept
#'   \item CCI6 N  6. Remembering new information told to me
#'   \item CCI7 N  7. Remembering where I placed familiar objects
#'   \item CCI8 N  8. Remembering what I intended to do
#'   \item CCI9 N  9. Remembering names of family members and friends
#'   \item CCI10 N  10. Remembering without notes and reminders
#'   \item CCI11 N  11. People who know me would find that my memory is
#'   \item CCI12 N  12. Remembering things compared to my age group
#'   \item CCI13 N  13. Making decisions about everyday matters
#'   \item CCI14 N  14. Reasoning through a complicated problem
#'   \item CCI15 N  15. Focusing on goals and carrying out a plan
#'   \item CCI16 N  16. Shifting easily from one activity to the next
#'   \item CCI17 N  17. Organizing my daily activities
#'   \item CCI18 N  18. Understanding conversations
#'   \item CCI19 N  19. Expressing myself when speaking
#'   \item CCI20 N  20. Following a story in a book, movie or TV
#'   \item CCI12TOT N  CCI Index:  Sum of first 12 items
#' }
#'
#' @examples
#' \donotrun{
#' describe(cci)
#' }
#' @docType data
#' @keywords datasets
#' @name cci
#' @usage data(cci)
#' @format A data frame with 397 rows and 28 variables
NULL

#' Clinical Dementia Rating
#'
#'
#'
#' @author \email{adni-data@googlegroups.com}
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item SPID N NA Study Partner ID:
#'   \item CDSOB N NA Sum of Boxes
#'   \item CDRSB N  CDR-SB
#'   \item CDVERSION N  Version
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item EXAMDATE D  Examination Date
#'   \item CDSOURCE N  Information Source
#'   \item CDMEMORY N  Score <!--Memory-->
#'   \item CDORIENT N  Score <!--Orientation-->
#'   \item CDJUDGE N  Score <!--Judgment and Problem Solving-->
#'   \item CDCOMMUN N  Score <!--Community Affairs-->
#'   \item CDHOME N  Score <!--Home and Hobbies-->
#'   \item CDCARE N  Score <!--Personal Care-->
#'   \item CDGLOBAL N  Global CDR
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' cdr$CDRSB = apply(cdr[, c('CDMEMORY', 'CDORIENT', 'CDJUDGE', 'CDCOMMUN', 'CDHOME', 'CDCARE')], 1, sum)
#' 
#' @docType data
#' @keywords datasets
#' @name cdr
#' @usage data(cdr)
#' @format A data frame with 10392 rows and 20 variables
NULL

#' Cells For Immortalization Speciman Collection
#'
#'
#'
#' @author \email{adni-data@googlegroups.com}
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item CLCOLL N NA Was sample collected?
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item EXAMDATE D  Examination Date
#'   \item CLTIME T  Time of Blood Draw
#'   \item CLFEDEXDT D  Date Fedexed
#'   \item CLFEDEX N  Fedex Tracking Number
#'   \item CLVOLUME N  Volume of Blood Shipped
#'   \item CLLICENSE N  6 digit License Plate Number
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name cellimort
#' @usage data(cellimort)
#' @format A data frame with 990 rows and 14 variables
NULL

#' Clinician Verification
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item PIN T NA I certify that I am using my own personal username and pin and understand that by using my username and pin, I am authorizing this electronic signature to be the legally binding equivalent of my handwritten signature executed on paper. - Enter Your PIN -
#'   \item DIAGNOSIS N  Specify diagnostic category:
#'   \item RID N NA Participant roster ID
#'   \item SITEID N NA Site ID
#'   \item VISCODE T NA Visit code
#'   \item USERDATE S NA Date record created
#'   \item USERDATE2 S NA Date record last updated
#'   \item INCLUSION N NA Does the participant fail to meet any of the inclusion criteria for new EMCIs? <a target="_blank" href="/docs/studydocs/Procedures Manual/ADNIGO Inclusion, Exclusion Criteria_current.pdf"> link to protocol inclusion/exclusion criteria</a>
#'   \item FAILINCLU T NA If yes, which criteria does the participant fail to meet:
#'   \item EXCLUSION N NA Does the participant meet any exclusion criteria for new EMCIs? <a target="_blank" href="/docs/studydocs/Procedures Manual/ADNIGO Inclusion, Exclusion Criteria_current.pdf"> link to protocol inclusion/exclusion criteria</a>
#'   \item FAILEXCLU T NA If yes, which criteria does the participant meet:
#'   \item CENROLL N NA Based on my review:
#'   \item CRAND N NA Does the participant continue to meet all the screening criteria?
#'   \item CDATE D NA Date of Approval or Denial
#'   \item CCOMM T NA Comments:
#'   \item CPASSWD T NA I certify that I am using my own personal username and password and understand that by using my username and password, I am authorizing this electronic signature to be the legally binding equivalent of my handwritten signature executed on paper. Enter Your Password:
#'   \item CEMRI N NA Does Screening MRI have evidence of infection, infarction, other focal lesions, or multiple lacunes in critical memory structures?
#'   \item CONTINCLU N NA Does the participant fail to meet any of the inclusion criteria for ADNI1 continuing participants? <a target="_blank" href="/docs/studydocs/Procedures Manual/ADNIGO Inclusion, Exclusion Criteria_current.pdf"> link to protocol inclusion/exclusion criteria</a>
#'   \item CONTFAILI T NA If yes, which criteria does the participant fail to meet:
#'   \item CONTEXCLU N NA Does the participant meet any of the exclusion criteria for ADNI1 continuing participants? <a target="_blank" href="/docs/studydocs/Procedures Manual/ADNIGO Inclusion, Exclusion Criteria_current.pdf"> link to protocol inclusion/exclusion criteria</a>
#'   \item CONTFAILE T NA If yes, which criteria does the participant meet:
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name clielg
#' @usage data(clielg)
#' @format A data frame with 3724 rows and 23 variables
NULL

#' Clinician Review
#'
#'
#'
#' @author \email{adni-data@googlegroups.com}
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N NA Participant roster ID
#'   \item SITEID N NA Site ID
#'   \item VISCODE T NA Visit code
#'   \item USERDATE S NA Date record created
#'   \item USERDATE2 S NA Date record last updated
#'   \item CLIPASS N NA If the visit is complete, please indicate below.
#'   \item CLIDATE D NA Approval Date
#'   \item CLICOMM T NA Comments:
#'   \item CLIPASSWD T NA I certify that I am using my own personal username and password and understand that by using my username and password, I am authorizing this electronic signature to be the legally binding equivalent of my handwritten signature executed on paper. Enter Your Password:
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name clirev
#' @usage data(clirev)
#' @format A data frame with 7072 rows and 11 variables
NULL

#' Consents
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item PROTVERSION N NA 2.  Indicate Version of Protocol
#'   \item CONSENTVERSION N NA 3.  Indicate Coordinating Center Consent template version signed:
#'   \item AMY N NA 3d.  Consent to Amyloid PET scan procedures
#'   \item AMYSAME N NA Separate consent document used from that reported in 3a (overall study participation)?
#'   \item AMYIRB D YYYY-MM-DD Consent IRB approval date:
#'   \item AMYVRS T NA Site version of consent:
#'   \item AMYDET T NA Reason for nonconsent:
#'   \item TAU N NA 3e. Consent to Tau PET scan procedures
#'   \item TAUSAME N NA Separate consent document used from that reported in 3a (overall study participation)?
#'   \item TAUIRB D YYYY-MM-DD Consent IRB approval date:
#'   \item TAUVRS T NA Site version of consent:
#'   \item TAUDET T NA Reason for nonconsent:
#'   \item FUTURE N NA 3g. Consent to contact for future studies
#'   \item FUTPROCDET T NA Reason for nonconsent:
#'   \item FITBIR N NA 3h. Consent to allow Tau PET scans to be uploaded to FITBIR
#'   \item FITPROCDET T NA Reason for nonconsent:
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#'   \item RECNO N  
#'   \item INCDATE D  1.  Date consent(s) signed:
#'   \item INCVERSION N  2.  Indicate ADCS template version signed:
#'   \item OVERALL N  3a. Overall study participation
#'   \item OVERALLDET T  Reason for nonconsent:  <!--Overall study participation-->
#'   \item MRI N  3b. MRI imaging
#'   \item MRIDET T  Reason for nonconsent:
#'   \item FDG N  3c. FDG imaging
#'   \item FDGDET T  Reason for nonconsent:
#'   \item AV45 N  3d. Florbetapir F18 PET imaging standard sequence
#'   \item AV45DET T  Reason for nonconsent:
#'   \item LPPROC N  3f. LP procedure
#'   \item LPPROCDET T  Reason for nonconsent:
#'   \item CLINSS N  3g. store and share samples/clinical data
#'   \item CLINSSDET T  Reason for nonconsent:
#'   \item DNACOLL N  3h. DNA sample collection
#'   \item DNACOLLDET T  Reason for nonconsent:
#'   \item DNASS N  3i. store and share DNA
#'   \item DNASSDET T  Reason for nonconsent:
#'   \item RNACOLL N  3j. RNA sample collection
#'   \item RNACOLLDET T  Reason for nonconsent:
#'   \item RNASS N  3k. store and share RNA
#'   \item RNASSDET T  Reason for nonconsent:
#'   \item OVERALLIRB D  Consent IRB approval date: <!--Overall study participation-->
#'   \item OVERALLVRS T  Site version of consent:  <!--Overall study participation-->
#'   \item MRISAME T  Check if:
#'   \item MRIIRB D  Consent IRB approval date:
#'   \item MRIVRS T  Site version of consent:
#'   \item FDGSAME T  Check if:
#'   \item FDGIRB D  Consent IRB approval date:
#'   \item FDGVRS T  Site version of consent:
#'   \item AV45SAME T  Check if:
#'   \item AV45IRB D  Consent IRB approval date:
#'   \item AV45VRS T  Site version of consent:
#'   \item LPSAME T  Check if:
#'   \item LPIRB D  Consent IRB approval date:
#'   \item LPVRS T  Site version of consent:
#'   \item CLINSAME T  Check if:
#'   \item CLINIRB D  Consent IRB approval date:
#'   \item CLINVRS T  Site version of consent:
#'   \item DNACSAME T  Check if:
#'   \item DNACIRB D  Consent IRB approval date:
#'   \item DNACVRS T  Site version of consent:
#'   \item DNASSAME T  Check if:
#'   \item DNASIRB D  Consent IRB approval date:
#'   \item DNASVRS T  Site version of consent:
#'   \item RNACSAME T  Check if:
#'   \item RNACIRB D  Consent IRB approval date:
#'   \item RNACVRS T  Site version of consent:
#'   \item RNASSAME T  Check if:
#'   \item RNASIRB D  Consent IRB approval date:
#'   \item RNASVRS T  Site version of consent:
#'   \item FBPAO N  3e. Florbetapir F18 PET imaging early add-on sequence
#'   \item FBPAOSAME T  Check if:
#'   \item FBPAOIRB D  Consent IRB approval date:
#'   \item FBPAOVRS T  Site version of consent:
#'   \item FBPAODET T  Reason for nonconsent:
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name consents
#' @usage data(consents)
#' @format A data frame with 5323 rows and 80 variables
NULL

#' Conversions Confirmed by Conversion Committee
#'
#'
#'
#' @author \email{adni-data@googlegroups.com}
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item USERDATE D -4 Date record created
#'   \item RID N -4 Participant roster ID
#'   \item VISCODE T -4 Visit code
#'   \item TYPE T -4 Conversion/Reversion Type
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name conversions
#' @usage data(conversions)
#' @format A data frame with 19 rows and 5 variables
NULL

#' Cross-Validation
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/CROSSVAL/cross-validation.pdf}
#' @description Leave k-out cross-vaiidation, stratified by diagnosis, study arm, and age, will be used by the groups conducting voxel-based analyses. A document describing the details of the implementation of the scheme and a table of the randomized assignments can be found below. The table contains a column of participant identifiers (RID), strata (GROUP), randomized set assignements (SET), and a training set indicator (TRAINING).
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item GROUP -4 -4 Strata
#'   \item SET -4 -4 Randomized set assignments
#'   \item TRAINING -4 -4 Training set indicator
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name crossval
#' @usage data(crossval)
#' @format A data frame with 822 rows and 5 variables
NULL

#' CSF Alpha-synuclein, Jing Zhang Lab, University of Washington
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N -4 Participant roster ID
#'   \item EXAMDATE D -4 Examination Date
#'   \item Protocol N -4 Protocol
#'   \item Box N -4 Box
#'   \item Luminex.batch.Number N -4 Luminex batch Number
#'   \item Luminex.testing.Date D -4 Luminex testing Date
#'   \item alpha.syn N ng/ml alpha syn
#'   \item Hemoglobin N ng/ml Hemoglobin
#' }
#'
#' @examples
#' \donotrun{
#' describe(csfalphasyn)
#' }
#' @docType data
#' @keywords datasets
#' @name csfalphasyn
#' @usage data(csfalphasyn)
#' @format A data frame with 390 rows and 9 variables
NULL

#' CSF Complement 3 & Factor H, Jing Zhang Lab, University of Washington
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item EXAMDATE -4 -4 Examination Date
#'   \item FH -4 ng/ml factor H
#'   \item C3 -4 ng/ml complement 3
#' }
#'
#' @examples
#' \donotrun{
#' describe(csfc3fh)
#' }
#' @docType data
#' @keywords datasets
#' @name csfc3fh
#' @usage data(csfc3fh)
#' @format A data frame with 390 rows and 5 variables
NULL

#' Baseline CSF homocysteine data.  ADNI Biomarker Core laboratory.
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N -4 Participant roster ID
#'   \item SITEID N -4 Site ID
#'   \item VISCODE T -4 Visit code
#'   \item EXAMDATE D -4 Examination Date
#'   \item USERDATE D -4 Date record created
#'   \item HC N micromoles/L CSF Homocysteine
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name csfhc
#' @usage data(csfhc)
#' @format A data frame with 416 rows and 7 variables
NULL

#' Method of CSF Collection
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item INTERSPACE N NA LP was performed at the:
#'   \item PTPOSITION N NA Patient Position:
#'   \item DONE N NA Was CSF collected?
#'   \item REASON N NA If no, please provide reason why CSF was not collected:
#'   \item REASONO T NA If other, specify:
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item EXAMDATE D  Examination Date
#'   \item NEEDLESIZE N  Needle used:
#'   \item COLTUBETYP N  Type of collection tube used
#'   \item SHPTUBETYP N  Type of tube used for shipping
#'   \item TUBEMIN N  If collected in polystyrene and shipped in polypropylene, please provide estimated amount of time CSF remained in collection tube
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name csfmeth
#' @usage data(csfmeth)
#' @format A data frame with 1165 rows and 17 variables
NULL

#' Biomarkers Consortium CSF Proteomics MRM data set
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/CSFMRM/04%20Apr%202014%20Bimarkers%20Consortium%20MRM%20Data%20Primer.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item A1AT.AVLTIDEK -4 -4 Alpha-1-antitrypsin 
#'   \item A1AT.LSITGTYDLK -4 -4 Alpha-1-antitrypsin 
#'   \item A1AT.SVLGQLGITK -4 -4 Alpha-1-antitrypsin 
#'   \item A1BG.NGVAQEPVHLDSPAIK -4 -4 Alpha-1B-glycoprotein 
#'   \item A1BG.SGLSTGWTQLSK -4 -4 Alpha-1B-glycoprotein 
#'   \item A2GL.DLLLPQPDLR -4 -4 Leucine-rich alpha-2-glycoprotein 
#'   \item A2GL.VAAGAFQGLR -4 -4 Leucine-rich alpha-2-glycoprotein 
#'   \item A4.LVFFAEDVGSNK -4 -4 Amyloid beta A4 protein 
#'   \item A4.THPHFVIPYR -4 -4 Amyloid beta A4 protein 
#'   \item A4.WYFDVTEGK -4 -4 Amyloid beta A4 protein 
#'   \item AACT.ADLSGITGAR -4 -4 Alpha-1-antichymotrypsin 
#'   \item AACT.EIGELYLPK -4 -4 Alpha-1-antichymotrypsin 
#'   \item AACT.NLAVSQVVHK -4 -4 Alpha-1-antichymotrypsin 
#'   \item AATC.IVASTLSNPELFEEWTGNVK -4 -4 Aspartate aminotransferase, cytoplasmic 
#'   \item AATC.LALGDDSPALK -4 -4 Aspartate aminotransferase, cytoplasmic 
#'   \item AATC.NLDYVATSIHEAVTK -4 -4 Aspartate aminotransferase, cytoplasmic 
#'   \item AATM.FVTVQTISGTGALR -4 -4 Aspartate aminotransferase, mitochondrial 
#'   \item AFAM.DADPDTFFAK -4 -4 Afamin 
#'   \item AFAM.FLVNLVK -4 -4 Afamin 
#'   \item AFAM.LPNNVLQEK -4 -4 Afamin 
#'   \item ALDOA.ALQASALK -4 -4 Fructose-bisphosphate aldolase A 
#'   \item ALDOA.QLLLTADDR -4 -4 Fructose-bisphosphate aldolase A 
#'   \item AMBP.AFIQLWAFDAVK -4 -4 Protein AMBP 
#'   \item AMBP.ETLLQDFR -4 -4 Protein AMBP 
#'   \item AMBP.FLYHK -4 -4 Protein AMBP 
#'   \item AMD.IPVDEEAFVIDFKPR -4 -4 Peptidyl-glycine alpha-amidating monooxygenase 
#'   \item AMD.IVQFSPSGK -4 -4 Peptidyl-glycine alpha-amidating monooxygenase 
#'   \item AMD.NGQWTLIGR -4 -4 Peptidyl-glycine alpha-amidating monooxygenase 
#'   \item APLP2.HYQHVLAVDPEK -4 -4 Amyloid-like protein 2 
#'   \item APLP2.WYFDLSK -4 -4 Amyloid-like protein 2 
#'   \item APOB.IAELSATAQEIIK -4 -4 Apolipoprotein B-100 
#'   \item APOB.SVSLPSLDPASAK -4 -4 Apolipoprotein B-100 
#'   \item APOB.TGISPLALIK -4 -4 Apolipoprotein B-100 
#'   \item APOD.VLNQELR -4 -4 Apolipoprotein D 
#'   \item APOE.AATVGSLAGQPLQER -4 -4 Apolipoprotein E 
#'   \item APOE.CLAVYQAGAR -4 -4 Apolipoprotein E 
#'   \item APOE.LAVYQAGAR -4 -4 Apolipoprotein E 
#'   \item APOE.LGADMEDVR -4 -4 Apolipoprotein E 
#'   \item APOE.LGPLVEQGR -4 -4 Apolipoprotein E 
#'   \item B2MG.VEHSDLSFSK -4 -4 Beta-2-microglobulin 
#'   \item B2MG.VNHVTLSQPK -4 -4 Beta-2-microglobulin 
#'   \item B3GN1.EPGEFALLR -4 -4 N-acetyllactosaminide beta-1,3-N-acetylglucosaminyltransferase 
#'   \item B3GN1.TALASGGVLDASGDYR -4 -4 N-acetyllactosaminide beta-1,3-N-acetylglucosaminyltransferase 
#'   \item B3GN1.YEAAVPDPR -4 -4 N-acetyllactosaminide beta-1,3-N-acetylglucosaminyltransferase 
#'   \item BACE1.SIVDSGTTNLR -4 -4 Beta-secretase 1 
#'   \item BASP1.ETPAATEAPSSTPK -4 -4 Brain acid soluble protein 1 
#'   \item BTD.LSSGLVTAALYGR -4 -4 Biotinidase 
#'   \item BTD.SHLIIAQVAK -4 -4 Biotinidase 
#'   \item C1QB.LEQGENVFLQATDK -4 -4 Complement C1q subcomponent subunit B 
#'   \item C1QB.VPGLYYFTYHASSR -4 -4 Complement C1q subcomponent subunit B 
#'   \item CA2D1.FVVTDGGITR -4 -4 Voltage-dependent calcium channel subunit alpha-2/delta-1 
#'   \item CA2D1.IKPVFIEDANFGR -4 -4 Voltage-dependent calcium channel subunit alpha-2/delta-1 
#'   \item CA2D1.TASGVNQLVDIYEK -4 -4 Voltage-dependent calcium channel subunit alpha-2/delta-1 
#'   \item CAD13.DIQGSLQDIFK -4 -4 Cadherin-13 
#'   \item CAD13.INENTGSVSVTR -4 -4 Cadherin-13 
#'   \item CAD13.YEVSSPYFK -4 -4 Cadherin-13 
#'   \item CADM3.EGSVPPLK -4 -4 Cell adhesion molecule 3 
#'   \item CADM3.GNPVPQQYLWEK -4 -4 Cell adhesion molecule 3 
#'   \item CADM3.SLVTVLGIPQKPIITGYK -4 -4 Cell adhesion molecule 3 
#'   \item CAH1.VLDALQAIK -4 -4 Carbonic anhydrase 1 
#'   \item CAH1.YSSLAEAASK -4 -4 Carbonic anhydrase 1 
#'   \item CATA.LFAYPDTHR -4 -4 Catalase 
#'   \item CATD.LVDQNIFSFYLSR -4 -4 Cathepsin D 
#'   \item CATD.VSTLPAITLK -4 -4 Cathepsin D 
#'   \item CATD.YSQAVPAVTEGPIPEVLK -4 -4 Cathepsin D 
#'   \item CATL1.VFQEPLFYEAPR -4 -4 Cathepsin L1 
#'   \item CCKN.AHLGALLAR -4 -4 Cholecystokinin 
#'   \item CCKN.NLQNLDPSHR -4 -4 Cholecystokinin 
#'   \item CD14.AFPALTSLDLSDNPGLGER -4 -4 Monocyte differentiation antigen CD14 
#'   \item CD14.FPAIQNLALR -4 -4 Monocyte differentiation antigen CD14 
#'   \item CD14.SWLAELQQWLKPGLK -4 -4 Monocyte differentiation antigen CD14 
#'   \item CD59.AGLQVYNK -4 -4 CD59 glycoprotein 
#'   \item CERU.IYHSHIDAPK -4 -4 Ceruloplasmin 
#'   \item CERU.NNEGTYYSPNYNPQSR -4 -4 Ceruloplasmin 
#'   \item CFAB.DAQYAPGYDK -4 -4 Complement factor B 
#'   \item CFAB.VSEADSSNADWVTK -4 -4 Complement factor B 
#'   \item CFAB.YGLVTYATYPK -4 -4 Complement factor B 
#'   \item CH3L1.ILGQQVPYATK -4 -4 Chitinase-3-like protein 1 
#'   \item CH3L1.SFTLASSETGVGAPISGPGIPGR -4 -4 Chitinase-3-like protein 1 
#'   \item CH3L1.VTIDSSYDIAK -4 -4 Chitinase-3-like protein 1 
#'   \item CLUS.IDSLLENDR -4 -4 Clusterin 
#'   \item CLUS.SGSGLVGR -4 -4 Clusterin 
#'   \item CLUS.VTTVASHTSDSDVPSGVTEVVVK -4 -4 Clusterin 
#'   \item CMGA.EDSLEAGLPLQVR -4 -4 Chromogranin-A 
#'   \item CMGA.SEALAVDGAGKPGAEEAQDPEGK -4 -4 Chromogranin-A 
#'   \item CMGA.SGEATDGARPQALPEPMQESK -4 -4 Chromogranin-A 
#'   \item CMGA.SGELEQEEER -4 -4 Chromogranin-A 
#'   \item CMGA.YPGPQAEGDSEGLSQGLVDR -4 -4 Chromogranin-A 
#'   \item CNDP1.ALEQDLPVNIK -4 -4 Beta-Ala-His dipeptidase 
#'   \item CNDP1.VFQYIDLHQDEFVQTLK -4 -4 Beta-Ala-His dipeptidase 
#'   \item CNDP1.WNYIEGTK -4 -4 Beta-Ala-His dipeptidase 
#'   \item CNTN1.DGEYVVEVR -4 -4 Contactin-1 
#'   \item CNTN1.TTKPYPADIVVQFK -4 -4 Contactin-1 
#'   \item CNTN2.IIVQAQPEWLK -4 -4 Contactin-2 
#'   \item CNTN2.TTGPGGDGIPAEVHIVR -4 -4 Contactin-2 
#'   \item CNTN2.VIASNILGTGEPSGPSSK -4 -4 Contactin-2 
#'   \item CNTP2.HELQHPIIAR -4 -4 Contactin-associated protein-like 2 
#'   \item CNTP2.VDNAPDQQNSHPDLAQEEIR -4 -4 Contactin-associated protein-like 2 
#'   \item CNTP2.YSSSDWVTQYR -4 -4 Contactin-associated protein-like 2 
#'   \item CO2.DFHINLFR -4 -4 Complement C2 
#'   \item CO2.HAIILLTDGK -4 -4 Complement C2 
#'   \item CO2.SSGQWQTPGATR -4 -4 Complement C2 
#'   \item CO3.IHWESASLLR -4 -4 Complement C3 
#'   \item CO3.LSINTHPSQKPLSITVR -4 -4 Complement C3 
#'   \item CO3.TELRPGETLNVNFLLR -4 -4 Complement C3 
#'   \item CO3.TGLQEVEVK -4 -4 Complement C3 
#'   \item CO3.VPVAVQGEDTVQSLTQGDGVAK -4 -4 Complement C3 
#'   \item CO4A.DHAVDLIQK -4 -4 Complement C4-A 
#'   \item CO4A.GSFEFPVGDAVSK -4 -4 Complement C4-A 
#'   \item CO4A.LGQYASPTAK -4 -4 Complement C4-A 
#'   \item CO4A.NVNFQK -4 -4 Complement C4-A 
#'   \item CO4A.VLSLAQEQVGGSPEK -4 -4 Complement C4-A 
#'   \item CO4A.VTASDPLDTLGSEGALSPGGVASLLR -4 -4 Complement C4-A 
#'   \item CO5.DINYVNPVIK -4 -4 Complement C5 
#'   \item CO5.TLLPVSKPEIR -4 -4 Complement C5 
#'   \item CO5.VFQFLEK -4 -4 Complement C5 
#'   \item CO6.ALNHLPLEYNSALYSR -4 -4 Complement component C6 
#'   \item CO6.SEYGAALAWEK -4 -4 Complement component C6 
#'   \item CO8B.IPGIFELGISSQSDR -4 -4 Complement component C8 beta chain 
#'   \item CO8B.SDLEVAHYK -4 -4 Complement component C8 beta chain 
#'   \item CO8B.YEFILK -4 -4 Complement component C8 beta chain 
#'   \item COCH.GVISNSGGPVR -4 -4 Cochlin 
#'   \item CRP.ESDTSYVSLK -4 -4 C-reactive protein 
#'   \item CSTN1.GNLAGLTLR -4 -4 Calsyntenin-1 
#'   \item CSTN1.IHGQNVPFDAVVVDK -4 -4 Calsyntenin-1 
#'   \item CSTN1.IPDGVVSVSPK -4 -4 Calsyntenin-1 
#'   \item CSTN3.ATGEGLIR -4 -4 Calsyntenin-3 
#'   \item CSTN3.ESLLLDTTSLQQR -4 -4 Calsyntenin-3 
#'   \item CUTA.TQSSLVPALTDFVR -4 -4 Protein CutA 
#'   \item CYTC.ALDFAVGEYNK -4 -4 Cystatin-C 
#'   \item DAG1.GVHYISVSATR -4 -4 Dystroglycan 
#'   \item DAG1.LVPVVNNR -4 -4 Dystroglycan 
#'   \item DAG1.VTIPTDLIASSGDIIK -4 -4 Dystroglycan 
#'   \item DIAC.ATYIQNYR -4 -4 Di-N-acetylchitobiase 
#'   \item ENOG.GNPTVEVDLYTAK -4 -4 Gamma-enolase 
#'   \item ENOG.LGAEVYHTLK -4 -4 Gamma-enolase 
#'   \item ENPP2.SYPEILTLK -4 -4 Ectonucleotide pyrophosphatase/phosphodiesterase family member 2 
#'   \item ENPP2.WWGGQPLWITATK -4 -4 Ectonucleotide pyrophosphatase/phosphodiesterase family member 2 
#'   \item EXTL2.VIVVWNNIGEK -4 -4 Exostosin-like 2 
#'   \item FABPH.SIVTLDGGK -4 -4 Fatty acid-binding protein, heart 
#'   \item FABPH.SLGVGFATR -4 -4 Fatty acid-binding protein, heart 
#'   \item FAM3C.GINVALANGK -4 -4 Protein FAM3C 
#'   \item FAM3C.SALDTAAR -4 -4 Protein FAM3C 
#'   \item FAM3C.SPFEQHIK -4 -4 Protein FAM3C 
#'   \item FAM3C.TGEVLDTK -4 -4 Protein FAM3C 
#'   \item FBLN1.AITPPHPASQANIIFDITEGNLR -4 -4 Fibulin-1 
#'   \item FBLN1.IIEVEEEQEDPYLNDR -4 -4 Fibulin-1 
#'   \item FBLN1.TGYYFDGISR -4 -4 Fibulin-1 
#'   \item FBLN3.IPSNPSHR -4 -4 EGF-containing fibulin-like extracellular matrix protein 1 
#'   \item FBLN3.LTIIVGPFSF -4 -4 EGF-containing fibulin-like extracellular matrix protein 1 
#'   \item FBLN3.SGNENGEFYLR -4 -4 EGF-containing fibulin-like extracellular matrix protein 1 
#'   \item FETUA.AHYDLR -4 -4 Alpha-2-HS-glycoprotein 
#'   \item FETUA.FSVVYAK -4 -4 Alpha-2-HS-glycoprotein 
#'   \item FETUA.HTLNQIDEVK -4 -4 Alpha-2-HS-glycoprotein 
#'   \item FMOD.YLPFVPSR -4 -4 Fibromodulin 
#'   \item GFAP.ALAAELNQLR -4 -4 Glial fibrillary acidic protein 
#'   \item GOLM1.DQLVIPDGQEEEQEAAGEGR -4 -4 Golgi membrane protein 1 
#'   \item GOLM1.QQLQALSEPQPR -4 -4 Golgi membrane protein 1 
#'   \item GRIA4.EYPGSETPPK -4 -4 Glutamate receptor 4 
#'   \item GRIA4.LQNILEQIVSVGK -4 -4 Glutamate receptor 4 
#'   \item GRIA4.NTDQEYTAFR -4 -4 Glutamate receptor 4 
#'   \item HBA.FLASVSTVLTSK -4 -4 Hemoglobin subunit alpha 
#'   \item HBA.TYFPHFDLSHGSAQVK -4 -4 Hemoglobin subunit alpha 
#'   \item HBA.VGAHAGEYGAEALER -4 -4 Hemoglobin subunit alpha 
#'   \item HBB.EFTPPVQAAYQK -4 -4 Hemoglobin subunit beta 
#'   \item HBB.SAVTALWGK -4 -4 Hemoglobin subunit beta 
#'   \item HBB.VNVDEVGGEALGR -4 -4 Hemoglobin subunit beta 
#'   \item HEMO.NFPSPVDAAFR -4 -4 Hemopexin 
#'   \item HEMO.QGHNSVFLIK -4 -4 Hemopexin 
#'   \item HEMO.SGAQATWTELPWPHEK -4 -4 Hemopexin 
#'   \item I18BP.LWEGSTSR -4 -4 Interleukin-18-binding protein 
#'   \item IBP2.HGLYNLK -4 -4 Insulin-like growth factor-binding protein 2 
#'   \item IBP2.LIQGAPTIR -4 -4 Insulin-like growth factor-binding protein 2 
#'   \item IGSF8.DTQFSYAVFK -4 -4 Immunoglobulin superfamily member 8 
#'   \item IGSF8.LQGDAVVLK -4 -4 Immunoglobulin superfamily member 8 
#'   \item IGSF8.VVAGEVQVQR -4 -4 Immunoglobulin superfamily member 8 
#'   \item ITIH1.EVAFDLEIPK -4 -4 Inter-alpha-trypsin inhibitor heavy chain H1 
#'   \item ITIH1.QYYEGSEIVVAGR -4 -4 Inter-alpha-trypsin inhibitor heavy chain H1 
#'   \item ITIH5.SYLEITPSR -4 -4 Inter-alpha-trypsin inhibitor heavy chain H5 
#'   \item KAIN.FYYLIASETPGK -4 -4 Kallistatin 
#'   \item KAIN.LGFTDLFSK -4 -4 Kallistatin 
#'   \item KAIN.VGSALFLSHNLK -4 -4 Kallistatin 
#'   \item KAIN.WADLSGITK -4 -4 Kallistatin 
#'   \item KLK10.ALQLPYR -4 -4 Kallikrein-10 
#'   \item KLK11.LPHTLR -4 -4 Kallikrein-11 
#'   \item KLK6.ESSQEQSSVVR -4 -4 Kallikrein-6 
#'   \item KLK6.LSELIQPLPLER -4 -4 Kallikrein-6 
#'   \item KLK6.YTNWIQK -4 -4 Kallikrein-6 
#'   \item KNG1.DIPTNSPELEETLTHTITK -4 -4 Kininogen-1 
#'   \item KNG1.QVVAGLNFR -4 -4 Kininogen-1 
#'   \item KNG1.TVGSDTFYSFK -4 -4 Kininogen-1 
#'   \item KPYM.LDIDSPPITAR -4 -4 Pyruvate kinase isozymes M1/M2 
#'   \item L1CAM.AQLLVVGSPGPVPR -4 -4 Neural cell adhesion molecule L1 
#'   \item L1CAM.LVLSDLHLLTQSQVR -4 -4 Neural cell adhesion molecule L1 
#'   \item L1CAM.WRPVDLAQVK -4 -4 Neural cell adhesion molecule L1 
#'   \item LAMB2.AQGIAQGAIR -4 -4 Laminin subunit beta-2 
#'   \item LPHN1.LVVSQLNPYTLR -4 -4 Latrophilin-1 
#'   \item LPHN1.SGETVINTANYHDTSPYR -4 -4 Latrophilin-1 
#'   \item LRC4B.HLEILQLSK -4 -4 Leucine-rich repeat-containing protein 4B 
#'   \item LRC4B.LTTVPTQAFEYLSK -4 -4 Leucine-rich repeat-containing protein 4B 
#'   \item LTBP2.EQDAPVAGLQPVER -4 -4 Latent-transforming growth factor beta-binding protein 2 
#'   \item MIME.ESAYLYAR -4 -4 Mimecan 
#'   \item MIME.ETVIIPNEK -4 -4 Mimecan 
#'   \item MIME.LEGNPIVLGK -4 -4 Mimecan 
#'   \item MOG.VVHLYR -4 -4 Myelin-oligodendrocyte glycoprotein 
#'   \item MUC18.EVTVPVFYPTEK -4 -4 Cell surface glycoprotein MUC18 
#'   \item MUC18.GATLALTQVTPQDER -4 -4 Cell surface glycoprotein MUC18 
#'   \item NBL1.LALFPDK -4 -4 Neuroblastoma suppressor of tumorigenicity 1 
#'   \item NCAM1.AGEQDATIHLK -4 -4 Neural cell adhesion molecule 1 
#'   \item NCAM1.GLGEISAASEFK -4 -4 Neural cell adhesion molecule 1 
#'   \item NCAM2.ASGSPEPAISWFR -4 -4 Neural cell adhesion molecule 2 
#'   \item NCAM2.IIELSQTTAK -4 -4 Neural cell adhesion molecule 2 
#'   \item NCAN.APVLELEK -4 -4 Neurocan core protein 
#'   \item NCAN.LSSAIIAAPR -4 -4 Neurocan core protein 
#'   \item NEGR1.SSIIFAGGDK -4 -4 Neuronal growth regulator 1 
#'   \item NEGR1.VVVNFAPTIQEIK -4 -4 Neuronal growth regulator 1 
#'   \item NEGR1.WSVDPR -4 -4 Neuronal growth regulator 1 
#'   \item NELL2.AFLFQDTPR -4 -4 Protein kinase C-binding protein NELL2 
#'   \item NELL2.FTGSSWIK -4 -4 Protein kinase C-binding protein NELL2 
#'   \item NELL2.SALAYVDGK -4 -4 Protein kinase C-binding protein NELL2 
#'   \item NEO1.DVVASLVSTR -4 -4 Neogenin 
#'   \item NEUS.ALGITEIFIK -4 -4 Neuroserpin 
#'   \item NEUS.QEVPLATLEPLVK -4 -4 Neuroserpin 
#'   \item NGF.SAPAAAIAAR -4 -4 Beta-nerve growth factor 
#'   \item NICA.ALADVATVLGR -4 -4 Nicastrin 
#'   \item NICA.APDVTTLPR -4 -4 Nicastrin 
#'   \item NPTX1.FQLTFPLR -4 -4 Neuronal pentraxin-1 
#'   \item NPTX1.LENLEQYSR -4 -4 Neuronal pentraxin-1 
#'   \item NPTX2.LESLEHQLR -4 -4 Neuronal pentraxin-2 
#'   \item NPTX2.TESTLNALLQR -4 -4 Neuronal pentraxin-2 
#'   \item NPTXR.ELDVLQGR -4 -4 Neuronal pentraxin receptor 
#'   \item NPTXR.LVEAFGGATK -4 -4 Neuronal pentraxin receptor 
#'   \item NRCAM.SLPSEASEQYLTK -4 -4 Neuronal cell adhesion molecule 
#'   \item NRCAM.VFNTPEGVPSAPSSLK -4 -4 Neuronal cell adhesion molecule 
#'   \item NRCAM.YIVSGTPTFVPYLIK -4 -4 Neuronal cell adhesion molecule 
#'   \item NRX1A.DLFIDGQSK -4 -4 Neurexin-1 
#'   \item NRX1A.ITTQITAGAR -4 -4 Neurexin-1 
#'   \item NRX1A.SDLYIGGVAK -4 -4 Neurexin-1 
#'   \item NRX2A.AIVADPVTFK -4 -4 Neurexin-2 
#'   \item NRX2A.LGERPPALLGSQGLR -4 -4 Neurexin-2 
#'   \item NRX2A.LSALTLSTVK -4 -4 Neurexin-2 
#'   \item NRX3A.IYGEVVFK -4 -4 Neurexin-3 
#'   \item NRX3A.SDLSFQFK -4 -4 Neurexin-3 
#'   \item OSTP.AIPVAQDLNAPSDWDSR -4 -4 Osteopontin 
#'   \item PCSK1.ALAHLLEAER -4 -4 ProSAAS 
#'   \item PCSK1.GEAAGAVQELAR -4 -4 ProSAAS 
#'   \item PCSK1.NSDPALGLDDDPDAPAAQLAR -4 -4 ProSAAS 
#'   \item PDYN.FLPSISTK -4 -4 Proenkephalin-B 
#'   \item PDYN.LSGSFLK -4 -4 Proenkephalin-B 
#'   \item PDYN.SVGEGPYSELAK -4 -4 Proenkephalin-B 
#'   \item PEDF.DTDTGALLFIGK -4 -4 Pigment epithelium-derived factor 
#'   \item PEDF.SSFVAPLEK -4 -4 Pigment epithelium-derived factor 
#'   \item PEDF.TVQAVLTVPK -4 -4 Pigment epithelium-derived factor 
#'   \item PGRP2.AGLLRPDYALLGHR -4 -4 N-acetylmuramoyl-L-alanine amidase 
#'   \item PGRP2.TFTLLDPK -4 -4 N-acetylmuramoyl-L-alanine amidase 
#'   \item PIMT.VQLVVGDGR -4 -4 Protein-L-isoaspartate(D-aspartate) O-methyltransferase 
#'   \item PLDX1.LYGPSEPHSR -4 -4 Plexin domain-containing protein 1 
#'   \item PLMN.EAQLPVIENK -4 -4 Plasminogen 
#'   \item PLMN.HSIFTPETNPR -4 -4 Plasminogen 
#'   \item PLMN.LSSPAVITDK -4 -4 Plasminogen 
#'   \item PPN.VHQSPDGTLLIYNLR -4 -4 Papilin 
#'   \item PRDX1.DISLSDYK -4 -4 Peroxiredoxin-1 
#'   \item PRDX1.LVQAFQFTDK -4 -4 Peroxiredoxin-1 
#'   \item PRDX2.GLFIIDGK -4 -4 Peroxiredoxin-2 
#'   \item PRDX2.IGKPAPDFK -4 -4 Peroxiredoxin-2 
#'   \item PRDX3.HLSVNDLPVGR -4 -4 Thioredoxin-dependent peroxide reductase, mitochondrial 
#'   \item PRDX6.LIALSIDSVEDHLAWSK -4 -4 Peroxiredoxin-6 
#'   \item PRDX6.LSILYPATTGR -4 -4 Peroxiredoxin-6 
#'   \item PTGDS.AQGFTEDTIVFLPQTDK -4 -4 Prostaglandin-H2 D-isomerase 
#'   \item PTGDS.WFSAGLASNSSWLR -4 -4 Prostaglandin-H2 D-isomerase 
#'   \item PTPRN.AEAPALFSR -4 -4 Receptor-type tyrosine-protein phosphatase-like N 
#'   \item PTPRN.LAAVLAGYGVELR -4 -4 Receptor-type tyrosine-protein phosphatase-like N 
#'   \item PTPRN.SELEAQTGLQILQTGVGQR -4 -4 Receptor-type tyrosine-protein phosphatase-like N 
#'   \item PVRL1.ITQVTWQK -4 -4 Poliovirus receptor-related protein 1 
#'   \item SCG1.GEAGAPGEEDIQGPTK -4 -4 Secretogranin-1 
#'   \item SCG1.HLEEPGETQNAFLNER -4 -4 Secretogranin-1 
#'   \item SCG1.NYLNYGEEGAPGK -4 -4 Secretogranin-1 
#'   \item SCG1.SSQGGSLPSEEK -4 -4 Secretogranin-1 
#'   \item SCG2.ALEYIENLR -4 -4 Secretogranin-2 
#'   \item SCG2.IILEALR -4 -4 Secretogranin-2 
#'   \item SCG2.VLEYLNQEK -4 -4 Secretogranin-2 
#'   \item SCG3.ELSAERPLNEQIAEAEEDK -4 -4 Secretogranin-3 
#'   \item SCG3.FQDDPDGLHQLDGTPLTAEDIVHK -4 -4 Secretogranin-3 
#'   \item SCG3.LNVEDVDSTK -4 -4 Secretogranin-3 
#'   \item SE6L1.ETGTPIWTSR -4 -4 Seizure 6-like protein 
#'   \item SE6L1.SPTNTISVYFR -4 -4 Seizure 6-like protein 
#'   \item SIAE.ELSNTAAYQSVR -4 -4 Sialate O-acetylesterase 
#'   \item SLIK1.SLPVDVFAGVSLSK -4 -4 SLIT and NTRK-like protein 1 
#'   \item SODC.GDGPVQGIINFEQK -4 -4 Superoxide dismutase [Cu-Zn] 
#'   \item SODC.HVGDLGNVTADK -4 -4 Superoxide dismutase [Cu-Zn] 
#'   \item SODC.TLVVHEK -4 -4 Superoxide dismutase [Cu-Zn] 
#'   \item SODE.AGLAASLAGPHSIVGR -4 -4 Extracellular superoxide dismutase [Cu-Zn] 
#'   \item SODE.AVVVHAGEDDLGR -4 -4 Extracellular superoxide dismutase [Cu-Zn] 
#'   \item SODE.VTGVVLFR -4 -4 Extracellular superoxide dismutase [Cu-Zn] 
#'   \item SORC1.TIAVYEEFR -4 -4 VPS10 domain-containing receptor SorCS1 
#'   \item SPON1.VTLSAAPPSYFR -4 -4 Spondin-1 
#'   \item SPRL1.HIQETEWQSQEGK -4 -4 SPARC-like protein 1 
#'   \item SPRL1.HSASDDYFIPSQAFLEAER -4 -4 SPARC-like protein 1 
#'   \item SPRL1.VLTHSELAPLR -4 -4 SPARC-like protein 1 
#'   \item TGFB1.LLAPSDSPEWLSFDVTGVVR -4 -4 Transforming growth factor beta-1 
#'   \item THRB.ETAASLLQAGYK -4 -4 Prothrombin 
#'   \item THRB.YGFYTHVFR -4 -4 Prothrombin 
#'   \item TIMP1.GFQALGDAADIR -4 -4 Metalloproteinase inhibitor 1 
#'   \item TIMP1.SEEFLIAGK -4 -4 Metalloproteinase inhibitor 1 
#'   \item TNR21.ASNLIGTYR -4 -4 Tumor necrosis factor receptor superfamily member 21 
#'   \item TRFM.ADTDGGLIFR -4 -4 Melanotransferrin 
#'   \item TTHY.TSESGELHGLTTEEEFVEGIYK -4 -4 Transthyretin 
#'   \item TTHY.VEIDTK -4 -4 Transthyretin 
#'   \item UBB.ESTLHLVLR -4 -4 Polyubiquitin-B 
#'   \item UBB.TITLEVEPSDTIENVK -4 -4 Polyubiquitin-B 
#'   \item UBB.TLSDYNIQK -4 -4 Polyubiquitin-B 
#'   \item VASN.NLHDLDVSDNQLER -4 -4 Vasorin 
#'   \item VASN.SLTLGIEPVSPTSLR -4 -4 Vasorin 
#'   \item VASN.YLQGSSVQLR -4 -4 Vasorin 
#'   \item VGF.AYQGVAAPFPK -4 -4 Neurosecretory protein VGF 
#'   \item VGF.NSEPQDEGELFQGVDPR -4 -4 Neurosecretory protein VGF 
#'   \item VGF.THLGEALAPLSK -4 -4 Neurosecretory protein VGF 
#'   \item VTDB.EFSHLGK -4 -4 Vitamin D-binding protein 
#'   \item VTDB.HLSLLTTLSNR -4 -4 Vitamin D-binding protein 
#'   \item VTDB.VPTADLEDVLPLAEDITNILSK -4 -4 Vitamin D-binding protein 
#' }
#'
#' @examples
#' \donotrun{
#' describe(csfmrm)
#' }
#' @docType data
#' @keywords datasets
#' @name csfmrm
#' @usage data(csfmrm)
#' @format A data frame with 304 rows and 323 variables
NULL

#' Data Dictionary
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item 
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name datadic
#' @usage data(datadic)
#' @format A data frame with 12190 rows and 12 variables
NULL

#' Protocol Deviations Log
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item PDDATE D YYYY-MM-DD Date of deviation
#'   \item PDREVIEW N NA Was deviation reviewed in advance by Coordinating Center or Project Director?
#'   \item PDRISK N NA Assessment of risk to participant:
#'   \item PDTYPE N NA Deviation Type:
#'   \item PDCONSENT N NA If deviation related to Informed Consent, select details:
#'   \item PDRAND N NA If deviation related to Enrollment, select details:
#'   \item PDPROC N NA If deviation related to Protocol Procedures, select details:
#'   \item PDASSESS N NA If deviation related to other protocol procedure, select assessment/procedure impacted:
#'   \item PDEXMED N NA If deviation related to Excluded Concurrent Medications, select details:
#'   \item PDPERSON N NA If deviation related to Site Personnel, select details:
#'   \item PDDESC T NA Description of Event
#'   \item PDVISIT T NA Select visit(s) impacted
#'   \item PDCOMM T NA Comments:
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' \donotrun{
#' describe(devlog)
#' }
#' @docType data
#' @keywords datasets
#' @name devlog
#' @usage data(devlog)
#' @format A data frame with 100 rows and 20 variables
NULL

#' DTI ROI summary measures
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/DTIROI/DTI-ADNI_Methods-Thompson-Oct2012.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4  Participant roster ID
#'   \item VISCODE -4  Visit code
#'   \item VISCODE2 -4  Translated visit code
#'   \item EXAMDATE -4  Examination Date
#'   \item VERSION -4  Version
#'   \item VISNAME -4  Visit Code
#'   \item VISITNO -4  Visit
#'   \item LONIUID_1 -4  LONI Image ID for FA
#'   \item LONIUID_2 -4  LONI Image ID for MD
#'   \item LONIUID_3 -4  LONI Image ID for RD
#'   \item LONIUID_4 -4  LONI Image ID for AD
#'   \item RUNDATE -4  Date
#'   \item STATUS -4  Status
#'   \item FA_CST_L -4 FA Corticospinal tract left 
#'   \item FA_CST_R -4 FA Corticospinal tract right 
#'   \item FA_ICP_L -4 FA Inferior cerebellar peduncle left 
#'   \item FA_ICP_R -4 FA Inferior cerebellar peduncle right 
#'   \item FA_ML_L -4 FA Medial lemniscus left 
#'   \item FA_ML_R -4 FA Medial lemniscus right 
#'   \item FA_SCP_L -4 FA Superior cerebellar peduncle left 
#'   \item FA_SCP_R -4 FA Superior cerebellar peduncle right 
#'   \item FA_CP_L -4 FA Cerebral peduncle left 
#'   \item FA_CP_R -4 FA Cerebral peduncle right 
#'   \item FA_ALIC_L -4 FA Anterior limb of internal capsule left 
#'   \item FA_ALIC_R -4 FA Anterior limb of internal capsule right 
#'   \item FA_PLIC_L -4 FA Posterior limb of internal capsule left 
#'   \item FA_PLIC_R -4 FA Posterior limb of internal capsule right 
#'   \item FA_PTR_L -4 FA Posterior thalamic radiation left 
#'   \item FA_PTR_R -4 FA Posterior thalamic radiation right 
#'   \item FA_ACR_L -4 FA Anterior corona radiata left 
#'   \item FA_ACR_R -4 FA Anterior corona radiata right 
#'   \item FA_SCR_L -4 FA Superior corona radiata left 
#'   \item FA_SCR_R -4 FA Superior corona radiata right 
#'   \item FA_PCR_L -4 FA Posterior corona radiata left 
#'   \item FA_PCR_R -4 FA Posterior corona radiata right 
#'   \item FA_CGC_L -4 FA Cingulum left 
#'   \item FA_CGC_R -4 FA Cingulum right 
#'   \item FA_CGH_L -4 FA Cingulum (hippocampus) left 
#'   \item FA_CGH_R -4 FA Cingulum (hippocampus) right 
#'   \item FA_FX_ST_L -4 FA Fornix (cres) / Stria terminalis left 
#'   \item FA_FX_ST_R -4 FA Fornix (cres) / Stria terminalis right 
#'   \item FA_SLF_L -4 FA Superior longitudinal fasciculus left 
#'   \item FA_SLF_R -4 FA Superior longitudinal fasciculus right 
#'   \item FA_SFO_L -4 FA Superior fronto-occipital fasciculus left 
#'   \item FA_SFO_R -4 FA Superior fronto-occipital fasciculus right 
#'   \item FA_IFO_L -4 FA Inferior fronto-occipital fasciculus left 
#'   \item FA_IFO_R -4 FA Inferior fronto-occipital fasciculus right 
#'   \item FA_SS_L -4 FA Sagittal stratum left 
#'   \item FA_SS_R -4 FA Sagittal stratum right 
#'   \item FA_EC_L -4 FA External capsule left 
#'   \item FA_EC_R -4 FA External capsule right 
#'   \item FA_UNC_L -4 FA Uncinate fasciculus left 
#'   \item FA_UNC_R -4 FA Uncinate fasciculus right 
#'   \item FA_FX_L -4 FA Fornix  left 
#'   \item FA_FX_R -4 FA Fornix  right 
#'   \item FA_GCC_L -4 FA Genu of corpus callosum left 
#'   \item FA_GCC_R -4 FA Genu of corpus callosum right 
#'   \item FA_BCC_L -4 FA Body of corpus callosum  left 
#'   \item FA_BCC_R -4 FA Body of corpus callosum  right 
#'   \item FA_SCC_L -4 FA Splenium of corpus callosum left 
#'   \item FA_SCC_R -4 FA Splenium of corpus callosum right 
#'   \item FA_RLIC_L -4 FA Retrolenticular part of internal capsule left 
#'   \item FA_RLIC_R -4 FA Retrolenticular part of internal capsule right 
#'   \item FA_TAP_L -4 FA Tapatum left 
#'   \item FA_TAP_R -4 FA Tapatum right 
#'   \item FA_SUMGCC -4 FA Bilateral genu of the corpus callosum 
#'   \item FA_SUMBCC -4 FA Bilateral body of  the corpus callosum 
#'   \item FA_SUMSCC -4 FA Bilateral splenium of  the corpus callosum 
#'   \item FA_SUMCC -4 FA Bilateral full corpus callosum 
#'   \item FA_SUMFX -4 FA Bilateral fornix 
#'   \item MD_CST_L -4 MD Corticospinal tract left 
#'   \item MD_CST_R -4 MD Corticospinal tract right 
#'   \item MD_ICP_L -4 MD Inferior cerebellar peduncle left 
#'   \item MD_ICP_R -4 MD Inferior cerebellar peduncle right 
#'   \item MD_ML_L -4 MD Medial lemniscus left 
#'   \item MD_ML_R -4 MD Medial lemniscus right 
#'   \item MD_SCP_L -4 MD Superior cerebellar peduncle left 
#'   \item MD_SCP_R -4 MD Superior cerebellar peduncle right 
#'   \item MD_CP_L -4 MD Cerebral peduncle left 
#'   \item MD_CP_R -4 MD Cerebral peduncle right 
#'   \item MD_ALIC_L -4 MD Anterior limb of internal capsule left 
#'   \item MD_ALIC_R -4 MD Anterior limb of internal capsule right 
#'   \item MD_PLIC_L -4 MD Posterior limb of internal capsule left 
#'   \item MD_PLIC_R -4 MD Posterior limb of internal capsule right 
#'   \item MD_PTR_L -4 MD Posterior thalamic radiation left 
#'   \item MD_PTR_R -4 MD Posterior thalamic radiation right 
#'   \item MD_ACR_L -4 MD Anterior corona radiata left 
#'   \item MD_ACR_R -4 MD Anterior corona radiata right 
#'   \item MD_SCR_L -4 MD Superior corona radiata left 
#'   \item MD_SCR_R -4 MD Superior corona radiata right 
#'   \item MD_PCR_L -4 MD Posterior corona radiata left 
#'   \item MD_PCR_R -4 MD Posterior corona radiata right 
#'   \item MD_CGC_L -4 MD Cingulum left 
#'   \item MD_CGC_R -4 MD Cingulum right 
#'   \item MD_CGH_L -4 MD Cingulum (hippocampus) left 
#'   \item MD_CGH_R -4 MD Cingulum (hippocampus) right 
#'   \item MD_FX_ST_L -4 MD Fornix (cres) / Stria terminalis left 
#'   \item MD_FX_ST_R -4 MD Fornix (cres) / Stria terminalis right 
#'   \item MD_SLF_L -4 MD Superior longitudinal fasciculus left 
#'   \item MD_SLF_R -4 MD Superior longitudinal fasciculus right 
#'   \item MD_SFO_L -4 MD Superior fronto-occipital fasciculus left 
#'   \item MD_SFO_R -4 MD Superior fronto-occipital fasciculus right 
#'   \item MD_IFO_L -4 MD Inferior fronto-occipital fasciculus left 
#'   \item MD_IFO_R -4 MD Inferior fronto-occipital fasciculus right 
#'   \item MD_SS_L -4 MD Sagittal stratum left 
#'   \item MD_SS_R -4 MD Sagittal stratum right 
#'   \item MD_EC_L -4 MD External capsule left 
#'   \item MD_EC_R -4 MD External capsule right 
#'   \item MD_UNC_L -4 MD Uncinate fasciculus left 
#'   \item MD_UNC_R -4 MD Uncinate fasciculus right 
#'   \item MD_FX_L -4 MD Fornix  left 
#'   \item MD_FX_R -4 MD Fornix  right 
#'   \item MD_GCC_L -4 MD Genu of corpus callosum left 
#'   \item MD_GCC_R -4 MD Genu of corpus callosum right 
#'   \item MD_BCC_L -4 MD Body of corpus callosum  left 
#'   \item MD_BCC_R -4 MD Body of corpus callosum  right 
#'   \item MD_SCC_L -4 MD Splenium of corpus callosum left 
#'   \item MD_SCC_R -4 MD Splenium of corpus callosum right 
#'   \item MD_RLIC_L -4 MD Retrolenticular part of internal capsule left 
#'   \item MD_RLIC_R -4 MD Retrolenticular part of internal capsule right 
#'   \item MD_TAP_L -4 MD Tapatum left 
#'   \item MD_TAP_R -4 MD Tapatum right 
#'   \item MD_SUMGCC -4 MD Bilateral genu of the corpus callosum 
#'   \item MD_SUMBCC -4 MD Bilateral body of  the corpus callosum 
#'   \item MD_SUMSCC -4 MD Bilateral splenium of  the corpus callosum 
#'   \item MD_SUMCC -4 MD Bilateral full corpus callosum 
#'   \item MD_SUMFX -4 MD Bilateral fornix 
#'   \item RD_CST_L -4 RD Corticospinal tract left 
#'   \item RD_CST_R -4 RD Corticospinal tract right 
#'   \item RD_ICP_L -4 RD Inferior cerebellar peduncle left 
#'   \item RD_ICP_R -4 RD Inferior cerebellar peduncle right 
#'   \item RD_ML_L -4 RD Medial lemniscus left 
#'   \item RD_ML_R -4 RD Medial lemniscus right 
#'   \item RD_SCP_L -4 RD Superior cerebellar peduncle left 
#'   \item RD_SCP_R -4 RD Superior cerebellar peduncle right 
#'   \item RD_CP_L -4 RD Cerebral peduncle left 
#'   \item RD_CP_R -4 RD Cerebral peduncle right 
#'   \item RD_ALIC_L -4 RD Anterior limb of internal capsule left 
#'   \item RD_ALIC_R -4 RD Anterior limb of internal capsule right 
#'   \item RD_PLIC_L -4 RD Posterior limb of internal capsule left 
#'   \item RD_PLIC_R -4 RD Posterior limb of internal capsule right 
#'   \item RD_PTR_L -4 RD Posterior thalamic radiation left 
#'   \item RD_PTR_R -4 RD Posterior thalamic radiation right 
#'   \item RD_ACR_L -4 RD Anterior corona radiata left 
#'   \item RD_ACR_R -4 RD Anterior corona radiata right 
#'   \item RD_SCR_L -4 RD Superior corona radiata left 
#'   \item RD_SCR_R -4 RD Superior corona radiata right 
#'   \item RD_PCR_L -4 RD Posterior corona radiata left 
#'   \item RD_PCR_R -4 RD Posterior corona radiata right 
#'   \item RD_CGC_L -4 RD Cingulum left 
#'   \item RD_CGC_R -4 RD Cingulum right 
#'   \item RD_CGH_L -4 RD Cingulum (hippocampus) left 
#'   \item RD_CGH_R -4 RD Cingulum (hippocampus) right 
#'   \item RD_FX_ST_L -4 RD Fornix (cres) / Stria terminalis left 
#'   \item RD_FX_ST_R -4 RD Fornix (cres) / Stria terminalis right 
#'   \item RD_SLF_L -4 RD Superior longitudinal fasciculus left 
#'   \item RD_SLF_R -4 RD Superior longitudinal fasciculus right 
#'   \item RD_SFO_L -4 RD Superior fronto-occipital fasciculus left 
#'   \item RD_SFO_R -4 RD Superior fronto-occipital fasciculus right 
#'   \item RD_IFO_L -4 RD Inferior fronto-occipital fasciculus left 
#'   \item RD_IFO_R -4 RD Inferior fronto-occipital fasciculus right 
#'   \item RD_SS_L -4 RD Sagittal stratum left 
#'   \item RD_SS_R -4 RD Sagittal stratum right 
#'   \item RD_EC_L -4 RD External capsule left 
#'   \item RD_EC_R -4 RD External capsule right 
#'   \item RD_UNC_L -4 RD Uncinate fasciculus left 
#'   \item RD_UNC_R -4 RD Uncinate fasciculus right 
#'   \item RD_FX_L -4 RD Fornix  left 
#'   \item RD_FX_R -4 RD Fornix  right 
#'   \item RD_GCC_L -4 RD Genu of corpus callosum left 
#'   \item RD_GCC_R -4 RD Genu of corpus callosum right 
#'   \item RD_BCC_L -4 RD Body of corpus callosum  left 
#'   \item RD_BCC_R -4 RD Body of corpus callosum  right 
#'   \item RD_SCC_L -4 RD Splenium of corpus callosum left 
#'   \item RD_SCC_R -4 RD Splenium of corpus callosum right 
#'   \item RD_RLIC_L -4 RD Retrolenticular part of internal capsule left 
#'   \item RD_RLIC_R -4 RD Retrolenticular part of internal capsule right 
#'   \item RD_TAP_L -4 RD Tapatum left 
#'   \item RD_TAP_R -4 RD Tapatum right 
#'   \item RD_SUMGCC -4 RD Bilateral genu of the corpus callosum 
#'   \item RD_SUMBCC -4 RD Bilateral body of  the corpus callosum 
#'   \item RD_SUMSCC -4 RD Bilateral splenium of  the corpus callosum 
#'   \item RD_SUMCC -4 RD Bilateral full corpus callosum 
#'   \item RD_SUMFX -4 RD Bilateral fornix 
#'   \item AD_CST_L -4 AD Corticospinal tract left 
#'   \item AD_CST_R -4 AD Corticospinal tract right 
#'   \item AD_ICP_L -4 AD Inferior cerebellar peduncle left 
#'   \item AD_ICP_R -4 AD Inferior cerebellar peduncle right 
#'   \item AD_ML_L -4 AD Medial lemniscus left 
#'   \item AD_ML_R -4 AD Medial lemniscus right 
#'   \item AD_SCP_L -4 AD Superior cerebellar peduncle left 
#'   \item AD_SCP_R -4 AD Superior cerebellar peduncle right 
#'   \item AD_CP_L -4 AD Cerebral peduncle left 
#'   \item AD_CP_R -4 AD Cerebral peduncle right 
#'   \item AD_ALIC_L -4 AD Anterior limb of internal capsule left 
#'   \item AD_ALIC_R -4 AD Anterior limb of internal capsule right 
#'   \item AD_PLIC_L -4 AD Posterior limb of internal capsule left 
#'   \item AD_PLIC_R -4 AD Posterior limb of internal capsule right 
#'   \item AD_PTR_L -4 AD Posterior thalamic radiation left 
#'   \item AD_PTR_R -4 AD Posterior thalamic radiation right 
#'   \item AD_ACR_L -4 AD Anterior corona radiata left 
#'   \item AD_ACR_R -4 AD Anterior corona radiata right 
#'   \item AD_SCR_L -4 AD Superior corona radiata left 
#'   \item AD_SCR_R -4 AD Superior corona radiata right 
#'   \item AD_PCR_L -4 AD Posterior corona radiata left 
#'   \item AD_PCR_R -4 AD Posterior corona radiata right 
#'   \item AD_CGC_L -4 AD Cingulum left 
#'   \item AD_CGC_R -4 AD Cingulum right 
#'   \item AD_CGH_L -4 AD Cingulum (hippocampus) left 
#'   \item AD_CGH_R -4 AD Cingulum (hippocampus) right 
#'   \item AD_FX_ST_L -4 AD Fornix (cres) / Stria terminalis left 
#'   \item AD_FX_ST_R -4 AD Fornix (cres) / Stria terminalis right 
#'   \item AD_SLF_L -4 AD Superior longitudinal fasciculus left 
#'   \item AD_SLF_R -4 AD Superior longitudinal fasciculus right 
#'   \item AD_SFO_L -4 AD Superior fronto-occipital fasciculus left 
#'   \item AD_SFO_R -4 AD Superior fronto-occipital fasciculus right 
#'   \item AD_IFO_L -4 AD Inferior fronto-occipital fasciculus left 
#'   \item AD_IFO_R -4 AD Inferior fronto-occipital fasciculus right 
#'   \item AD_SS_L -4 AD Sagittal stratum left 
#'   \item AD_SS_R -4 AD Sagittal stratum right 
#'   \item AD_EC_L -4 AD External capsule left 
#'   \item AD_EC_R -4 AD External capsule right 
#'   \item AD_UNC_L -4 AD Uncinate fasciculus left 
#'   \item AD_UNC_R -4 AD Uncinate fasciculus right 
#'   \item AD_FX_L -4 AD Fornix  left 
#'   \item AD_FX_R -4 AD Fornix  right 
#'   \item AD_GCC_L -4 AD Genu of corpus callosum left 
#'   \item AD_GCC_R -4 AD Genu of corpus callosum right 
#'   \item AD_BCC_L -4 AD Body of corpus callosum  left 
#'   \item AD_BCC_R -4 AD Body of corpus callosum  right 
#'   \item AD_SCC_L -4 AD Splenium of corpus callosum left 
#'   \item AD_SCC_R -4 AD Splenium of corpus callosum right 
#'   \item AD_RLIC_L -4 AD Retrolenticular part of internal capsule left 
#'   \item AD_RLIC_R -4 AD Retrolenticular part of internal capsule right 
#'   \item AD_TAP_L -4 AD Tapatum left 
#'   \item AD_TAP_R -4 AD Tapatum right 
#'   \item AD_SUMGCC -4 AD Bilateral genu of the corpus callosum 
#'   \item AD_SUMBCC -4 AD Bilateral body of  the corpus callosum 
#'   \item AD_SUMSCC -4 AD Bilateral splenium of  the corpus callosum 
#'   \item AD_SUMCC -4 AD Bilateral full corpus callosum 
#'   \item AD_SUMFX -4 AD Bilateral fornix 
#' }
#'
#' @examples
#' \donotrun{
#' describe(dtiroi)
#' }
#' @docType data
#' @keywords datasets
#' @name dtiroi
#' @usage data(dtiroi)
#' @format A data frame with 805 rows and 241 variables
NULL

#' Diagnostic Summary
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item DIAGNOSIS N NA 1.  Which best describes the participant's current diagnosis?
#'   \item RID N NA Participant roster ID
#'   \item SITEID N NA Site ID
#'   \item VISCODE T NA Visit code
#'   \item USERDATE S NA Date record created
#'   \item USERDATE2 S NA Date record last updated
#'   \item EXAMDATE D NA Examination Date
#'   \item DXCHANGE N NA 1.  Which best describes the participant's change in cognitive status from last visit to current visit:
#'   \item DXMDES T NA 2a.  MCI features (select all that apply):
#'   \item DXMPTR1 N NA If MCI - Memory features, complete the following (Petersen Criteria, see procedures manual for details):<p />i. Subjective memory complaint
#'   \item DXMPTR2 N NA ii. Informant memory complaint
#'   \item DXMPTR3 N NA iii. Normal general cognitive function
#'   \item DXMPTR4 N NA iv. Normal activities of daily living
#'   \item DXMPTR5 N NA v. Objective memory impairment for age and education
#'   \item DXMPTR6 N NA vi. Not demented by diagnostic criteria
#'   \item DXMDUE N NA 2b. Suspected cause of MCI:
#'   \item DXMOTHET T NA If MCI due to other etiology, select box(es) to indicate reason:
#'   \item DXMOTHSP T NA Other (specify)
#'   \item DXDSEV N NA 3a.  Dementia Severity - Clinician's Impression
#'   \item DXDDUE N NA 3b.  Suspected cause of dementia
#'   \item DXAPP N NA If Dementia due to Alzheimer's Disease, indicate likelihood:
#'   \item DXAPOSS T NA If Possible AD, select box(es) to indicate reason:
#'   \item DXAATYSP T NA Atypical clinical course or features (specify)
#'   \item DXAMETSP T NA Metabolic / Toxic Disorder (specify)
#'   \item DXAOTHSP T NA Other (specify)
#'   \item DXODES N NA If dementia due to other etiology, select best diagnosis:
#'   \item DXOOTHSP T NA Other (specify)
#'   \item DXDEP N NA 4a. Depressive symptoms present?
#'   \item DXDEPSP T NA If yes, please describe
#'   \item DXPARK N NA 4b.  Parkinsonism symptoms present?
#'   \item DXPARKSP T NA If yes, please describe
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name dxsum
#' @usage data(dxsum)
#' @format A data frame with 10507 rows and 49 variables
NULL

#' ECG
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#'   \item DONE N  Was assessment/procedure done?
#'   \item NDREASON N  If No, reason not done:
#'   \item ECOMPDT D MM/DD/YYYY Date ECG Completed
#'   \item ECOMPTM T HHMM Time ECG Completed
#'   \item ECGPR N  Was there a PR interval?
#'   \item ECGPRI N ms PR Interval
#'   \item ECGQRS N ms QRS Duration
#'   \item ECGQTC N ms QT Interval
#'   \item ECGHRT N bpm Heart Rate
#'   \item ECGNORM N  ECG Status:
#'   \item ECGABNORM T  If abnormal, please describe:
#'   \item ECGREV N  Was the result reviewed prior to the AV-1451 dose?
#'   \item ECGLIMIT N  Was the result within limits specified in the addendum?
#'   \item ECGCOMM T  Comments:
#' }
#'
#' @examples
#' \donotrun{
#' describe(ecg)
#' }
#' @docType data
#' @keywords datasets
#' @name ecg
#' @usage data(ecg)
#' @format A data frame with 117 rows and 21 variables
NULL

#' Everyday Cognition - Participant Self-Report 
#'
#'
#'
#'
#' @references Farias T. S., Mungas, D., Harvey, D. J., Simmons, A., Reed, B. R., & DeCarli, C. (November 01, 2011). The measurement of everyday cognition: Development and validation of a short form of the Everyday Cognition scales. Alzheimer's and Dementia, 7, 6, 593-601. http://www.sciencedirect.com/science/article/pii/S1552526011000896
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item EcogPtMem     N  Participant ECog - Mem         
#'   \item EcogPtLang    N  Participant ECog - Lang        
#'   \item EcogPtVisspat N  Participant ECog - Vis//Spat   
#'   \item EcogPtPlan    N  Participant ECog - Plan        
#'   \item EcogPtOrgan   N  Participant ECog - Organ       
#'   \item EcogPtDivatt  N  Participant ECog - Div atten   
#'   \item EcogPtTotal   N  Participant ECog - Total       
#'   \item SOURCE N  Information Source:
#'   \item RID N NA Participant roster ID
#'   \item SITEID N NA Site ID
#'   \item VISCODE T NA Visit code
#'   \item USERDATE S NA Date record created
#'   \item USERDATE2 S NA Date record last updated
#'   \item MEMORY1 N NA 1. Remembering a few shopping items without a list.
#'   \item MEMORY2 N NA 2. Remembering things that happened recently (such as recent outings, events in the news).
#'   \item MEMORY3 N NA 3. Recalling conversations a few days later.
#'   \item MEMORY4 N NA 4. Remembering where I have placed objects.
#'   \item MEMORY5 N NA 5. Repeating stories and/or questions.
#'   \item MEMORY6 N NA 6. Remembering the current date or day of the week.
#'   \item MEMORY7 N NA 7. Remembering I have already told someone something.
#'   \item MEMORY8 N NA 8. Remembering appointments, meetings, or engagements.
#'   \item LANG1 N NA 1. Forgetting the names of objects.
#'   \item LANG2 N NA 2. Verbally giving instructions to others.
#'   \item LANG3 N NA 3. Finding the right words to use in conversations.
#'   \item LANG4 N NA 4. Communicating thoughts in a conversation.
#'   \item LANG5 N NA 5. Following a story in a book or on TV.
#'   \item LANG6 N NA 6. Understanding the point of what other people are trying to say.
#'   \item LANG7 N NA 7. Remembering the meaning of common words.
#'   \item LANG8 N NA 8. Describing a program I have watched on TV.
#'   \item LANG9 N NA 9. Understanding spoken directions or instructions.
#'   \item VISSPAT1 N NA 1. Following a map to find a new location.
#'   \item VISSPAT2 N NA 2. Reading a map and helping with directions when someone else is driving.
#'   \item VISSPAT3 N NA 3. Finding my car in a parking lot.
#'   \item VISSPAT4 N NA 4. Finding my way back to a meeting spot in the mall or other location.
#'   \item VISSPAT5 N NA Duplicate Field Removed:  5. Following a story in a book or on TV.
#'   \item VISSPAT6 N NA 5. Finding my way around a familiar neighborhood.
#'   \item VISSPAT7 N NA 6. Finding my way around a familiar store.
#'   \item VISSPAT8 N NA 7. Finding my way around a house visited many times.
#'   \item PLAN1 N NA 1. Planning a sequence of stops on a shopping trip.
#'   \item PLAN2 N NA 2. The ability to anticipate weather changes and plan accordingly (i.e., bring a coat or umbrella)
#'   \item PLAN3 N NA 3. Developing a schedule in advance of anticipated events.
#'   \item PLAN4 N NA 4. Thinking things through before acting.
#'   \item PLAN5 N NA 5. Thinking ahead.
#'   \item ORGAN1 N NA 1. Keeping living and work space organized.
#'   \item ORGAN2 N NA 2. Balancing the checkbook without error.
#'   \item ORGAN3 N NA 3. Keeping financial records organized.
#'   \item ORGAN4 N NA 4. Prioritizing tasks by importance.
#'   \item ORGAN5 N NA 5. Keeping mail and papers organized.
#'   \item ORGAN6 N NA 6. Using an organized strategy to manage a medication schedule involving multiple medications.
#'   \item DIVATT1 N NA 1. The ability to do two things at once.
#'   \item DIVATT2 N NA 2. Returning to a task after being interrupted.
#'   \item DIVATT3 N NA 3. The ability to concentrate on a task without being distracted by external things in the environment.
#'   \item DIVATT4 N NA 4. Cooking or working and talking at the same time.
#'   \item STAFFASST N NA 1. How much assistance was needed from the research staff to complete this form?
#'   \item VALIDITY N NA 2. Validity of the information collected from the participant (based on research assistant's observations and interactions with the participant while they were completing the ECog):
#'   \item CONCERN N NA Are you concerned that you have a memory or other thinking problem?
#' }
#'
#' @examples
#' ecog.score <- function(x){ 
#'   x <- as.numeric(unlist(lapply(strsplit(as.character(x), '- ', fixed = TRUE),
#'       FUN = function(x) x[1])))
#'   x[x == 9] <- NA
#'   missing <- sum(is.na(x))
#'   if(missing/length(x) < 0.5){
#'     return(mean(x, na.rm = TRUE))
#'   }else{
#'     return(NA)
#'   }
#' }
#' 
#' mem <- c('MEMORY1', 'MEMORY2', 'MEMORY3', 'MEMORY4', 'MEMORY5', 'MEMORY6', 'MEMORY7', 'MEMORY8')
#' lang <-  c('LANG1', 'LANG2', 'LANG3', 'LANG4', 'LANG5', 'LANG6', 'LANG7', 'LANG8', 'LANG9')
#' visspat <- c('VISSPAT1', 'VISSPAT2', 'VISSPAT3', 'VISSPAT4', 
#'  'VISSPAT5', 'VISSPAT6', 'VISSPAT7', 'VISSPAT8')
#' plan <- c('PLAN1', 'PLAN2', 'PLAN3', 'PLAN4', 'PLAN5')
#' organ <- c('ORGAN1', 'ORGAN2', 'ORGAN3', 'ORGAN4', 'ORGAN5', 'ORGAN6')
#' divatt <- c('DIVATT1', 'DIVATT2', 'DIVATT3', 'DIVATT4')
#' 
#' ecogpt$EcogPtMem <- apply(ecogpt[, mem], 1, ecog.score)
#' ecogpt$EcogPtLang <- apply(ecogpt[, lang], 1, ecog.score)
#' ecogpt$EcogPtVisspat <- apply(ecogpt[, visspat], 1, ecog.score)
#' ecogpt$EcogPtPlan <- apply(ecogpt[, plan], 1, ecog.score)
#' ecogpt$EcogPtOrgan <- apply(ecogpt[, organ], 1, ecog.score)
#' ecogpt$EcogPtDivatt <- apply(ecogpt[, divatt], 1, ecog.score)
#' ecogpt$EcogPtTotal <- apply(ecogpt[, c(mem, lang, visspat, plan, organ, divatt)], 1, ecog.score)
#' 
#' label(ecogpt$EcogPtMem) <- 'Pt ECog - Mem'
#' label(ecogpt$EcogPtLang) <- 'Pt ECog - Lang'
#' label(ecogpt$EcogPtVisspat) <- 'Pt ECog - Vis/Spat'
#' label(ecogpt$EcogPtPlan) <- 'Pt ECog - Plan'
#' label(ecogpt$EcogPtOrgan) <- 'Pt ECog - Organ'
#' label(ecogpt$EcogPtDivatt) <- 'Pt ECog - Mem'
#' label(ecogpt$EcogPtTotal) <- 'Pt ECog - Div atten'
#' 
#' 
#' @docType data
#' @keywords datasets
#' @name ecogpt
#' @usage data(ecogpt)
#' @format A data frame with 5623 rows and 58 variables
NULL

#' Everyday Cognition - Study Partner Report 
#'
#'
#'
#'
#' @references Farias T. S., Mungas, D., Harvey, D. J., Simmons, A., Reed, B. R., & DeCarli, C. (November 01, 2011). The measurement of everyday cognition: Development and validation of a short form of the Everyday Cognition scales. Alzheimer's and Dementia, 7, 6, 593-601. http://www.sciencedirect.com/science/article/pii/S1552526011000896
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item SPID N NA Study Partner ID:
#'   \item EcogSPMem     N  Study Partner ECog - Mem       
#'   \item EcogSPLang    N  Study Partner ECog - Lang      
#'   \item EcogSPVisspat N  Study Partner ECog - Vis//Spat 
#'   \item EcogSPPlan    N  Study Partner ECog - Plan      
#'   \item EcogSPOrgan   N  Study Partner ECog - Organ     
#'   \item EcogSPDivatt  N  Study Partner ECog - Div atten 
#'   \item EcogSPTotal   N  Study Partner ECog - Total     
#'   \item SOURCE N  Information Source:
#'   \item RID N NA Participant roster ID
#'   \item SITEID N NA Site ID
#'   \item VISCODE T NA Visit code
#'   \item USERDATE S NA Date record created
#'   \item USERDATE2 S NA Date record last updated
#'   \item MEMORY1 N NA 1. Remembering a few shopping items without a list.
#'   \item MEMORY2 N NA 2. Remembering things that happened recently (such as recent outings, events in the news).
#'   \item MEMORY3 N NA 3. Recalling conversations a few days later.
#'   \item MEMORY4 N NA 4. Remembering where he/she has placed objects.
#'   \item MEMORY5 N NA 5. Repeating stories and/or questions.
#'   \item MEMORY6 N NA 6. Remembering the current date or day of the week.
#'   \item MEMORY7 N NA 7. Remembering he/she has already told someone something.
#'   \item MEMORY8 N NA 8. Remembering appointments, meetings, or engagements.
#'   \item LANG1 N NA 1. Forgetting the names of objects.
#'   \item LANG2 N NA 2. Verbally giving instructions to others.
#'   \item LANG3 N NA 3. Finding the right words to use in conversations.
#'   \item LANG4 N NA 4. Communicating thoughts in a conversation.
#'   \item LANG5 N NA 5. Following a story in a book or on TV.
#'   \item LANG6 N NA 6. Understanding the point of what other people are trying to say.
#'   \item LANG7 N NA 7. Remembering the meaning of common words.
#'   \item LANG8 N NA 8. Describing a program he/she has watched on TV.
#'   \item LANG9 N NA 9. Understanding spoken directions or instructions.
#'   \item VISSPAT1 N NA 1. Following a map to find a new location.
#'   \item VISSPAT2 N NA 2. Reading a map and helping with directions when someone else is driving.
#'   \item VISSPAT3 N NA 3. Finding one's car in a parking lot.
#'   \item VISSPAT4 N NA 4. Finding my way back to a meeting spot in the mall or other location.
#'   \item VISSPAT5 N NA Duplicate Field Removed:  5. Following a story in a book or on TV.
#'   \item VISSPAT6 N NA 5. Finding his/her way around a familiar neighborhood.
#'   \item VISSPAT7 N NA 6. Finding his/her way around a familiar store.
#'   \item VISSPAT8 N NA 7. Finding his/her way around a house visited many times.
#'   \item PLAN1 N NA 1. Planning a sequence of stops on a shopping trip.
#'   \item PLAN2 N NA 2. The ability to anticipate weather changes and plan accordingly (i.e., bring a coat or umbrella)
#'   \item PLAN3 N NA 3. Developing a schedule in advance of anticipated events.
#'   \item PLAN4 N NA 4. Thinking things through before acting.
#'   \item PLAN5 N NA 5. Thinking ahead.
#'   \item ORGAN1 N NA 1. Keeping living and work space organized.
#'   \item ORGAN2 N NA 2. Balancing the checkbook without error.
#'   \item ORGAN3 N NA 3. Keeping financial records organized.
#'   \item ORGAN4 N NA 4. Prioritizing tasks by importance.
#'   \item ORGAN5 N NA 5. Keeping mail and papers organized.
#'   \item ORGAN6 N NA 6. Using an organized strategy to manage a medication schedule involving multiple medications.
#'   \item DIVATT1 N NA 1. The ability to do two things at once.
#'   \item DIVATT2 N NA 2. Returning to a task after being interrupted.
#'   \item DIVATT3 N NA 3. The ability to concentrate on a task without being distracted by external things in the environment.
#'   \item DIVATT4 N NA 4. Cooking or working and talking at the same time.
#' }
#'
#' @examples
#' 
#' ecog.score <- function(x){ 
#'   x <- as.numeric(unlist(lapply(strsplit(as.character(x), '- ', fixed = TRUE),
#'       FUN = function(x) x[1])))
#'   x[x == 9] <- NA
#'   missing <- sum(is.na(x))
#'   if(missing/length(x) < 0.5){
#'     return(mean(x, na.rm = TRUE))
#'   }else{
#'     return(NA)
#'   }
#' }
#' 
#' mem <- c('MEMORY1', 'MEMORY2', 'MEMORY3', 'MEMORY4', 'MEMORY5', 'MEMORY6', 'MEMORY7', 'MEMORY8')
#' lang <-  c('LANG1', 'LANG2', 'LANG3', 'LANG4', 'LANG5', 'LANG6', 'LANG7', 'LANG8', 'LANG9')
#' visspat <- c('VISSPAT1', 'VISSPAT2', 'VISSPAT3', 'VISSPAT4', 
#'  'VISSPAT5', 'VISSPAT6', 'VISSPAT7', 'VISSPAT8')
#' plan <- c('PLAN1', 'PLAN2', 'PLAN3', 'PLAN4', 'PLAN5')
#' organ <- c('ORGAN1', 'ORGAN2', 'ORGAN3', 'ORGAN4', 'ORGAN5', 'ORGAN6')
#' divatt <- c('DIVATT1', 'DIVATT2', 'DIVATT3', 'DIVATT4')
#' 
#' ecogsp$EcogSPMem <- apply(ecogsp[, mem], 1, ecog.score)
#' ecogsp$EcogSPLang <- apply(ecogsp[, lang], 1, ecog.score)
#' ecogsp$EcogSPVisspat <- apply(ecogsp[, visspat], 1, ecog.score)
#' ecogsp$EcogSPPlan <- apply(ecogsp[, plan], 1, ecog.score)
#' ecogsp$EcogSPOrgan <- apply(ecogsp[, organ], 1, ecog.score)
#' ecogsp$EcogSPDivatt <- apply(ecogsp[, divatt], 1, ecog.score)
#' ecogsp$EcogSPTotal <- apply(ecogsp[, c(mem, lang, visspat, plan, organ, divatt)], 1, ecog.score)
#' 
#' label(ecogsp$EcogSPMem) <- 'SP ECog - Mem'
#' label(ecogsp$EcogSPLang) <- 'SP ECog - Lang'
#' label(ecogsp$EcogSPVisspat) <- 'SP ECog - Vis/Spat'
#' label(ecogsp$EcogSPPlan) <- 'SP ECog - Plan'
#' label(ecogsp$EcogSPOrgan) <- 'SP ECog - Organ'
#' label(ecogsp$EcogSPDivatt) <- 'SP ECog - Mem'
#' label(ecogsp$EcogSPTotal) <- 'SP ECog - Div atten'
#' @docType data
#' @keywords datasets
#' @name ecogsp
#' @usage data(ecogsp)
#' @format A data frame with 5616 rows and 56 variables
NULL

#' Eligibility Confirmation
#'
#'
#'
#' @author \email{adni-data@googlegroups.com}
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item EXAMDATE D  Examination Date
#'   \item CHSTATUS N  Status of participant at this visit (check one):
#'   \item CHREASON T  Reason participant excluded from protocol:
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name eligconf
#' @usage data(eligconf)
#' @format A data frame with 1386 rows and 10 variables
NULL

#' Enrollment Tracking
#'
#'
#'
#' @author \email{adni-data@googlegroups.com}
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item DATE D  Date
#'   \item CITY T  City
#'   \item STATE T  State/Province
#'   \item COUNTRY T  Country
#'   \item REFSOURCE T  Please check all that apply when asking the volunteer where they heard about the ADNI study:
#'   \item RADIOSPE T  Radio Station Specify:
#'   \item OTHERSPE T  Other Specify:
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name enrolltr
#' @usage data(enrolltr)
#' @format A data frame with 961 rows and 14 variables
NULL

#' Exclusion Criteria
#'
#'
#'
#' @author \email{adni-data@googlegroups.com}
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item EXAMDATE D  Examination Date
#'   \item EXNEURO N  1. NL - Does the participant have a significant neurologic disease such as Parkinson's disease, multi-infarct dementia, Huntington's disease, normal pressure hydrocephalus, brain tumor, progressive supranuclear palsy, seizure disorder, subdural hematoma, multiple sclerosis, or history of significant head trauma followed by persistent neurologic defaults or known structural brain abnormalities.<br>MCI - Does the participant have a significant neurologic disease other than suspected incipient Alzheimer's disease such as...<br>AD - Does the participant have a significant neurologic disease other than Alzheimer's disease including...
#'   \item EXNIMAG N  2. Does the participant's screening/baseline MRI scans have evidence of infection, infarction, or other focal lesions?  Participants with multiple lacunes or lacunes in a critical memory structure are excluded.
#'   \item EXMRI N  3. Does the participant have a pacemaker, aneurysm clips, artificial heart valves, ear implants, metal fragments or foreign objects in the eyes, skin or body.
#'   \item EXPSYCH N  4. NL - Has the participant had major depression or bipolar disorder as described in DSM-IV within the past year or a history of schizophrenia (DSM IV criteria)?<br>MCI/AD - Does the participant have a history of major depression...or a history of psychotic features, agitation, or behavioral problems within the last 3 months which could lead to difficulty complying with the protocol?
#'   \item EXABUSE N  5. Does the participant have a history of alcohol or substance abuse or dependence within the past 2 years (DSM IV criteria)?
#'   \item EXILLNESS N  6. Does the participant have a significant systemic illness or unstable medical condition which could lead to difficulty complying with the protocol?
#'   \item EXLAB N  7. Does the participant have any clinically significant abnormalities in B12, RPR, or TFTs that might interfere with the study.
#'   \item EXRESID N  8. Does the participant reside in a skilled nursing facility?
#'   \item EXMEDS N  9. Is the participant currently taking, or has he/she taken in the last 4 weeks, any excluded medication(s) as described in the Procedures Manual?
#'   \item EXINVEST N  10. Has the participant used another investigational agent within one month prior to screening?
#'   \item EXPARTICIP N  11. Is the participant participating in a clinical study involving neuropsychological measures being collected more than one time per year?
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name exclusio
#' @usage data(exclusio)
#' @format A data frame with 1087 rows and 19 variables
NULL

#' Inclusion/Exclusion Exceptions Log
#'
#'
#'
#' @author \email{adni-data@googlegroups.com}
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item RECNO N  Record Number
#'   \item EXAMDATE D  Examination Date
#'   \item EXCCRIT N  Exception applies to:
#'   \item EXCNUMB T  Inclusion/Exclusion Criteria Item number
#'   \item EXUNSCAN N  If requesting an unscheduled visit, specify which scans are being requested:
#'   \item EXCBIDT D  If Fluroscopy or LP spine film, indicate [anticipated] date performed:
#'   \item EXCDESC T  Description of exception
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name excptlog
#' @usage data(excptlog)
#' @format A data frame with 1340 rows and 14 variables
NULL

#' Extension Consent Form
#'
#'
#'
#' @author \email{adni-data@googlegroups.com}
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#'   \item INCEXT N  Has the participant signed the Informed Consent form for the ADNI Extension (Amendment 3)?
#'   \item INCEXTDT D  If Yes, date signed.
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name extconsnt
#' @usage data(extconsnt)
#' @format A data frame with 137 rows and 9 variables
NULL

#' Fagan lab summaries
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/FAGANLAB/ADNI_Methods_Fagan%20Lab%20Final.pdf}, \url{https://adni.bitbucket.io/reference/docs/FAGANLAB/ADNI_Methods_Fagan%20Lab%20VILIP.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item VISCODE2 -4 -4 Translated visit code
#'   \item EXAMDATE -4 -4 Examination Date
#'   \item VILIP -4 pg/ml VILIP-1 
#'   \item VILIP_STDEV -4  Standard Deviation
#'   \item VILIP_CV -4  Coefficient of Variation (%)
#'   \item YKL -4 ng/ml YKL-40
#'   \item YKL_STDEV -4  Standard Deviation
#'   \item YKL_CV -4  Coefficient of Variation (%)
#'   \item SNAP -4 pg/ml SNAP-25 
#'   \item SNAP_STDEV -4  Standard Deviation
#'   \item SNAP_CV -4  Coefficient of Variation (%)
#'   \item NGRN -4 pg/ml NRGN
#'   \item NGRN_STDEV -4  Standard Deviation
#'   \item NGRN_CV -4  Coefficient of Variation (%)
#' }
#'
#' @examples
#' \donotrun{
#' describe(faganlab)
#' }
#' @docType data
#' @keywords datasets
#' @name faganlab
#' @usage data(faganlab)
#' @format A data frame with 587 rows and 16 variables
NULL

#' Family History - Parents
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item MOTHALIVE N NA Is mother living? 
#'   \item MOTHAGE N NA Current age or age at death? 
#'   \item MOTHDEM N NA Did/Does the biological mother have dementia?
#'   \item MOTHAD N NA If yes, did/does biological mother have Alzheimer's Disease?
#'   \item MOTHSXAGE N NA At what approximate age did mother's symptoms start?
#'   \item FATHALIVE N NA Is father living? 
#'   \item FATHAGE N NA Current age or age at death? 
#'   \item FATHDEM N NA Did/Does the biological father have dementia?
#'   \item FATHAD N NA If yes, did/does biological father have Alzheimer's Disease?
#'   \item FATHSXAGE N NA At what approximate age did father's symptoms start?
#'   \item COMM T NA Comments
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' \donotrun{
#' describe(famhxpar)
#' }
#' @docType data
#' @keywords datasets
#' @name famhxpar
#' @usage data(famhxpar)
#' @format A data frame with 231 rows and 18 variables
NULL

#' Family History - Sibling Log
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item SIBYOB N NA Biological sibling year of birth
#'   \item SIBRELAT N NA Specify relationship
#'   \item SIBGENDER N NA Gender
#'   \item SIBALIVE N NA Is sibling living?
#'   \item SIBAGE N NA Current age or age of death
#'   \item SIBDEMENT N NA Did/Does this sibling have dementia?
#'   \item SIBAD N NA If yes, did/does sibling have Alzheimer's Disease?
#'   \item SIBSXAGE N NA At what approximate age did symptoms start?
#'   \item COMM T NA Comments
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' \donotrun{
#' describe(famhxsib)
#' }
#' @docType data
#' @keywords datasets
#' @name famhxsib
#' @usage data(famhxsib)
#' @format A data frame with 614 rows and 16 variables
NULL

#' Functional Assessment Questionnaire
#'
#'
#'
#' @author \email{adni-data@googlegroups.com}
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item SPID N NA Study Partner ID:
#'   \item SOURCE N NA Information Source
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item EXAMDATE D  Examination Date
#'   \item FAQSOURCE N  Information Source
#'   \item FAQFINAN N  1. Writing checks, paying bills, or balancing checkbook.
#'   \item FAQFORM N  2. Assembling tax records, business affairs, or other papers.
#'   \item FAQSHOP N  3. Shopping alone for clothes, household necessities, or groceries.
#'   \item FAQGAME N  4. Playing a game of skill such as bridge or chess, working on a hobby.
#'   \item FAQBEVG N  5. Heating water, making a cup of coffee, turing off the stove.
#'   \item FAQMEAL N  6. Preparing a balanced meal.
#'   \item FAQEVENT N  7. Keeping track of current events.
#'   \item FAQTV N  8. Paying attention to and understanding a TV program, book, or magazine.
#'   \item FAQREM N  9. Remembering appointments, family occasions, holidays, medications.
#'   \item FAQTRAVL N  10. Traveling out of the neighborhood, driving, or arranging to take public transportation.
#'   \item FAQTOTAL N  Total Score
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name faq
#' @usage data(faq)
#' @format A data frame with 9502 rows and 22 variables
NULL

#' Financial Capacity Instrument Short Form (FCI-SF) 
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item DONE N NA Was assessment/procedure done?
#'   \item NDREASON N NA If No, reason not done
#'   \item RATER T NA Rater Initials
#'   \item NICKELS N NA 1.  Nickels
#'   \item QUARTERS N NA 2.  Quarters
#'   \item BUDGET N NA 3. Budget
#'   \item EXPMEDINS N NA Experience with Medical Insurance Plan?
#'   \item INSURANCE N NA 4. Health Care Insurance Problem
#'   \item MEDINSTIME N seconds Time to complete Item 4
#'   \item EXPINCTAX N NA Experience with Income Taxes?
#'   \item TAXCREDA N NA 5. a. Tax Credit
#'   \item QUES5TIME N seconds Time to complete Item 5.a.
#'   \item TAXCREDB N NA 5. b. Tax Credit
#'   \item EXPCHECKREG N NA Experience with Checkbook/Check Register?
#'   \item PAYEE N NA 6. Payee
#'   \item SNGLCHK7 N NA 7. Payee section
#'   \item SNGLCHK8 N NA 8.  $ amount section (numerical)
#'   \item SNGLCHK9 N NA 9.  $ amount section (written)
#'   \item SNGLCHK10 N NA 10. Signature of payer
#'   \item SNGLCHK11 N NA 11. Date properly written
#'   \item SNGLCHK12 N NA 12. Number of check
#'   \item SNGLCHK13 N NA 13. Date properly entered
#'   \item SNGLCHK14 N NA 14. Payee section
#'   \item SNGLCHK15 N NA 15. Amount of check
#'   \item SNGLCHK16 N NA 16. New account balance
#'   \item SNGLCHKTIME N seconds Time to complete items 7-16
#'   \item COMPLXCHK17 N NA 17. Number of check
#'   \item COMPLXCHK18 N NA 18. Date properly entered
#'   \item COMPLXCHK19 N NA 19. Payee section
#'   \item COMPLXCHK20 N NA 20. Amount of check
#'   \item COMPLXCHK21 N NA 21. New Account Balance
#'   \item COMPLXCHK22 N NA 22. Number of check
#'   \item COMPLXCHK23 N NA 23. Date properly entered
#'   \item COMPLXCHK24 N NA 24. Payee section
#'   \item COMPLXCHK25 N NA 25. Amount of check
#'   \item COMPLXCHK26 N NA 26. New Account Balance
#'   \item COMPLXCHK27 N NA 27. Date properly entered
#'   \item COMPLXCHK28 N NA 28. Description of Transaction
#'   \item COMPLXCHK29 N NA 29. Amount of deposit
#'   \item COMPLXCHK30 N NA 30. New account balance
#'   \item COMPLXCHKTIME N seconds Time to complete Items 17-30
#'   \item BANKSTATA N NA 31. a. Bank Statement
#'   \item BANKSTATB N NA 31. b. Bank Statement
#'   \item EXPBANKSTATE N NA Experience with Bank Statement?
#'   \item BANKSTAT32 N NA 32. Interest Rate
#'   \item BANKSTAT33 N NA 33. Time Period
#'   \item BANKSTAT34 N NA 34. Checks Cleared
#'   \item BANKSTAT35 N NA 35. Quarterly Interest
#'   \item BANKSTAT36 N NA 36. Gaps in Check Sequence
#'   \item BANKSTAT37 N NA 37. Date of the Withdrawal Payment
#'   \item COMM T NA Comments
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#'   \item MC_SCORE N  Mental Calculation Score (Items 1-2)            
#'   \item FC_SCORE N  Financial Conceptual Knowledge Score (Items 3-6)
#'   \item SNGLCHKSCORE   N  Single/Checkbook Register Score (Items 7-16):       
#'   \item COMPLXCHKSCORE N  Complex Checkbook/Register Score (Items 17-30):
#'   \item CHKCOMPOSTIME  N seconds Checkbook/Register Composite Time (Items 7-16 & 17-30):
#'   \item CHKCOMPOSSCORE N  Combined Checkbook/Register Score (Items 7-16 + 17-30 ):
#'   \item BANKSTATSCORE  N  Bank Statement Management Score (Items 31-37):
#'   \item TOTCOMPTIME N seconds TOTAL Composite Time (Items 4, 5, 7-16, 17-30):
#'   \item FCISCORE N  TOTAL FCI-SF SCORE:
#' }
#'
#' @examples
#' \donotrun{
#' describe(fci)
#' }
#' @docType data
#' @keywords datasets
#' @name fci
#' @usage data(fci)
#' @format A data frame with 385 rows and 67 variables
NULL

#' Family History Questionnaire
#'
#'
#'
#' @author \email{adni-data@googlegroups.com}
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item EXAMDATE D  Examination Date
#'   \item FHQSOURCE N  Information Souce
#'   \item FHQPROV N  Indicate below who provided the information collected for this questionnaire:
#'   \item FHQMOM N  Dementia
#'   \item FHQMOMAD N  Alzheimer's Disease
#'   \item FHQDAD N  Dementia
#'   \item FHQDADAD N  Alzheimer's Disease
#'   \item FHQSIB N  3. Does the participant have any siblings?
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name fhq
#' @usage data(fhq)
#' @format A data frame with 2952 rows and 15 variables
NULL

#' FLAIR QC
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item USERDATE -4 NA Date record created
#'   \item RID -4 NA Participant roster ID
#'   \item DATE -4 NA Date
#'   \item HEADCOVERAGE -4 NA Headcoverage
#'   \item SUSCEPTIBILITYARTIFACTS -4 NA Susceptibility artifacts
#'   \item INHOMOGENEITYARTIFACTS -4 NA Inhomogeneity artifacts
#'   \item MOTION -4 NA Motion
#'   \item TWODSERIESALIGNMENT -4 NA 2D series alignment
#'   \item CSFFLOWARTIFACTS -4 NA CSF Flow Artifacts
#'   \item CSFSUPPRESSION -4 NA CSF Suppression
#'   \item SNR -4 NA SNR
#'   \item PULSEARTIFACT -4 NA Pulse Artifact
#'   \item FLAIROVERALLQUALITY -4 NA FLAIR overallquality
#'   \item FLAIRCOMMENTS -4 NA FLAIR Comments
#' }
#'
#' @examples
#' \donotrun{
#' describe(flairqc)
#' }
#' @docType data
#' @keywords datasets
#' @name flairqc
#' @usage data(flairqc)
#' @format A data frame with 1128 rows and 15 variables
NULL

#' Fox Lab BSI measures
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/FOXLABBSI/ADNI2_Methods_BrainMAPS.pdf}, \url{https://adni.bitbucket.io/reference/docs/FOXLABBSI/ADNI2_Methods_STEPS.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4  Participant roster ID
#'   \item VISCODE -4  Visit code
#'   \item VISCODE2 -4 -4 Translated visit code
#'   \item EXAMDATE -4  Examination Date
#'   \item VERSION -4  Version date of results
#'   \item RUNDATE -4  Analysis run date
#'   \item STATUS -4  Analysis completeness
#'   \item LONIUID -4  UID of fully pre-processed scan for which results are provided
#'   \item LONIUID_BASE -4  UID of fully pre-processed baseline scan for longitudinal results
#'   \item BRAINVOL -4 ml Whole brain volume
#'   \item VENTVOL -4 ml Ventricular volume
#'   \item HIPPOVOL_R -4 ml Right side hippocampal volume
#'   \item HIPPOVOL_L -4 ml Left side hippocampal volume
#'   \item DBCBBSI -4 ml Whole brain classic BSI
#'   \item KMNDBCBBSI -4 ml Whole brain KN-BSI
#'   \item VBSI -4 ml Ventricular BSI
#'   \item HBSI_R -4 ml Right side hippocampal BSI
#'   \item HBSI_L -4 ml Left side hippocampal BSI
#'   \item REGRATING -4  Longitudinal QC rating
#'   \item VENTACCEPT -4  Ventricular QC rating
#'   \item HPACCEPT_R -4  Right side hippocampal QC rating
#'   \item HPACCEPT_L -4  Left side hippocampal QC rating
#'   \item MRSEQUENCE -4 -4 -4
#'   \item MRFIELD -4 -4 -4
#'   \item PROTOCOL -4  The ADNI study under which the original scans were collected
#'   \item QC_PASS -4  Selected for cross-sectional analysis
#' }
#'
#' @examples
#' \donotrun{
#' describe(foxlabbsi)
#' }
#' @docType data
#' @keywords datasets
#' @name foxlabbsi
#' @usage data(foxlabbsi)
#' @format A data frame with 12156 rows and 26 variables
NULL

#' Geriatric Depression Scale
#'
#'
#'
#' @author \email{adni-data@googlegroups.com}
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item SOURCE N NA Information Source
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item EXAMDATE D  Examination Date
#'   \item GDSOURCE N  Information Source
#'   \item GDUNABL T  Check here if:
#'   \item GDUNABSP T  If unable, explain:
#'   \item GDSATIS N  1. Are you basically satisfied with your life?
#'   \item GDDROP N  2. Have you dropped many of your activities and interests?
#'   \item GDEMPTY N  3. Do you feel that your life is empty?
#'   \item GDBORED N  4. Do you often get bored?
#'   \item GDSPIRIT N  5. Are you in good spirits most of the time?
#'   \item GDAFRAID N  6. Are you afraid that something bad is going to happen to you?
#'   \item GDHAPPY N  7. Do you feel happy most of the time?
#'   \item GDHELP N  8. Do you often feel helpless?
#'   \item GDHOME N  9. Do you prefer to stay at home, rather than going out and doing new things?
#'   \item GDMEMORY N  10. Do you feel you have more problems with memory than most?
#'   \item GDALIVE N  11. Do you think its wonderful to be alive now?
#'   \item GDWORTH N  12. Do you feel pretty worthless the way you are now?
#'   \item GDENERGY N  13. Do you feel full of energy?
#'   \item GDHOPE N  14. Do you feel that your situation is hopeless?
#'   \item GDBETTER N  15. Do you think that most people are better off than you are?
#'   \item GDTOTAL N  Total Score
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name gdscale
#' @usage data(gdscale)
#' @format A data frame with 9462 rows and 28 variables
NULL

#' Genetic Sample Collection
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item COLLDATE D YYYY-MM-DD Date of Collection
#'   \item RNAFROZT T HHMM If Frozen, Time RNA placed in freezer (24hr clock):
#'   \item PBMCCOLL N NA On this date, was PBMC sample collected?
#'   \item PBMCVOL N mL If PBMC collected, volume
#'   \item RBCCOLL N NA On this date, was RBC extracted from biomarker collection tube?
#'   \item RBCTUBE N NA If RBC collected, total number of aliquot tubes
#'   \item RBCALIQ1 N mL RBC aliquot 1 volume (2.0 mL tube)
#'   \item RBCALIQ2 N mL RBC aliquot 2 volume (4.0 mL tube)
#'   \item RBCFROZT T HHMM If RBC collected, time placed in freezer
#'   \item BCFROZT T HHMM If Buffy Coat frozen, time placed in freezer
#'   \item GENFEDDATE D YYYY-MM-DD Date FedExed
#'   \item COMM T NA Comments:
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#'   \item RECNO N  
#'   \item APCOLLECT N  Was DNA sample collected (1 x 10 mL purple top EDTA tube)?
#'   \item EXAMDATE D  Examination Date
#'   \item APTIME T HHMM Time of DNA Collection (24hr clock)
#'   \item APVOLUME N mL Volume of blood drawn into 10 mL EDTA tube for DNA testing
#'   \item RNACOLL N  Was RNA sample collected (3 x 2.5 mL PAXgene RNA tubes)?
#'   \item RNADATE D  Date of RNA collection:
#'   \item RNATIME T HHMM Time of RNA collection (24hr clock):
#'   \item RNAVOL N mL Volume of blood drawn into 3 x 2.5 mL PAXgene RNA Tubes
#'   \item CLCOLL N  Was cell immortalization sample collected?
#'   \item CLDATE D  Date of cell immortalization collection
#'   \item CLTIME T HHMM Time of cell immortalization collection (24hr clock)
#'   \item CLVOLUME N mL Total volume of blood drawn for cell immortalization into 2 x 8.5 mL ACD-A (yellow top) tubes
#'   \item BCOAT N  Was Buffy Coat extracted from biomarker collection tube?
#'   \item BCREASON N  If No, please provide reason why the Buffy Coat was not extracted
#'   \item BCREASOTH T  Other (specify):
#'   \item BCVOL N mL Volume of aliquot
#'   \item DNAREASON N  If no, indicate reason
#'   \item DNAREASOTH T  Other (specify):
#'   \item RNAREASON N  If no, indicate reason
#'   \item RNAREASOTH T  Other (specify):
#'   \item CLREASON N  If no, indicate reason
#'   \item CLREASOTH T  Other (specify):
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name genetic
#' @usage data(genetic)
#' @format A data frame with 5060 rows and 42 variables
NULL

#' Global Unique Identifier (GUID)
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item DONE N NA Was assessment/procedure done?
#'   \item NDREASON N NA If No, reason not done
#'   \item GUID N NA Enter ADNI GUID
#'   \item COMM T NA Comments
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' \donotrun{
#' describe(guid)
#' }
#' @docType data
#' @keywords datasets
#' @name guid
#' @usage data(guid)
#' @format A data frame with 370 rows and 11 variables
NULL

#' Homocysteine - Results
#'
#'
#'
#' @author \email{adni-data@googlegroups.com}
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item HCTESTDT D  Date Test Performed
#'   \item HCAMPLAS N  AM total plasma Homocysteine
#'   \item HCVOLUME N  Volume of Blood Shipped in Lavendar Top Tube
#'   \item HCRECEIVE N  Sample received within 24 hours of blood draw?
#'   \item HCFROZEN N  Sample received frozen and packed in dry ice?
#'   \item HCRESAMP N  Request Resample?
#'   \item HCUSABLE N  Sample Useable?
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name hcres
#' @usage data(hcres)
#' @format A data frame with 3390 rows and 14 variables
NULL

#' Inclusion Criteria
#'
#'
#'
#' @author \email{adni-data@googlegroups.com}
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item EXAMDATE D  Examination Date
#'   \item INCSIGN N  1. Have the participant and study partner signed the Informed Consent form?
#'   \item INCSGDT D  If Yes, date signed
#'   \item INCSG15T N  Check the following to indicate the participant is suitable for and consents to:
#'   \item INCSGPET N  
#'   \item INCSG3T N  
#'   \item INCSGLP N  
#'   \item INCMCOMP N  2. NL - Is participant free of memory complaints, verified by an informant, aside from those normal with age?<br>MCI - Does the subject have memory complaints and memory difficulties that are verified by an informant?<br>AD -  Does the subject have memory complaints that are verified by an informant?
#'   \item INCMFXN N  3. NL - Normal memory function documented by scoring at specific cutoffs on the Logical Memory II subscale (delayed Paragraph Recall) from the Wechsler Memory Scaled - Revised (the maximum score is 25)<br>MCI/AD - Abnormal memory function documented by scoring below the educationn adjusted cutoff on the Logical Memory II subscale (Delayed  Paragraph Recall) from the Wechsler Memory Scale - Revised (the maximum score is 25)
#'   \item INCMMSE N  4. NL/MCI - Does the participant have Mini-Mental State Exam score between 24 and 30 (inclusive)?  (Exceptions must be made for subjects with less than 8 years of education at the discretion of the project director).<br>AD - Does the participant have an MMSE score between 20 and 26 (inclusive)?
#'   \item INCCDR N  5. NL - Does the participant have a Clinical Dementia Rating of 0?  Memory Box score must be 0.<br>MCI - Does the participant have a Clinical Dementia Rating of 0.5?  Memory Box score must be at least 0.5.<br>AD - Does participant have a Clinical Dementia rating of 0.5 or 1.0?
#'   \item INCCOG N  6. NL - Is the participant cognitively normal based on an absence of significant impairment in cognitive functions or activities of daily living?<br>MCI - Is the participant's general cognition and functional performance sufficiently perserved such that a diagnosis of Alzheimer's disease cannot be made by the site physician at the time of the screening visit? <br>AD - Does the participant meet NINCDS/ADRDA criteria for probable AD?
#'   \item INCHACH N  7. Does the participant have a Modified Hachinski score less than or equal to 4?
#'   \item INCAGE N  8. Is the participant between 55 and 90 years of age inclusive?
#'   \item INCSTMED N  9. Has the participant been on stable doses of non-excluded medications for at least 4 weeks prior to screening?
#'   \item INCGDS N  10. Does the participant have a Geriatric Depression Scale score of <6?
#'   \item INCINFORM N  11. Does the participant have an informant available who they have frequent contact with (e.g. an average of 10 hours per week or more), and can accompany the participant to all clinic visits and imaging sessions for the duration of the protocol?
#'   \item INCVISUAL N  12. Does the participant have adequate visual and auditory acuity to allow neuropsychological testing?
#'   \item INCHEALTH N  13. Is the participant in good general health with no additional diseases expected to interfere with the study?
#'   \item INCFEM N  14. If female, is the participant not pregnant, lactating, or of childbearing potential (i.e. women must be two years post-menopausal or surgically sterile)?
#'   \item INCPART N  15. NL/MCI - Is the participant willing and able to complete all Baseline assessment and participate in a 3-year protocol?<br>AD - Is the participant willing and able to ...2-year protocol?
#'   \item INCIMAG N  16. Is the participant willing to undergo MRI 1.5 Tesla neuroimaging (PET and MRI 3 Tesla are optional) and provide DNA for ApoE assessments and banking as well as plasma samples at protocol specified time points?
#'   \item INCEDUC N  17. Has the participant completed 6 grades of education (or had a good work history sufficient to exclude mental retardation)?
#'   \item INCLANG N  18. Is the participant fluent in English or Spanish?
#'   \item INCHIST N  19a. Medical History
#'   \item INCPHYS N  19b. Physical Examination?
#'   \item INCNEUR N  19c. Neurological Examination?
#'   \item INCLAB N  19d. Laboratory Tests?
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name inclusio
#' @usage data(inclusio)
#' @format A data frame with 1109 rows and 35 variables
NULL

#' Initial Health Assessment
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item IHNUM N NA Condition Number
#'   \item IHSYMPTOM N NA System/Category
#'   \item IHDESC T NA Description/Condition
#'   \item IHSURG N NA Is this a surgery?
#'   \item IHSURGDATE D YYYY-MM-DD If Yes, surgery date
#'   \item IHPRESENT N NA Is this a condition or symptom present in the three months prior to screening?
#'   \item IHCHRON N NA Chronicity
#'   \item IHSEVER N NA Severity
#'   \item IHDTONSET D YYYY-MM-DD Onset Date
#'   \item IHONGOING N NA Is symptom/condition ongoing?
#'   \item IHCEASE D YYYY-MM-DD Cease Date
#'   \item IHCOMM T NA Comments:
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' \donotrun{
#' describe(inithealth)
#' }
#' @docType data
#' @keywords datasets
#' @name inithealth
#' @usage data(inithealth)
#' @format A data frame with 6158 rows and 19 variables
NULL

#' An inventory of all ADNI assessments and samples
#'
#'
#'
#' @author \email{adni-data@googlegroups.com}
#'
#'
#' @description An inventory of all ADNI assessments and samples
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID   Participant roster ID
#'   \item VISCODE2   Translated visit code
#'   \item VISCODE   Visit code
#'   \item TABLE   Source data table or case report form
#'   \item ORIGPROT   Original study protocol
#'   \item COLPROT   Study protocol of data collection
#'   \item EXAMDATE   Exam date
#'   \item STATUS   Was the assessment conducted (Yes/No) or was CSF collected?
#'   \item EXAMDATE_LONI   Scan date from DICOM header
#'   \item USERDATE_LONI   Date image uploaded to LONI
#'   \item QCSTAT_LONI   QCstatus
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name inventory
#' @usage data(inventory)
#' @format A data frame with 59598 rows and 15 variables
NULL

#' Baseleine isoprostanes data. ADNI Biomarker Core laboratory
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N -4 Participant roster ID
#'   \item SITEID N -4 Site ID
#'   \item VISCODE T -4 Visit code
#'   \item USERDATE S -4 Date record created
#'   \item ISO8PGF2A N pg/ml 8-iso-PGF2alpha
#'   \item ISO812IPF2A N pg/ml 8,12-iso-iPF2alpha
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name isoprostane
#' @usage data(isoprostane)
#' @format A data frame with 415 rows and 7 variables
NULL

#' Item Level Data
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID T NA Participant roster ID
#'   \item VISCODE N NA Visit code
#'   \item ADAS_QuestionnaireNotAttempted T NA ADAS
#'   \item ADAS_Q1_T1_WL1_W1_butter T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T1_WL1_W2_arm T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T1_WL1_W3_shore T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T1_WL1_W4_letter T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T1_WL1_W5_queen T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T1_WL1_W6_cabin T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T1_WL1_W7_pole T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T1_WL1_W8_ticket T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T1_WL1_W9_grass T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T1_WL1_W10_engine T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T2_WL1_W1_pole T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T2_WL1_W2_letter T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T2_WL1_W3_butter T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T2_WL1_W4_queen T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T2_WL1_W5_arm T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T2_WL1_W6_shore T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T2_WL1_W7_grass T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T2_WL1_W8_cabin T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T2_WL1_W9_ticket T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T2_WL1_W10_engine T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T3_WL1_W1_shore T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T3_WL1_W2_letter T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T3_WL1_W3_arm T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T3_WL1_W4_cabin T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T3_WL1_W5_pole T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T3_WL1_W6_ticket T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T3_WL1_W7_engine T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T3_WL1_W8_grass T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T3_WL1_W9_butter T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T3_WL1_W10_queen T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T1_WL2_W1_bottle T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T1_WL2_W2_potato T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T1_WL2_W3_girl T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T1_WL2_W4_temple T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T1_WL2_W5_star T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T1_WL2_W6_animal T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T1_WL2_W7_forest T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T1_WL2_W8_lake T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T1_WL2_W9_clock T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T1_WL2_W10_office T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T2_WL2_W1_forest T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T2_WL2_W2_temple T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T2_WL2_W3_bottle T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T2_WL2_W4_star T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T2_WL2_W5_potato T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T2_WL2_W6_girl T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T2_WL2_W7_clock T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T2_WL2_W8_animal T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T2_WL2_W9_lake T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T2_WL2_W10_office T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T3_WL2_W1_girl T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T3_WL2_W2_temple T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T3_WL2_W3_potato T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T3_WL2_W4_animal T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T3_WL2_W5_forest T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T3_WL2_W6_lake T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T3_WL2_W7_office T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T3_WL2_W8_clock T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T3_WL2_W9_bottle T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T3_WL2_W10_star T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T1_WL3_W1_coast T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T1_WL3_W2_doll T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T1_WL3_W3_lip T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T1_WL3_W4_chair T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T1_WL3_W5_student T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T1_WL3_W6_apple T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T1_WL3_W7_horse T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T1_WL3_W8_pipe T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T1_WL3_W9_valley T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T1_WL3_W10_rock T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T2_WL3_W1_horse T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T2_WL3_W2_chair T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T2_WL3_W3_coast T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T2_WL3_W4_student T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T2_WL3_W5_doll T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T2_WL3_W6_lip T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T2_WL3_W7_valley T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T2_WL3_W8_apple T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T2_WL3_W9_pipe T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T2_WL3_W10_rock T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T3_WL3_W1_lip T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T3_WL3_W2_chair T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T3_WL3_W3_doll T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T3_WL3_W4_apple T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T3_WL3_W5_horse T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T3_WL3_W6_pipe T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T3_WL3_W7_rock T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T3_WL3_W8_valley T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T3_WL3_W9_coast T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_T3_WL3_W10_student T NA ADAS: ADAS Q1, T1-T3 indicate Trial 1 to Trial 3 of the Word-recall task. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q1_TimeEnded T NA ADAS: Time Q1 tasks ended
#'   \item ADAS_Q2a T NA ADAS
#'   \item ADAS_Q2b T NA ADAS
#'   \item ADAS_Q2c T NA ADAS
#'   \item ADAS_Q2d T NA ADAS
#'   \item ADAS_Q2e T NA ADAS
#'   \item ADAS_Q3a T NA ADAS
#'   \item ADAS_Q3b T NA ADAS
#'   \item ADAS_Q3c T NA ADAS
#'   \item ADAS_Q3d T NA ADAS
#'   \item ADAS_Q4_TimeBegan T NA ADAS: Time Q4 began
#'   \item ADAS_Q4_WL1_W1_butter T NA ADAS: ADAS Q4 is a repetition of Trial 1 of Q1. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q4_WL1_W2_arm T NA ADAS: ADAS Q4 is a repetition of Trial 1 of Q1. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q4_WL1_W3_shore T NA ADAS: ADAS Q4 is a repetition of Trial 1 of Q1. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q4_WL1_W4_letter T NA ADAS: ADAS Q4 is a repetition of Trial 1 of Q1. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q4_WL1_W5_queen T NA ADAS: ADAS Q4 is a repetition of Trial 1 of Q1. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q4_WL1_W6_cabin T NA ADAS: ADAS Q4 is a repetition of Trial 1 of Q1. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q4_WL1_W7_pole T NA ADAS: ADAS Q4 is a repetition of Trial 1 of Q1. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q4_WL1_W8_ticket T NA ADAS: ADAS Q4 is a repetition of Trial 1 of Q1. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q4_WL1_W9_grass T NA ADAS: ADAS Q4 is a repetition of Trial 1 of Q1. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q4_WL1_W10_engine T NA ADAS: ADAS Q4 is a repetition of Trial 1 of Q1. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q4_WL2_W1_bottle T NA ADAS: ADAS Q4 is a repetition of Trial 1 of Q1. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q4_WL2_W2_potato T NA ADAS: ADAS Q4 is a repetition of Trial 1 of Q1. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q4_WL2_W3_girl T NA ADAS: ADAS Q4 is a repetition of Trial 1 of Q1. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q4_WL2_W4_temple T NA ADAS: ADAS Q4 is a repetition of Trial 1 of Q1. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q4_WL2_W5_star T NA ADAS: ADAS Q4 is a repetition of Trial 1 of Q1. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q4_WL2_W6_animal T NA ADAS: ADAS Q4 is a repetition of Trial 1 of Q1. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q4_WL2_W7_forest T NA ADAS: ADAS Q4 is a repetition of Trial 1 of Q1. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q4_WL2_W8_lake T NA ADAS: ADAS Q4 is a repetition of Trial 1 of Q1. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q4_WL2_W9_clock T NA ADAS: ADAS Q4 is a repetition of Trial 1 of Q1. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q4_WL2_W10_office T NA ADAS: ADAS Q4 is a repetition of Trial 1 of Q1. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q4_WL3_W1_coast T NA ADAS: ADAS Q4 is a repetition of Trial 1 of Q1. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q4_WL3_W2_doll T NA ADAS: ADAS Q4 is a repetition of Trial 1 of Q1. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q4_WL3_W3_lip T NA ADAS: ADAS Q4 is a repetition of Trial 1 of Q1. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q4_WL3_W4_chair T NA ADAS: ADAS Q4 is a repetition of Trial 1 of Q1. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q4_WL3_W5_student T NA ADAS: ADAS Q4 is a repetition of Trial 1 of Q1. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q4_WL3_W6_apple T NA ADAS: ADAS Q4 is a repetition of Trial 1 of Q1. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q4_WL3_W7_horse T NA ADAS: ADAS Q4 is a repetition of Trial 1 of Q1. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q4_WL3_W8_pipe T NA ADAS: ADAS Q4 is a repetition of Trial 1 of Q1. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q4_WL3_W9_valley T NA ADAS: ADAS Q4 is a repetition of Trial 1 of Q1. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q4_WL3_W10_rock T NA ADAS: ADAS Q4 is a repetition of Trial 1 of Q1. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W10 followed by the word indicates the actual word and its position in the list.
#'   \item ADAS_Q5a_Flower T NA ADAS
#'   \item ADAS_Q5a_Bed T NA ADAS
#'   \item ADAS_Q5a_Whistle T NA ADAS
#'   \item ADAS_Q5a_Pencil T NA ADAS
#'   \item ADAS_Q5a_Rattle T NA ADAS
#'   \item ADAS_Q5a_Mask T NA ADAS
#'   \item ADAS_Q5a_Scissors T NA ADAS
#'   \item ADAS_Q5a_Comb T NA ADAS
#'   \item ADAS_Q5a_Wallet T NA ADAS
#'   \item ADAS_Q5a_Harmonica T NA ADAS
#'   \item ADAS_Q5a_Stethoscope T NA ADAS
#'   \item ADAS_Q5a_Tongs T NA ADAS
#'   \item ADAS_Q5b_Thumb T NA ADAS
#'   \item ADAS_Q5b_Middle T NA ADAS
#'   \item ADAS_Q5b_Ring T NA ADAS
#'   \item ADAS_Q5b_Index T NA ADAS
#'   \item ADAS_Q5b_Pinky T NA ADAS
#'   \item ADAS_Q6a T NA ADAS
#'   \item ADAS_Q6b T NA ADAS
#'   \item ADAS_Q6c T NA ADAS
#'   \item ADAS_Q6d T NA ADAS
#'   \item ADAS_Q6e T NA ADAS
#'   \item ADAS_Q7a T NA ADAS
#'   \item ADAS_Q7b T NA ADAS
#'   \item ADAS_Q7c T NA ADAS
#'   \item ADAS_Q7d T NA ADAS
#'   \item ADAS_Q7e T NA ADAS
#'   \item ADAS_Q7f T NA ADAS
#'   \item ADAS_Q7g T NA ADAS
#'   \item ADAS_Q7h T NA ADAS
#'   \item ADAS_Q8_WL1_REC_W1_nurse T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL1_REC_W2_magazine T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL1_REC_W3_wizard T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL1_REC_W4_van T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL1_REC_W5_leopard T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL1_REC_W6_sale T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL1_REC_W7_sea T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL1_REC_W8_train T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL1_REC_W9_coin T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL1_REC_W10_ship T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL1_REC_W11_institution T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL1_REC_W12_map T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL1_REC_W13_axe T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL1_REC_W14_board T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL1_REC_W15_carrot T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL1_REC_W16_milk T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL1_REC_W17_volume T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL1_REC_W18_forest T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL1_REC_W19_anchor T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL1_REC_W20_gem T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL1_REC_W21_cat T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL1_REC_W22_fund T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL1_REC_W23_edge T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL1_REC_W24_cake T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL1_Reminder_W1_nurse T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL1_Reminder_W2_magazine T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL1_Reminder_W3_wizard T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL1_Reminder_W4_van T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL1_Reminder_W5_leopard T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL1_Reminder_W6_sale T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL1_Reminder_W7_sea T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL1_Reminder_W8_train T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL1_Reminder_W9_coin T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL1_Reminder_W10_ship T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL1_Reminder_W11_institution T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL1_Reminder_W12_map T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL1_Reminder_W13_axe T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL1_Reminder_W14_board T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL1_Reminder_W15_carrot T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL1_Reminder_W16_milk T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL1_Reminder_W17_volume T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL1_Reminder_W18_forest T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL1_Reminder_W19_anchor T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL1_Reminder_W20_gem T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL1_Reminder_W21_cat T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL1_Reminder_W22_fund T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL1_Reminder_W23_edge T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL1_Reminder_W24_cake T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL2_REC_W1_cost T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL2_REC_W2_nation T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL2_REC_W3_chimney T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL2_REC_W4_sparrow T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL2_REC_W5_damages T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL2_REC_W6_traffic T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL2_REC_W7_sandwich T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL2_REC_W8_service T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL2_REC_W9_shell T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL2_REC_W10_solution T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL2_REC_W11_yard T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL2_REC_W12_tube T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL2_REC_W13_body T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL2_REC_W14_ground T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL2_REC_W15_stick T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL2_REC_W16_engine T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL2_REC_W17_riches T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL2_REC_W18_gravity T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL2_REC_W19_summer T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL2_REC_W20_wisdom T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL2_REC_W21_man T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL2_REC_W22_meal T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL2_REC_W23_passenger T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL2_REC_W24_acid T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL2_Reminder_W1_cost T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL2_Reminder_W2_nation T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL2_Reminder_W3_chimney T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL2_Reminder_W4_sparrow T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL2_Reminder_W5_damages T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL2_Reminder_W6_traffic T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL2_Reminder_W7_sandwich T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL2_Reminder_W8_service T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL2_Reminder_W9_shell T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL2_Reminder_W10_solution T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL2_Reminder_W11_yard T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL2_Reminder_W12_tube T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL2_Reminder_W13_body T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL2_Reminder_W14_ground T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL2_Reminder_W15_stick T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL2_Reminder_W16_engine T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL2_Reminder_W17_riches T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL2_Reminder_W18_gravity T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL2_Reminder_W19_summer T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL2_Reminder_W20_wisdom T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL2_Reminder_W21_man T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL2_Reminder_W22_meal T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL2_Reminder_W23_passenger T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL2_Reminder_W24_acid T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL3_REC_W1_silence T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL3_REC_W2_elbow T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL3_REC_W3_daughter T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL3_REC_W4_powder T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL3_REC_W5_canal T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL3_REC_W6_forehead T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL3_REC_W7_tiger T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL3_REC_W8_twilight T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL3_REC_W9_dragon T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL3_REC_W10_chamber T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL3_REC_W11_sister T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL3_REC_W12_beggar T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL3_REC_W13_echo T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL3_REC_W14_nephew T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL3_REC_W15_duty T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL3_REC_W16_village T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL3_REC_W17_corner T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL3_REC_W18_olive T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL3_REC_W19_music T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL3_REC_W20_courage T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL3_REC_W21_bushel T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL3_REC_W22_ribbon T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL3_REC_W23_object T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL3_REC_W24_collar T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. REC means these columns store responses as to whether the participant recalled the word
#'   \item ADAS_Q8_WL3_Reminder_W1_silence T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL3_Reminder_W2_elbow T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL3_Reminder_W3_daughter T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL3_Reminder_W4_powder T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL3_Reminder_W5_canal T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL3_Reminder_W6_forehead T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL3_Reminder_W7_tiger T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL3_Reminder_W8_twilight T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL3_Reminder_W9_dragon T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL3_Reminder_W10_chamber T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL3_Reminder_W11_sister T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL3_Reminder_W12_beggar T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL3_Reminder_W13_echo T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL3_Reminder_W14_nephew T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL3_Reminder_W15_duty T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL3_Reminder_W16_village T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL3_Reminder_W17_corner T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL3_Reminder_W18_olive T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL3_Reminder_W19_music T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL3_Reminder_W20_courage T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL3_Reminder_W21_bushel T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL3_Reminder_W22_ribbon T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL3_Reminder_W23_object T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q8_WL3_Reminder_W24_collar T NA ADAS: ADAS Q8. WL1-WL3 - indicates which wordlist was used (dependent on timepoint). W1-W14 followed by the word indicates the actual word and its position in the list. Reminder menas these columsn store whether or not a participant was given a reminder
#'   \item ADAS_Q9 T NA ADAS
#'   \item ADAS_Q10 T NA ADAS
#'   \item ADAS_Q11 T NA ADAS
#'   \item ADAS_Q12 T NA ADAS
#'   \item ADAS_Q13a N NA ADAS
#'   \item ADAS_Q13b N NA ADAS
#'   \item ADAS_Q13c N NA ADAS
#'   \item ADAS_ExamInit T NA ADAS: Examiner's Initials
#'   \item ADAS_ExamDate D NA ADAS: Examination Date
#'   \item ANART_QuestionnaireNotAttempted T NA ANART
#'   \item ANART_Q1 T NA ANART
#'   \item ANART_Q2 T NA ANART
#'   \item ANART_Q3 T NA ANART
#'   \item ANART_Q4 T NA ANART
#'   \item ANART_Q5 T NA ANART
#'   \item ANART_Q6 T NA ANART
#'   \item ANART_Q7 T NA ANART
#'   \item ANART_Q8 T NA ANART
#'   \item ANART_Q9 T NA ANART
#'   \item ANART_Q10 T NA ANART
#'   \item ANART_Q11 T NA ANART
#'   \item ANART_Q12 T NA ANART
#'   \item ANART_Q13 T NA ANART
#'   \item ANART_Q14 T NA ANART
#'   \item ANART_Q15 T NA ANART
#'   \item ANART_Q16 T NA ANART
#'   \item ANART_Q17 T NA ANART
#'   \item ANART_Q18 T NA ANART
#'   \item ANART_Q19 T NA ANART
#'   \item ANART_Q20 T NA ANART
#'   \item ANART_Q21 T NA ANART
#'   \item ANART_Q22 T NA ANART
#'   \item ANART_Q23 T NA ANART
#'   \item ANART_Q24 T NA ANART
#'   \item ANART_Q25 T NA ANART
#'   \item ANART_Q26 T NA ANART
#'   \item ANART_Q27 T NA ANART
#'   \item ANART_Q28 T NA ANART
#'   \item ANART_Q29 T NA ANART
#'   \item ANART_Q30 T NA ANART
#'   \item ANART_Q31 T NA ANART
#'   \item ANART_Q32 T NA ANART
#'   \item ANART_Q33 T NA ANART
#'   \item ANART_Q34 T NA ANART
#'   \item ANART_Q35 T NA ANART
#'   \item ANART_Q36 T NA ANART
#'   \item ANART_Q37 T NA ANART
#'   \item ANART_Q38 T NA ANART
#'   \item ANART_Q39 T NA ANART
#'   \item ANART_Q40 T NA ANART
#'   \item ANART_Q41 T NA ANART
#'   \item ANART_Q42 T NA ANART
#'   \item ANART_Q43 T NA ANART
#'   \item ANART_Q44 T NA ANART
#'   \item ANART_Q45 T NA ANART
#'   \item ANART_Q46 T NA ANART
#'   \item ANART_Q47 T NA ANART
#'   \item ANART_Q48 T NA ANART
#'   \item ANART_Q49 T NA ANART
#'   \item ANART_Q50 T NA ANART
#'   \item ANART_ExamInit T NA ANART: Examiner's Initials
#'   \item ANART_ExamDate D NA ANART: Examination Date
#'   \item AVLT_QuestionnaireNotAttempted T NA AVLT
#'   \item AVLT_StartTime T NA AVLT: Start Time of the task
#'   \item AVLTA_WL1a_T1_W1_drum T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T1_W2_curtain T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T1_W3_bell T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T1_W4_coffee T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T1_W5_school T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T1_W6_parent T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T1_W7_moon T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T1_W8_garden T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T1_W9_hat T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T1_W10_farmer T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T1_W11_nose T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T1_W12_turkey T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T1_W13_color T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T1_W14_house T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T1_W15_river T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T2_W1_drum T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T2_W2_curtain T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T2_W3_bell T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T2_W4_coffee T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T2_W5_school T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T2_W6_parent T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T2_W7_moon T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T2_W8_garden T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T2_W9_hat T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T2_W10_farmer T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T2_W11_nose T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T2_W12_turkey T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T2_W13_color T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T2_W14_house T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T2_W15_river T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T3_W1_drum T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T3_W2_curtain T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T3_W3_bell T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T3_W4_coffee T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T3_W5_school T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T3_W6_parent T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T3_W7_moon T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T3_W8_garden T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T3_W9_hat T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T3_W10_farmer T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T3_W11_nose T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T3_W12_turkey T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T3_W13_color T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T3_W14_house T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T3_W15_river T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T4_W1_drum T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T4_W2_curtain T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T4_W3_bell T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T4_W4_coffee T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T4_W5_school T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T4_W6_parent T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T4_W7_moon T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T4_W8_garden T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T4_W9_hat T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T4_W10_farmer T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T4_W11_nose T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T4_W12_turkey T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T4_W13_color T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T4_W14_house T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T4_W15_river T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T5_W1_drum T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T5_W2_curtain T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T5_W3_bell T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T5_W4_coffee T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T5_W5_school T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T5_W6_parent T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T5_W7_moon T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T5_W8_garden T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T5_W9_hat T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T5_W10_farmer T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T5_W11_nose T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T5_W12_turkey T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T5_W13_color T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T5_W14_house T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T5_W15_river T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T6_W1_drum T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T6_W2_curtain T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T6_W3_bell T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T6_W4_coffee T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T6_W5_school T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T6_W6_parent T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T6_W7_moon T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T6_W8_garden T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T6_W9_hat T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T6_W10_farmer T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T6_W11_nose T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T6_W12_turkey T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T6_W13_color T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T6_W14_house T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1a_T6_W15_river T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1b_T7_W1_desk T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1b_T7_W2_ranger T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1b_T7_W3_bird T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1b_T7_W4_shoe T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1b_T7_W5_stove T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1b_T7_W6_mountain T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1b_T7_W7_glasses T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1b_T7_W8_towel T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1b_T7_W9_cloud T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1b_T7_W10_boat T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1b_T7_W11_lamb T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1b_T7_W12_gun T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1b_T7_W13_pencil T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1b_T7_W14_church T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTA_WL1b_T7_W15_fish T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL1a/WL1b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T1_W1_doll T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T1_W2_mirror T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T1_W3_nail T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T1_W4_sailor T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T1_W5_heart T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T1_W6_desert T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T1_W7_face T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T1_W8_letter T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T1_W9_bed T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T1_W10_machine T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T1_W11_milk T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T1_W12_helmet T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T1_W13_music T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T1_W14_horse T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T1_W15_road T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T2_W1_doll T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T2_W2_mirror T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T2_W3_nail T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T2_W4_sailor T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T2_W5_heart T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T2_W6_desert T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T2_W7_face T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T2_W8_letter T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T2_W9_bed T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T2_W10_machine T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T2_W11_milk T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T2_W12_helmet T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T2_W13_music T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T2_W14_horse T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T2_W15_road T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T3_W1_doll T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T3_W2_mirror T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T3_W3_nail T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T3_W4_sailor T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T3_W5_heart T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T3_W6_desert T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T3_W7_face T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T3_W8_letter T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T3_W9_bed T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T3_W10_machine T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T3_W11_milk T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T3_W12_helmet T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T3_W13_music T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T3_W14_horse T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T3_W15_road T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T4_W1_doll T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T4_W2_mirror T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T4_W3_nail T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T4_W4_sailor T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T4_W5_heart T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T4_W6_desert T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T4_W7_face T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T4_W8_letter T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T4_W9_bed T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T4_W10_machine T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T4_W11_milk T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T4_W12_helmet T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T4_W13_music T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T4_W14_horse T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T4_W15_road T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T5_W1_doll T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T5_W2_mirror T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T5_W3_nail T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T5_W4_sailor T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T5_W5_heart T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T5_W6_desert T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T5_W7_face T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T5_W8_letter T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T5_W9_bed T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T5_W10_machine T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T5_W11_milk T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T5_W12_helmet T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T5_W13_music T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T5_W14_horse T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T5_W15_road T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T6_W1_doll T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T6_W2_mirror T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T6_W3_nail T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T6_W4_sailor T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T6_W5_heart T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T6_W6_desert T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T6_W7_face T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T6_W8_letter T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T6_W9_bed T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T6_W10_machine T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T6_W11_milk T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T6_W12_helmet T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T6_W13_music T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T6_W14_horse T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2a_T6_W15_road T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2b_T7_W1_dish T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2b_T7_W2_jester T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2b_T7_W3_hill T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2b_T7_W4_coat T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2b_T7_W5_tool T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2b_T7_W6_forest T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2b_T7_W7_water T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2b_T7_W8_ladder T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2b_T7_W9_girl T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2b_T7_W10_foot T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2b_T7_W11_shield T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2b_T7_W12_pie T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2b_T7_W13_insect T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2b_T7_W14_ball T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLTB_WL2b_T7_W15_car T NA AVLT: AVLT Version A, T1-T7 indicate Trial 1 to Trial 7 of the task. WL2a/WL2b indicates which wordlist was used in that trial (Trial 7 uses list b). W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLT_Trial1Int N NA AVLT: The number of intrusions made by the examiner in each of 7 trials.
#'   \item AVLT_Trial2Int N NA AVLT: The number of intrusions made by the examiner in each of 7 trials.
#'   \item AVLT_Trial3Int N NA AVLT: The number of intrusions made by the examiner in each of 7 trials.
#'   \item AVLT_Trial4Int N NA AVLT: The number of intrusions made by the examiner in each of 7 trials.
#'   \item AVLT_Trial5Int N NA AVLT: The number of intrusions made by the examiner in each of 7 trials.
#'   \item AVLT_Trial6Int N NA AVLT: The number of intrusions made by the examiner in each of 7 trials.
#'   \item AVLT_Trial7Int N NA AVLT: The number of intrusions made by the examiner in each of 7 trials.
#'   \item AVLT_ExamInit T NA AVLT: Examiner's Initials
#'   \item AVLT_ExamDate D NA AVLT: Examination Date
#'   \item AVLT_Delay_QuestionnaireNotAttempted T NA AVLT Delayed
#'   \item AVLT_DelayTime T NA AVLT Delayed: Start Time of the task
#'   \item AVLT_Delay_WL1_W1_drum T NA AVLT Delayed: AVLT Delay, WL1/WL2 indicates which wordlist was used. W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLT_Delay_WL1_W2_curtain T NA AVLT Delayed: AVLT Delay, WL1/WL2 indicates which wordlist was used. W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLT_Delay_WL1_W3_bell T NA AVLT Delayed: AVLT Delay, WL1/WL2 indicates which wordlist was used. W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLT_Delay_WL1_W4_coffee T NA AVLT Delayed: AVLT Delay, WL1/WL2 indicates which wordlist was used. W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLT_Delay_WL1_W5_school T NA AVLT Delayed: AVLT Delay, WL1/WL2 indicates which wordlist was used. W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLT_Delay_WL1_W6_parent T NA AVLT Delayed: AVLT Delay, WL1/WL2 indicates which wordlist was used. W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLT_Delay_WL1_W7_moon T NA AVLT Delayed: AVLT Delay, WL1/WL2 indicates which wordlist was used. W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLT_Delay_WL1_W8_garden T NA AVLT Delayed: AVLT Delay, WL1/WL2 indicates which wordlist was used. W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLT_Delay_WL1_W9_hat T NA AVLT Delayed: AVLT Delay, WL1/WL2 indicates which wordlist was used. W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLT_Delay_WL1_W10_farmer T NA AVLT Delayed: AVLT Delay, WL1/WL2 indicates which wordlist was used. W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLT_Delay_WL1_W11_nose T NA AVLT Delayed: AVLT Delay, WL1/WL2 indicates which wordlist was used. W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLT_Delay_WL1_W12_turkey T NA AVLT Delayed: AVLT Delay, WL1/WL2 indicates which wordlist was used. W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLT_Delay_WL1_W13_color T NA AVLT Delayed: AVLT Delay, WL1/WL2 indicates which wordlist was used. W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLT_Delay_WL1_W14_house T NA AVLT Delayed: AVLT Delay, WL1/WL2 indicates which wordlist was used. W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLT_Delay_WL1_W15_river T NA AVLT Delayed: AVLT Delay, WL1/WL2 indicates which wordlist was used. W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLT_Delay_WL2_W1_doll T NA AVLT Delayed: AVLT Delay, WL1/WL2 indicates which wordlist was used. W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLT_Delay_WL2_W2_mirror T NA AVLT Delayed: AVLT Delay, WL1/WL2 indicates which wordlist was used. W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLT_Delay_WL2_W3_nail T NA AVLT Delayed: AVLT Delay, WL1/WL2 indicates which wordlist was used. W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLT_Delay_WL2_W4_sailor T NA AVLT Delayed: AVLT Delay, WL1/WL2 indicates which wordlist was used. W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLT_Delay_WL2_W5_heart T NA AVLT Delayed: AVLT Delay, WL1/WL2 indicates which wordlist was used. W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLT_Delay_WL2_W6_desert T NA AVLT Delayed: AVLT Delay, WL1/WL2 indicates which wordlist was used. W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLT_Delay_WL2_W7_face T NA AVLT Delayed: AVLT Delay, WL1/WL2 indicates which wordlist was used. W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLT_Delay_WL2_W8_letter T NA AVLT Delayed: AVLT Delay, WL1/WL2 indicates which wordlist was used. W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLT_Delay_WL2_W9_bed T NA AVLT Delayed: AVLT Delay, WL1/WL2 indicates which wordlist was used. W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLT_Delay_WL2_W10_machine T NA AVLT Delayed: AVLT Delay, WL1/WL2 indicates which wordlist was used. W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLT_Delay_WL2_W11_milk T NA AVLT Delayed: AVLT Delay, WL1/WL2 indicates which wordlist was used. W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLT_Delay_WL2_W12_helmet T NA AVLT Delayed: AVLT Delay, WL1/WL2 indicates which wordlist was used. W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLT_Delay_WL2_W13_music T NA AVLT Delayed: AVLT Delay, WL1/WL2 indicates which wordlist was used. W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLT_Delay_WL2_W14_horse T NA AVLT Delayed: AVLT Delay, WL1/WL2 indicates which wordlist was used. W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLT_Delay_WL2_W15_road T NA AVLT Delayed: AVLT Delay, WL1/WL2 indicates which wordlist was used. W1-W15 followed by the word indicates the actual word and its position in the list.
#'   \item AVLT_Delay_Int N NA AVLT Delayed: The intrusions value entered by the examiner
#'   \item AVLT_Delay_Rec N NA AVLT Delayed: The recognition score entered by the examiner
#'   \item AVLT_Delay_TotInt N NA AVLT Delayed: The total intrustions entered by the examiner
#'   \item AVLT_Delay_ExamInit T NA AVLT Delayed: Examiner's Initials
#'   \item AVLT_Delay_ExamDate D NA AVLT Delayed: Examination Date
#'   \item BosNam_QuestionnaireNotAttempted T NA Boston Naming Test
#'   \item BosNam_Q1 T NA Boston Naming Test
#'   \item BosNam_Q3 T NA Boston Naming Test
#'   \item BosNam_Q5 T NA Boston Naming Test
#'   \item BosNam_Q7 T NA Boston Naming Test
#'   \item BosNam_Q9 T NA Boston Naming Test
#'   \item BosNam_Q11 T NA Boston Naming Test
#'   \item BosNam_Q13 T NA Boston Naming Test
#'   \item BosNam_Q15 T NA Boston Naming Test
#'   \item BosNam_Q17 T NA Boston Naming Test
#'   \item BosNam_Q19 T NA Boston Naming Test
#'   \item BosNam_Q21 T NA Boston Naming Test
#'   \item BosNam_Q23 T NA Boston Naming Test
#'   \item BosNam_Q25 T NA Boston Naming Test
#'   \item BosNam_Q27 T NA Boston Naming Test
#'   \item BosNam_Q29 T NA Boston Naming Test
#'   \item BosNam_Q31 T NA Boston Naming Test
#'   \item BosNam_Q33 T NA Boston Naming Test
#'   \item BosNam_Q35 T NA Boston Naming Test
#'   \item BosNam_Q37 T NA Boston Naming Test
#'   \item BosNam_Q39 T NA Boston Naming Test
#'   \item BosNam_Q41 T NA Boston Naming Test
#'   \item BosNam_Q43 T NA Boston Naming Test
#'   \item BosNam_Q45 T NA Boston Naming Test
#'   \item BosNam_Q47 T NA Boston Naming Test
#'   \item BosNam_Q49 T NA Boston Naming Test
#'   \item BosNam_Q51 T NA Boston Naming Test
#'   \item BosNam_Q53 T NA Boston Naming Test
#'   \item BosNam_Q55 T NA Boston Naming Test
#'   \item BosNam_Q57 T NA Boston Naming Test
#'   \item BosNam_Q59 T NA Boston Naming Test
#'   \item BosNam_ExamInit T NA Boston Naming Test: Examiner's Initials
#'   \item BosNam_ExamDate D NA Boston Naming Test: Examination Date
#'   \item CatFlu_QuestionnaireNotAttempted T NA Category Fluency Test
#'   \item CatFlu_Practise T NA Category Fluency Test: The outcome score the participant received when performing a practise run
#'   \item CatFlu_Animal_Total N NA Category Fluency Test: Total number of animals named
#'   \item CatFlu_Animal_Perseverations N NA Category Fluency Test: Number of perseverations
#'   \item CatFlu_Animal_Intrusions N NA Category Fluency Test: Number of intrustions
#'   \item CatFlu_Vegetable_Total N NA Category Fluency Test: Total number of vegetables named
#'   \item CatFlu_Vegetable_Perseverations N NA Category Fluency Test: Number of perseverations
#'   \item CatFlu_Vegetable_Intrusions N NA Category Fluency Test: Number of intrustions
#'   \item CatFlu_ExamInit T NA Category Fluency Test: Examiner's Initials
#'   \item CatFlu_ExamDate D NA Category Fluency Test: Examination Date
#'   \item CDT_QuestionnaireNotAttempted T NA Clock Drawing Test
#'   \item CDT_Q1pt1 T NA Clock Drawing Test
#'   \item CDT_Q1pt2 T NA Clock Drawing Test
#'   \item CDT_Q1pt3 T NA Clock Drawing Test
#'   \item CDT_Q1pt4 T NA Clock Drawing Test
#'   \item CDT_Q1pt5 T NA Clock Drawing Test
#'   \item CDT_Q2pt1 T NA Clock Drawing Test
#'   \item CDT_Q2pt2 T NA Clock Drawing Test
#'   \item CDT_Q2pt3 T NA Clock Drawing Test
#'   \item CDT_Q2pt4 T NA Clock Drawing Test
#'   \item CDT_Q2pt5 T NA Clock Drawing Test
#'   \item CDT_ExamInit T NA Clock Drawing Test: Examiner's Initials
#'   \item CDT_ExamDate D NA Clock Drawing Test: Examination Date
#'   \item DSBac_QuestionnaireNotAttempted T NA Digit Span Backwards
#'   \item DSBac_Q1a T NA Digit Span Backwards
#'   \item DSBac_Q1b T NA Digit Span Backwards
#'   \item DSBac_Q2a T NA Digit Span Backwards
#'   \item DSBac_Q2b T NA Digit Span Backwards
#'   \item DSBac_Q3a T NA Digit Span Backwards
#'   \item DSBac_Q3b T NA Digit Span Backwards
#'   \item DSBac_Q4a T NA Digit Span Backwards
#'   \item DSBac_Q4b T NA Digit Span Backwards
#'   \item DSBac_Q5a T NA Digit Span Backwards
#'   \item DSBac_Q5b T NA Digit Span Backwards
#'   \item DSBac_Q6a T NA Digit Span Backwards
#'   \item DSBac_Q6b T NA Digit Span Backwards
#'   \item DSBac_Length N NA Digit Span Backwards
#'   \item DSBac_ExamInit T NA Digit Span Backwards: Examiner's Initials
#'   \item DSBac_ExamDate D NA Digit Span Backwards: Examination Date
#'   \item DSFor_QuestionnaireNotAttempted T NA Digit Span Forwards
#'   \item DSFor_Q1a T NA Digit Span Forwards
#'   \item DSFor_Q1b T NA Digit Span Forwards
#'   \item DSFor_Q2a T NA Digit Span Forwards
#'   \item DSFor_Q2b T NA Digit Span Forwards
#'   \item DSFor_Q3a T NA Digit Span Forwards
#'   \item DSFor_Q3b T NA Digit Span Forwards
#'   \item DSFor_Q4a T NA Digit Span Forwards
#'   \item DSFor_Q4b T NA Digit Span Forwards
#'   \item DSFor_Q5a T NA Digit Span Forwards
#'   \item DSFor_Q5b T NA Digit Span Forwards
#'   \item DSFor_Q6a T NA Digit Span Forwards
#'   \item DSFor_Q6b T NA Digit Span Forwards
#'   \item DSFor_Length N NA Digit Span Forwards
#'   \item DSFor_ExamInit T NA Digit Span Forwards: Examiner's Initials
#'   \item DSFor_ExamDate D NA Digit Span Forwards: Examination Date
#'   \item LogMemIA_QuestionnaireNotAttempted T NA Logical Memory IA
#'   \item LogMemIA_TimeEnded T NA Logical Memory IA: Time the task ended
#'   \item LogMemIA_ImmediateScore N NA Logical Memory IA
#'   \item LogMemIA_ExamInit T NA Logical Memory IA: Examiner's Initials
#'   \item LogMemIA_ExamDate D NA Logical Memory IA: Examination Date
#'   \item LogMemIIA_QuestionnaireNotAttempted T NA Logical Memory IIA
#'   \item LogMemIIA_TimeBegan T NA Logical Memory IIA: Time the task began
#'   \item LogMemIIA_DelayedScore N NA Logical Memory IIA
#'   \item LogMemIIA_ReminderGiven T NA Logical Memory IIA: Indicates whether participant was given a reminder of the task
#'   \item LogMemIIA_ExamInit T NA Logical Memory IIA: Examiner's Initials
#'   \item LogMemIIA_ExamDate D NA Logical Memory IIA: Examination Date
#'   \item MMSE_QuestionnaireNotAttempted T NA Mini Mental State Exam
#'   \item MMSE_Q1 T NA Mini Mental State Exam
#'   \item MMSE_Q2 T NA Mini Mental State Exam
#'   \item MMSE_Q3 T NA Mini Mental State Exam
#'   \item MMSE_Q4 T NA Mini Mental State Exam
#'   \item MMSE_Q5 T NA Mini Mental State Exam
#'   \item MMSE_Q6 T NA Mini Mental State Exam
#'   \item MMSE_Q7 T NA Mini Mental State Exam
#'   \item MMSE_Q8 T NA Mini Mental State Exam
#'   \item MMSE_Q9 T NA Mini Mental State Exam
#'   \item MMSE_Q10 T NA Mini Mental State Exam
#'   \item MMSE_Q11 T NA Mini Mental State Exam
#'   \item MMSE_Q12 T NA Mini Mental State Exam
#'   \item MMSE_Q13 T NA Mini Mental State Exam
#'   \item MMSE_Q13a N NA Mini Mental State Exam: Number Of Trials
#'   \item MMSE_Q14 T NA Mini Mental State Exam
#'   \item MMSE_Q15 T NA Mini Mental State Exam
#'   \item MMSE_Q16 T NA Mini Mental State Exam
#'   \item MMSE_Q17 T NA Mini Mental State Exam
#'   \item MMSE_Q18 T NA Mini Mental State Exam
#'   \item MMSE_Q14value T NA Mini Mental State Exam: The actual response entered for each question
#'   \item MMSE_Q15value T NA Mini Mental State Exam: The actual response entered for each question
#'   \item MMSE_Q16value T NA Mini Mental State Exam: The actual response entered for each question
#'   \item MMSE_Q17value T NA Mini Mental State Exam: The actual response entered for each question
#'   \item MMSE_Q18value T NA Mini Mental State Exam: The actual response entered for each question
#'   \item MMSE_Q19 T NA Mini Mental State Exam
#'   \item MMSE_Q20 T NA Mini Mental State Exam
#'   \item MMSE_Q21 T NA Mini Mental State Exam
#'   \item MMSE_Q22 T NA Mini Mental State Exam
#'   \item MMSE_Q23 T NA Mini Mental State Exam
#'   \item MMSE_Q24 T NA Mini Mental State Exam
#'   \item MMSE_Q25 T NA Mini Mental State Exam
#'   \item MMSE_Q26 T NA Mini Mental State Exam
#'   \item MMSE_Q27 T NA Mini Mental State Exam
#'   \item MMSE_Q28 T NA Mini Mental State Exam
#'   \item MMSE_Q29 T NA Mini Mental State Exam
#'   \item MMSE_Q30 T NA Mini Mental State Exam
#'   \item MMSE_ExamInit T NA Mini Mental State Exam: Examiner's Initials
#'   \item MMSE_ExamDate D NA Mini Mental State Exam: Examination Date
#'   \item TMT_QuestionnaireNotAttempted T NA Trail Making Test
#'   \item TMT_PtA_Complete N NA Trail Making Test: Time in seconds it took participant to complete the task
#'   \item TMT_PtA_Comission N NA Trail Making Test: Number of errors of comission by the participant
#'   \item TMT_PtA_Omission N NA Trail Making Test: Number of errors of omission by the particpant
#'   \item TMT_PtB_Complete N NA Trail Making Test: Time in seconds it took participant to complete the task
#'   \item TMT_PtB_Comission N NA Trail Making Test: Number of errors of comission by the participant
#'   \item TMT_PtB_Omission N NA Trail Making Test: Number of errors of omission by the particpant
#'   \item TMT_ExamInit T NA Trail Making Test: Examiner's Initials
#'   \item TMT_ExamDate D NA Trail Making Test: Examination Date
#'   \item WAISR_QuestionnaireNotAttempted T NA WAIS-R
#'   \item WAISR_Score N NA WAIS-R: Digit symbol substitution score
#'   \item WAISR_ExamInit T NA WAIS-R: Examiner's Initials
#'   \item WAISR_ExamDate D NA WAIS-R: Examination Date
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name item
#' @usage data(item)
#' @format A data frame with 5341 rows and 780 variables
NULL

#' Laboratory Data
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/LABDATA/Cancellation%20Codes%2025-Mar-13-1.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item RECNO N  
#'   \item ACCNO T  
#'   \item COVVIS T  
#'   \item EXAMDATE D  Examination Date
#'   \item AXT117 T  Test AXT117; Thyroid Stim. Hormone
#'   \item BAT126 T  Test BAT126; Vitamin B12
#'   \item CMT1 T  Test CMT1; Color
#'   \item CMT10 T  Test CMT10; Urine Nitrite
#'   \item CMT11 T  Test CMT11; Leukocyte Esterase
#'   \item CMT2 T  Test CMT2; Specific Gravity
#'   \item CMT3 T  Test CMT3; pH
#'   \item CMT43 T  Test CMT43; Blood (+)
#'   \item CMT49 T  Test CMT49; Urine Protein (3+)
#'   \item CMT5 T  Test CMT5; Urine Urobilinogen (new)
#'   \item CMT6 T  Test CMT6; Urine Ketones
#'   \item CMT7 T  Test CMT7; Urine Bilirubin
#'   \item HMT97 T  Test HMT97; Blasts
#'   \item HMT55 T  Test HMT55; Lymphoma Cell
#'   \item HMT56 T  Test HMT56; Prolymphocyte
#'   \item HMT57 T  Test HMT57; Sezary Cell
#'   \item HMT59 T  Test HMT59; Lymphocyte, Immunoblastic
#'   \item HMT60 T  Test HMT60; Lymphocyte, Plasmacytoid
#'   \item HMT61 T  Test HMT61; Lymphocyte, Reactive
#'   \item HMT62 T  Test HMT62; Lymphoblast
#'   \item HMT96 T  Test HMT96; Atypical Lymphocytes
#'   \item HMT63 T  Test HMT63; Promonocyte
#'   \item HMT64 T  Test HMT64; Monoblast
#'   \item HMT65 T  Test HMT65; Monocyte, Immature
#'   \item HMT49 T  Test HMT49; Eosinophil, Immature
#'   \item HMT48 T  Test HMT48; Basophil, Immature
#'   \item HMT50 T  Test HMT50; Malighant Cell, NOS
#'   \item HMT51 T  Test HMT51; WBC Comment:
#'   \item HMT52 T  Test HMT52; Plasma Cell Precursor
#'   \item HMT53 T  Test HMT53; Plasma Cell, Immature
#'   \item HMT54 T  Test HMT54; Plasma Cell, Mature
#'   \item HMT58 T  Test HMT58; Hairy Cell
#'   \item HMT70 T  Test HMT70; Nucleated Red Blood Cells
#'   \item HMT94 T  Test HMT94; Blasts
#'   \item HMT72 T  Test HMT72; Sezary Cell (Absolute)
#'   \item HMT80 T  Test HMT80; Lymphoma Cell
#'   \item HMT81 T  Test HMT81; Prolymphocyte
#'   \item HMT83 T  Test HMT83; Lymphocyte, Immunoblastic
#'   \item HMT84 T  Test HMT84; Lymphocyte, Plasmacytoid
#'   \item HMT85 T  Test HMT85; Lymphocyte, Reactive
#'   \item HMT86 T  Test HMT86; Lymphoblast
#'   \item HMT95 T  Test HMT95; Atypical Lymphocytes
#'   \item HMT87 T  Test HMT87; Promonocyte
#'   \item HMT88 T  Test HMT88; Monoblast
#'   \item HMT89 T  Test HMT89; Monocyte, Immature
#'   \item HMT75 T  Test HMT75; Eosinophil, Immature
#'   \item HMT74 T  Test HMT74; Basophil, Immature
#'   \item HMT76 T  Test HMT76; Malignant Cell, NOS
#'   \item HMT77 T  Test HMT77; Plasma Cell Precursor
#'   \item HMT78 T  Test HMT78; Plasma Cell, Immature
#'   \item HMT79 T  Test HMT79; Plasma Cell, Mature
#'   \item HMT82 T  Test HMT82; Hairy Cell
#'   \item HMT98 T  Test HMT98; Nucleated Red Blood Cells
#'   \item HMT99 T  Test HMT99; WBC Comment:
#'   \item HMT21 T  Test HMT21; Bands (%)
#'   \item HMT66 T  Test HMT66; Myeloblast
#'   \item HMT67 T  Test HMT67; Promyelocyte
#'   \item HMT68 T  Test HMT68; Myelocyte
#'   \item HMT69 T  Test HMT69; Metamyelocyte
#'   \item HMT20 T  Test HMT20; Bands
#'   \item HMT90 T  Test HMT90; Myeloblast
#'   \item HMT91 T  Test HMT91; Promyelocyte
#'   \item HMT92 T  Test HMT92; Myelocyte
#'   \item HMT93 T  Test HMT93; Metamyelocyte
#'   \item HMT10 T  Test HMT10; Monocytes
#'   \item HMT100 T  Test HMT100; MCH
#'   \item HMT102 T  Test HMT102; MCHC
#'   \item HMT11 T  Test HMT11; Eosinophils
#'   \item HMT12 T  Test HMT12; Basophils
#'   \item HMT13 T  Test HMT13; Platelets
#'   \item HMT15 T  Test HMT15; Neutrophils (%)
#'   \item HMT16 T  Test HMT16; Lymphocytes (%)
#'   \item HMT17 T  Test HMT17; Monocytes (%)
#'   \item HMT18 T  Test HMT18; Eosinophils (%)
#'   \item HMT19 T  Test HMT19; Basophils (%)
#'   \item HMT2 T  Test HMT2; Hematocrit
#'   \item HMT3 T  Test HMT3; RBC
#'   \item HMT4 T  Test HMT4; MCV
#'   \item HMT40 T  Test HMT40; Hemoglobin
#'   \item HMT7 T  Test HMT7; WBC
#'   \item HMT71 T  Test HMT71; RBC Morphology
#'   \item HMT8 T  Test HMT8; Neutrophils
#'   \item HMT9 T  Test HMT9; Lymphocytes
#'   \item ORT1859 T  Test ORT1859; Trep.Pall.Ab (FTA-ABS) (-70) -38
#'   \item RCT1 T  Test RCT1; Total Bilirubin
#'   \item RCT11 T  Test RCT11; Serum Glucose
#'   \item RCT12 T  Test RCT12; Total Protein
#'   \item RCT13 T  Test RCT13; Albumin
#'   \item RCT14 T  Test RCT14; Creatine Kinase
#'   \item RCT1407 T  Test RCT1407; Alkaline Phosphatase
#'   \item RCT1408 T  Test RCT1408; LDH
#'   \item RCT183 T  Test RCT183; Calcium (EDTA)
#'   \item RCT19 T  Test RCT19; Triglycerides (GPO)
#'   \item RCT20 T  Test RCT20; Cholesterol (High Performance)
#'   \item RCT29 T  Test RCT29; Direct Bilirubin
#'   \item RCT3 T  Test RCT3; GGT
#'   \item RCT392 T  Test RCT392; Creatinine (Rate Blanked)
#'   \item RCT4 T  Test RCT4; ALT (SGPT)
#'   \item RCT5 T  Test RCT5; AST (SGOT)
#'   \item RCT6 T  Test RCT6; Urea Nitrogen
#'   \item RCT8 T  Test RCT8; Serum Uric Acid
#'   \item RCT9 T  Test RCT9; Phosphorus
#'   \item SLT3 T  Test SLT3; Rapid Plasma Reagin
#'   \item CMT53 T  
#'   \item BAT324 T  
#'   \item UAT13 T  
#'   \item UAT10 T  
#'   \item UAT11 T  
#'   \item UAT2 T  
#'   \item UAT3 T  
#'   \item UAT43 T  
#'   \item UAT49 T  
#'   \item UAT59 T  
#'   \item UAT65 T  
#'   \item UAT7 T  
#'   \item UAT1 T  
#'   \item UAT5 T  
#'   \item UAT6 T  
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name labdata
#' @usage data(labdata)
#' @format A data frame with 2422 rows and 129 variables
NULL

#' Clinical Laboratory Tests
#'
#'
#'
#' @author \email{adni-data@googlegroups.com}
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item EXAMDATE D  Examination Date
#'   \item LABLOOD N  1. Was blood drawn for safety labs?
#'   \item LANOBLOD T  If No, explain: <!--safety lab blood drawn-->
#'   \item LAURINE N  2. Was a urine sample obtained for safety labs?
#'   \item LANOURIN T  If No, explain: <!--safety lab urine sample-->
#'   \item LAABNORM N  3. Are there any clinically significant laboratory abnormalities that would exclude the participant from the study?
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name labtests
#' @usage data(labtests)
#' @format A data frame with 2582 rows and 13 variables
NULL

#' Latent Disease Time Estimates, Alzheimer's Therapeutic Research Institute (ATRI) of University of Southern California
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 NA Participant roster ID
#'   \item DX -4 NA Baseline diagnosis
#'   \item OUTCOME -4 NA Indicates the outcome for which the random_intercept or random_slope is estimated
#'   \item VARIABLE -4 NA Indicates the type of estimate (latent_time, random_intercept, or random_slope)
#'   \item ESTIMATE -4 NA The estimates. Note the scale of latent_time is years and the random intercepts and slopes are on a common standardized scale (the outcomes are modeled as Z-scores).
#'   \item LWR -4 NA Lower limit of 95% credible interval
#'   \item UPR -4 NA Upper limit of 95% credible interval
#'   \item RHAT -4 NA Convergence statistic that should be close to 1 (see e.g. https://www.jstatsoft.org/article/view/v076i01/v76i01.pdf)
#' }
#'
#' @examples
#' \donotrun{
#' describe(latent_disease_time)
#' }
#' @docType data
#' @keywords datasets
#' @name latent_disease_time
#' @usage data(latent_disease_time)
#' @format A data frame with 60865 rows and 9 variables
NULL

#' CSF - Local Lab Results
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item COMM T NA Comments
#'   \item SAMPLECOLL N NA Was LP conducted?
#'   \item SAMPLEDATE D NA Date of Sample Collection
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item EXAMDATE D  Examination Date
#'   \item SAMPLETIME T  Time of Sample Collection
#'   \item SENTTIME T  Time sent to Local Lab
#'   \item CTWHITE N  White Blood Cell Count
#'   \item CTRED N  Red Blood Cell Count
#'   \item PROTEIN N  Protein Results
#'   \item GLUCOSE N  Glucose Results
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name loclab
#' @usage data(loclab)
#' @format A data frame with 5387 rows and 17 variables
NULL

#' Month 24 CSF Extension Consent
#'
#'
#'
#' @author \email{adni-data@googlegroups.com}
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#'   \item INCLPM24 N  Has the participant signed the Informed Consent form for the CSF Extension (2 year visit)?
#'   \item INCLPDTM24 D  If Yes, date signed.
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name m24csfcsnt
#' @usage data(m24csfcsnt)
#' @format A data frame with 122 rows and 9 variables
NULL

#' Jack Lab - Default Mode Network connectivity
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/MAYOADIRL_MRI_FMRI/ADNI_Methods_TF_fMRI_Oct31.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item VISCODE2 -4 -4 Translated visit code
#'   \item SCANDATE -4 CHAR(8) scan date
#'   \item VERSION -4 -4 -4
#'   \item RUNDATE -4 CHAR(8) Run Date
#'   \item IMAGEUID -4 CHAR(var) LONI Image ID
#'   \item STATUS -4 CHAR(var) analysis status
#'   \item ADMNRV -4 CHAR(var) Anterior DMN RV
#'   \item PDMNRV -4 CHAR(var) Posterior DMN RV
#'   \item DMNRVR -4 CHAR(var) DMN RV-ratio
#'   \item MAGSTRENG -4 CHAR(var) Mag Field
#'   \item SERDESC -4 CHAR(var) Series Description
#'   \item PITCH -4 CHAR(var) Max Pitch Change
#'   \item ROLL -4 CHAR(var) Max Roll Change
#'   \item YAW -4 CHAR(var) Max Yaw Change
#'   \item MMX -4 CHAR(var) Max X change
#'   \item MMY -4 CHAR(var) Max Y change
#'   \item MMZ -4 CHAR(var) Max Z change
#'   \item SLICEORD -4 CHAR(var) temporal slice order
#'   \item COVVERMIS -4 CHAR(1) vermis coverage
#'   \item COVCEREBEL -4 CHAR(1) cerebellum coverage
#'   \item COVOCCIP -4 CHAR(1) occip lobe coverage
#'   \item COVSUPER -4 CHAR(1) superior aspect coverage
#'   \item COVTEMPOR -4 CHAR(1) temporal lobe coverage
#'   \item COVOTHER -4 CHAR(1) other coverage failure
#'   \item MEANTSNR -4 CHAR(var) mean temporal SNR in brain
#'   \item MEDTSNR -4 CHAR(var) median temporal SNR in brain
#'   \item SDTSNR -4 CHAR(var) std deviation of temporal SNR in brain
#'   \item PENCIL -4 CHAR(var) pencil artifact observed
#'   \item VENETIAN -4 CHAR(var) venetian blind artifact observed
#'   \item PHASEDIR -4 CHAR(var) observed phase direction
#' }
#'
#' @examples
#' \donotrun{
#' describe(mayoadirl_mri_fmri)
#' }
#' @docType data
#' @keywords datasets
#' @name mayoadirl_mri_fmri
#' @usage data(mayoadirl_mri_fmri)
#' @format A data frame with 892 rows and 32 variables
NULL

#' Jack Lab - ADNI GO/2/3 MRI QC
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/MAYOADIRL_MRI_IMAGEQC/ADNI_data_file_specifications_quality.pdf}, \url{https://adni.bitbucket.io/reference/docs/MAYOADIRL_MRI_IMAGEQC/ADNI_Methods_Mayo_MRI_QC.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 CHAR(10) Participant roster ID
#'   \item LONI_STUDY -4 CHAR(5) LONI Study ID
#'   \item LONI_SERIES -4 CHAR(7) LONI Series ID
#'   \item LONI_IMAGE -4 -4 -4
#'   \item SERIES_DATE -4 CHAR(8) Series Scan Date
#'   \item SERIES_TIME -4 CHAR(12) Series Time
#'   \item SERIES_NUMBER -4 CHAR(4) Series Number
#'   \item SERIES_DESCRIPTION -4 CHAR(34) Series Description
#'   \item SERIES_TYPE -4 CHAR(5) Series Type
#'   \item SOFTWARE_VERSION -4 CHAR(45) Software Version
#'   \item FIELD_STRENGTH -4 CHAR(5) Field Strength
#'   \item COIL -4 CHAR(32) Coil
#'   \item SERIES_QUALITY -4 CHAR(1) Series Quality
#'   \item SERIES_SELECTED -4 CHAR(1) Series Selected
#'   \item SERIES_COMMENTS -4 CHAR(200) Series Comments
#'   \item SERIES_COVERAGE_OCCIPITAL -4 CHAR(1) Series Coverage Occipital
#'   \item SERIES_COVERAGE_VERMIS -4 CHAR(1) Series Coverage Vermis
#'   \item SERIES_COVERAGE_CEREBELLUM -4 CHAR(1) Series Coverage Cerebellum
#'   \item SERIES_COVERAGE_SUPERIOR -4 CHAR(1) Series Coverage Superior
#'   \item SERIES_COVERAGE_TEMPORAL -4 CHAR(1) Series Coverage Temporal
#'   \item SERIES_COVERAGE_OTHER -4 CHAR(1) Series Coverage Other
#'   \item T1_ACCELERATED -4 Char (1) T1 Accelerated
#'   \item FMRI_PHASE -4 CHAR(1) fMRI Phase
#'   \item FMRI_PENCIL -4 CHAR(1) fMRI Pencil
#'   \item FMRI_VENETIAN -4 CHAR(1) fMRI Venetian
#'   \item FMRI_DMN -4 CHAR(1) fMRI DMN
#'   \item FMRI_YAW -4 CHAR(7) fMRI Yaw
#'   \item FMRI_ROLL -4 CHAR(7) fMRI Roll
#'   \item FMRI_PITCH -4 CHAR(7) fMRI Pitch
#'   \item FMRI_MMZ -4 CHAR(7) fMRI MMZ
#'   \item FMRI_MMY -4 CHAR(7) fMRI MMY
#'   \item FMRI_MMX -4 CHAR(7) fMRI MMX
#'   \item FMRI_MOTION_DISPLAY -4 CHAR(1) fMRI Motion Display
#'   \item FMRI_TEMPORAL_SLICE_ORDER -4 CHAR(189) fMRI Temporal Slice Order
#'   \item FMRI_MEAN_SNR -4 CHAR(8) fMRI Mean SNR
#'   \item FMRI_PHASE_DIRECTION -4 CHAR(6) fMRI Phase Direction
#'   \item STUDY_MEDICAL_ABNORMALITIES -4 CHAR(1) Study Medical
#'   \item STUDY_OVERALLPASS -4 CHAR(1) Study Overall Quality Assessment
#'   \item STUDY_COMMENTS -4 CHAR(200) Study Comments
#' }
#'
#' @examples
#' \donotrun{
#' describe(mayoadirl_mri_imageqc)
#' }
#' @docType data
#' @keywords datasets
#' @name mayoadirl_mri_imageqc
#' @usage data(mayoadirl_mri_imageqc)
#' @format A data frame with 73380 rows and 40 variables
NULL

#' Jack Lab - ADNI MRI MCH
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item SCANDATE -4 CHAR(10) Examination Date
#'   \item LONI_STUDY -4 -4 -4
#'   \item LONI_SERIES -4 -4 -4
#'   \item LONI_IMG_ID -4 -4 -4
#'   \item SERIES_NUM -4 -4 -4
#'   \item NORM_TYPE -4 -4 -4
#'   \item CHOSEN -4 -4 -4
#'   \item STUDY_QUALITY -4 -4 -4
#'   \item SERIES_QUALITY -4 -4 -4
#'   \item UNIQUEID -4 CHAR(v) Unique ID of MCH
#'   \item TYPE -4 CHAR(5) Type of finding
#'   \item STATUS -4 CHAR(8) Status
#'   \item FINDCOMMENTS -4 -4 -4
#'   \item ATLASREGIONS -4 CHAR(200) Atlas Regions
#'   \item RASLOCATIONS -4 CHAR(300) RAS Location
#'   \item NOFINDINGS -4 CHAR(1) No Findings
#'   \item SCAN_COMMENT -4 -4 -4
#'   \item EVALDATE -4 -4 -4
#'   \item SERIES_UID -4 -4 -4
#' }
#'
#' @examples
#' \donotrun{
#' describe(mayoadirl_mri_mch)
#' }
#' @docType data
#' @keywords datasets
#' @name mayoadirl_mri_mch
#' @usage data(mayoadirl_mri_mch)
#' @format A data frame with 13935 rows and 21 variables
NULL

#' Jack Lab - TBM-SyN Based Scores
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/MAYOADIRL_MRI_TBMSYN/ADNI_Mayo_Methods_TBM_SyN_20130206v1_1.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 CHAR(10) Participant roster ID
#'   \item VISCODE -4 CHAR(3) Visit code
#'   \item VISCODE2 -4 CHAR(3) Translated visit code
#'   \item EXAMDATE -4 CHAR(10) Examination Date
#'   \item VERSION -4 CHAR(3) Version Number
#'   \item SCANNERCHANGE -4 -4 -4
#'   \item VISCODEBL -4 CHAR(3) Visit code for Baseline Scan used
#'   \item VISCODE2BL -4 CHAR(3) Translated visit code for Baseline Scan used
#'   \item EXAMDATEBL -4 CHAR(10) Examination Date
#'   \item LONIUIDBL -4 CHAR(7) LONI Unique ID Baseline Scan
#'   \item LONIUID -4 CHAR(7) LONI Unique ID
#'   \item RUNDATE -4 CHAR(10) Run Date
#'   \item STATUS -4 CHAR(8) Status
#'   \item TBMSYNSCOR -4 CHAR(var) Finding Comment
#'   \item ACCELERATED -4 -4 -4
#' }
#'
#' @examples
#' \donotrun{
#' describe(mayoadirl_mri_tbmsyn)
#' }
#' @docType data
#' @keywords datasets
#' @name mayoadirl_mri_tbmsyn
#' @usage data(mayoadirl_mri_tbmsyn)
#' @format A data frame with 468 rows and 14 variables
NULL

#' Medical History
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item MH15ADRUG N  15a.  Duration of abuse (years):
#'   \item MH15BDRUG N  15b.  Period of time since end of abuse (years):
#'   \item MH14AALCH N NA 14a. During period of alcohol abuse, estimate the average number of drinks per day
#'   \item MH14BALCH N NA 14b. Duration of abuse (years)
#'   \item MH14CALCH N NA 14c. Period of time since end of abuse (years)
#'   \item MH16ASMOK N NA 16a. During periods of smoking, the average number of packs/day
#'   \item MH16BSMOK N NA 16b. Duration (years)
#'   \item MH16CSMOK N NA 16c. If no longer smoking, provide period of time since stopped smoking (years)
#'   \item SOURCE N NA Information Source
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item EXAMDATE D  Examination Date
#'   \item MHSOURCE N  Information Source
#'   \item MHPSYCH N  1. Psychiatric
#'   \item MH2NEURL N  2. Neurologic (other than AD)
#'   \item MH3HEAD N  3. Head, Eyes, Ears, Nose and Throat
#'   \item MH4CARD N  4. Cardiovascular
#'   \item MH5RESP N  5. Respiratory
#'   \item MH6HEPAT N  6. Hepatic
#'   \item MH7DERM N  7. Dermatologic-Connective Tissue
#'   \item MH8MUSCL N  8. Musculoskeletal
#'   \item MH9ENDO N  9. Endocrine-Metabolic
#'   \item MH10GAST N  10. Gastrointestinal
#'   \item MH11HEMA N  11. Hematopoietic-Lymphatic
#'   \item MH12RENA N  12. Renal-Genitourinary
#'   \item MH13ALLE N  13. Allergies or Drug Sensitivities
#'   \item MH14ALCH N  14. Alcohol Abuse
#'   \item MH15DRUG N  15. Drug Abuse
#'   \item MH16SMOK N  16. Smoking
#'   \item MH17MALI N  17. Malignancy
#'   \item MH18SURG N  18. Major Surgical Procedures
#'   \item MH19OTHR N  19. Other (if none, select "No")
#'   \item MHCOMMEN T  General Comments
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name medhist
#' @usage data(medhist)
#' @format A data frame with 3082 rows and 38 variables
NULL

#' Mini Mental State Exam
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item DONE N NA Was assessment/procedure done?
#'   \item NDREASON N NA If No, reason not done
#'   \item WORDLIST N NA Which list was used?
#'   \item WORD1 N NA Ball (alt: Apple)
#'   \item WORD2 N NA Flag (alt: Penny)
#'   \item WORD3 N NA Tree (alt: Table)
#'   \item MMLTR1 T NA Indicate 1st letter
#'   \item MMLTR2 T NA Indicate 2nd letter
#'   \item MMLTR3 T NA Indicate 3rd letter
#'   \item MMLTR4 T NA Indicate 4th letter
#'   \item MMLTR5 T NA Indicate 5th letter
#'   \item MMLTR6 T NA Indicate 6th letter (if given)
#'   \item MMLTR7 T NA Indicate 7th letter (if given)
#'   \item WORLDSCORE N NA Score:  World Backwards
#'   \item WORD1DL N NA Ball (alt: Apple)
#'   \item WORD2DL N NA Flag (alt: Penny)
#'   \item WORD3DL N NA Tree (alt: Table)
#'   \item MMRECALL N  Which list was used?
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item EXAMDATE D  Examination Date
#'   \item MMDATE N  1. What is today's date?
#'   \item MMDATECM T  Verbatim response <!--What is today's date?-->
#'   \item MMYEAR N  2. What is the year?
#'   \item MMYEARCM T  Verbatim response <!--What is the year?-->
#'   \item MMMONTH N  3. What is the month?
#'   \item MMMNTHCM T  Verbatim response <!--What is the month?-->
#'   \item MMDAY N  4. What day of the week is today?
#'   \item MMDAYCM T  Verbatim response <!--What day of the week is today?-->
#'   \item MMSEASON N  5. What season is it?
#'   \item MMSESNCM T  Verbatim response <!--What season is it?-->
#'   \item MMHOSPIT N  6. What is the name of this hospital (clinic, place)?
#'   \item MMHOSPCM T  Verbatim response <!--What is the name of this hospital (clinic, place)?-->
#'   \item MMFLOOR N  7. What floor are we on?
#'   \item MMFLRCM T  Verbatim response <!--What floor are we on?-->
#'   \item MMCITY N  8. What town or city are we in?
#'   \item MMCITYCM T  Verbatim response <!--What town or city are we in?-->
#'   \item MMAREA N  9. What county (district, borough, area) are we in?
#'   \item MMAREACM T  Verbatim response <!--What county (district, borough, area) are we in?-->
#'   \item MMSTATE N  10. What state are we in?
#'   \item MMSTCM T  Verbatim response <!--What state are we in?-->
#'   \item MMBALL N  11. Ball
#'   \item MMFLAG N  12. Flag
#'   \item MMTREE N  13. Tree
#'   \item MMTRIALS N  13a. Enter number of trials
#'   \item MMD N  14. D
#'   \item MMDLTR T  Response: Letter 1
#'   \item MML N  15. L
#'   \item MMLLTR T  Response: Letter 2
#'   \item MMR N  16. R
#'   \item MMRLTR T  Response: Letter 3
#'   \item MMO N  17. O
#'   \item MMOLTR T  Response: Letter 4
#'   \item MMW N  18. W
#'   \item MMWLTR T  Response: Letter 5
#'   \item MMBALLDL N  19. Ball
#'   \item MMFLAGDL N  20. Flag
#'   \item MMTREEDL N  21. Tree
#'   \item MMWATCH N  22. Show the participant a wrist watch and ask "What is this?"
#'   \item MMPENCIL N  23. Repeat for pencil.
#'   \item MMREPEAT N  24. Say, "Repeat after me: no ifs, ands, or buts."
#'   \item MMHAND N  25. Takes paper in right hand.
#'   \item MMFOLD N  26. Folds paper in half.
#'   \item MMONFLR N  27. Puts paper on floor.
#'   \item MMREAD N  28. Present the piece of paper which reads, "CLOSE YOUR EYES," and say: "Read this and do what it says."
#'   \item MMWRITE N  29. Give the participant a blank piece of paper and say: "Write a sentence."
#'   \item MMDRAW N  30. Present the participant with the Construction Stimulus page. Say, "Copy this design."
#'   \item MMSCORE N  MMSE TOTAL SCORE
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name mmse
#' @usage data(mmse)
#' @format A data frame with 10589 rows and 75 variables
NULL

#' MoCA
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item MOCA          N  MOCA                           
#'   \item RID N NA Participant roster ID
#'   \item SITEID N NA Site ID
#'   \item VISCODE T NA Visit code
#'   \item USERDATE S NA Date record created
#'   \item USERDATE2 S NA Date record last updated
#'   \item TRAILS N NA Trails
#'   \item CUBE N NA Copy Cube
#'   \item CLOCKCON N NA Draw Clock - Contour
#'   \item CLOCKNO N NA Draw Clock - Number
#'   \item CLOCKHAN N NA Draw Clock - Hands
#'   \item LION N NA Lion
#'   \item RHINO N NA Rhinoceros
#'   \item CAMEL N NA Camel
#'   \item IMMT1W1 N NA Immediate (#1): Face
#'   \item IMMT1W2 N NA Immediate (#1): Velvet
#'   \item IMMT1W3 N NA Immediate (#1): Church
#'   \item IMMT1W4 N NA Immediate (#1): Daisy
#'   \item IMMT1W5 N NA Immediate (#1): Red
#'   \item IMMT2W1 N NA Immediate (#2): Face
#'   \item IMMT2W2 N NA Immediate (#2): Velvet
#'   \item IMMT2W3 N NA Immediate (#2): Church
#'   \item IMMT2W4 N NA Immediate (#2): Daisy
#'   \item IMMT2W5 N NA Immediate (#2): Red
#'   \item DIGFOR N NA Digits Forward
#'   \item DIGBACK N NA Digits Backward
#'   \item LETTERS N NA List of Letters/Tapping:  # Errors
#'   \item SERIAL1 N NA Serial 7: 1st Subtraction
#'   \item SERIAL2 N NA Serial 7: 2nd Subtraction
#'   \item SERIAL3 N NA Serial 7: 3rd Subtraction
#'   \item SERIAL4 N NA Serial 7: 4th Subtraction
#'   \item SERIAL5 N NA Serial 7: 5th Subtraction
#'   \item REPEAT1 N NA Repeat Sentence: I only know that John is the one to help today.
#'   \item REPEAT2 N NA Repeat Sentence: The cat always hid under the couch when dogs were in the room.
#'   \item FFLUENCY N NA Letter Fluency - F: Total number of correct words
#'   \item ABSTRAN N NA Abstraction: train-bicycle
#'   \item ABSMEAS N NA Abstraction: watch-ruler
#'   \item DELW1 N NA Delayed: Face
#'   \item DELW2 N NA Delayed: Velvet
#'   \item DELW3 N NA Delayed: Church
#'   \item DELW4 N NA Delayed: Daisy
#'   \item DELW5 N NA Delayed: Red
#'   \item DATE N NA Date
#'   \item MONTH N NA Month
#'   \item YEAR N NA Year
#'   \item DAY N NA Day
#'   \item PLACE N NA Place
#'   \item CITY N NA City
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name moca
#' @usage data(moca)
#' @format A data frame with 5496 rows and 50 variables
NULL

#' Modified Hachinski
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item EXAMDATE D  Examination Date
#'   \item HMONSET N  1. Abrupt Onset of Dementia
#'   \item HMSTEPWS N  2. Stepwise Deterioration of Dementia
#'   \item HMSOMATC N  3. Somatic Complaints
#'   \item HMEMOTIO N  4. Emotional Incontinence
#'   \item HMHYPERT N  5. History of Hypertension
#'   \item HMSTROKE N  6. History of Stroke
#'   \item HMNEURSM N  7. Focal Neurologic Symptoms
#'   \item HMNEURSG N  8. Focal Neurologic Signs
#'   \item HMSCORE N  TOTAL SCORE
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name modhach
#' @usage data(modhach)
#' @format A data frame with 2661 rows and 17 variables
NULL

#' Monitor Eligibility
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item MPIN T NA I certify that I am using my own personal username and pin and understand that by using my username and pin, I am authorizing this electronic signature to be the legally binding equivalent of my handwritten signature executed on paper. - Enter Your PIN -
#'   \item RID N NA Participant roster ID
#'   \item SITEID N NA Site ID
#'   \item VISCODE T NA Visit code
#'   \item USERDATE S NA Date record created
#'   \item USERDATE2 S NA Date record last updated
#'   \item MINELG N NA Please confirm participant's eligibility for enrollment in the protocol.
#'   \item MELGDATE D NA Confirmation Date
#'   \item MCOMM T NA Comments:
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name monelg
#' @usage data(monelg)
#' @format A data frame with 3328 rows and 11 variables
NULL

#' Monitor Review
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item MONCONDUCT N NA Review conducted:
#'   \item SDV N NA Was this visit 100% Source Doc Verified (SDV)?
#'   \item RSDV N NA If No, were the minimum set of forms requiring SDV at this visit reviewed?
#'   \item RID N NA Participant roster ID
#'   \item SITEID N NA Site ID
#'   \item VISCODE T NA Visit code
#'   \item USERDATE S NA Date record created
#'   \item USERDATE2 S NA Date record last updated
#'   \item MONPASS N NA Please indicate below.
#'   \item MONDATE D NA Approval Date:
#'   \item MONCOMM T NA Comments:
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name monrev
#' @usage data(monrev)
#' @format A data frame with 7438 rows and 13 variables
NULL

#' 3T MRI Scan Information
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N NA Participant roster ID
#'   \item SITEID N NA Site ID
#'   \item VISCODE T NA Visit code
#'   \item USERDATE S NA Date record created
#'   \item USERDATE2 S NA Date record last updated
#'   \item RECNO N NA 
#'   \item MMCONDCT N NA Was the scan conducted?
#'   \item MMREASON N NA Reason why the scan was not conducted:
#'   \item MMOTHSPE T NA If Other, specify:
#'   \item EXAMDATE D NA Examination Date
#'   \item MOTION N NA Patient Motion Problems:
#'   \item MOTIONDET T NA If yes, describe:
#'   \item MALFUNC N NA Scanner Malfunction:
#'   \item MALFUNCDET T NA If yes, describe:
#'   \item OTRDEV N NA Other Protocol Variations
#'   \item OTRDEVDET T NA If yes, describe:
#'   \item MMTRNSFR N NA Was data transferred to LONI within 24 hours of scan?
#'   \item MMTRNDATE D NA Transfer Date
#'   \item MMTRNCOM T NA Comments
#'   \item MMARCHIVE N NA Data Archived Locally
#'   \item MMARCMED T NA Archive Medium
#'   \item MMARCCOM T NA Comments
#'   \item MMLPDONE N NA Was a Lumbar Puncture completed prior to the MRI scan?
#'   \item MMLPINTER N NA If Yes, What was the interval between LP and MRI?
#'   \item EYEASK4 N NA Was the subject instructed to open their eyes?
#'   \item EYEKEEP4 N NA Did the subject keep their eyes open (MRI Tech:  ask the subject right after the scan)
#'   \item EYEASK6 N NA Was the subject instructed to open their eyes?
#'   \item EYEKEEP6 N NA Did the subject keep their eyes open (MRI Tech:  ask the subject right after the scan)
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name mri3gometa
#' @usage data(mri3gometa)
#' @format A data frame with 417 rows and 30 variables
NULL

#' 3T MRI Scan Information
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item RECNO N  
#'   \item MMCONDCT N  Was the scan conducted?
#'   \item MMREASON N  Reason why the scan was not conducted:
#'   \item MMOTHSPE T  If Other, specify:
#'   \item EXAMDATE D  Examination Date
#'   \item MMSCOUT N  1. Tri-Planar Scout (if available, otherwise use an axial scout)
#'   \item MMSCTCOM T  Comments <!--Tri-Planar Scout-->
#'   \item MMSMPRAGE N  2. Straight Sagittal MPRAGE Sequence
#'   \item MMSMPCOM T  Comments <!--Straight Sagittal MPRAGE-->
#'   \item MMRMPRAGE N  3. Repeat Straight Sagittal MPRAGE Sequence
#'   \item MMRMPCOM T  Comments <!--Repeat Straight Sagittal MPRAGE-->
#'   \item MMB1HEAD N  4. B1 Calibration Head Coil Scan (Only applicable for phased array head coil on GE and Siemens systems)
#'   \item MMB1HDCOM T  Comments <!--B1 Calibration Head Coil Scan-->
#'   \item MMB1BODY N  5. B1 Calibration Body Coil Scan (Only applicable for phased array head coil on GE and Siemens systems)
#'   \item MMB1BDCOM T  Comments <!--B1 Calibration Body Coil Scan-->
#'   \item MMECHO N  6. Straight Axial Fast or Turbo Spin Echo
#'   \item MMECCOM T  Comments <!--6. Straight axial or spin echo-->
#'   \item MMPHAN N  7. In new exam; Perform ADNI QC Scan. Localizer and Straight Sagittal MPRAGE (with increased slice thickness to ensure phantom coverage)
#'   \item MMPHCOM T  Comments:  <!--ADNI QC Scan-->
#'   \item MMTRNSFR N  Was data transferred to LONI within 24 hours of scan?
#'   \item MMTRNDATE D  Transfer Date
#'   \item MMTRNCOM T  Comments
#'   \item MMARCHIVE N  Data Archived Locally
#'   \item MMARCMED T  Archive Medium
#'   \item MMARCCOM T  Comments
#'   \item MMLPDONE N  9. Was a Lumbar Puncture completed prior to the MRI scan?
#'   \item MMLPINTER N  If Yes, What was the interval between LP and MRI?
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name mri3meta
#' @usage data(mri3meta)
#' @format A data frame with 940 rows and 34 variables
NULL

#' MRI B1 Calibration
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item RECNO N  
#'   \item EXAMDATE D  Examination Date
#'   \item FLDSTRENG N  Field Strength
#'   \item COILTYPE T  Coil Type
#'   \item SCAN N  Scan
#'   \item LONISID N  LONI Study ID
#'   \item PRESENT N  
#'   \item COMMENTS T  
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name mrib1calib
#' @usage data(mrib1calib)
#' @format A data frame with 4480 rows and 15 variables
NULL

#' MRI Infarcts
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/MRI_INFARCTS/UCD%20ADNI%20MRI%20Infarct%20Assessment%20Method.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4  Participant roster ID
#'   \item VISCODE -4  Visit code
#'   \item VISCODE2 -4 -4 Translated visit code
#'   \item USERDATE -4  Date record created
#'   \item EXAMDATE -4  Examination Date
#'   \item STROKE_READ_DATE -4  Date Image Evaluated
#'   \item SIDE -4 Text Side of Infarct, if detected
#'   \item SIZE -4 Text Size of Infarct, if detected
#'   \item INFARCT_NUMBER -4 integer Number detected
#'   \item BRAIN_REGION -4 integer Anatomical Location
#'   \item STROKE_TYPE -4 -4 -4
#'   \item LOCATION_XYZ -4 Text Image Space Location
#' }
#'
#' @examples
#' \donotrun{
#' describe(mri_infarcts)
#' }
#' @docType data
#' @keywords datasets
#' @name mri_infarcts
#' @usage data(mri_infarcts)
#' @format A data frame with 6931 rows and 12 variables
NULL

#' 1.5T MRI Scan Information
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item FLDSTRNGTH N  Field Strength
#'   \item EYEASK N  Was the participant instructed to open their eyes?
#'   \item EYEKEEP N  Did the participant keep their eyes open (MRI Tech:  ask the subject right after the scan)
#'   \item SEDATIVE N  Was sedation medication consumed for use during MRI scan?
#'   \item MOTION N  Patient Motion Problems:
#'   \item MOTIONDET T  If yes, describe:
#'   \item MALFUNC N  Scanner Malfunction:
#'   \item MALFUNCDET T  If yes, describe:
#'   \item OTRDEV N  Other Protocol Variations
#'   \item OTRDEVDET T  If yes, describe:
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item RECNO N  
#'   \item MMCONDCT N  Was the scan conducted?
#'   \item MMREASON N  Reason why the scan was not conducted:
#'   \item MMOTHSPE T  If Other, specify:
#'   \item EXAMDATE D  Examination Date
#'   \item MMSCOUT N  1. Tri-Planar Scout (if available, otherwise use an axial scout)
#'   \item MMSCTCOM T  Comments <!--Tri-Planar Scout-->
#'   \item MMSMPRAGE N  2. Straight Sagittal MPRAGE Sequence
#'   \item MMSMPCOM T  Comments <!--Straight Sagittal MPRAGE-->
#'   \item MMRMPRAGE N  3. Repeat Straight Sagittal MPRAGE Sequence
#'   \item MMRMPCOM T  Comments <!--Repeat Straight Sagittal MPRAGE-->
#'   \item MMB1HEAD N  4. B1 Calibration Head Coil Scan (Only applicable for phased array head coil on GE and Siemens systems)
#'   \item MMB1HDCOM T  Comments <!--B1 Calibration Head Coil Scan-->
#'   \item MMB1BODY N  5. B1 Calibration Body Coil Scan (Only applicable for phased array head coil on GE and Siemens systems)
#'   \item MMB1BDCOM T  Comments <!--B1 Calibration Body Coil Scan-->
#'   \item MMECHO N  6. Straight Axial Fast or Turbo Spin Echo
#'   \item MMECCOM T  Comments <!--6. Straight axial or spin echo-->
#'   \item MMPHAN N  7. In new exam; Perform ADNI QC Scan. Localizer and Straight Sagittal MPRAGE (with increased slice thickness to ensure phantom coverage)
#'   \item MMPHCOM T  Comments:  <!--ADNI QC Scan-->
#'   \item MMTRNSFR N  Was data transferred to LONI within 24 hours of scan?
#'   \item MMTRNDATE D  Transfer Date
#'   \item MMTRNCOM T  Comments
#'   \item MMARCHIVE N  Data Archived Locally
#'   \item MMARCMED T  Archive Medium
#'   \item MMARCCOM T  Comments
#'   \item MMLPDONE N  9. Was a Lumbar Puncture completed prior to the MRI scan?
#'   \item MMLPINTER N  If Yes, What was the interval between LP and MRI?
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name mrimeta
#' @usage data(mrimeta)
#' @format A data frame with 10086 rows and 44 variables
NULL

#' MRI MPRAGE Process
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item RECNO N  
#'   \item EXAMDATE D  Examination Date
#'   \item FLDSTRENG N  Field Strength
#'   \item COILTYPE T  Coil Type
#'   \item SCAN N  Scan
#'   \item LONISID N  LONI Study ID
#'   \item LONIUID T  LONI Unique Series ID selected for processing. This field identifies which scan the MRI Core has selected to be the preferred scan to be used for processing.  MPRAGE Rankings: The MPRAGE rankings are done in a qualitative manner.A scan with a 1 ranking is considered a high quality scan.  A 2 ranking is considered a medium quality scan.  3 ranking is a low quality scan.3 is the lowest ranking a scan can receive and still be considered a passing scan.  Anything below 3 would be a failure for quality. The rankings are found in the MRIMPRANK table in the RANK field.  Choosing MPRAGES: For scans ranked 2 and 3 the scan ranked 2 (whatever is the lower ranking of the two) should always be the "preferred/chosen" MPRAGE.  If the rankings are tied in ranking the QC-er would chose the "sharper of the two". If the two scans are identical the first MPRAGE was always chosen.
#'   \item COMMENTS T  
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name mrimppro
#' @usage data(mrimppro)
#' @format A data frame with 3269 rows and 15 variables
NULL

#' MRI MPRAGE Ranking
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item RECNO N  
#'   \item EXAMDATE D  Examination Date
#'   \item FLDSTRENG N  Field Strength
#'   \item COILTYPE T  Coil Type
#'   \item SCAN N  Scan
#'   \item LONISID N  LONI Study ID
#'   \item LONIUID T  LONI Unique Series ID
#'   \item RANK N  MPRAGE Rankings: The MPRAGE rankings are done in a qualitative manner.A scan with a 1 ranking is considered a high quality scan.  A 2 ranking is considered a medium quality scan.  3 ranking is a low quality scan.3 is the lowest ranking a scan can receive and still be considered a passing scan.  Anything below 3 would be a failure for quality.  Choosing MPRAGES: For scans ranked 2 and 3 the scan ranked 2 (whatever is the lower ranking of the two) should always be the "preferred/chosen"MPRAGE.  If the rankings are tied in ranking the QC-er would chose the"sharper of the two". If the two scans are identical the first MPRAGE was always chosen. The preferred scan is indicated by the LONIUID field in the MRIMPPRO table.
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name mrimprank
#' @usage data(mrimprank)
#' @format A data frame with 9412 rows and 15 variables
NULL

#' MRI Subject Inclusion
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#'   \item RECNO N  
#'   \item EXAMDATE D  Examination Date
#'   \item LONISID N  LONI Study ID
#'   \item FLDSTRENG N  Field Strength
#'   \item SCAN N  Scan
#'   \item QCTYPE N  QC Type
#'   \item NOMEDICAL N  Image Medical Issues (check all that apply):
#'   \item SURGERY N  
#'   \item HEMMORHAGE N  
#'   \item DEVANOMALY N  
#'   \item LESION N  
#'   \item ATROPHY N  
#'   \item INFARCTION N  
#'   \item TRAUMA N  
#'   \item METALLIC N  
#'   \item NPH N  
#'   \item EDEMA N  
#'   \item OTHER N  
#'   \item INCLUSION N  Inclusion
#'   \item STEREOMARK N  Stereotactic Marker present
#'   \item SERIAL N  Serial scan
#'   \item MEDEXCL N  Medical Exclusion (see Comments for details)
#'   \item PASS N  Pass:
#'   \item QUARANTINE N  Release from Quarantine:
#'   \item PAYPATIENT N  Pay Patient:
#'   \item PAYSITE N  Pay Site:
#'   \item RESCAN N  Rescan
#'   \item COMMENTS T  Comments
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name mrinclusio
#' @usage data(mrinclusio)
#' @format A data frame with 9777 rows and 35 variables
NULL

#' MRI Phantom
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item RECNO N  
#'   \item EXAMDATE D  Examination Date
#'   \item FLDSTRENG N  Field Strength
#'   \item COILTYPE T  Coil Type
#'   \item SCAN N  Scan
#'   \item LONISID N  LONI Study ID
#'   \item LONIPSID N  Phantom - LONI Study ID
#'   \item PRESENT N  Phantom Present
#'   \item COMMENTS T  
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name mriphantom
#' @usage data(mriphantom)
#' @format A data frame with 4141 rows and 16 variables
NULL

#' MRI Protocol
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item RECNO N  
#'   \item EXAMDATE D  Examination Date
#'   \item FLDSTRENG N  Field Strength
#'   \item COILTYPE T  Coil Type
#'   \item SCAN N  Scan
#'   \item LONISID N  LONI Study ID
#'   \item LONIUID T  LONI Unique Series ID
#'   \item SERIESNUMB N  
#'   \item SERIESDESC T  
#'   \item PASS N  
#'   \item COMMENTS T  
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name mriprot
#' @usage data(mriprot)
#' @format A data frame with 11918 rows and 18 variables
NULL

#' MRI Quality
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item RECNO N  
#'   \item EXAMDATE D  Examination Date
#'   \item FLDSTRENG N  Field Strength
#'   \item COILTYPE T  Coil Type
#'   \item SCAN N  Scan
#'   \item LONISID N  LONI Study ID
#'   \item LONIUID T  LONI Unique Series ID
#'   \item SERIESNUMB N  
#'   \item SERIESDESC T  
#'   \item INBGR N  
#'   \item OUTBGR N  
#'   \item INFLOW N  
#'   \item OUTFLOW N  
#'   \item INOTHER N  
#'   \item OUTOTHER N  
#'   \item WRAP N  
#'   \item HEADCOVER N  
#'   \item INHOMOGEN N  
#'   \item IPMOTION N  
#'   \item MARKER N  
#'   \item PASS N  
#'   \item COMMENTS T  
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name mriquality
#' @usage data(mriquality)
#' @format A data frame with 11720 rows and 29 variables
NULL

#' MRI Clinical Read
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item EXAMDATE D  Examination Date
#'   \item MRREAD N  Was the 1.5T MRI done?
#'   \item MRUPLD I  Upload 1.5T MRI Clinical Read:
#'   \item MRCOMPAT N  Is the MRI compatible with the Inclusion/Exclusion Criteria?
#'   \item MRCOMSPE T  If No, explain:
#'   \item MR3TREAD N  Was a clinical read of the 3T MRI done?
#'   \item MR3TUPLD I  Upload 3T MRI Clinical Read :
#'   \item MRSUITABL N  Is the participant clinically suitable to remain in the study?
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name mriread
#' @usage data(mriread)
#' @format A data frame with 4106 rows and 15 variables
NULL

#' MRI Serial
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item RECNO N  
#'   \item EXAMDATE D  Examination Date
#'   \item FLDSTRENG N  Field Strength
#'   \item COILTYPE T  Coil Type
#'   \item SCAN N  Scan
#'   \item LONISID N  LONI Study ID
#'   \item LONIUID T  LONI Unique Series ID
#'   \item BLLONIUID T  LONI Unique Series ID for the baseline scan.
#'   \item BLSDATE D  Baseline scan date.
#'   \item SAMESUBJ N  
#'   \item REGISTRAT N  
#'   \item GROSSINHOM N  
#'   \item COMMENTS T  
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name mriserial
#' @usage data(mriserial)
#' @format A data frame with 3204 rows and 20 variables
NULL

#' Neuropsychological Battery
#'
#'
#'
#'
#' @references Estevez-Gonzalez, A., Kulisevsky, J., Boltes, A., Otermin, P., & Garcia-Sanchez, C. (2003). Rey verbal learning test is a useful tool for differential diagnosis in the preclinical phase of Alzheimer's disease: comparison with mild cognitive impairment and normal aging. \emph{International Journal of Geriatric Psychiatry}. 18 (11), 1021.
#'
#' @description The Neuropsychological Battery table contains data for multiple assessments, including:  Logical Memory, Rey Auditory Verbal Learning Test, Clock Drawing, Clock Copying, Category Fluency, Trail Making Test, Boston Naming Test, ANART, and Digit Span.  At any given visit, only a subset of those tests are administered.  The Digit Span was dropped after ADNI1.  The Category Fluency - Animals was retained, but Vegetables were dropped after ADNI1.  A Spanish language option for the Boston Naming Test became available for participants testing in Spanish beginning with ADNIGO.  The data dictionary for this table can be difficult to parse to identify which variables belong to which assessment.  For clarity, the field/variable names associated with each test are identified here:   
#' 
#' Logical Memory - Immediate Recall:  LMSTORY, LIMMTOTAL, LIMMEND
#' 
#' Logical Memory - Delayed Recall: LDELBEGIN, LDELTOTAL, LDELCUE.
#' 
#' Rey Auditory Verbal Learning Test: AVTOT1, AVERR1, AVTOT2, AVERR2, AVTOT3, AVERR3, AVTOT4, AVERR4, AVTOT5, AVERR5, AVTOT6, AVERR6, AVTOTB, AVERRB, AVENDED
#' 
#' Rey Auditory Verbal Learning Test - Delayed:  AVDELBEGAN, AVDEL30MIN, AVDELERR1, AVDELTOT, AVDELERR2 
#' 
#' Clock Drawing: CLOCKCIRC, CLOCKSYM, CLOCKNUM, CLOCKHAND, CLOCKTIME, CLOCKSCOR
#' 
#' Clock Copying: COPYCIRC, COPYSYM, COPYNUM, COPYHAND, COPYTIME, COPYSCOR
#' 
#' Category Fluency (Vegetables ADNI1 only): CATANIMSC, CATANPERS, CATANINTR, CATVEGESC, CATVGPERS, CATVGINTR
#' 
#' Trail Making Test: TRAASCOR, TRAAERRCOM, TRAAERROM, TRABSCOR, TRABERRCOM, TRABERROM
#' 
#' Boston Naming Test (Spanish version provided in ADNIGO/2): BNTND, BNTSPONT, BNTSTIM, BNTCSTIM, BNTPHON, BNTCPHON, BNTTOTAL
#' 
#' American National Adult Reading Test (ANART): ANARTND, ANARTERR
#' 
#' Digit Span (ADNI1 only): DSPANFOR, DSPANFLTH, DSPANBAC, DSPANBLTH
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item MINTUNCUED N NA MINT Total Uncued Correct 
#'   \item MINTSEMCUE N NA MINT Total Correct - with Semantic Cue
#'   \item MINTTOTAL N NA MINT Total Correct (Uncued + Correct with Semantic cue)
#'   \item ANART N NA Was ANART conducted?  
#'   \item RAVLT.immediate       N  RAVLT Immediate (sum of 5 trials)    
#'   \item RAVLT.learning        N  RAVLT Learning (trial 5 - trial 1)   
#'   \item RAVLT.forgetting      N  RAVLT Forgetting (trial 5 - delayed) 
#'   \item RAVLT.perc.forgetting N  RAVLT Percent Forgetting             
#'   \item LIMMEND T HHMM Time Ended (24-hour clock)
#'   \item LDELBEGIN T HHMM Time Began (24-hour clock)
#'   \item AVENDED T HHMM AVLT Time Trial B Ended
#'   \item AVDELBEGAN T HHMM Time Began (24-hour clock)
#'   \item LMSTORY N NA Which Logical Memory story was used?
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item EXAMDATE D  Examination Date
#'   \item CLOCKCIRC N  1. Approximately circular face
#'   \item CLOCKSYM N  2. Symmetry of number placement
#'   \item CLOCKNUM N  3. Correctness of numbers
#'   \item CLOCKHAND N  4. Presence of the two hands
#'   \item CLOCKTIME N  5. Presence of the two hands, set to ten after eleven
#'   \item CLOCKSCOR N  Total Score
#'   \item COPYCIRC N  1. Approximately circular face
#'   \item COPYSYM N  2. Symmetry of number placement
#'   \item COPYNUM N  3. Correctness of numbers
#'   \item COPYHAND N  4. Presence of the two hands
#'   \item COPYTIME N  5. Presence of the two hands, set to ten after eleven
#'   \item COPYSCOR N  Total Score
#'   \item LIMMTOTAL N  Logical Memory - Immediate Recall <br />Total Number of Story Units Recalled:
#'   \item AVTOT1 N  Trial 1 Total
#'   \item AVERR1 N  Total Intrusions
#'   \item AVTOT2 N  Trial 2 Total
#'   \item AVERR2 N  Total Intrusions
#'   \item AVTOT3 N  Trial 3 Total
#'   \item AVERR3 N  Total Intrusions
#'   \item AVTOT4 N  Trial 4 Total
#'   \item AVERR4 N  Total Intrusions
#'   \item AVTOT5 N  Trial 5 Total
#'   \item AVERR5 N  Total Intrusions
#'   \item AVTOT6 N  Trial 6 Total
#'   \item AVERR6 N  Total Intrusions
#'   \item AVTOTB N  List B Total
#'   \item AVERRB N  Total Intrusions
#'   \item DSPANFOR N  Forward: Total Correct
#'   \item DSPANFLTH N  Forward: Length
#'   \item DSPANBAC N  Backward: Total Correct
#'   \item DSPANBLTH N  Backward: Length
#'   \item CATANIMSC N  Category Fluency (Animals) - Total Correct
#'   \item CATANPERS N  Category Fluency (Animals) - Perseverations
#'   \item CATANINTR N  Category Fluency (Animals) - Intrusions
#'   \item CATVEGESC N  Category Fluency (Vegetables) - Total Correct
#'   \item CATVGPERS N  Category Fluency (Vegetables) - Perseverations
#'   \item CATVGINTR N  Category Fluency (Vegetables) - Intrusions
#'   \item TRAASCOR N  Part A - Time to Complete
#'   \item TRAAERRCOM N  Errors of Commission
#'   \item TRAAERROM N  Errors of Omission
#'   \item TRABSCOR N  Part B - Time to complete
#'   \item TRABERRCOM N  Errors of Commission
#'   \item TRABERROM N  Errors of Omission
#'   \item DIGITSCOR N  Total Correct
#'   \item LDELTOTAL N  Logical Memory - Delayed Recall <br />Total Number of Story Units Recalled:
#'   \item LDELCUE N  Cue used?
#'   \item BNTND T  Check here if:
#'   \item BNTSPONT N  1. Number of spontaneously given correct responses
#'   \item BNTSTIM N  2. Number of semantic cues given
#'   \item BNTCSTIM N  3. Number of correct responses following a semantic cue
#'   \item BNTPHON N  4. Number of phonemic cues given
#'   \item BNTCPHON N  5. Number of correct responses following a phonemic cue
#'   \item BNTTOTAL N  Total Number Correct (1+3)
#'   \item AVDEL30MIN N  30 Minute Delay Total
#'   \item AVDELERR1 N  Total Intrusions
#'   \item AVDELTOT N  Recognition Score
#'   \item AVDELERR2 N  Recognition Errors
#'   \item ANARTND T  Check here if:
#'   \item ANARTERR N  ANART Total Score (Total # of errors)
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' neurobat$RAVLT.immediate <- apply(neurobat[, paste('AVTOT', 1:5, sep = '')], 
#'   1, sum, na.rm = FALSE)
#' neurobat$RAVLT.learning <- neurobat$AVTOT5-neurobat$AVTOT1
#' neurobat$RAVLT.forgetting <- neurobat$AVTOT5-neurobat$AVDEL30MIN
#' neurobat$RAVLT.perc.forgetting <- 100*neurobat$RAVLT.forgetting / neurobat$AVTOT5
#' neurobat$RAVLT.perc.forgetting <- ifelse(neurobat$AVTOT5 == 0, NA, neurobat$RAVLT.perc.forgetting)
#' neurobat$RAVLT <- neurobat$RAVLT.learning
#' label(neurobat$RAVLT) <- 'RAVLT Learning'
#' 
#' @docType data
#' @keywords datasets
#' @name neurobat
#' @usage data(neurobat)
#' @format A data frame with 12448 rows and 80 variables
NULL

#' Neurological Exam
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item EXAMDATE D  Examination Date
#'   \item NXVISUAL N  1. Significant Visual Impairment
#'   \item NXVISDES T  Details <!--Significant Visual Impairment-->
#'   \item NXAUDITO N  2. Significant Auditory Impairment
#'   \item NXAUDDES T  Details <!--Significant Auditory Impairment-->
#'   \item NXTREMOR N  3. Tremor
#'   \item NXTREDES T  Details <!--Tremor-->
#'   \item NXCONSCI N  4. Level of Consciousness
#'   \item NXCONDES T  Details <!--Level of Consciousness-->
#'   \item NXNERVE N  5. Cranial Nerves
#'   \item NXNERDES T  Details <!--Cranial Nerves-->
#'   \item NXMOTOR N  6. Motor Strength
#'   \item NXMOTDES T  Details <!--Motor Strength-->
#'   \item NXFINGER N  7a. Cerebellar - Finger to Nose
#'   \item NXFINDES T  Details <!--Cerebellar - Finger to Nose-->
#'   \item NXHEEL N  7b. Cerebellar - Heel to Shin
#'   \item NXHEEDES T  Details <!--Cerebellar - Heel to Shin-->
#'   \item NXSENSOR N  8. Sensory
#'   \item NXSENDES T  Details <!--Sensory-->
#'   \item NXTENDON N  9. Deep Tendon Reflexes
#'   \item NXTENDES T  Details <!--Deep Tendon Reflexes-->
#'   \item NXPLANTA N  10. Plantar Reflexes
#'   \item NXPLADES T  Details <!--Plantar Reflexes-->
#'   \item NXGAIT N  11. Gait
#'   \item NXGAIDES T  Details <!--Gait-->
#'   \item NXOTHER N  12. Other
#'   \item NXOTHSPE T  Details <!--Other-->
#'   \item NXGENCOM T  13. General Comments
#'   \item NXABNORM N  14. Based on Neurological Examination, clinician must check appropriate box below:
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name neuroexm
#' @usage data(neuroexm)
#' @format A data frame with 2883 rows and 36 variables
NULL

#' NACC Neuropathology Data Form
#'
#'
#'
#' @author \email{betsy@wubios.wustl.edu}
#'
#'
#' @description See \url{https://www.alz.washington.edu/NONMEMBER/NP/npded10.pdf} and \url{https://www.alz.washington.edu/NONMEMBER/NP/npded9.pdf}
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID C -4 Participant roster ID
#'   \item NPFIX N -4 Fixative 
#'   \item NPFIXX C -4 Fixative -- Other, specify 
#'   \item NPWBRWT N -4 Whole brain weight 
#'   \item NPWBRF N -4 Fresh or fixed weight 
#'   \item NPGRCCA N -4 Severity of gross findings -- Cerebral cortex atrophy 
#'   \item NPGRLA N -4 Severity of gross findings -- Lobaratrophy 
#'   \item NPGRHA N -4 Severity of gross findings -- Hippocampus atrophy 
#'   \item NPGRSNH N -4 Severity of gross findings -- Substantianigra hypopigmentation 
#'   \item NPGRLCH N -4 Severity of gross findings -- L. ceruleus hypopigmentation 
#'   \item NPTAN N -4 Tau antibody 
#'   \item NPTANX C -4 Tau antibody -- Other, specify 
#'   \item NPABAN N -4 Amyloid beta antibody 
#'   \item NPABANX C -4 Amyloid beta antibody -- Other, specify 
#'   \item NPASAN N -4 Alpha synuclein antibody 
#'   \item NPASANX C -4 Alpha synuclein antibody -- Other, specify 
#'   \item NPTDPAN N -4 TDP-43 antibody 
#'   \item NPTDPANX C -4 TDP-43 antibody -- Other, specify 
#'   \item NPHISMB N -4 Histochemical stains -- Modified Bielschowsky 
#'   \item NPHISG N -4 Histochemical stains -- Gallyas 
#'   \item NPHISSS N -4 Histochemical stains -- Other silver stain 
#'   \item NPHIST N -4 Histochemical stains -- Thioflavin 
#'   \item NPHISO N -4 Histochemical stains -- Other 
#'   \item NPHISOX C -4 Histochemical stains -- Other, specify 
#'   \item NPTHAL N -4 Thal phase for amyloid plaques (A score) 
#'   \item NPADNC N -4 NIA-AA ADNC 
#'   \item NPINF N -4 Old infarcts observed grossly, including lacunes 
#'   \item NPINF1A N -4 Number of infarcts -- Cerebral cortex 
#'   \item NPINF2A N -4 Number of infarcts -- Subcortical cerebral white matter and peri-ventricular white matter 
#'   \item NPINF3A N -4 Number of infarcts -- Deep cerebral gray matter or internal capsule 
#'   \item NPINF4A N -4 Number of infarcts -- Brainstem or cerebellum 
#'   \item NPHEMO N -4 Were single or multiple old hemorrhagesobserved grossly? 
#'   \item NPHEMO1 N -4 Subdural or epidural hemorrhage 
#'   \item NPHEMO2 N -4 Primary parenchymal hemorrhage 
#'   \item NPHEMO3 N -4 Secondary parenchymal hemorrhage (e.g., tumor, vascular malformation) 
#'   \item NPOLD N -4 Old microinfarcts (not observed grossly) 
#'   \item NPOLD1 N -4 Number of old microinfarcts -- Cerebral cortex 
#'   \item NPOLD2 N -4 Number of old microinfarcts -- Subcortical and periventricular white matter 
#'   \item NPOLD3 N -4 Number of old microinfarcts -- Subcortical gray matter 
#'   \item NPOLD4 N -4 Number of old microinfarcts -- Brainstem and cerebellum 
#'   \item NPOLDD N -4 Old cerebral microbleeds 
#'   \item NPOLDD1 N -4 Number of microbleeds -- Cerebral cortex 
#'   \item NPOLDD2 N -4 Number of microbleeds -- Subcortical and periventricular white matter 
#'   \item NPOLDD3 N -4 Number of microbleeds -- Subcortical gray matter 
#'   \item NPOLDD4 N -4 Number of microbleeds -- Brainstem and cerebellum 
#'   \item NPWMR N -4 White matter rarefaction 
#'   \item NPPATH N -4 Other pathologic changes related to ischemic or vascular disease not previously specified 
#'   \item NPPATH2 N -4 Acute neuronal necrosis 
#'   \item NPPATH3 N -4 Acute/subacute gross infarcts 
#'   \item NPPATH4 N -4 Acute/subacute microinfarcts 
#'   \item NPPATH5 N -4 Acute/subacute gross hemorrhage 
#'   \item NPPATH6 N -4 Acute/subacute microhemorrhage 
#'   \item NPPATH7 N -4 Vascular malformation of any type 
#'   \item NPPATH8 N -4 Aneurysm of any type 
#'   \item NPPATH9 N -4 Vasculitis of any type 
#'   \item NPPATH10 N -4 CADASIL 
#'   \item NPPATH11 N -4 Mineralization of blood vessels 
#'   \item NPPATHO N -4 Other ischemic or vascular pathology 
#'   \item NPPATHOX C -4 Other ischemic or vascular pathology, specify 
#'   \item NPLBOD N -4 Is there evidence of Lewy body pathology 
#'   \item NPNLOSS N -4 Neuron loss in the substantia nigra 
#'   \item NPHIPSCL N -4 Hippocampal sclerosis (CA1 and/or subiculum) 
#'   \item NPTDPA N -4 Distribution of TDP-43 immunoreactive inclusions -- Spinal cord 
#'   \item NPTDPB N -4 Distribution of TDP-43 immunoreactive inclusions -- Amygdala 
#'   \item NPTDPC N -4 Distribution of TDP-43 immunoreactive inclusions -- Hippocampus 
#'   \item NPTDPD N -4 Distribution of TDP-43 immunoreactive inclusions -- Entorhinal/inferior temporal cortex 
#'   \item NPTDPE N -4 Distribution of TDP-43 immunoreactive inclusions -- Neocortex 
#'   \item NPFTDTAU N -4 FTLD with tau pathology (FTLD-tau) or other tauopathy 
#'   \item NPFTDT2 N -4 FTLD-tau subtype -- Other 3R tauopathy (Includes MAPT mutationtauopathy) 
#'   \item NPFTDT5 N -4 FTLD-tau subtype -- Argyrophilic grains 
#'   \item NPFTDT6 N -4 FTLD-tau subtype -- Other 4R tauopathy (includes sporadic multiple systems tauopathy, globular glial tauopathy, MAPT mutation tauopathy) 
#'   \item NPFTDT7 N -4 FTLD-tau subtype -- Chronic traumatic encephalopathy 
#'   \item NPFTDT8 N -4 FTLD-tau subtype -- Amyotrophic lateral sclerosis (ALS)/parkinsonism-dementia complex of Guam 
#'   \item NPFTDT9 N -4 FTLD-tau subtype -- Tangle dominant disease 
#'   \item NPFTDT10 N -4 FTLD-tau subtype -- Other 3R + 4R tauopathy (includes unclassifiable, focal, glial only, MAPT mutation tauopathy, NOS) 
#'   \item NPFTDTDP N -4 FTLD with TDP-43 pathology (FTLD-TDP) 
#'   \item NPALSMND N -4 ALS/motor neuron disease (MND) present 
#'   \item NPOFTD N -4 Other FTLD 
#'   \item NPOFTD1 N -4 Other FTLD subtype -- Atypical FTLD-U (aFTLD-U) 
#'   \item NPOFTD2 N -4 Other FTLD subtype -- NIFID (neuronal intermediate filament inclusions disease) 
#'   \item NPOFTD3 N -4 Other FTLD subtype -- BIBD (basophilic inclusion body disease) 
#'   \item NPOFTD4 N -4 Other FTLD subtype -- FTLD-UPS (ubiquitin-proteasome system [ubiquitin or p62 positive, tau/TDP-43/FUS negative inclusions]) 
#'   \item NPOFTD5 N -4 Other FTLD subtype -- FTLD-NOS (includes dementia lacking distinctive histology (DLDH) and FTLD with no inclusions (FTLD-NI) detected by tau, TDP-43, or ubiquitin/p62 IHC) 
#'   \item NPPDXA N -4 Pigment-spheroid degeneration/NBIA 
#'   \item NPPDXB N -4 Multiple system atrophy 
#'   \item NPPDXD N -4 Trinucleotidedisease (Huntingtondisease, SCA other) 
#'   \item NPPDXE N -4 Malformation of cortical development 
#'   \item NPPDXF N -4 Metabolic/storage disorder of any type 
#'   \item NPPDXG N -4 WM disease, leukodystrophy 
#'   \item NPPDXH N -4 WM disease, multiple sclerosis or other demyelinating disease 
#'   \item NPPDXI N -4 Contusion/traumatic brain injury of any type, acute 
#'   \item NPPDXJ N -4 Contusion/traumatic brain injury of any type, chronic 
#'   \item NPPDXK N -4 Neoplasm, primary 
#'   \item NPPDXL N -4 Neoplasm, metastatic 
#'   \item NPPDXM N -4 Infectious process of any type (encephalitis, abscess, etc.) 
#'   \item NPPDXN N -4 Herniation, any site 
#'   \item NPPDXP N -4 AD-related genes 
#'   \item NPPDXQ N -4 FTLD-related genes 
#'   \item NPBNKB N -4 Banked frozen wedge of cerebellum or other sample for future DNA prep 
#'   \item NPBNKF N -4 Banked postmortem blood or serum 
#'   \item NPFAUT N -4 Full autopsy performed 
#'   \item NPFAUT1 C -4 If full autopsy, first major finding 
#'   \item NPFAUT2 C -4 If full autopsy, second major finding 
#'   \item NPFAUT3 C -4 If full autopsy, third major finding 
#'   \item NPFAUT4 C -4 If full autopsy, fourth major finding 
#'   \item NPSEX N -4 Subject's sex 
#'   \item ADCID N -4 center id
#'   \item NPFORMVER N -4 NP form version
#'   \item NACCMOD N -4 Month of death
#'   \item NACCYOD N -4 year of death
#'   \item NACCNBRN N -4 Normal brain/No major pathology
#'   \item NACCAVAS N -4 Severity of gross findings-atherosclerosis of the circle of Willis
#'   \item NACCBRAA N -4 Braak stage for neurofibrillary degeneration (B score)
#'   \item NACCNEUR N -4 Density of neocortical neuritic plaques (CERAD score) (C score) 
#'   \item NACCDIFF N -4 Density of diffuse plaques (CERAD semiquantitative score)
#'   \item NACCAMY N -4 Cerebral amyloid angiopathy
#'   \item NACCINF N -4 Infarcts and lacunes
#'   \item NACCMICR N -4 Microinfarcts
#'   \item NACCHEM N -4 Hemorrhages and microbleeds
#'   \item NACCARTE N -4 Arteriolosclerosis
#'   \item NACCNEC N -4 Laminar necrosis
#'   \item NACCVASC N -4 Ischemic, hemorrhagic, or vascular pathology present
#'   \item NACCLEWY N -4 Lewy body pathology
#'   \item NACCPICK N -4 FTLD-tau subtype Pick's (PID) 
#'   \item NACCCBD N -4 FTLD-tau subtype corticobasal degeneration (CBD)
#'   \item NACCPROG N -4 FTLD-tau subtype progressive supranuclear palsy (PSP)
#'   \item NACCPRIO N -4 Prion disease
#'   \item NACCOTHP N -4 Other pathologic diagnosis
#'   \item NACCWRI1 N -4 First other pathologic diagnosis write-in
#'   \item NACCWRI2 N -4 Second other pathologic diagnosis write-in
#'   \item NACCWRI3 N -4 Third other pathologic diagnosis write-in
#'   \item NACCDOWN N -4 Down syndrome
#'   \item NACCBNKF N -4 Banked frozen brain
#'   \item NACCFORM N -4 Formalin or paraformaldehyde -fixed brain
#'   \item NACCPARA N -4 Paraffin-embedded blocks or brain regions
#'   \item NACCCSFP N -4 Banked postmortem CSF
#'   \item NPLINF N -4 Are one or more large artery cerebral infarcts present?
#'   \item NPMICRO N -4 Are one or more cortical microinfarcts (including "granular atrophy") present?
#'   \item NPLAC N -4 Are one or more lacunes (small artery infarcts and/or hemmorrhages) present?
#'   \item NPHEM N -4 Are single or multiple hemmorhages present?
#'   \item NPART N -4 Is subcortical arteriosclerotic leukoencephalopathy present?
#'   \item NPSCL N -4 Is medial temporal lobe sclerosis (including hippocampal sclerosis) present?
#'   \item NPOANG N -4 Is another type of angiopathy (e.g., CADASIL or arteritis) present?
#'   \item NPFRONT N -4 Frontotemporal dementia and Parkinsonism with tau-positive or argyrophiilic inclusions
#'   \item NPTAU N -4 Tauopathy, other (e.g., tangle-only dementia and argyrophilic grain dementia):
#'   \item NPFTD N -4 FTD with ubiquitin-positive (tau-negative) inclusions
#'   \item NPFTDNO N -4 Is ther FTD with no distinctive histopathology (tau-negative, ubiquitin-negative, and no agryrophilic inclusions)?
#'   \item NPFTDSPC N -4 Was FTD "not otherwise specified" present (e.g., "immunostaining for ubiquitin and tau not done")?
#'   \item NPPMIH N -4 Postmortem interval (PMI) (hours)
#'   \item NPINF1B N -4 Largest Infarct -- Cerebral cortex 
#'   \item NPINF1D N -4 Second-largest infarct -- Cerebral cortex 
#'   \item NPINF1F N -4 Third-largest Infarct -- Cerebral cortex 
#'   \item NPINF2B N -4 Largest infarct -- white matter 
#'   \item NPINF2D N -4 Second-largest infarct -- white matter 
#'   \item NPINF2F N -4 Third-largest infarct -- White matter 
#'   \item NPINF3B N -4 Largest infarct -- Deep cerebral gray matter or internal capsule 
#'   \item NPINF3D N -4 Second-largest infarct -- Deep cerebral gray matter or internal capsule 
#'   \item NPINF3F N -4 Third-largest infarct -- Deep cerebral gray matter or internal capsule 
#'   \item NPINF4B N -4 Largest infarct -- Brainstem or cerebellum 
#'   \item NPINF4D N -4 Second-largest infarct -- Brainstem or cerebellum 
#'   \item NPINF4F N -4 Third-largest infarct -- Brainstem or cerebellum
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name neuropath
#' @usage data(neuropath)
#' @format A data frame with 57 rows and 162 variables
NULL

#' Neuropathology Extension Consent
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#'   \item NPINFO N  Has participant been given information regarding autopsy/brain donation?
#'   \item NPAPPROVE N  Has the ADNI provisional autopsy consent form been signed?
#'   \item NPAPDT D  If "Yes", date signed.
#'   \item NPREASON T  If "No", please give reason
#'   \item NPOTHERAP N  Has provisional autopsy consent form been signed as part of a study other than ADNI?
#'   \item NPOTHERDT D  If "Yes", date signed.
#'   \item NPOTHERCOM T  If "Yes", please provide additional information regarding the "other" autopsy consent, including the name of the other study.
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name npconsent
#' @usage data(npconsent)
#' @format A data frame with 50 rows and 14 variables
NULL

#' Neuropsychiatric Inventory Q
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item SPID N NA Study Partner ID:
#'   \item SOURCE N NA Information Source
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item EXAMDATE D  Examination Date
#'   \item NPISOURCE N  Information Source
#'   \item NPIA N  Does {P} believe that others are stealing from him/her, or planning to harm him/her in some way?
#'   \item NPIASEV N  Severity Ratings <!--A. Delusions-->
#'   \item NPIB N  Does {P} act as if he/she hears voices? Does he/she talk to people who are not there?
#'   \item NPIBSEV N  Severity Ratings <!--B. Hallucinations-->
#'   \item NPIC N  Is {P} stubborn and resistive to help from others?
#'   \item NPICSEV N  Severity Ratings <!--C. Agitation/Aggression-->
#'   \item NPID N  Does {P} act as if he/she is sad or in low spirits? Does he/she cry?
#'   \item NPIDSEV N  Severity Ratings <!--D. Depression/Dysphoria-->
#'   \item NPIE N  Does {P} become upset when separated from you? Does he/she have any other signs of nervousness, such as shortness of breath, sighing, being unable to relax, or feeling excessively tense?
#'   \item NPIESEV N  Severity Ratings <!--E. Anxiety-->
#'   \item NPIF N  Does {P} appear to feel too good or act excessively happy?
#'   \item NPIFSEV N  Severity Ratings <!--F. Elation/Euphoria-->
#'   \item NPIG N  Does {P} seem less interested in his/her usual activities and in the activities and plans of others?
#'   \item NPIGSEV N  Severity Ratings <!--G. Apathy/Indifference-->
#'   \item NPIH N  Does {P} seem to act impulsively? For example, does {P} talk to strangers as if he/she knows them, or does {P} say things that may hurt people's feelings?
#'   \item NPIHSEV N  Severity Ratings <!--H. Disinhibition-->
#'   \item NPII N  Is {P} impatient or cranky? Does he/she have difficulty coping with delays or waiting for planned activities?
#'   \item NPIISEV N  Severity Ratings <!--I. Irritability/Lability-->
#'   \item NPIJ N  Does {P} engage in repetitive activities, such as pacing around the house, handling buttons, wrapping strings, or doing other things repeatedly?
#'   \item NPIJSEV N  Severity Ratings <!--J. Aberrant Motor Behavior-->
#'   \item NPIK N  Does {P} awaken you during the night, rise too early in the morning, or take excessive naps during the day?
#'   \item NPIKSEV N  Severity Ratings <!--K. Sleep-->
#'   \item NPIL N  Has {P} lost or gained weight, or had a change in the food he/she likes?
#'   \item NPILSEV N  Severity Ratings <!--L. Appetite-->
#'   \item NPISCORE N  Total Score
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name npiq
#' @usage data(npiq)
#' @format A data frame with 6448 rows and 36 variables
NULL

#' Neuropsychiatric Inventory Examination
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item SPID N NA Study Partner ID:
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#'   \item EXAMDATE T  Examination Date
#'   \item NPISOURC N  Information source
#'   \item NPIA N  A. Delusions
#'   \item NPIA1 N  1. Does {P} believe that he/she is in danger - that others are planning to hurt him/her?
#'   \item NPIA2 N  2. Does {P} believe that others are stealing from him/her?
#'   \item NPIA3 N  3. Does {P} believe that his/her spouse is having an affair?
#'   \item NPIA4 N  4. Does {P} believe that unwelcome guests are living in his/her house?
#'   \item NPIA5 N  5. Does {P} believe that his/her spouse or others are not who they claim to be?
#'   \item NPIA6 N  6. Does {P} believe that his/her house is not his/her home?
#'   \item NPIA7 N  7. Does {P} believe that family members plan to abandon him/her?
#'   \item NPIA8 N  8. Does {P} believe that television or magazine figures are actually present in the home?  [Does he/she try to talk to or interact with them?]
#'   \item NPIA9 N  9. Does {P} believe any other unusual things that I haven't asked about?
#'   \item NPIA10A N  10a. Frequency Ratings
#'   \item NPIA10B N  10b. Severity Ratings
#'   \item NPIA10C N  10c. Caregiver Distress
#'   \item NPIATOT N  A. Delusions: Item score
#'   \item NPIB N  B.  Hallucinations
#'   \item NPIB1 N  1. Does {P} describe hearing voices or act as if he/she hears voices?
#'   \item NPIB2 N  2. Does {P} talk to people who are not there?
#'   \item NPIB3 N  3. Does {P} describe seeing things not seen by others or behave as if he/she is seeing things not seen by others (people, animals, lights, etc.)?
#'   \item NPIB4 N  4. Does {P} report smelling odors not smelled by others?
#'   \item NPIB5 N  5. Does {P} describe feeling things on his/her skin or otherwise appear to be feeling things crawling or touching him/her?
#'   \item NPIB6 N  6. Does {P} describe tastes that are without any known cause?
#'   \item NPIB7 N  7. Does {P} describe any other unusual sensory experiences?
#'   \item NPIB8A N  8a.  Frequency Ratings
#'   \item NPIB8B N  8b. Severity Ratings
#'   \item NPIB8C N  8c. Caregiver Distress
#'   \item NPIBTOT N  B. Hallucinations: Item score
#'   \item NPIC N  C: Agitation/Aggression
#'   \item NPIC1 N  1. Does {P} get upset with those trying to care for him/her or resist activities such as bathing or changing clothes?
#'   \item NPIC2 N  2. Is {P} stubborn, having to have things his/her way?
#'   \item NPIC3 N  3. Is {P} uncooperative, resistive to help from others?
#'   \item NPIC4 N  4. Does {P} have any other behaviors that make him/her hard to handle?
#'   \item NPIC5 N  5. Does {P} shout or curse angrily?
#'   \item NPIC6 N  6. Does {P} slam doors, kick furniture, throw things?
#'   \item NPIC7 N  7. Does {P} attempt to hurt or hit others?
#'   \item NPIC8 N  8. Does {P} have any other aggressive or agitated behaviors?
#'   \item NPIC9A N  9a. Frequency Ratings
#'   \item NPIC9B N  9b. Severity Ratings
#'   \item NPIC9C N  9c. Caregiver Distress
#'   \item NPICTOT N  C. Agitation/Aggression: Item score
#'   \item NPID N  D: Depression/Dysphoria
#'   \item NPID1 N  1. Does {P} have periods of tearfulness or sobbing that seem to indicate sadness?
#'   \item NPID2 N  2. Does {P} say or act as if he/she is sad or low in spirits?
#'   \item NPID3 N  3. Does {P} put him/herself down or say that he/she feels like a failure?
#'   \item NPID4 N  4. Does {P} say that he/she is a bad person or deserves to be punished?
#'   \item NPID5 N  5. Does {P} seem very discouraged or say that he/ she has not future?
#'   \item NPID6 N  6. Does {P} say he/she is a burden to the family or that the family would be better off without him/her?
#'   \item NPID7 N  7. Does {P} express a wish for death or talk about killing him/herself?
#'   \item NPID8 N  8. Does {P} show any other signs of depression or sadness?
#'   \item NPID9A N  9a. Frequency Ratings
#'   \item NPID9B N  9b. Severity Ratings
#'   \item NPID9C N  9c. Caregiver Distress
#'   \item NPIDTOT N  D. Depression/Dysphoria: Item score
#'   \item NPIE N  E. Anxiety
#'   \item NPIE1 N  1. Does {P} say that he/she is worried about planned events?
#'   \item NPIE2 N  2. Does {P} have periods of feeling shaky, unable to relax, or feeling excessively tense?
#'   \item NPIE3 N  3. Does {P} have periods of [or complain of] shortness of breath, gasping, or sighing for no apparent reason other than nervousness?
#'   \item NPIE4 N  4. Does {P} complain of butterflies in his/her stomach, or of racing or pounding of the heart in association with nervousness? [Symptoms not explained by ill health]?
#'   \item NPIE5 N  5. Does {P} avoid certain places or situations that make him.her more nervous such as riding in the car, meeting with friends, or being in crowds?
#'   \item NPIE6 N  6. Does {P} become nervous or upset when separated from you [or his/her caregiver]? [Does he/she cling to you to keep from being separated?]
#'   \item NPIE7 N  7. Does {P} show any other signs of anxiety?
#'   \item NPIE8A N  8a. Frequency Ratings
#'   \item NPIE8B N  8b. Severity Ratings
#'   \item NPIE8C N  8c. Caregiver Distress
#'   \item NPIETOT N  E. Anxiety: Item score
#'   \item NPIF N  F. Elation/Euphoria
#'   \item NPIF1 N  1. Does {P} appear to feel too good or too happy, different from his/her usual self?
#'   \item NPIF2 N  2. Does {P} find humor and laugh at things that others do not find funny?
#'   \item NPIF3 N  3. Does {P} seem to have a childish sense of humor with a tendency to giggle or laugh inappropriately (such as when something unfortunate happens to others)?
#'   \item NPIF4 N  4. Does {P} tell jokes or make remarks that have little humor for others but seem funny to him/her?
#'   \item NPIF5 N  5. Does he/she play childish pranks such as pinching or playing "keep away" for the fun of it?
#'   \item NPIF6 N  6. Does {P} "talk big" or claim to have more abilities or wealth than is true?
#'   \item NPIF7 N  7. Does {P} show any other signs of feeling too good or being too happy?
#'   \item NPIF8A N  8a. Frequency Ratings
#'   \item NPIF8B N  8b. Severity Ratings
#'   \item NPIF8C N  8c. Caregiver Distress
#'   \item NPIFTOT N  F. Elation/Euphoria: Item score
#'   \item NPIG N  G. Apathy/Indifference
#'   \item NPIG1 N  1. Does {P} seem less spontaneous and less active than usual?
#'   \item NPIG2 N  2. Is {P} less likely to initiate a conversation?
#'   \item NPIG3 N  3. Is {P} less affectionate or lacking in emotions when compared to his/her usual self?
#'   \item NPIG4 N  4. Does {P} contribute less to household chores?
#'   \item NPIG5 N  5. Does {P} seem less interested in the activities and plans of others?
#'   \item NPIG6 N  6. Has {P} lost interest in friends and family members?
#'   \item NPIG7 N  7. Is {P} less enthusiastic about his/her usual interests?
#'   \item NPIG8 N  8. Does {P} show any other signs that he/she doesn't care about doing new things?
#'   \item NPIG9A N  9a. Frequency Ratings
#'   \item NPIG9B N  9b. Severity Ratings
#'   \item NPIG9C N  9c. Caregiver Distress
#'   \item NPIGTOT N  G. Apathy/Indifference: Item score
#'   \item NPIH N  H. Disinhibition
#'   \item NPIH1 N  1. Does {P} act impulsively without appearing to consider the consequences?
#'   \item NPIH2 N  2. Does {P} talk to total strangers as if he/she knew them?
#'   \item NPIH3 N  3. Does {P} say things to people that are insensitive or hurt their feelings?
#'   \item NPIH4 N  4. Does {P} say crude things or make sexual remarks that they would not usually have said?
#'   \item NPIH5 N  5. Does {P} talk openly about very personal or private matters not usually discussed in public?
#'   \item NPIH6 N  6. Does {P} take liberties or touch or hug others in a way that is out of character for him/her?
#'   \item NPIH7 N  7. Does {P} show any other signs of loss of control of his/her impulses?
#'   \item NPIH8A N  8a. Frequency Ratings
#'   \item NPIH8B N  8b. Severity Ratings
#'   \item NPIH8C N  8c. Caregiver Distress
#'   \item NPIHTOT N  H. Disinhibition: Item score
#'   \item NPII N  I. Irritability/Lability
#'   \item NPII1 N  1. Does {P} have a bad temper, flying "off the handle" easily over little things?
#'   \item NPII2 N  2. Does {P} rapidly change moods from one to another, being fine one minute and angry the next?
#'   \item NPII3 N  3. Does {P} have sudden flashes of anger?
#'   \item NPII4 N  4. Is {P} impatient, having trouble coping with delays or waiting for planned activities?
#'   \item NPII5 N  5. Is {P} cranky and irritable?
#'   \item NPII6 N  6. Is {P} argumentative and difficult to get along with?
#'   \item NPII7 N  7. Does {P} show any other signs of irritability?
#'   \item NPII8A N  8a. Frequency Ratings
#'   \item NPII8B N  8b. Severity Ratings
#'   \item NPII8C N  8c. Caregiver Distress
#'   \item NPIITOT N  I. Irritability/Lability: Item score
#'   \item NPIJ N  J. Aberrant Motor Behavior
#'   \item NPIJ1 N  1. Does {P} pace around the house without apparent purpose?
#'   \item NPIJ2 N  2. Does {P} rummage around opening and unpacking drawers or closets?
#'   \item NPIJ3 N  3. Does {P} repeatedly put on and take off clothing?
#'   \item NPIJ4 N  4. Does {P} have repetitive activities or "habits" that he/she performs over and over?
#'   \item NPIJ5 N  5. Does {P} engage in repetitive activities such as handling buttons, picking, wrapping string, etc?
#'   \item NPIJ6 N  6. Has {P} fidget excessively, seem unable to sit still, or bounce his/her feet or tap his/her fingers a lot?
#'   \item NPIJ7 N  7. Does {P} do any other activities over and over?
#'   \item NPIJ8A N  8a. Frequency Ratings
#'   \item NPIJ8B N  8b. Severity Ratings
#'   \item NPIJ8C N  8c. Caregiver Distress
#'   \item NPIJTOT N  J. Aberrant Motor Behavior: Item score
#'   \item NPIK N  K. Sleep
#'   \item NPIK1 N  1. Does {P} have difficulty falling asleep?
#'   \item NPIK2 N  2. Does {P} get up during the night (do not count if the patient gets up once or twice per night only to go to the bathroom and falls back asleep immediately)?
#'   \item NPIK3 N  3. Does {P} wander, pace, or get involved in inappropriate activities at night?
#'   \item NPIK4 N  4. Does {P} awaken you during the night?
#'   \item NPIK5 N  5. Does {P} awaken at night, dress, and plan to go out thinking that it is morning and time to start the day?
#'   \item NPIK6 N  6. Does {P} awaken too early in the morning (earlier than was his/her habit)?
#'   \item NPIK7 N  7. Does {P} sleep excessively during the day?
#'   \item NPIK8 N  8. Does {P} have any other night-time behaviors that bother you that we haven't talked about?
#'   \item NPIK9A N  9a. Frequency Ratings
#'   \item NPIK9B N  9b. Severity Ratings
#'   \item NPIK9C N  9c. Caregiver Distress
#'   \item NPIKTOT N  K. Sleep: Item score
#'   \item NPIL N  L. Appetite and eating disorders:
#'   \item NPIL1 N  1. Has he/she had a loss of appetite?
#'   \item NPIL2 N  2. Has he/she had an increase in appetite?
#'   \item NPIL3 N  3. Has he/she had a loss of weight?
#'   \item NPIL4 N  4. Has he/she gained weight?
#'   \item NPIL5 N  5. Has he/she had a change in eating behavior such as putting too much food in his/her mouth at once?
#'   \item NPIL6 N  6. Has he/she had a change in the kind of food he/she likes such as eating too many sweets or other specific types of food?
#'   \item NPIL7 N  7. Has he/she developed eating behaviors such as eating exactly the same types of food each day or eating the food in exactly the same order?
#'   \item NPIL8 N  8. Have there been any other changes in appetite or eating that I haven't asked about?
#'   \item NPIL9A N  9a. Frequency Ratings
#'   \item NPIL9B N  9b. Severity Ratings
#'   \item NPIL9C N  9c. Caregiver Distress
#'   \item NPILTOT N  L. Appetite and eating disorders: Item score
#'   \item NPITOTAL N  NPI Total Score
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name npi
#' @usage data(npi)
#' @format A data frame with 4431 rows and 162 variables
NULL

#' Neuropathology Status
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item NPCONS N NA Was Neuropath consent discussed at this visit?
#'   \item NPCONSNO N NA If no, why not:
#'   \item NPCONSNOTH T NA If other reason(s), specify:
#'   \item NPDECNOOTH T NA If other, specify:
#'   \item NPUNDECOTH T NA If no decision has been made, specify follow up plan
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#'   \item NPDECIDE N  Has a definitive decision about brain donation been made?
#'   \item NPUNDEC N  If no decision has been made, has participant been given information (brochure, discussion with clinician) regarding autopsy/brain donation?
#'   \item NPDEC N  If a decision has been made, is there agreement to participate in brain donation?
#'   \item NPDECNO T  If No, provide reason for nonparticipation:
#'   \item NPDECOTH T  If other, specify:
#'   \item NPDECCF N  If there is agreement to participate, is the provisional autopsy consent part of a study other than ADNI?
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name npstatus
#' @usage data(npstatus)
#' @format A data frame with 5598 rows and 20 variables
NULL

#' NYU FDG-PET Hippocampus (pons normalized)
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/NYUFDGHIP/NYUFDGHip.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item PHASE -4 NA ADNI phase
#'   \item SITEID -4 NA Site ID
#'   \item PTID -4 NA Participant ID
#'   \item RID -4 NA Participant roster ID
#'   \item EXAMDATE -4 NA Examination Date
#'   \item VISCODE -4 NA Visit code
#'   \item LONIUID -4 NA LONI Image ID
#'   \item STUDYID -4 NA LONI PET study ID
#'   \item SERIESID -4 NA LONI PET series ID
#'   \item SCANDATE -4 NA PET scan date
#'   \item RUNDATE -4 NA Run date of analysis result
#'   \item STATUS -4 NA Result status
#'   \item VERSION -4 NA Version of results
#'   \item HIPRPONS -4 NA Right Hip / Pons normalized
#'   \item HIPLPONS -4 NA Left Hip / Pons normalized
#' }
#'
#' @examples
#' \donotrun{
#' describe(nyufdghip)
#' }
#' @docType data
#' @keywords datasets
#' @name nyufdghip
#' @usage data(nyufdghip)
#' @format A data frame with 612 rows and 16 variables
NULL

#' Addenda Consent Tracking
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#'   \item RECNO N  
#'   \item ADDENDUM N  Indicate addendum:
#'   \item INCDATE D MM/DD/YYYY Date consent(s) signed/updated:
#'   \item INCVERSION N  ADCS template version signed:
#'   \item OTIRB D MM/DD/YYYY Consent IRB approval date:
#'   \item OTEXPDT D MM/DD/YYYY Consent IRB expiration date:
#'   \item OTVRS T  Site version of consent:
#'   \item ADDCOMM T  Comments:
#' }
#'
#' @examples
#' \donotrun{
#' describe(otconsent)
#' }
#' @docType data
#' @keywords datasets
#' @name otconsent
#' @usage data(otconsent)
#' @format A data frame with 229 rows and 15 variables
NULL

#' Other Discontinuations and Withdrawals
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item OTCOMP N NA Study Component
#'   \item OTSPEC T NA If other, specify
#'   \item OTDATE D YYYY-MM-DD Date of Discontinuation/Withdrawn Consent
#'   \item OTREASON T NA Reason(s) for Discontinuation/Withdrawn Consent
#'   \item OTOTHER T NA If other, specify
#'   \item OTAE T NA If Adverse Event, provide Adverse Event number(s)
#'   \item OTCOMM T NA Please detail the circumstances surrounding the discontinuation/withdrawn consent
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' \donotrun{
#' describe(otdisc)
#' }
#' @docType data
#' @keywords datasets
#' @name otdisc
#' @usage data(otdisc)
#' @format A data frame with 39 rows and 14 variables
NULL

#' Tau AV-1451 PET Eligibility
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#'   \item RECNO N  
#'   \item TAUELG N  Please confirm if participant meets eligibility criteria:
#'   \item EXCLUSION N  If participant should be excluded, select reason:
#'   \item NVROT N  
#'   \item NVRSPECIFY T  If Other, specify:
#'   \item EXC1 N  If Exclusion Criteria, which criteria does the participant meet:
#'   \item EXC2 N  
#'   \item EXC3 N  
#'   \item EXC4 N  
#'   \item EXC5 N  
#'   \item EXC6 N  
#'   \item EXC7 N  
#'   \item TAUCOMM T  Comments:
#' }
#'
#' @examples
#' \donotrun{
#' describe(otelgtau)
#' }
#' @docType data
#' @keywords datasets
#' @name otelgtau
#' @usage data(otelgtau)
#' @format A data frame with 139 rows and 20 variables
NULL

#' PET Scan Information
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item DONE N NA Was the scan conducted?
#'   \item NDREASON N NA If No, reason not done:
#'   \item NDSPECIFY T NA If Other, specify:
#'   \item SCANDATE D YYYY-MM-DD Scan Date/Dose Date
#'   \item QCTIME T HHMM Time of today's Scanner QC
#'   \item ASSAYTIME T HHMM Time of FDG dose assay
#'   \item FDGDOS N mCi Injected FDG dose assay
#'   \item INJTIME T HHMM Time of FDG injection
#'   \item SCANTIME T HHMM Emission Scan Start Time
#'   \item SCANDIFF T NA Provide an explanation if start time is not between 30-32 mins post-injection.
#'   \item VARIAT N NA Any variations from protocol during FDG uptake?
#'   \item VARIATSPEC T NA If Yes, describe
#'   \item PROTID T NA Predefined Acquisition Protocol Name
#'   \item MOTION N NA Participant motion problems
#'   \item OTHERVAR N NA Other protocol variations
#'   \item RECON N NA Select reconstruction used
#'   \item SHARP N NA For Phillips scanners:  was "smooth" parameter set to "sharp"?
#'   \item ARCHIVE N NA Data archived locally?
#'   \item LONI N NA Data transferred to LONI?
#'   \item TRANDATE D YYYY-MM-DD Transfer Date
#'   \item COMM T NA Comments
#'   \item RADTRACER N  If no, was radiotracer administered?
#'   \item PMSHARP T NA Was "Smooth" parameter set to "Sharp"?
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item RECNO N  
#'   \item PMCONDCT N  Was the scan conducted?
#'   \item PMREASON N  Reason why the scan was not conducted:
#'   \item PMOTHSPE T  If Other, specify:
#'   \item PMCONSENT N  Did the participant consent to quantitative scan?
#'   \item PMTYPE N  Type of scan conducted
#'   \item EXAMDATE D  Examination Date
#'   \item PMSCANNER T  GE
#'   \item PMGEMODEL N  If GE, Scanner Model:
#'   \item PMSIEMENS T  Siemens/CTI
#'   \item PMSIEMODEL N  If Siemens/CTI, Scanner Model:
#'   \item PMPHILLIPS T  Phillips
#'   \item PMPHMODEL N  If Phillips, Scanner Model:
#'   \item PMQCTIME T  Time of today's Scanner QC
#'   \item PMBLTIME T  Time of blood glucose measurement
#'   \item PMBLGLUC N  Blood Glucose (pre-FDG)
#'   \item PMFDGTIME T  Time of FDG dose assay
#'   \item PMFDGDOS N  FDG dose assay
#'   \item PMFDGVOL N  FDG Volume
#'   \item PMINJTIME T  Time of FDG injection
#'   \item PMGLUCOM T  Provide an explanation if blood glucose was measured after the FDG injection
#'   \item PMSCTIME T  Time scan started (emission)
#'   \item PMSCANCOM T  Provide an explanation if start time is not within the allowable window
#'   \item PMVARIAT N  Any variations from protocol during FDG uptake?
#'   \item PMVARSP T  If Yes, describe:
#'   \item PMPROTID T  Predefined acquisition protocol ID
#'   \item PMFRAME N  Which framing rate was used?
#'   \item PMDEVIAT T  If any deviations, describe:
#'   \item PMMOTION N  Subject motion problems:
#'   \item PMMOTSP T  If yes, describe:
#'   \item PMMALFUN N  Scanner malfunction
#'   \item PMMALSP T  If yes, describe:
#'   \item PMOTHER N  Other protocol variations:
#'   \item PMOTHSP T  If yes, describe:
#'   \item PMRECON N  Check which of the following reconstructions was used:
#'   \item PMSUBSET N  # subsets:
#'   \item PMSUBSPE N  If Other, specify
#'   \item PMITERAT N  # iterations:
#'   \item PMITERSPE N  If Other, specify:
#'   \item PMRAMLA T  If Ramla, Lambda=0.016?
#'   \item PMFILTER T  If Back Projection, Ramp filter?
#'   \item PMMODEON T  If FORE/2D-OSEM, Brain Mode "ON" for PET only scanners or TRIM "ON" for PET/CT scanners?
#'   \item PMSMOOTH T  No post-process smoothing:
#'   \item PMDECAY N  Decay Correction
#'   \item PMSCATTR N  Scatter Correction:
#'   \item PMATTEN N  Attenuation Correction:
#'   \item PMWITHDRAW N  Clock for blood sample withdrawal time
#'   \item PMWITHTIME T  If No, provide the time difference
#'   \item PMCOUNT N  Clock for blood sample count time
#'   \item PMCOUNTIME T  If No, provide the time difference
#'   \item PMBG1TIME T  Sample Count Time (24h) <!--Background #1-->
#'   \item PMBG1VOL N  Sample Plasma Volume Counted <!--Background #1-->
#'   \item PMBG1DUR N  Sample Count Duration <!--Background #1-->
#'   \item PMBG1COUNT N  Sample Count Rate <!--Background #1-->
#'   \item PMP1DTIME T  Sample Draw Time (24h) <!--Plasma 1-->
#'   \item PMP1CTIME T  Sample Count Time (24h) <!--Plasma 1-->
#'   \item PMP1BGL N  Sample BGL <!--Plasma 1-->
#'   \item PMP1VOL N  Sample Plasma Volume Counted <!--Plasma 1-->
#'   \item PMP1DUR N  Sample Count Duration <!--Plasma 1-->
#'   \item PMP1COUNT N  Sample Count Rate <!--Plasma 1-->
#'   \item PMP2DTIME T  Sample Draw Time (24h) <!--Plasma 2-->
#'   \item PMP2CTIME T  Sample Count Time (24h) <!--Plasma 2-->
#'   \item PMP2BGL N  Sample BGL <!--Plasma 2-->
#'   \item PMP2VOL N  Sample Plasma Volume Counted <!--Plasma 2-->
#'   \item PMP2DUR N  Sample Count Duration <!--Plasma 2-->
#'   \item PMP2COUNT N  Sample Count Rate <!--Plasma 2-->
#'   \item PMP3DTIME T  Sample Draw Time (24h) <!--Plasma 3-->
#'   \item PMP3CTIME T  Sample Count Time (24h) <!--Plasma 3-->
#'   \item PMP3BGL N  Sample BGL <!--Plasma 3-->
#'   \item PMP3VOL N  Sample Plasma Volume Counted <!--Plasma 3-->
#'   \item PMP3DUR N  Sample Count Duration <!--Plasma 3-->
#'   \item PMP3COUNT N  Sample Count Rate <!--Plasma 3-->
#'   \item PMP4DTIME T  Sample Draw Time (24h) <!--Plasma 4-->
#'   \item PMP4CTIME T  Sample Count Time (24h) <!--Plasma 4-->
#'   \item PMP4BGL N  Sample BGL <!--Plasma 4-->
#'   \item PMP4VOL N  Sample Plasma Volume Counted <!--Plasma 4-->
#'   \item PMP4DUR N  Sample Count Duration <!--Plasma 4-->
#'   \item PMP4COUNT N  Sample Count Rate <!--Plasma 4-->
#'   \item PMP5DTIME T  Sample Draw Time (24h) <!--Plasma 5-->
#'   \item PMP5CTIME T  Sample Count Time (24h) <!--Plasma 5-->
#'   \item PMP5BGL N  Sample BGL <!--Plasma 5-->
#'   \item PMP5VOL N  Sample Plasma Volume Counted <!--Plasma 5-->
#'   \item PMP5DUR N  Sample Count Duration <!--Plasma 5-->
#'   \item PMP5COUNT N  Sample Count Rate <!--Plasma 5-->
#'   \item PMBG2CTIME T  Sample Count Time (24h) <!--Background 2-->
#'   \item PMBG2VOL N  Sample Plasma Volume Counted <!--Background 2-->
#'   \item PMBG2DUR N  Sample Count Duration <!--Background 2-->
#'   \item PMBG2COUNT N  Sample Count Rate <!--Background 2-->
#'   \item PMPIPVOL N  Was the pipetted plasma volume 200 uL?
#'   \item PMPIPVOLSP T  If No, denote volume used:
#'   \item PMCTIME N  Was the plasma sample count time 1 minute?
#'   \item PMCTIMESP T  If No, denote count time used
#'   \item PMPHACT N  Phantom Activity at Time of Scan
#'   \item PMPHVOL N  Phantom Volume
#'   \item PMPHCOUNT N  Average Counts from Phantom Image ROI
#'   \item PMALIQVOL N  Aliquot Volume
#'   \item PMALIQACT N  Aliquot Count Rate
#'   \item PMBLOOD I  Blood Sample Data - Upload File
#'   \item PMBLOOD2 I  Blood Sample Data - Upload File
#'   \item PMTRNSFR N  Was data transferred to LONI within 24 hours of scan?
#'   \item PMTRNDATE D  Transfer Date
#'   \item PMTRNCOM T  Comments
#'   \item PMARCHIVE N  Data Archived Locally
#'   \item PMARCMED T  Archive Medium
#'   \item PMARCCOM T  Comments
#'   \item PMLPDONE N  Was a Lumbar Puncture completed prior to the PET scan?
#'   \item PMLPINTER N  If Yes, What was the interval between LP and PET?
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name petmeta
#' @usage data(petmeta)
#' @format A data frame with 5527 rows and 137 variables
NULL

#' PET QC Tracking
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item SCANDATE D YYYY-MM-DD Scan Date
#'   \item LONIUPDT D YYYY-MM-DD Date uploaded to LONI
#'   \item REVDT D YYYY-MM-DD Date Reviewed
#'   \item ALLFRAME N NA Were all frames acceptable?
#'   \item UNUSABL T NA If No, indicate which frames were unacceptable
#'   \item UNRSN N NA If No, indicate why frames were unacceptable
#'   \item UNRSNSPEC T NA If Other, Specify
#'   \item SCANQLTY N NA Scan Pass QC?
#'   \item REPROCREQ N NA Reprocessing requested?
#'   \item PROCERR T NA If Yes, select processing error(s)
#'   \item PROCERRSPEC T NA If Other, Specify
#'   \item RESCANREQ N NA Rescan requested?
#'   \item COMM T NA Comments
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item RECNO N  
#'   \item SCAN N  Scan
#'   \item EXAMDATE D  Examination Date
#'   \item PQFILENO N  Upload Number
#'   \item PQDATTRA D  Date images uploaded to LONI
#'   \item LONIUID T  LONI Unique Series ID
#'   \item PQDATE D  Date reviewed
#'   \item PQACQFR N  Acquisition
#'   \item PQCORALG N  Correct Reconstruction Algorithm?
#'   \item PQRECON N  Check which of the following reconstruction algorithms was used
#'   \item PQCORNUM N  If OSEM or Ramla, correct # iterations and subsets?
#'   \item PQCORFIL N  Correct Filters/TRIM?
#'   \item PQCORTHI N  Correct Slice Thickness (PET/CT systems)?
#'   \item PQVOXEL N  Acceptable Voxel Size?
#'   \item PQALLFRAME N  Were all frames acceptable?
#'   \item PQUNUSABLE T  Indicate which frames were unacceptable:
#'   \item PQREASON T  Indicate why frames were unacceptable:
#'   \item PQREASSP T  If Other, Specify:
#'   \item PASS N  Pass QC?
#'   \item PQPROERR T  A. Processing Error(s)
#'   \item PQERRSP T  Specify
#'   \item PQACTION N  B. QC outcome
#'   \item PQNONESP T  Reason for not rescanning
#'   \item PQISSUES T  Imaging issues
#'   \item PQISSOTH T  Other, specify
#'   \item COMMENTS T  Additional QC Comments
#'   \item QUARANTINE N  Release from quarantine?
#'   \item PAYSITE N  Pay Site?
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name petqc
#' @usage data(petqc)
#' @format A data frame with 4073 rows and 48 variables
NULL

#' Physical Exam
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item PXBACK N NA 12. Back
#'   \item PXBACKDES T NA Details <!--Back-->
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item EXAMDATE D  Examination Date
#'   \item PXGENAPP N  1. General Appearance
#'   \item PXGENDES T  Details <!--General Appearance-->
#'   \item PXHEADEY N  2. Head, Eyes, Ears, Nose and Throat
#'   \item PXHEADDE T  Details <!--Head, Eyes, Ears, Nose and Throat-->
#'   \item PXNECK N  3. Neck
#'   \item PXNECDES T  Details <!--Neck-->
#'   \item PXCHEST N  4. Chest
#'   \item PXCHEDES T  Details <!--Chest-->
#'   \item PXHEART N  5. Heart
#'   \item PXHEADES T  Details <!--Heart-->
#'   \item PXABDOM N  6. Abdomen
#'   \item PXABDDES T  Details <!--Abdomen-->
#'   \item PXEXTREM N  7. Extremities
#'   \item PXEXTDES T  Details <!--Extremities-->
#'   \item PXEDEMA N  8. Edema
#'   \item PXEDEDES T  Details <!--Edema-->
#'   \item PXPERIPH N  9. Peripheral Vascular
#'   \item PXPERDES T  Details <!--Peripheral Vascular-->
#'   \item PXSKIN N  10. Skin and Appendages
#'   \item PXSKIDES T  Details <!--Skin and Appendages-->
#'   \item PXMUSCUL N  11. Musculoskeletal
#'   \item PXMUSDES T  Details <!--Musculoskeletal-->
#'   \item PXOTHER N  12. Other
#'   \item PXOTRCOM T  Details <!--Other-->
#'   \item PXGENCOM T  13. General Comments
#'   \item PXABNORM N  14. Based on the Physical Examination, clinician must check appropriate box below:
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name physical
#' @usage data(physical)
#' @format A data frame with 2885 rows and 36 variables
NULL

#' PIB Approval
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item USERDATE S  Date record created
#'   \item RID N  Participant roster ID
#'   \item PIBAPPROVE N  Is the participant approved to participate in PIB sub-study?
#'   \item PIBAPDT D  If Yes, date approved
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name pibapprove
#' @usage data(pibapprove)
#' @format A data frame with 110 rows and 7 variables
NULL

#' PIB Consent
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item EXAMDATE D  Examination Date
#'   \item PIBSIGN N  Have the participant and study partner signed the PIB Informed Consent form?
#'   \item PIBSGDT D  If Yes, date signed
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name pibconsent
#' @usage data(pibconsent)
#' @format A data frame with 126 rows and 10 variables
NULL

#' PIB Scan Information
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item PBCONDCT N  Was the scan conducted?
#'   \item PBREASON N  Reason why the scan was not conducted:
#'   \item PBOTHSPE T  If Other, specify:
#'   \item EXAMDATE D  Examination Date
#'   \item PBGE T  GE
#'   \item PBGEMODEL N  If GE, Scanner Model:
#'   \item PBSIEMENS T  Siemens/CTI
#'   \item PBSIEMODEL N  If Siemens/CTI, Scanner Model:
#'   \item PBPHILLIPS T  Phillips
#'   \item PBPHMODEL N  If Phillips, Scanner Model:
#'   \item PBQCTIME T  Time of today's Scanner QC
#'   \item PBPIBTIME T  Time of PIB dose assay
#'   \item PBPIBDOS N  PIB dose assay
#'   \item PBRESTIME T  Time of residual PIB assay
#'   \item PBRESID T  Residual left in syringe
#'   \item PBINJDOS N  Net injected dose of PIB
#'   \item PBPIBVOL N  PIB volume
#'   \item PBINJTIME T  Time of PIB injection
#'   \item PBSCTIME T  Time scan started (emission)
#'   \item PBSCANCOM T  Provide an explanation if start time is not within the allowable window
#'   \item PBVARIAT N  Any variations from protocol during PIB uptake?
#'   \item PBVARSP T  If Yes, describe:
#'   \item PBPROTID T  Predefined acquisition protocol ID
#'   \item PBSTATDYN N  Indicate whether scan was static or dynamic:
#'   \item PBNMFRAM1 N  1. No. of Frames
#'   \item PBDURATN1 N  Duration:
#'   \item PBNMFRAM2 N  2. No. of Frames:
#'   \item PBDURATN2 N  Duration:
#'   \item PBNMFRAM3 N  3. No. of Frames:
#'   \item PBDURATN3 N  Duration:
#'   \item PBNMFRAM4 N  4. No. of Frames:
#'   \item PBDURATN4 N  Duration:
#'   \item PBNMFRAM5 N  5. No. of Frames:
#'   \item PBDURATN5 N  Duration:
#'   \item PBNMFRAM6 N  6. No. of Frames:
#'   \item PBDURATN6 N  Duration:
#'   \item PBNMFRAM7 N  7. No. of Frames:
#'   \item PBDURATN7 N  Duration:
#'   \item PBNMFRAM8 N  8. No. of Frames:
#'   \item PBDURATN8 N  Duration:
#'   \item PBNMFRAM9 N  9. No. of Frames:
#'   \item PBDURATN9 N  Duration:
#'   \item PBNMFRAM10 N  10. No. of Frames:
#'   \item PBDURATN10 N  Duration:
#'   \item PBMOTION N  Subject motion problems:
#'   \item PBMOTSP T  If yes, describe:
#'   \item PBMALFUN N  Scanner malfunction
#'   \item PBMALSP T  If yes, describe:
#'   \item PBOTHER N  Other protocol variations:
#'   \item PBOTHSP T  If yes, describe:
#'   \item PBRECON N  Check which of the following reconstructions was used:
#'   \item PBSUBSET N  # subsets:
#'   \item PBSUBSPE N  If Other, specify
#'   \item PBITERAT N  # iterations:
#'   \item PBITERSPE N  If Other, specify:
#'   \item PBRAMLA N  If Ramla, Lambda=0.016?
#'   \item PBFILTER N  If Back Projection, Ramp filter?
#'   \item PBMODEON N  If FORE/2D-OSEM, Brain Mode "ON" for PET only scanners or TRIM "ON" for PET/CT scanners?
#'   \item PBSMOOTH N  No post-process smoothing:
#'   \item PBDECAY N  Decay Correction
#'   \item PBSCATTR N  Scatter Correction:
#'   \item PBMATTEN N  Attenuation Correction:
#'   \item PBTRSNFR N  Was data transferred to LONI within 24 hours of scan?
#'   \item PBTRNDATE D  Transfer Date
#'   \item PBTRNCOM T  Comments
#'   \item PBARCHIVE N  Data Archived Locally
#'   \item PBARCMED T  Archive Medium
#'   \item PBARCCOM T  Comments
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name pibmeta
#' @usage data(pibmeta)
#' @format A data frame with 257 rows and 75 variables
NULL

#' U Pitt PIB PET Analysis
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/PIBPETSUVR/UPitt_PIBPET_AD_ROI.pdf}, \url{https://adni.bitbucket.io/reference/docs/PIBPETSUVR/UPitt_PIBPET_MCI_ROI.pdf}, \url{https://adni.bitbucket.io/reference/docs/PIBPETSUVR/UPitt_PIBPET_NL_ROI.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N -4 Participant roster ID
#'   \item VISCODE T -4 Visit code
#'   \item EXAMDATE D -4 Examination Date
#'   \item IMAGEUID T -4 -4
#'   \item LONISID T -4 -4
#'   \item LONIUID T -4 -4
#'   \item ACG N -4 Anterior cingulate 
#'   \item FRC N -4 Frontal cortex 
#'   \item LTC N -4 Lateral temporal cortex 
#'   \item PAR N -4 Parietal cortex 
#'   \item PRC N -4 Precuneus cortex 
#'   \item MTC N -4 Mesial temporal cortex 
#'   \item OCC N -4 Occipital cortex 
#'   \item OCP N -4 Occipital pole 
#'   \item PON N -4 Pons
#'   \item AVS N -4 Anterior ventral striatum
#'   \item CER N -4 Cerebellum 
#'   \item SMC N -4 Sensory motor cortex
#'   \item SWM N -4 Sub-cortical white matter 
#'   \item THL N -4 Thalamus
#' }
#'
#' @examples
#' pibpetsuvr$PIBp = apply(pibpetsuvr[, c('FRC', 'ACG', 'PRC', 'PAR')], 1, mean) > 1.5
#' @docType data
#' @keywords datasets
#' @name pibpetsuvr
#' @usage data(pibpetsuvr)
#' @format A data frame with 224 rows and 21 variables
NULL

#' PIB QC Tracking
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item RECNO N  
#'   \item EXAMDATE D  Examination Date
#'   \item PQFILENO N  Upload Number
#'   \item PQDATTRA D  Date images uploaded to LONI
#'   \item LONIUID T  LONI Unique Series ID
#'   \item PQDATE D  Date reviewed
#'   \item PQACQFR N  Acquisition
#'   \item PQCORALG N  Correct Reconstruction Algorithm?
#'   \item PQRECON N  Check which of the following reconstruction algorithms was used
#'   \item PQCORNUM N  If OSEM or Ramla, correct # iterations and subsets?
#'   \item PQCORFIL N  Correct Filters/TRIM?
#'   \item PQCORTHI N  Correct Slice Thickness (PET/CT systems)?
#'   \item PQVOXEL N  Acceptable Voxel Size?
#'   \item PQALLFRAME N  Were all frames acceptable?
#'   \item PQUNUSABLE T  Indicate which frames were unacceptable:
#'   \item PQREASON T  Indicate why frames were unacceptable:
#'   \item PQREASSP T  If Other, Specify:
#'   \item PASS N  Pass QC?
#'   \item PQPROERR T  A. Processing Error(s)
#'   \item PQERRSP T  Specify
#'   \item PQACTION N  B. QC outcome
#'   \item PQISSUES T  Imaging issues
#'   \item PQISSOTH T  Other, specify
#'   \item COMMENTS T  Additional QC Comments
#'   \item QUARANTINE N  Release from quarantine?
#'   \item PAYSITE N  Pay Site?
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name pibqc
#' @usage data(pibqc)
#' @format A data frame with 294 rows and 33 variables
NULL

#' ABeta40 and ABeta42 quantification in plasma using ABtest40 and ABtest42
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/PLASMAABETA/ADNI_Araclon%20Methods.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item FP40 -4 (pg/ml) Free ABeta40 in plasma
#'   \item TP40 -4 (pg/ml) Total ABeta40 in plasma
#'   \item FP42 -4 (pg/ml) Free ABeta42 in plasma
#'   \item TP42 -4 (pg/ml) Total ABeta42 in plasma
#' }
#'
#' @examples
#' \donotrun{
#' describe(plasmaabeta)
#' }
#' @docType data
#' @keywords datasets
#' @name plasmaabeta
#' @usage data(plasmaabeta)
#' @format A data frame with 784 rows and 7 variables
NULL

#' Participant Demographic Information
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item PTCOGBEG N  11a. Year of onset of cognitive symptoms (best estimate)
#'   \item PTADDX N  11b. Year of Alzheimer's Disease diagnosis
#'   \item PTMCIBEG N NA 11a. Year of onset of Mild Cognitive Impairment symptoms (best estimate)
#'   \item PTDOBMM N NA 2a. Participant Month of Birth
#'   \item PTDOBYY N NA 2b. Participant Year of Birth
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item EXAMDATE D  Examination Date
#'   \item PTSOURCE N  Information Source
#'   \item PTGENDER N  1. Participant Gender
#'   \item PTDOB D  2. Participant Date of Birth
#'   \item PTHAND N  3. Participant Handedness
#'   \item PTMARRY N  4. Participant Marital Status
#'   \item PTEDUCAT N  5. Participant Education
#'   \item PTWORKHS N  5a. Does the participant have a work history sufficient to exclude mental retardation? <!--Participant Education-->
#'   \item PTWORK T  6a. Primary occupation during most of adult life
#'   \item PTWRECNT T  6b. Most recent occupation
#'   \item PTNOTRT N  7. Participant Retired?
#'   \item PTRTYR D  Retirement Date
#'   \item PTHOME N  8. Type of Participant residence
#'   \item PTOTHOME T  If Other, specify:
#'   \item PTTLANG N  9. Language to be used for testing the Participant
#'   \item PTPLANG N  10. Participant's Primary Language
#'   \item PTPSPEC T  If Other, specify:
#'   \item PTADBEG N  11. Year of onset of Alzheimer's disease symptoms (best estimate)
#'   \item PTETHCAT N  12. Ethnic Category
#'   \item PTRACCAT N  13. Racial Categories
#'   \item USERDATE2 S  Date record last updated
#'   \item AGE   
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name ptdemog
#' @usage data(ptdemog)
#' @format A data frame with 3992 rows and 32 variables
NULL

#' Publicity Tracking
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item REFERRAL N NA Do you have a referral code for this participant?
#'   \item REFERCODE T NA If Yes, enter referral code:
#'   \item HEARD N NA 1.  How did you hear about the study?  
#'   \item HRDSPCFY T NA Please provide specifics here for how you heard about  the study.
#'   \item WHOMHRD N NA 2.  From whom did you hear about the study?  
#'   \item WHOMSPCFY T NA If Other, specify:
#'   \item COMM T NA Comments:
#'   \item RID N NA Participant roster ID
#'   \item SITEID N NA Site ID
#'   \item VISCODE T NA Visit code
#'   \item USERDATE S NA Date record created
#'   \item USERDATE2 S NA Date record last updated
#'   \item INTERNAL T NA Internal
#'   \item DOCTOR T NA Doctor's Office
#'   \item COMMNEWS T NA Community Newspaper
#'   \item MAJORNEWS T NA Major Newspaper
#'   \item MAGAZINE T NA Magazine
#'   \item OTHERPUB T NA Other Publication
#'   \item OTRPUBSO T NA Specify Publication
#'   \item OTHPUBTYP T NA Indicate:
#'   \item MOUTH T NA Word of Mouth
#'   \item MOUTHSO T NA Specify Other:
#'   \item NEWSLETTER T NA Organization Newsletter
#'   \item NESWSLORG T NA Specify Organization:
#'   \item NEWSLSO T NA Specify Other:
#'   \item TELEVISION T NA Television
#'   \item HEALTHFAIR T NA Health Fair
#'   \item ALZASSOC T NA Alzheimer's Association
#'   \item WEBSITE T NA Website
#'   \item WEBSITESO T NA Specify Other:
#'   \item SNAILMAIL T NA Direct Mail
#'   \item SNMAILORG T NA Specify Organization:
#'   \item EMAIL T NA E-Mail
#'   \item EMAILORG T NA Specify Organization:
#'   \item PRESENT T NA Presentation
#'   \item PRESENTORG T NA Specify Organization:
#'   \item OTHERORG T NA Other Organization<p>Specify:
#'   \item RADIO T NA Radio<p>Specify Station:
#'   \item PRIORTRIAL T NA Involved in Prior Clinical Trials<p>Specify Trials:
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name publicity
#' @usage data(publicity)
#' @format A data frame with 1753 rows and 41 variables
NULL

#' Rules Based Medicine Plasma Multiplex QC Data
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4  Participant roster ID
#'   \item VISCODE -4  Visit code
#'   \item RBMID -4  RBM Sample ID
#'   \item RECDATE D  Sample_Received_Date
#'   \item A1MICRO -4 ug/ml Alpha-1-Microglobulin 
#'   \item A2MACRO -4 mg/mL Alpha-2-Macroglobulin 
#'   \item AACT -4 ug/ml Alpha-1-Antichymotrypsin 
#'   \item AAT -4 mg/mL Alpha-1-Antitrypsin 
#'   \item ACE -4 ng/ml Angiotensin-Converting Enzyme 
#'   \item ACTH -4 ng/mL Adrenocorticotropic Hormone 
#'   \item ADIPNCTN -4 ug/mL Adiponectin 
#'   \item AFP -4 ng/mL Alpha-Fetoprotein 
#'   \item AGRP -4 pg/mL Agouti-Related Protein 
#'   \item ANG2 -4 ng/mL Angiopoietin-2 
#'   \item ANGTNSNG -4 ng/mL Angiotensinogen 
#'   \item APOAI -4 mg/mL Apolipoprotein A-I 
#'   \item APOAII -4 ng/ml Apolipoprotein A-II 
#'   \item APOAIV -4 ug/ml Apolipoprotein A-IV 
#'   \item APOB -4 ug/ml Apolipoprotein B 
#'   \item APOCI -4 ng/ml Apolipoprotein C-I 
#'   \item APOCIII -4 ug/mL Apolipoprotein C-III 
#'   \item APOD -4 ug/ml Apolipoprotein D 
#'   \item APOE -4 ug/ml Apolipoprotein E 
#'   \item APOH -4 ug/mL Apolipoprotein H 
#'   \item AR -4 pg/mL Amphiregulin 
#'   \item AXL -4 ng/mL AXL Receptor Tyrosine Kinase 
#'   \item B2M -4 ug/mL Beta-2-Microglobulin 
#'   \item BDNF -4 ng/mL Brain-Derived Neurotrophic Factor 
#'   \item BLC -4 pg/ml B Lymphocyte Chemoattractant 
#'   \item BMP6 -4 ng/mL Bone Morphogenetic Protein 6 
#'   \item BNP -4 pg/ml Brain Natriuretic Peptide  
#'   \item BTC -4 pg/mL Betacellulin 
#'   \item C3 -4 mg/mL Complement C3 
#'   \item CA125 -4 U/mL Cancer Antigen 125 
#'   \item CA199 -4 U/mL Cancer Antigen 19-9 
#'   \item CALBINDN -4 ng/ml Calbindin 
#'   \item CALCITNN -4 pg/mL Calcitonin 
#'   \item CD40 -4 ng/mL CD 40 antigen 
#'   \item CD40L -4 ng/mL CD40 Ligand 
#'   \item CD5L -4 ng/ml CD5 
#'   \item CEA -4 ng/mL Carcinoembryonic Antigen 
#'   \item CGA -4 ng/mL Chromogranin-A 
#'   \item CKMB -4 ng/mL Creatine Kinase-MB 
#'   \item CLU -4 ug/ml Clusterin 
#'   \item CNTF -4 pg/mL Ciliary Neurotrophic Factor 
#'   \item CMPLMNFH -4 ug/ml Complement Factor H 
#'   \item CORTISOL -4 ng/ml Cortisol 
#'   \item CPEPTIDE -4 ng/ml C-peptide 
#'   \item CRP -4 ug/mL C-Reactive Protein 
#'   \item CTGF -4 ng/ml Connective Tissue Growth Factor 
#'   \item CYSTATNC -4 ng/ml Cystatin-C 
#'   \item EGF -4 pg/mL Epidermal Growth Factor 
#'   \item EGFR -4 ng/mL Epidermal Growth Factor Receptor 
#'   \item EPTHLDNA -4 ng/mL Epithelial-Derived Neutrophil-Activating 
#'   \item ENRAGE -4 ng/mL EN-RAGE 
#'   \item EOTAXIN1 -4 pg/mL Eotaxin-1 
#'   \item EOTAXIN3 -4 pg/mL Eotaxin-3 
#'   \item EPO -4 pg/mL Erythropoietin 
#'   \item EPR -4 pg/mL Epiregulin 
#'   \item ESELECTN -4 ng/mL E-Selectin 
#'   \item ET1 -4 pg/mL Endothelin-1 
#'   \item FABP -4 ng/mL Fatty Acid-Binding Protein- heart  
#'   \item FACTRVII -4 ng/mL Factor VII 
#'   \item FAS -4 ng/mL FASLG Receptor 
#'   \item FASL -4 pg/mL Fas Ligand 
#'   \item FETUINA -4 ug/ml Fetuin-A 
#'   \item FGF4 -4 pg/mL Fibroblast Growth Factor 4 
#'   \item FGFBASI -4 pg/mL Fibroblast Growth Factor basic 
#'   \item FIBRINGN -4 mg/mL Fibrinogen 
#'   \item FRTN -4 ng/mL Ferritin 
#'   \item FSH -4 mIU/mL Follicle-Stimulating Hormone 
#'   \item G -4 pg/mL Granulocyte Colony-Stimulating Factor 
#'   \item GH -4 ng/mL Growth Hormone 
#'   \item GLP1TO -4 pg/ml Glucagon-like Peptide 1- total 
#'   \item GLUCAGON -4 pg/ml Glucagon 
#'   \item GRNLCMCS -4 pg/mL Granulocyte-Macrophage Colony-Stimulatin 
#'   \item GROALPH -4 pg/mL Growth-Regulated alpha protein 
#'   \item GSTALP -4 ng/ml Glutathione S-Transferase alpha 
#'   \item HAPTGLBN -4 mg/mL Haptoglobin 
#'   \item HBEGFGF -4 pg/mL Heparin-Binding EGF-Like Growth Factor 
#'   \item HCC4 -4 ng/mL Chemokine CC-4 
#'   \item HGF -4 ng/mL Hepatocyte Growth Factor 
#'   \item HSP60 -4 ng/ml Heat Shock Protein 60 
#'   \item I3 -4 pg/mL T Lymphocyte-Secreted Protein I-309 
#'   \item ICAM -4 ng/mL Intercellular Adhesion Molecule 1 
#'   \item IFNGAMMA -4 pg/mL Interferon gamma 
#'   \item IGA -4 mg/mL Immunoglobulin A 
#'   \item IGE -4 ng/mL Immunoglobulin E 
#'   \item INSLGFBP -4 ng/mL Insulin-like Growth Factor-Binding Prote 
#'   \item IGFI -4 ng/mL Insulin-like Growth Factor I 
#'   \item IGM -4 mg/mL Immunoglobulin M 
#'   \item IL1ALPHA -4 ng/mL Interleukin-1 alpha 
#'   \item IL1BETA -4 pg/mL Interleukin-1 beta 
#'   \item IL10 -4 pg/mL Interleukin-10 
#'   \item IL11 -4 pg/mL Interleukin-11 
#'   \item IL12P40 -4 ng/mL Interleukin-12 Subunit p40 
#'   \item IL12P70 -4 pg/mL Interleukin-12 Subunit p70 
#'   \item IL13 -4 pg/mL Interleukin-13 
#'   \item IL15 -4 ng/mL Interleukin-15 
#'   \item IL16 -4 pg/mL Interleukin-16 
#'   \item IL18 -4 pg/mL Interleukin-18 
#'   \item IL1R -4 pg/mL Interleukin-1 receptor antagonist 
#'   \item IL2 -4 pg/mL Interleukin-2 
#'   \item IL25 -4 pg/mL Interleukin-25 
#'   \item IL3 -4 ng/mL Interleukin-3 
#'   \item IL4 -4 pg/mL Interleukin-4 
#'   \item IL5 -4 pg/mL Interleukin-5 
#'   \item IL6 -4 pg/mL Interleukin-6 
#'   \item IL6R -4 ng/mL Interleukin-6 receptor 
#'   \item IL7 -4 pg/mL Interleukin-7 
#'   \item IL8 -4 pg/mL Interleukin-8 
#'   \item INSULIN -4 uIU/mL Insulin 
#'   \item IP -4 pg/ml Interferon gamma Induced Protein 10 
#'   \item KIM1 -4 ng/ml Kidney Injury Molecule-1  
#'   \item LEPTIN -4 ng/mL Leptin 
#'   \item LH -4 mIU/mL Luteinizing Hormone  
#'   \item LOX -4 ng/mL Lectin-Like Oxidized LDL Receptor 1 
#'   \item A -4 ug/mL Apolipoprotein
#'   \item LYMPHTCT -4 ng/mL Lymphotactin 
#'   \item MCP1 -4 pg/mL Monocyte Chemotactic Protein 1 
#'   \item MCP2 -4 pg/ml Monocyte Chemotactic Protein 2 
#'   \item MCP3 -4 pg/mL Monocyte Chemotactic Protein 3 
#'   \item MCP4 -4 pg/ml Monocyte Chemotactic Protein 4 
#'   \item MCLNSF1 -4 ng/mL Macrophage Colony-Stimulating Factor 1 
#'   \item MLNDMLDL -4 ng/mL Malondialdehyde-Modified Low-Density Lip 
#'   \item MDC -4 pg/mL Macrophage-Derived Chemokine 
#'   \item MCRPHMIF -4 ng/mL Macrophage Migration Inhibitory Factor 
#'   \item MI -4 pg/ml Monokine Induced by Gamma Interferon 
#'   \item MCRPHIP1 -4 pg/mL Macrophage Inflammatory Protein-1 alpha 
#'   \item MIPRT1B -4 pg/mL Macrophage Inflammatory Protein-1 beta 
#'   \item MCRPHIP3 -4 pg/ml Macrophage Inflammatory Protein-3 alpha 
#'   \item MMP1 -4 ng/ml Matrix Metalloproteinase-1 
#'   \item MMP10 -4 ng/ml Matrix Metalloproteinase-10 
#'   \item MMP2 -4 ng/mL Matrix Metalloproteinase-2 
#'   \item MMP3 -4 ng/mL Matrix Metalloproteinase-3 
#'   \item MMP7 -4 ng/ml Matrix Metalloproteinase-7 
#'   \item MMP9 -4 ng/mL Matrix Metalloproteinase-9 
#'   \item MM9T -4 ng/ml Matrix Metalloproteinase-9- total 
#'   \item MYLDPIF1 -4 ng/mL Myeloid Progenitor Inhibitory Factor 1 
#'   \item MPO -4 ng/mL Myeloperoxidase 
#'   \item MYOGLOBN -4 ng/mL Myoglobin 
#'   \item NTRPHGAL -4 ng/ml Neutrophil Gelatinase-Associated Lipocal 
#'   \item NGFBETA -4 ng/mL Nerve Growth Factor beta 
#'   \item NRCAM -4 ng/mL Neuronal Cell Adhesion Molecule 
#'   \item OSTEPNTN -4 ng/ml Osteopontin 
#'   \item PAI1 -4 ng/mL Plasminogen Activator Inhibitor 1 
#'   \item PAP -4 ng/mL Prostatic Acid Phosphatase 
#'   \item P -4 mIU/mL Pregnancy-Associated Plasma Protein A 
#'   \item PLMNRARC -4 ng/mL Pulmonary and Activation-Regulated Chemo 
#'   \item PDGF -4 pg/ml Platelet-Derived Growth Factor BB 
#'   \item PLGF -4 pg/ml Placenta Growth Factor 
#'   \item PPP -4 pg/ml Pancreatic Polypeptide 
#'   \item PRL -4 ng/ml Prolactin 
#'   \item PROGSTRN -4 ng/ml Progesterone 
#'   \item PRNSLNIN -4 pM Proinsulin- Intact 
#'   \item PRNSLNTT -4 pM Proinsulin- Total 
#'   \item PSAF -4 ng/mL Prostate-Specific Antigen- Free 
#'   \item PYY -4 pg/mL Peptide YY 
#'   \item RCPTRFRD -4 ng/mL Receptor for advanced glycosylation end 
#'   \item RANTES -4 ng/mL T-Cell-Specific Protein RANTES 
#'   \item RESISTIN -4 ng/ml Resistin 
#'   \item S100B -4 ng/mL S100 calcium-binding protein B 
#'   \item SAP -4 ug/mL Serum Amyloid P-Component 
#'   \item SCF -4 pg/mL Stem Cell Factor 
#'   \item SECRETIN -4 ng/mL Secretin 
#'   \item SRMGLTOT -4 ug/mL Serum Glutamic Oxaloacetic Transaminase 
#'   \item SHBG -4 nmol/L Sex Hormone-Binding Globulin 
#'   \item SOD1 -4 ng/mL Superoxide Dismutase 1- Soluble 
#'   \item SORTILIN -4 ng/mL Sortilin 
#'   \item TBG -4 ug/mL Thyroxine-Binding Globulin 
#'   \item TECK -4 ng/mL Thymus-Expressed Chemokine 
#'   \item TSTSTRNT -4 ng/ml Testosterone- Total 
#'   \item TF -4 ng/mL Tissue Factor 
#'   \item TFF3 -4 ug/ml Trefoil Factor 3 
#'   \item TGFAL -4 pg/mL Transforming Growth Factor alpha 
#'   \item TGFB -4 pg/mL Transforming Growth Factor beta-3 
#'   \item THP -4 ug/ml Tamm-Horsfall Urinary Glycoprotein 
#'   \item THRMBSP1 -4 ng/mL Thrombospondin-1 
#'   \item TSSINHM1 -4 ng/mL Tissue Inhibitor of Metalloproteinases 1 
#'   \item TM -4 ng/ml Thrombomodulin 
#'   \item TNC -4 ng/mL Tenascin-C 
#'   \item TNFALPHA -4 pg/mL Tumor Necrosis Factor alpha 
#'   \item TNFBETA -4 pg/mL Tumor Necrosis Factor beta 
#'   \item T -4 ng/mL Tumor Necrosis Factor Receptor-Like 2 
#'   \item THRMBPTN -4 ng/mL Thrombopoietin 
#'   \item TNFRAILR -4 ng/mL TNF-Related Apoptosis-Inducing Ligand Re 
#'   \item TRNSFRRN -4 mg/dl Serotransferrin 
#'   \item TSH -4 uIU/mL Thyroid-Stimulating Hormone  
#'   \item TTR -4 mg/dl Transthyretin 
#'   \item VCAM -4 ng/mL Vascular Cell Adhesion Molecule-1 
#'   \item VEGF -4 pg/mL Vascular Endothelial Growth Factor 
#'   \item VITRNCTN -4 ug/ml Vitronectin 
#'   \item VKDPS -4 ug/ml Vitamin K-Dependent Protein S 
#'   \item VWF -4 ug/mL von Willebrand Factor 
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name rbmqc
#' @usage data(rbmqc)
#' @format A data frame with 1063 rows and 195 variables
NULL

#' Rules Based Medicine Plasma Multiplex Raw Data
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item RBMID -4 -4 Sample ID from RBM 
#'   \item VISCODE -4 -4 Visit code
#'   \item ANALYTE -4 -4 Name of Analyte with Units 
#'   \item LDD -4 -4 Least Detectable Dose (see primer for details) 
#'   \item AVALUE -4 -4 Recorded Value 
#'   \item ANALVAL -4 -4 Numeric Value after possible imputation (see primer for details; note that some analytes are all blank due to too many <LOW> values) 
#'   \item BELOWLDD -4 -4 Is analval < LDD? Note: this flag pertains to both recorded value and imputed value
#'   \item READLOW -4 -4 Is recorded value <LOW> or numeric? (see primer for details) 
#'   \item LOGTRANS -4 -4 Is analval log10 transformed?
#'   \item OUTLIER -4 -4 Is analval considered an outlier (see primer for details)
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name rbmraw
#' @usage data(rbmraw)
#' @format A data frame with 201970 rows and 12 variables
NULL

#' Diagnosis and Symptoms Log
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N NA Participant roster ID
#'   \item SITEID N NA Site ID
#'   \item VISCODE T NA Visit code
#'   \item USERDATE S NA Date record created
#'   \item USERDATE2 S NA Date record last updated
#'   \item RECNO N NA 
#'   \item SXSYMNO N NA Symptom Number
#'   \item SXSYMP T NA Description of Symptom
#'   \item SXSEVER N NA Severity
#'   \item SXCHRON N NA Chronicity
#'   \item SXONSET D NA Date of Onset
#'   \item SXCONTD N NA Is the symptom ongoing?
#'   \item SXCEASE D NA Date Ceased
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name recadsx
#' @usage data(recadsx)
#' @format A data frame with 881 rows and 15 variables
NULL

#' Adverse Events/Hospitalizations - Log
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item AEHCSHR T HHMM Estimated Cease Time:
#'   \item AENUMBER N  Adverse Event Number
#'   \item AERELATSP N  Related to other study procedure(s)
#'   \item AEHTAU N  Related to AV-1451 (Tau) Imaging
#'   \item AEHAV45 N NA Investigator Judgment of Relatedness to F-AV-45
#'   \item AEHONSHR N NA Estimated Onset Time:
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item RECNO N  
#'   \item EXAMDATE D  Examination Date
#'   \item AEHEVNT T  Event (Diagnosis or Symptom if diagnosis is not known)
#'   \item AEHBLSYM T  Check here if:
#'   \item AEHONSDT D  Onset Date
#'   \item AEHONGNG N  Is the event ongoing?
#'   \item AEHCSDT D  Cease Date
#'   \item AEHCHRON N  Chronicity
#'   \item AEHSEVR N  Severity
#'   \item AEHSERIO N  Serious?
#'   \item AEHSAE T  Check here if:
#'   \item AEHREPBY T  Serious Adverse Event Reported By:
#'   \item AEHREASN T  Reason for Qualifying as Serious Adverse Event:
#'   \item AEHLIFE N  Life-Threatening?
#'   \item AEHIMG N  Related to Imaging Procedure
#'   \item AEHLUMB N  Related to Lumbar Puncture
#'   \item AEHCMEDS N  Concurrent Medication Prescribed or Changed
#'   \item AEHINHOS N  Did this event occur while the participant was being hospitalized for another event?
#'   \item AEHPRO N  If Yes, did this event prolong hospitalization?
#'   \item AEHHOSP N  If No, did this event require hospitalization?
#'   \item AEHOUTDT D  If Outpatient, provide the date of visit
#'   \item AEHADMDT D  Admit Date
#'   \item AEHADDIA T  Admit Diagnosis
#'   \item AEHDISDT D  Discharge Date
#'   \item AEHDISDI T  Discharge Diagnosis
#'   \item AEHDEATH N  Did this event result in death?
#'   \item AEHDTHDT D  Date of death
#'   \item AEHDCAUS T  Cause of death:
#'   \item AEHALZHI N  Was diagnosis of Alzheimer's confirmed at autopsy?
#'   \item AEHCOMM T  Comments
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name recadv
#' @usage data(recadv)
#' @format A data frame with 19349 rows and 43 variables
NULL

#' Documentation of Baseline Symptoms Log
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item RECNO N  
#'   \item EXAMDATE D  Examination Date
#'   \item BSXSYMNO N  Symptom Number
#'   \item BSXSYMP T  Description of Symptom
#'   \item BSXSEVER N  Severity
#'   \item BSXCHRON N  Chronicity
#'   \item BSXONSET D  Date of Onset
#'   \item BSXCONTD N  Is the symptom ongoing?
#'   \item BSXCEASE D  Date Ceased
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name recbllog
#' @usage data(recbllog)
#' @format A data frame with 12849 rows and 16 variables
NULL

#' Concurrent Medications Log
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item CMUNITO T  If other, specify:
#'   \item CMFREQNCO T  If other, specify:
#'   \item CMROUTEO T  If other, specify:
#'   \item CMMEDO T  If medication not found in search list, hand enter for approval
#'   \item CMEVNUM T  If Adverse Event, enter event number:
#'   \item CMUNITS T NA Units
#'   \item CMMEDID N NA medlist ID
#'   \item CMUNITSID T NA 
#'   \item CMFREQID T NA 
#'   \item CMROUTEID T NA 
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item RECNO N  
#'   \item EXAMDATE D  Examination Date
#'   \item CMHFS N  HFS Code
#'   \item CMDOSE T  Dose
#'   \item CMFREQNC T  Frequency
#'   \item CMROUTE T  Route
#'   \item CMREASON T  Reason Prescribed
#'   \item CMBGN D  Date Began
#'   \item CMCONT N  Is the medication continuing?
#'   \item CMEND D  Date Ended
#'   \item CMCOMM T  Comments
#'   \item USERDATE2 S  Date record last updated
#'   \item CMMED TRUE NA Free text meds entered into Concurrent Medications Log
#'   \item DONEPEZIL TRUE NA DONEPEZIL
#'   \item GALANTAMINE TRUE NA GALANTAMINE
#'   \item RIVASTIGMINE TRUE NA RIVASTIGMINE
#'   \item MEMANTINE TRUE NA MEMANTINE
#'   \item TACRINE TRUE NA TACRINE
#'   \item THYROXINE TRUE NA THYROXINE
#'   \item METHIMAZOLE TRUE NA METHIMAZOLE
#'   \item NSAID TRUE NA Nonsteroidal anti-inflammatory drugs
#'   \item BP TRUE NA Blood pressure drugs
#'   \item PPAR TRUE NA Peroxisome proliferator-activated receptors
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name reccmeds
#' @usage data(reccmeds)
#' @format A data frame with 50257 rows and 40 variables
NULL

#' Family History Questionnaire Subtable
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item RECNO N  
#'   \item EXAMDATE D  Examination Date
#'   \item FHQGNDR N  Gender
#'   \item FHQSIB N  Dementia
#'   \item FHQSIBAD N  Alzheimer's Disease
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name recfhq
#' @usage data(recfhq)
#' @format A data frame with 7407 rows and 12 variables
NULL

#' Medical History
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item MHDTONSET D  Date of onset:
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item RECNO N  
#'   \item EXAMDATE D  Examination Date
#'   \item MHNUM N  System Number
#'   \item MHDESC T  Description of problem (including date of onset)
#'   \item MHCUR N  Is the problem current?
#'   \item MHSTAB N  If Yes, is the problem stable?
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name recmhist
#' @usage data(recmhist)
#' @format A data frame with 30796 rows and 14 variables
NULL

#' Redox Reactive Reagents LLC ADNI R-RAA ELISA
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID NA  Participant roster ID
#'   \item VISCODE NA  Visit code
#'   \item PSG NA Interpolated OD PSG 10% Hemin Treated minus Untreated
#'   \item PSGSD NA  PSG 10% Hemin Treated minus Untreated SD
#'   \item CLG NA Interpolated OD CLG 10% Hemin Treated minus Untreated
#'   \item CLGSD NA  CLG 10% Hemin Treated minus Untreated SD
#'   \item PEG NA Interpolated OD PEG 10% Hemin Treated minus Untreated
#'   \item PEGSD NA  PEG 10% Hemin Treated minus Untreated SD
#'   \item PCG NA Interpolated OD PCG 1% Hemin Treated minus Untreated
#'   \item PCGSD NA  PCG 1% Hemin Treated minus Untreated SD
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name redox
#' @usage data(redox)
#' @format A data frame with 90 rows and 11 variables
NULL

#' Registry
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RGSTATUS N  Was a screening visit/ADNI2 initial visit performed?
#'   \item RGSOURCE N  Who participated in this visit?
#'   \item PTSTATUS N NA Participant Status:
#'   \item VISTYPE N NA Visit Type:
#'   \item CHANGTR N NA Would you like to change this visit's track or the participant's visit schedule?
#'   \item CGTRACK N NA Please select from the following visit's tracks:
#'   \item CGTRACK2 N NA Please select from the following visit schedule:
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item RGCONDCT N  Was this visit conducted?
#'   \item RGREASON N  Reason why the visit was not conducted:
#'   \item RGOTHSPE T  If Other, specify:
#'   \item EXAMDATE D  Examination Date
#'   \item RGRESCRN N  Is this a rescreen?
#'   \item RGPREVID T  If Yes, what was the participant's initial ID number?
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name registry
#' @usage data(registry)
#' @format A data frame with 21669 rows and 20 variables
NULL

#' Residual aliquot count in the LDMS database
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/RESIDUAL_ALIQUOT_LIST/ADNI_Methods_Template_Biomarker%20Core%20Residual%20CSF%20aliquot%20samples%20v1.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item COLPROT -4 -4 Study protocol of data collection
#'   \item RID -4  Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item VISCODE2 -4 -4 Translated visit code
#'   \item EXAMDATE -4 -4 Examination Date
#'   \item SITE -4  Hospital/Site ID
#'   \item VID -4  Visit ID from sample tube
#'   \item VOL -4 mL Volume of residual CSF left after analysis
#'   \item GUSPECID -4  Global Specimen ID identifying individual aliquots
#'   \item RECDTE -4 YYYYMMDD Date of sample receipt at UPenn
#'   \item STORDTE -4 YYYYMMDD Date of aliquoting and storing
#' }
#'
#' @examples
#' \donotrun{
#' describe(residual_aliquot_list)
#' }
#' @docType data
#' @keywords datasets
#' @name residual_aliquot_list
#' @usage data(residual_aliquot_list)
#' @format A data frame with 1661 rows and 11 variables
NULL

#' Return of Research Results
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RECIPPT N NA 7a. Were the research results returned to the Participant?
#'   \item RECIPFAM N NA 7b. Were the research results returned to a Family Member?  
#'   \item RECIPFR N NA 7c.  Were the research results returned to a Friend?
#'   \item RECIPSP N NA 7d.  Were the research results returned to a Study Partner?
#'   \item RECIPCLIN N NA 7e.  Were the research results returned to a Treating Clinician?
#'   \item RECIPOTH N NA 7f.  Were the research results returned to another individual (Other, Specify)
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#'   \item RECNO N  
#'   \item TYPE N  1. What type of research results were disclosed?
#'   \item TYPEOTH T  If Other, please specify:
#'   \item REQUESTED N  2. Who requested the return of research results?
#'   \item REQUESTOTH T  If Other, please specify:
#'   \item REASON T  3. What was the reason for returning research results? (check all that apply)
#'   \item REASONOTH T  If Other, please specify:
#'   \item CONSENT N  4. Who gave informed consent for the decision to return research results?
#'   \item CONSENTOTH T  If Other, please specify:
#'   \item IRBPLAN N  5. Was the plan to return research results presented to your institution's IRB?
#'   \item IRBINFO T  a) How was this information presented to your IRB (email, in-person meeting, etc.)?
#'   \item IRBPROTO T  b) What was the protocol for returning results that you presented?
#'   \item WAIVER N  c) Was a waiver obtained?
#'   \item EXCEPOBT N  d) Was an exception obtained?
#'   \item COGSTATUS N  6. What was the participant's cognitive status at the time these results were returned?
#'   \item RECIPIENT T  7. Who were the research results returned to? (check all that apply)
#'   \item RECIPIENTO T  If Other, please specify:
#'   \item RETURNPOS T  Position:  <!--8. Who returned the results?-->
#'   \item RETURNMETH N  How were results returned (verbally or in writing)?
#'   \item RETURNTIME T  What was the timeframe for returning results (from request to date of disclosure)?
#'   \item RETURNROLE N  9. What is this person's role in ADNI?
#'   \item RTNROLEOTH T  If Other, please specify:
#'   \item AMYLRESNM T  Name:  <!--10. If amyloid imaging results were returned, please indicate who read  the scan and the individual's qualifications for interpreting amyloid  imaging:-->
#'   \item AMLYLRESQU T  Qualifications (e.g., degrees, specialty area):  <!--10. If amyloid imaging results were returned, please indicate who read  the scan and the individual's qualifications for interpreting amyloid  imaging:-->
#'   \item AMLYRESTR T  Training (e.g., specific training in interpretation of amyloid imaging, such as Amyvid training course):  <!--10. If amyloid imaging results were returned, please indicate who read  the scan and the individual's qualifications for interpreting amyloid  imaging:-->
#'   \item AMLYRESEXP T  Experience: <!--10. If amyloid imaging results were returned, please indicate who read  the scan and the individual's qualifications for interpreting amyloid  imaging:-->
#'   \item PTRESPONSE T  Participant:  <!--11. How did the recipient respond to the information provided?-->
#'   \item FMRESPONSE T  Family member: <!--11. How did the recipient respond to the information provided?-->
#'   \item FRRESPONSE T  Friend: <!--11. How did the recipient respond to the information provided?-->
#'   \item SPRESPONSE T  Study partner: <!--11. How did the recipient respond to the information provided?-->
#'   \item CLRESPONSE T  Treating clinician: <!--11. How did the recipient respond to the information provided?-->
#'   \item OTRESPONSE T  Other recipient: <!--11. How did the recipient respond to the information provided?-->
#'   \item PREDISC T  Pre-disclosure: <!--12. What kind of pre- and post-disclosure support and monitoring was provided to the participant and his or her family?-->
#'   \item POSTDISC T  Post-disclosure:  <!--12. What kind of pre- and post-disclosure support and monitoring  was provided to the participant and his or her family?-->
#' }
#'
#' @examples
#' \donotrun{
#' describe(rorr)
#' }
#' @docType data
#' @keywords datasets
#' @name rorr
#' @usage data(rorr)
#' @format A data frame with 16 rows and 47 variables
NULL

#' Roster
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item USERDATE S  Date record created
#'   \item PTID T  Participant ID
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name roster
#' @usage data(roster)
#' @format A data frame with 4393 rows and 7 variables
NULL

#' Source Doc Upload
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item SRCDOC N NA Source Documents to Upload:
#'   \item SRCDOCOTH T NA If Other, Specify: 
#'   \item SRCSTAT N NA Initial or Updated Version:
#'   \item SRCVFY N NA Has all PHI been removed from the documents to be uploaded?
#'   \item COMMENT T NA Comments:
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' \donotrun{
#' describe(sourceup)
#' }
#' @docType data
#' @keywords datasets
#' @name sourceup
#' @usage data(sourceup)
#' @format A data frame with 2645 rows and 12 variables
NULL

#' sPAP Avid ADNI Florbetapir summaries
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/SPAP_AVID_FLORBETAPIR/sPAP_Avid_Florbetapir_Analysis_Methods.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID T  Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item VISCODE2 -4 -4 Translated visit code
#'   \item EXAMDATE -4 -4 Examination Date
#'   \item DIAGRP2 T  clinical diagnosis close to the AV45 scan available during the data download in August 2012
#'   \item SPAP_GLOBAL_SUVR N Florbetapir (AV45) ratio (cortical grey matter/whole cerebellum), using sPAP software Average six region SUVr normalized by entire cerebellum for flroetbapir (AV-45) images calcualted using sPAP software. Refer to sPAP_Avid_Florbetapir_Analysis_Methods PDF on LONI for details
#'   \item SPAP_FRONTAL_SUVR N av45 uptake in cortical grey matter medial orbital frontal normalized to entire cerebellum in sPAP. Refer to sPAP_Avid_Florbetapir_Analysis_Methods PDF on LONI for details
#'   \item SPAP_TEMPORAL_SUVR N av45 uptake in cortical grey matter lateral temporal normalized to entire cerebellum in sPAP. Refer to sPAP_Avid_Florbetapir_Analysis_Methods PDF on LONI for details
#'   \item SPAP_ANTERIOR_CINGULATE_SUVR N av45 uptake in cortical grey matter anterior cingulate normalized to entire cerebellum in sPAP. Refer to sPAP_Avid_Florbetapir_Analysis_Methods PDF on LONI for details
#'   \item SPAP_POSTERIOR_CINGULATE_SUVR N av45 uptake in cortical grey matter posterior cingulate normalized to entire cerebellum is sPAP. Refer to sPAP_Avid_Florbetapir_Analysis_Methods PDF on LONI for details
#'   \item SPAP_PARIETAL_SUVR N av45 uptake in cortical grey matter parietal region normalized to entire cerebellum is sPAP. Refer to sPAP_Avid_Florbetapir_Analysis_Methods PDF on LONI for details
#'   \item SPAP_PRECUNEUS_SUVR N av45 uptake in cortical grey matter precuneus region normalized to entire cerebellum is sPAP. Refer to sPAP_Avid_Florbetapir_Analysis_Methods PDF on LONI for details
#'   \item AVID_STAGE_4_GLOBAL_SUVR N Florbetapir (AV45) ratio (cortical grey matter/whole cerebellum), using Avid semi-automated quantification method Average six region SUVr normalized by entire cerebellmu for florbetapir (AV-45) images calcualted using AVID semi-automated quantification. Refer to sPAP_Avid_Florbetapir_Analysis_Methods PDF on LONI for details
#'   \item AVID_STAGE_4_FRONTAL_MEDIAL_ORBITAL_SUVR N av45 uptake in cortical grey matter medial orbital frontal normalized to entire cerebellum using Avid semi-automated method. Refer to sPAP_Avid_Florbetapir_Analysis_Methods PDF on LONI for details
#'   \item AVID_STAGE_4_TEMPORAL_SUVR N av45 uptake in cortical grey matter lateral temporal normalized to entire cerebellum using Avid semi-automated method. Refer to sPAP_Avid_Florbetapir_Analysis_Methods PDF on LONI for details
#'   \item AVID_STAGE_4_PARIETAL_SUVR N av45 uptake in cortical grey matter parietal normalized to entire cerebellum using Avid semi-automated method. Refer to sPAP_Avid_Florbetapir_Analysis_Methods PDF on LONI for details
#'   \item AVID_STAGE_4_PRECUNEUS_SUVR N av45 uptake in cortical grey matter precuneus normalized to entire cerebellum using Avid semi-automated method. Refer to sPAP_Avid_Florbetapir_Analysis_Methods PDF on LONI for details
#'   \item AVID_STAGE_4_ANTERIOR_CINGULATE_SUVR N av45 uptake in cortical grey matter anterior cingulate normalized to entire cerebellum using Avid semi-automated method. Refer to sPAP_Avid_Florbetapir_Analysis_Methods PDF on LONI for details
#'   \item AVID_STAGE_4_POSTERIOR_CINGULATE_SUVR N av45 uptake in cortical grey matter s
#' }
#'
#' @examples
#' \donotrun{
#' describe(spap_avid_florbetapir)
#' }
#' @docType data
#' @keywords datasets
#' @name spap_avid_florbetapir
#' @usage data(spap_avid_florbetapir)
#' @format A data frame with 604 rows and 19 variables
NULL

#' Study Partner Consent
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item SPID N NA Study Partner ID Number:
#'   \item SPINCDATE D YYYY-MM-DD Date of consent:
#'   \item SPPROTVERSN T NA Indicate Version of Protocol
#'   \item SPCONSVERSN N NA Indicate Coordinating Center consent template version signed:  
#'   \item SPIRB D YYYY-MM-DD Consent IRB approval date:
#'   \item SPIRBEXPDT D YYYY-MM-DD Consent IRB expiration date:
#'   \item SPSITEVRS T NA Site version of consent:  
#'   \item SPCTCOMM T NA Comments:
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' \donotrun{
#' describe(spconsent)
#' }
#' @docType data
#' @keywords datasets
#' @name spconsent
#' @usage data(spconsent)
#' @format A data frame with 520 rows and 14 variables
NULL

#' Study Partner Information
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item INFSPID N NA Study Partner ID Number:
#'   \item INFRELAT N NA Relationship of the study partner to the participant
#'   \item INFOTHER T NA If Paid caregiver or Other, specify:
#'   \item INFGENDER N NA Gender of study partner
#'   \item INFAGE N NA Is study partner 90 or older?
#'   \item INFAGESP N NA If No, age of study partner:
#'   \item INFLIVE N NA Do the study partner and participant live together?
#'   \item INFHRS N NA How many hours per week does the study partner spend with the participant in-person?
#'   \item INFHRSOT N NA Other than in-person, how many hours per week does the study partner spend interacting with the participant?
#'   \item COMM T NA Comments:
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' \donotrun{
#' describe(spinfo)
#' }
#' @docType data
#' @keywords datasets
#' @name spinfo
#' @usage data(spinfo)
#' @format A data frame with 525 rows and 17 variables
NULL

#' Stroke Summary
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N -4 Participant roster ID
#'   \item VISCODE T -4 Visit code
#'   \item EXAMDATE D -4 Examination Date
#'   \item SIDE N -4 Side
#'   \item SIZE N -4 Size
#'   \item STROKEFORM N -4 Stroke number (1-100)
#'   \item ANATOMTER N -4 Anatomical Territory
#'   \item STROKETYPE T -4 Stoke type
#'   \item LOCATIONXYZ T -4 Location (xyz coordinate)
#'   \item WHITMATHYP T -4 White matter hyperintensivity volume -- whole brain.
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name strokesum
#' @usage data(strokesum)
#' @format A data frame with 3648 rows and 11 variables
NULL

#' Study Summary
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item SDSTATUS N NA Final disposition
#'   \item SDDATE D YYYY-MM-DD Final ADNI3 disposition date
#'   \item INCLUSION N NA Never enrolled due to: Failing to meet Inclusion Criteria
#'   \item EXCLUSION N NA Never enrolled due to: Meeting Exclusion Criteria
#'   \item VERSION N NA Indicate version of criteria evaluated:
#'   \item INCROLL T NA If Never enrolled due to failing Inclusion Criteria select criteria:
#'   \item INCNEWPT T NA If Never enrolled due to failing Inclusion Criteria select criteria:
#'   \item EXCCRIT T NA If Never enrolled due to meeting Exclusion Criteria select criteria:
#'   \item MRIFIND N NA Never enrolled due to: MRI finding(s) other than those listed in Exclusion Criteria
#'   \item NVRDISC N NA Never enrolled due to: Discontinuation (e.g. consent withdrawal, lost to follow-up)
#'   \item NVROT N NA Never enrolled due to Other reason(s)
#'   \item NVRSPECIFY T NA If Other, specify
#'   \item SDPRIMARY N NA Primary reason for early discontinuation of study visits
#'   \item SDPRIMOTH T NA If Other, specify:
#'   \item SDPRIMAE N NA If Adverse Event, provide Adverse Event number
#'   \item SDSECOND N NA Were there other contributing reason(s) for early discontinuation of study visits?
#'   \item SDSECREAS N NA If Yes, select other contributing reason(s) for early discontinuation of study visits:
#'   \item SDOTHSPE T NA If Other, specify:
#'   \item AENUM T NA If Adverse Event, provide Adverse Event number
#'   \item SDDETAILS T NA Please detail the circumstances leading to this final disposition
#'   \item SDCOMM T NA Comments
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name studysum
#' @usage data(studysum)
#' @format A data frame with 79 rows and 28 variables
NULL

#' Participant Registration
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item PTTYPE N NA Indicate Participant Type
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' \donotrun{
#' describe(subject)
#' }
#' @docType data
#' @keywords datasets
#' @name subject
#' @usage data(subject)
#' @format A data frame with 870 rows and 8 variables
NULL

#' Tau AV-1451 PET Scan Information
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item NDSPECIFY T NA If Other, specify
#'   \item QCTIME T HHMM Time of today's Scanner QC
#'   \item ASSAYTIME T HHMM Time of AV-1451 dose assay
#'   \item INJTIME T HHMM Time of AV-1451 injection
#'   \item SCANTIME T HHMM Emission Scan Start Time
#'   \item SCANDIFF T NA If scan start time is not 75-77 min post-injection, provide explanation
#'   \item VARIAT N NA Any variations from protocol during AV-1451 uptake?
#'   \item VARIATSPEC T NA If Yes, describe
#'   \item PROTID T NA Predefined Acquisition Protocol Name
#'   \item MOTION N NA Participant motion problems
#'   \item OTHERVAR N NA Other protocol variations
#'   \item RECON N NA Select reconstruction used
#'   \item SHARP N NA For Phillips scanners:  was "smooth" parameter set to "sharp"?
#'   \item ARCHIVE N NA Data archived locally?
#'   \item LONI N NA Data transferred to LONI?
#'   \item TRANDATE D YYYY-MM-DD Transfer Date
#'   \item COMM T NA Comments
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#'   \item RECNO N  
#'   \item DONE N  Was scan conducted?
#'   \item NDREASON N  If No, reason not done:
#'   \item RADTRACER N  If No, was radiotracer administered?
#'   \item SCANDATE D  Scan Date/Dose Date
#'   \item TAUQCTIME T HHMM Time of today's Scanner QC
#'   \item TAUDOSE N mCi AV-1451 dose assay
#'   \item TAUTIME T HHMM Time of AV-1451 dose assay
#'   \item TAUINJTIME T HHMM Time of AV-1451 injection
#'   \item TAUSCANTM T HHMM Emission Scan Start Time
#'   \item TAUVARIAT N  Any variations from protocol during AV-1451 uptake?
#'   \item TAUVARSP T  If Yes, describe:
#'   \item TAUSCANDIF T  If scan start time is not between 73 and 77 min post-injection, provide explanation
#'   \item TAUPROTID T  Predefined Acquisition Protocol Name
#'   \item TAUFRAME N  For the acquisition, which framing rate was used?
#'   \item TAUFRAMESP T  If other, specify
#'   \item TAUMOTION N  Participant motion problems:
#'   \item TAUOTHER N  Other protocol variations:
#'   \item TAUARCHIVE N  Data archived locally?
#'   \item TAULONI N  Data transferred to LONI?
#'   \item TAUTRANDT D  Transfer Date
#'   \item TAURECON N  Check which of the following reconstructions was used:
#'   \item TAURAMLA N  Lambda
#'   \item TAUSHARP T  Was "Smooth" parameter set to "Sharp"?
#'   \item TAUSMOOTH T  Was post-process smoothing performed:
#'   \item TAUCOMM T  Comments:
#' }
#'
#' @examples
#' \donotrun{
#' describe(taumeta)
#' }
#' @docType data
#' @keywords datasets
#' @name taumeta
#' @usage data(taumeta)
#' @format A data frame with 435 rows and 50 variables
NULL

#' Tau AV-1451 Follow-up Phone Contact
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#'   \item DONE N  Was assessment/procedure done?
#'   \item NDREASON N  If No, reason not done:
#'   \item TAUPHONEDT D MM/DD/YYYY Date Completed:
#'   \item TAUPHONETM T HHMM Time Completed:
#'   \item TAUPHONEAE N  Were any Advere Events reported?
#'   \item TAUCOMM T  Comments
#' }
#'
#' @examples
#' \donotrun{
#' describe(tauphone)
#' }
#' @docType data
#' @keywords datasets
#' @name tauphone
#' @usage data(tauphone)
#' @format A data frame with 121 rows and 13 variables
NULL

#' Tau AV-1451 PET QC
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item REVDT D YYYY-MM-DD Date Reviewed
#'   \item ALLFRAME N NA Were all frames acceptable?
#'   \item UNUSABL T NA If No, indicate which frames were unacceptable
#'   \item UNRSN N NA If No, indicate why frames were unacceptable
#'   \item UNRSNSPEC T NA If Other, Specify
#'   \item PROCERR T NA If Yes, select processing error(s)
#'   \item PROCERRSPEC T NA If Other, Specify
#'   \item COMM T NA Comments
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#'   \item RECNO N  
#'   \item SCANDATE D MM/DD/YYYY Scan Date:
#'   \item LONIUPDT D MM/DD/YYYY Date uploaded to LONI
#'   \item LONIUID T  LONI Unique Series ID
#'   \item TAUREVDT D MM/DD/YYYY Date Reviewed:
#'   \item TAUALLFRM N  Were all frames acceptable?
#'   \item TAUUNUSABL T  If No, indicate which frames were unacceptable?
#'   \item TAUUNRSN N  If No, indicate why frames were unacceptable:
#'   \item TAUUNRSNSP T  If Other, Specify:
#'   \item SCANQLTY N  Scan Pass QC?
#'   \item TECHERR N  If No, was this due to technologist error?
#'   \item RESCANREQ N  Rescan requested?
#'   \item REPROCREQ N  Reprocessing requested?
#'   \item TAUPROERR T  If Yes, select processing error(s):
#'   \item TAUERRSP T  If Other, Specify:
#'   \item TAUCOMM T  Comments:
#' }
#'
#' @examples
#' \donotrun{
#' describe(tauqc)
#' }
#' @docType data
#' @keywords datasets
#' @name tauqc
#' @usage data(tauqc)
#' @format A data frame with 403 rows and 31 variables
NULL

#' Paul Thompson's Lab, Imaging Genetics Center (IGC), University of Southern California - Cross-sectional and longitudinal tensor-based morphometry Versions 2.0 and 2.1
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/TBM/ADNI_Methods_TBM_IGC_LONI_Oct2012.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item COLPROT -4 -4 Study protocol of data collection
#'   \item RID -4 -4 Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item EXAMDATE -4 -4 Examination Date
#'   \item VERSION -4 -4 -4
#'   \item IMAGEUID_1 -4 -4 IMAGE ID of the screening scan
#'   \item IMAGEUID_2 -4 -4 IMAGE ID of the follow-up scan; see VISCODE
#'   \item FIELD.STRENGTH -4 -4 -4
#'   \item RUNDATE -4 -4 -4
#'   \item STATUS -4 -4 -4
#'   \item MEASURE_1 -4 -4 Numerical summary of cumulative temporal lobe atrophy  average within a statistically defined region-of-interest (p&lt;0.00001) inside the temporal lobes; see VISCODE; summaries are scaled by 1000 (e.g. 1000: no change, 1200: 20% increase, 800: 20% loss)
#'   \item MEASURE_2 -4 -4 Numerical summary of cumulative temporal lobe atrophy  average within an anatomically defined region-of-interest including bilateral temporal lobes; see VISCODE; summaries are scaled by 1000 (e.g. 1000: no change, 1200: 20% increase, 800: 20% loss)
#'   \item SEQUENCE -4 -4 -4
#'   \item ACCEL.NONACCEL -4 -4 -4
#'   \item DESCRIPTION -4 -4 -4
#'   \item ACQUISITION -4 -4 -4
#' }
#'
#' @examples
#' \donotrun{
#' describe(tbm)
#' }
#' @docType data
#' @keywords datasets
#' @name tbm
#' @usage data(tbm)
#' @format A data frame with 6913 rows and 17 variables
NULL

#' Total Cranial Vault Segmentation 
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/TCV/TCVGradeSheet.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4  Participant roster ID
#'   \item VISCODE -4  Visit code
#'   \item EXAMDATE -4  Examination Date
#'   \item LONIUID -4  Study ID
#'   \item RUNDATE -4  Run Date
#'   \item STATUS -4  Status
#'   \item VERSION -4  Version Number
#'   \item T2TCV -4 cc T2 Total Intracranial Volume
#'   \item GRADE -4  Grade
#' }
#'
#' @examples
#' \donotrun{
#' describe(tcv)
#' }
#' @docType data
#' @keywords datasets
#' @name tcv
#' @usage data(tcv)
#' @format A data frame with 810 rows and 10 variables
NULL

#' TOMM40 PolyT variable length polymorphism
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N NA Participant roster ID
#'   \item TOMM40ALLELE1 N NA 
#'   \item TOMM40ALLELE2 N NA 
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name tomm40
#' @usage data(tomm40)
#' @format A data frame with 757 rows and 4 variables
NULL

#' Participant Transfers
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#'   \item RECNO N  
#'   \item PTTYPE N  Type of transfer
#'   \item SITEIDA T  Site conducting visits PRIOR to transfer:
#'   \item PTPVISIT T  Visits conducted prior to transfer:
#'   \item SITEIDB T  Site conducting visits AFTER transfer:
#'   \item SITEIDTMP T  Temporary site:
#'   \item PTTVISIT T  Visit(s) conducted at site:
#'   \item PTREASON T  Reason for Transfer:
#'   \item PTCOMM T  Comments:
#' }
#'
#' @examples
#' \donotrun{
#' describe(transfer)
#' }
#' @docType data
#' @keywords datasets
#' @name transfer
#' @usage data(transfer)
#' @format A data frame with 33 rows and 16 variables
NULL

#' Early Discontinuation and Withdrawal
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RECNO N  
#'   \item WDBURDEN T NA If Participant or Study Partner Burden selected, indicate items reported to be most burdensome:
#'   \item WDDETAILS T NA Detailed Description:
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item EXAMDATE D  Examination Date
#'   \item WDRAWTYPE N  1. Is this a Full or Partial Withdrawal or Completion of ADNI 1, not continuing to extension protocol?
#'   \item WDPARTIAL T  If Partial, what is the participant withdrawing from?
#'   \item WDREASON T  Reason for Withdrawal
#'   \item WDPARTCOM T  Please provide any additional information regarding the withdrawal.  If individual procedures are being discontinued for different reasons, please provide an explanation.
#'   \item WDFOLLOWUP T  2. Follow-up:  (check all that apply)
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name treatdis
#' @usage data(treatdis)
#' @format A data frame with 1656 rows and 16 variables
NULL

#' UA (Gene Alexander) MRI SPM voxel based morphometry (VBM) analysis
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item RECNO N  
#'   \item EXAMDATE D  Examination Date
#'   \item IMAGEUID N  imageUID
#'   \item FLDSTRENG N  Field Strength
#'   \item PRECENTL N Mean Gray Matter Precentral_L. 1) Mean gray matter values extracted from 1.5T ADNI MPRAGE MRI segmented gray matter maps using longitudinal voxel based morphometry (VBM) processing steps (Chetelat et al., Neuroimage, 2005, 27:934-946) adapted for SPM5 with customized tissue-specific priors derived from a representative sample of 300 ADNI subjects (ADNI300). The regions of interest (ROI) were defined by Anatomical Automatic Labeling (AAL, Tzourio-Mazoyer et al., Neuroimage, 2002, 15:273-89, http://www.cyceron.fr/freeware/) after warping the standard AAL ROI template into the customized sample-specific ADNI300 template space. The ADNI300-customized AAL ROI template was applied to spatially normalized and segmented SPM5 gray matter maps for the longitudinal VBM generated baseline and 6 month (indicated by RECNO=2) or 12 month (indicated by RECNO=3) follow up scans without Gaussian smoothing to reduce averaging across regional borders. 2) The ADNI300 template was created from AD, MCI, and Normal subjects proportional to the distribution of these subject groups enrolled in the whole ADNI study and the groups were matched in age and gender.  3) Regional values will be subject to change due to study alterations in image pre- or post-processing, inclusion of additional analysis time points, and/or modifications or updates in image analysis procedures. 4) SPM analyses were performed by ADNI Analysis Team Members: Gene E. Alexander, Ph.D., Kewei Chen, Ph.D., and Eric M. Reiman, M.D.
#'   \item PRECENTR N  Precentral_R
#'   \item FRONTSUPL N  Frontal_Sup_L
#'   \item FRONTSUPR N  Frontal_Sup_R
#'   \item FRONTSORBL N  Frontal_Sup_Orb_L
#'   \item FRONTSORBR N  Frontal_Sup_Orb_R
#'   \item FRONTMIDL N  Frontal_Mid_L
#'   \item FRONTMIDR N  Frontal_Mid_R
#'   \item FRTMIDORBL N  Frontal_Mid_Orb_L
#'   \item FRTMIDORBR N  Frontal_Mid_Orb_R
#'   \item FRONTINOPL N  Frontal_Inf_Oper_L
#'   \item FRONTINOPR N  Frontal_Inf_Oper_R
#'   \item FRONTINTRL N  Frontal_Inf_Tri_L
#'   \item FRONTINTRR N  Frontal_Inf_Tri_R
#'   \item FRONTINOBL N  Frontal_Inf_Orb_L
#'   \item FRONTINOBR N  Frontal_Inf_Orb_R
#'   \item ROLANDOPL N  Rolandic_Oper_L
#'   \item ROLANDOPR N  Rolandic_Oper_R
#'   \item SUPMOTORL N  Supp_Motor_Area_L
#'   \item SUPMOTORR N  Supp_Motor_Area_R
#'   \item OLFACTL N  Olfactory_L
#'   \item OLFACTR N  Olfactory_R
#'   \item FRONTSMEDL N  Frontal_Sup_Medial_L
#'   \item FRONTSMEDR N  Frontal_Sup_Medial_R
#'   \item FRTMEDORBL N  Frontal_Med_Orb_L
#'   \item FRTMEDORBR N  Frontal_Med_Orb_R
#'   \item RECTUSL N  Rectus_L
#'   \item RECTUSR N  Rectus_R
#'   \item INSULAL N  Insula_L
#'   \item INSULAR N  Insula_R
#'   \item CINGANTL N  Cingulum_Ant_L
#'   \item CINGANTR N  Cingulum_Ant_R
#'   \item CINGMIDL N  Cingulum_Mid_L
#'   \item CINGMIDR N  Cingulum_Mid_R
#'   \item CINGPOSTL N  Cingulum_Post_L
#'   \item CINGPOSTR N  Cingulum_Post_R
#'   \item HIPPL N  Hippocampus_L
#'   \item HIPPR N  Hippocampus_R
#'   \item PARAHIPPL N  ParaHippocampal_L
#'   \item PARAHIPPR N  
#'   \item AMYGDL N  
#'   \item AMYGDR N  Amygdala_R
#'   \item CALCARINEL N  Calcarine_L
#'   \item CALCARINER N  Calcarine_R
#'   \item CUNEUSL N  
#'   \item CUNEUSR N  
#'   \item LINGUALL N  
#'   \item LINGUALR N  
#'   \item OCCSUPL N  
#'   \item OCCSUPR N  
#'   \item OCCMIDL N  
#'   \item OCCMIDR N  
#'   \item OCCINFL N  
#'   \item OCCINFR N  
#'   \item FUSIFORML N  
#'   \item FUSIFORMR N  
#'   \item POSTCENTL N  
#'   \item POSTCENTR N  
#'   \item PARIETSUPL N  
#'   \item PARIETSUPR N  
#'   \item PARIETINFL N  
#'   \item PARIETINFR N  
#'   \item SUPRAMARGL N  
#'   \item SUPRAMARGR N  
#'   \item ANGULARL N  
#'   \item ANGULARR N  
#'   \item PRECUNEUSL N  
#'   \item PRECUNEUSR N  
#'   \item PARCENTLBL N  
#'   \item PARCENTLBR N  
#'   \item CAUDATEL N  
#'   \item CAUDATER N  
#'   \item PUTAMENL N  
#'   \item PUTAMENR N  
#'   \item PALLIDUML N  
#'   \item PALLIDUMR N  
#'   \item THALAMUSL N  
#'   \item THALAMUSR N  
#'   \item HESCHLL N  
#'   \item HESCHLR N  
#'   \item TEMPSUPL N  
#'   \item TEMPSUPR N  
#'   \item TEMPPLSUPL N  
#'   \item TEMPPLSUPR N  
#'   \item TEMPMIDL N  
#'   \item TEMPMIDR N  
#'   \item TEMPPLMIDL N  
#'   \item TEMPPLMIDR N  
#'   \item TEMPINFL N  
#'   \item TEMPINFR N  
#'   \item CEREBCR1L N  
#'   \item CEREBCR1R N  
#'   \item CEREBCR2L N  
#'   \item CEREBCR2R N  
#'   \item CEREB3L N  
#'   \item CEREB3R N  
#'   \item CEREB45L N  
#'   \item CEREB45R N  
#'   \item CEREB6L N  
#'   \item CEREB6R N  
#'   \item CEREB7BL N  
#'   \item CEREB7BR N  
#'   \item CEREB8L N  
#'   \item CEREB8R N  
#'   \item CEREB9L N  
#'   \item CEREB9R N  
#'   \item CEREB10L N  
#'   \item CEREB10R N  
#'   \item VERMIS12 N  
#'   \item VERMIS3 N  
#'   \item VERMIS45 N  
#'   \item VERMIS6 N  
#'   \item VERMIS7 N  
#'   \item VERMIS8 N  
#'   \item VERMIS9 N  
#'   \item VERMIS10 N  
#'   \item ETIV N  
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name uaspmvbm
#' @usage data(uaspmvbm)
#' @format A data frame with 4091 rows and 126 variables
NULL

#' UC Berkeley - AV1451 analysis
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID T  Participant roster ID
#'   \item VISCODE T  Visit code
#'   \item VISCODE2 T  Translated visit code
#'   \item EXAMDATE D  Examination Date
#'   \item BRAAK1 N av1451 uptake - reference region Braak region 1
#'   \item BRAAK1_SIZE N mm^3 Braak region 1 ROI size in mm^3
#'   \item BRAAK2 N av1451 uptake - reference region Braak region 2
#'   \item BRAAK2_SIZE N mm^3 Braak region 2 ROI size in mm^3
#'   \item BRAAK3 N av1451 uptake - subregion Braak region 3
#'   \item BRAAK3_SIZE N mm^3 Braak region 3 ROI size in mm^3
#'   \item BRAAK4 N av1451 uptake - subregion Braak region 4
#'   \item BRAAK4_SIZE N mm^3 Braak region 4 ROI size in mm^3
#'   \item BRAAK5 N av1451 uptake - subregion Braak region 5
#'   \item BRAAK5_SIZE N mm^3 Braak region 5 ROI size in mm^3
#'   \item BRAAK6 N av1451 uptake - subregion Braak region 6
#'   \item BRAAK6_SIZE N mm^3 Braak region 6 ROI size in mm^3
#'   \item CEREBGM N av1451 uptake - subregion Cerebellar grey matter
#'   \item CEREBGM_SIZE N mm^3 Cerebellar grey matter ROI size in mm^3
#'   \item CEREBWM N av1451 uptake - subregion Cerebellar white matter
#'   \item CEREBWM_SIZE N mm^3 Cerebellar white matter ROI size in mm^3
#'   \item BRAIN_STEM N av1451 uptake - subregion Brain stem 
#'   \item BRAIN_STEM_SIZE N mm^3 Brain stem ROI size in mm^3
#'   \item HEMIWM N av1451 uptake - subregion Hemispheric white matter
#'   \item HEMIWM_SIZE N mm^3 Hemispheric white matter ROI size in mm^3
#'   \item BONE N av1451 uptake - subregion Bone
#'   \item BONE_SIZE N mm^3 Bone ROI size in mm^3
#'   \item CSF_SA N av1451 uptake - subregion CSF 
#'   \item CSF_SA_SIZE N mm^3 CSF ROI size in mm^3
#'   \item SOFT_TISSUE N av1451 uptake - subregion Soft tissue
#'   \item SOFT_TISSUE_SIZE N mm^3 Soft tissue ROI size in mm^3
#'   \item LEFT_MIDDLEFR N av1451 uptake - subregion Left middle frontal ROI
#'   \item LEFT_MIDDLEFR_SIZE N mm^3 Left middle frontal ROI size in mm^3
#'   \item LEFT_ORBITOFR N av1451 uptake - subregion Left orbitofrontal ROI
#'   \item LEFT_ORBITOFR_SIZE N mm^3 Left orbitofrontal ROI size in mm^3
#'   \item LEFT_PARSFR N av1451 uptake - subregion Left pars frontal ROI
#'   \item LEFT_PARSFR_SIZE N mm^3 Left pars frontal ROI size in mm^3
#'   \item LEFT_ACCUMBENS_AREA N av1451 uptake - subregion left-accumbens-area
#'   \item LEFT_ACCUMBENS_AREA_SIZE N mm^3 left-accumbens-area ROI size in mm^3
#'   \item LEFT_AMYGDALA N av1451 uptake - subregion left-amygdala
#'   \item LEFT_AMYGDALA_SIZE N mm^3 left-amygdala ROI size in mm^3
#'   \item LEFT_CAUDATE N av1451 uptake - subregion left-caudate
#'   \item LEFT_CAUDATE_SIZE N mm^3 left-caudate ROI size in mm^3
#'   \item LEFT_HIPPOCAMPUS N av1451 uptake - subregion left-hippocampus
#'   \item LEFT_HIPPOCAMPUS_SIZE N mm^3 left-hippocampus ROI size in mm^3
#'   \item LEFT_PALLIDUM N av1451 uptake - subregion left-pallidum
#'   \item LEFT_PALLIDUM_SIZE N mm^3 left-pallidum ROI size in mm^3
#'   \item LEFT_PUTAMEN N av1451 uptake - subregion left-putamen
#'   \item LEFT_PUTAMEN_SIZE N mm^3 left-putamen ROI size in mm^3
#'   \item LEFT_THALAMUS_PROPER N av1451 uptake - subregion left-thalamus-proper
#'   \item LEFT_THALAMUS_PROPER_SIZE N mm^3 left-thalamus-proper ROI size in mm^3
#'   \item RIGHT_MIDDLEFR N av1451 uptake - subregion Right middle frontal ROI
#'   \item RIGHT_MIDDLEFR_SIZE N mm^3 Right middle frontal ROI size in mm^3
#'   \item RIGHT_ORBITOFR N av1451 uptake - subregion Right orbitofrontal ROI
#'   \item RIGHT_ORBITOFR_SIZE N mm^3 Right orbitofrontal ROI size in mm^3
#'   \item RIGHT_PARSFR N av1451 uptake - subregion Right pars frontal ROI
#'   \item RIGHT_PARSFR_SIZE N mm^3 Right pars frontal ROI size in mm^3
#'   \item RIGHT_ACCUMBENS_AREA N av1451 uptake - subregion right-accumbens-area
#'   \item RIGHT_ACCUMBENS_AREA_SIZE N mm^3 right-accumbens-area ROI size in mm^3
#'   \item RIGHT_AMYGDALA N av1451 uptake - subregion right-amygdala
#'   \item RIGHT_AMYGDALA_SIZE N mm^3 right-amygdala ROI size in mm^3
#'   \item RIGHT_CAUDATE N av1451 uptake - subregion right-caudate
#'   \item RIGHT_CAUDATE_SIZE N mm^3 right-caudate ROI size in mm^3
#'   \item RIGHT_HIPPOCAMPUS N av1451 uptake - subregion right-hippocampus
#'   \item RIGHT_HIPPOCAMPUS_SIZE N mm^3 right-hippocampus ROI size in mm^3
#'   \item RIGHT_PALLIDUM N av1451 uptake - subregion right-pallidum
#'   \item RIGHT_PALLIDUM_SIZE N mm^3 right-pallidum ROI size in mm^3
#'   \item RIGHT_PUTAMEN N av1451 uptake - subregion right-putamen
#'   \item RIGHT_PUTAMEN_SIZE N mm^3 right-putamen ROI size in mm^3
#'   \item RIGHT_THALAMUS_PROPER N av1451 uptake - subregion right-thalamus-proper
#'   \item RIGHT_THALAMUS_PROPER_SIZE N mm^3 right-thalamus-proper ROI size in mm^3
#'   \item CHOROID N av1451 uptake - subregion Bilateral choroid plexus
#'   \item CHOROID_SIZE N mm^3 Bilateral choroid plexus ROI size in mm^3
#'   \item CTX_LH_BANKSSTS N av1451 uptake - subregion ctx-lh-bankssts
#'   \item CTX_LH_BANKSSTS_SIZE N mm^3 ctx-lh-bankssts ROI size in mm^3
#'   \item CTX_LH_CAUDALANTERIORCINGULATE N av1451 uptake - subregion ctx-lh-caudalanteriorcingulate
#'   \item CTX_LH_CAUDALANTERIORCINGULATE_SIZE N mm^3 ctx-lh-caudalanteriorcingulate ROI size in mm^3
#'   \item CTX_LH_CUNEUS N av1451 uptake - subregion ctx-lh-cuneus
#'   \item CTX_LH_CUNEUS_SIZE N mm^3 ctx-lh-cuneus ROI size in mm^3
#'   \item CTX_LH_ENTORHINAL N av1451 uptake - subregion ctx-lh-entorhinal
#'   \item CTX_LH_ENTORHINAL_SIZE N mm^3 ctx-lh-entorhinal ROI size in mm^3
#'   \item CTX_LH_FUSIFORM N av1451 uptake - subregion ctx-lh-fusiform
#'   \item CTX_LH_FUSIFORM_SIZE N mm^3 ctx-lh-fusiform ROI size in mm^3
#'   \item CTX_LH_INFERIORPARIETAL N av1451 uptake - subregion ctx-lh-inferiorparietal
#'   \item CTX_LH_INFERIORPARIETAL_SIZE N mm^3 ctx-lh-inferiorparietal ROI size in mm^3
#'   \item CTX_LH_INFERIORTEMPORAL N av1451 uptake - subregion ctx-lh-inferiortemporal
#'   \item CTX_LH_INFERIORTEMPORAL_SIZE N mm^3 ctx-lh-inferiortemporal ROI size in mm^3
#'   \item CTX_LH_INSULA N av1451 uptake - subregion ctx-lh-insula
#'   \item CTX_LH_INSULA_SIZE N mm^3 ctx-lh-insula ROI size in mm^3
#'   \item CTX_LH_ISTHMUSCINGULATE N av1451 uptake - subregion ctx-lh-isthmuscingulate
#'   \item CTX_LH_ISTHMUSCINGULATE_SIZE N mm^3 ctx-lh-isthmuscingulate ROI size in mm^3
#'   \item CTX_LH_LATERALOCCIPITAL N av1451 uptake - subregion ctx-lh-lateraloccipital
#'   \item CTX_LH_LATERALOCCIPITAL_SIZE N mm^3 ctx-lh-lateraloccipital ROI size in mm^3
#'   \item CTX_LH_LINGUAL N av1451 uptake - subregion ctx-lh-lingual
#'   \item CTX_LH_LINGUAL_SIZE N mm^3 ctx-lh-lingual ROI size in mm^3
#'   \item CTX_LH_MIDDLETEMPORAL N av1451 uptake - subregion ctx-lh-middletemporal
#'   \item CTX_LH_MIDDLETEMPORAL_SIZE N mm^3 ctx-lh-middletemporal ROI size in mm^3
#'   \item CTX_LH_PARACENTRAL N av1451 uptake - subregion ctx-lh-paracentral
#'   \item CTX_LH_PARACENTRAL_SIZE N mm^3 ctx-lh-paracentral ROI size in mm^3
#'   \item CTX_LH_PARAHIPPOCAMPAL N av1451 uptake - subregion ctx-lh-parahippocampal
#'   \item CTX_LH_PARAHIPPOCAMPAL_SIZE N mm^3 ctx-lh-parahippocampal ROI size in mm^3
#'   \item CTX_LH_PERICALCARINE N av1451 uptake - subregion ctx-lh-pericalcarine
#'   \item CTX_LH_PERICALCARINE_SIZE N mm^3 ctx-lh-pericalcarine ROI size in mm^3
#'   \item CTX_LH_POSTCENTRAL N av1451 uptake - subregion ctx-lh-postcentral
#'   \item CTX_LH_POSTCENTRAL_SIZE N mm^3 ctx-lh-postcentral ROI size in mm^3
#'   \item CTX_LH_POSTERIORCINGULATE N av1451 uptake - subregion ctx-lh-posteriorcingulate
#'   \item CTX_LH_POSTERIORCINGULATE_SIZE N mm^3 ctx-lh-posteriorcingulate ROI size in mm^3
#'   \item CTX_LH_PRECENTRAL N av1451 uptake - subregion ctx-lh-precentral
#'   \item CTX_LH_PRECENTRAL_SIZE N mm^3 ctx-lh-precentral ROI size in mm^3
#'   \item CTX_LH_PRECUNEUS N av1451 uptake - subregion ctx-lh-precuneus
#'   \item CTX_LH_PRECUNEUS_SIZE N mm^3 ctx-lh-precuneus ROI size in mm^3
#'   \item CTX_LH_ROSTRALANTERIORCINGULATE N av1451 uptake - subregion ctx-lh-rostralanteriorcingulate
#'   \item CTX_LH_ROSTRALANTERIORCINGULATE_SIZE N mm^3 ctx-lh-rostralanteriorcingulate ROI size in mm^3
#'   \item CTX_LH_SUPERIORFRONTAL N av1451 uptake - subregion ctx-lh-superiorfrontal
#'   \item CTX_LH_SUPERIORFRONTAL_SIZE N mm^3 ctx-lh-superiorfrontal ROI size in mm^3
#'   \item CTX_LH_SUPERIORPARIETAL N av1451 uptake - subregion ctx-lh-superiorparietal
#'   \item CTX_LH_SUPERIORPARIETAL_SIZE N mm^3 ctx-lh-superiorparietal ROI size in mm^3
#'   \item CTX_LH_SUPERIORTEMPORAL N av1451 uptake - subregion ctx-lh-superiortemporal
#'   \item CTX_LH_SUPERIORTEMPORAL_SIZE N mm^3 ctx-lh-superiortemporal ROI size in mm^3
#'   \item CTX_LH_SUPRAMARGINAL N av1451 uptake - subregion ctx-lh-supramarginal
#'   \item CTX_LH_SUPRAMARGINAL_SIZE N mm^3 ctx-lh-supramarginal ROI size in mm^3
#'   \item CTX_LH_TEMPORALPOLE N av1451 uptake - subregion ctx-lh-temporalpole
#'   \item CTX_LH_TEMPORALPOLE_SIZE N mm^3 ctx-lh-temporalpole ROI size in mm^3
#'   \item CTX_LH_TRANSVERSETEMPORAL N av1451 uptake - subregion ctx-lh-transversetemporal
#'   \item CTX_LH_TRANSVERSETEMPORAL_SIZE N mm^3 ctx-lh-transversetemporal ROI size in mm^3
#'   \item CTX_RH_BANKSSTS N av1451 uptake - subregion ctx-rh-bankssts
#'   \item CTX_RH_BANKSSTS_SIZE N mm^3 ctx-rh-bankssts ROI size in mm^3
#'   \item CTX_RH_CAUDALANTERIORCINGULATE N av1451 uptake - subregion ctx-rh-caudalanteriorcingulate
#'   \item CTX_RH_CAUDALANTERIORCINGULATE_SIZE N mm^3 ctx-rh-caudalanteriorcingulate ROI size in mm^3
#'   \item CTX_RH_CUNEUS N av1451 uptake - subregion ctx-rh-cuneus
#'   \item CTX_RH_CUNEUS_SIZE N mm^3 ctx-rh-cuneus ROI size in mm^3
#'   \item CTX_RH_ENTORHINAL N av1451 uptake - subregion ctx-rh-entorhinal
#'   \item CTX_RH_ENTORHINAL_SIZE N mm^3 ctx-rh-entorhinal ROI size in mm^3
#'   \item CTX_RH_FUSIFORM N av1451 uptake - subregion ctx-rh-fusiform
#'   \item CTX_RH_FUSIFORM_SIZE N mm^3 ctx-rh-fusiform ROI size in mm^3
#'   \item CTX_RH_INFERIORPARIETAL N av1451 uptake - subregion ctx-rh-inferiorparietal
#'   \item CTX_RH_INFERIORPARIETAL_SIZE N mm^3 ctx-rh-inferiorparietal ROI size in mm^3
#'   \item CTX_RH_INFERIORTEMPORAL N av1451 uptake - subregion ctx-rh-inferiortemporal
#'   \item CTX_RH_INFERIORTEMPORAL_SIZE N mm^3 ctx-rh-inferiortemporal ROI size in mm^3
#'   \item CTX_RH_INSULA N av1451 uptake - subregion ctx-rh-insula
#'   \item CTX_RH_INSULA_SIZE N mm^3 ctx-rh-insula ROI size in mm^3
#'   \item CTX_RH_ISTHMUSCINGULATE N av1451 uptake - subregion ctx-rh-isthmuscingulate
#'   \item CTX_RH_ISTHMUSCINGULATE_SIZE N mm^3 ctx-rh-isthmuscingulate ROI size in mm^3
#'   \item CTX_RH_LATERALOCCIPITAL N av1451 uptake - subregion ctx-rh-lateraloccipital
#'   \item CTX_RH_LATERALOCCIPITAL_SIZE N mm^3 ctx-rh-lateraloccipital ROI size in mm^3
#'   \item CTX_RH_LINGUAL N av1451 uptake - subregion ctx-rh-lingual
#'   \item CTX_RH_LINGUAL_SIZE N mm^3 ctx-rh-lingual ROI size in mm^3
#'   \item CTX_RH_MIDDLETEMPORAL N av1451 uptake - subregion ctx-rh-middletemporal
#'   \item CTX_RH_MIDDLETEMPORAL_SIZE N mm^3 ctx-rh-middletemporal ROI size in mm^3
#'   \item CTX_RH_PARACENTRAL N av1451 uptake - subregion ctx-rh-paracentral
#'   \item CTX_RH_PARACENTRAL_SIZE N mm^3 ctx-rh-paracentral ROI size in mm^3
#'   \item CTX_RH_PARAHIPPOCAMPAL N av1451 uptake - subregion ctx-rh-parahippocampal
#'   \item CTX_RH_PARAHIPPOCAMPAL_SIZE N mm^3 ctx-rh-parahippocampal ROI size in mm^3
#'   \item CTX_RH_PERICALCARINE N av1451 uptake - subregion ctx-rh-pericalcarine
#'   \item CTX_RH_PERICALCARINE_SIZE N mm^3 ctx-rh-pericalcarine ROI size in mm^3
#'   \item CTX_RH_POSTCENTRAL N av1451 uptake - subregion ctx-rh-postcentral
#'   \item CTX_RH_POSTCENTRAL_SIZE N mm^3 ctx-rh-postcentral ROI size in mm^3
#'   \item CTX_RH_POSTERIORCINGULATE N av1451 uptake - subregion ctx-rh-posteriorcingulate
#'   \item CTX_RH_POSTERIORCINGULATE_SIZE N mm^3 ctx-rh-posteriorcingulate ROI size in mm^3
#'   \item CTX_RH_PRECENTRAL N av1451 uptake - subregion ctx-rh-precentral
#'   \item CTX_RH_PRECENTRAL_SIZE N mm^3 ctx-rh-precentral ROI size in mm^3
#'   \item CTX_RH_PRECUNEUS N av1451 uptake - subregion ctx-rh-precuneus
#'   \item CTX_RH_PRECUNEUS_SIZE N mm^3 ctx-rh-precuneus ROI size in mm^3
#'   \item CTX_RH_ROSTRALANTERIORCINGULATE N av1451 uptake - subregion ctx-rh-rostralanteriorcingulate
#'   \item CTX_RH_ROSTRALANTERIORCINGULATE_SIZE N mm^3 ctx-rh-rostralanteriorcingulate ROI size in mm^3
#'   \item CTX_RH_SUPERIORFRONTAL N av1451 uptake - subregion ctx-rh-superiorfrontal
#'   \item CTX_RH_SUPERIORFRONTAL_SIZE N mm^3 ctx-rh-superiorfrontal ROI size in mm^3
#'   \item CTX_RH_SUPERIORPARIETAL N av1451 uptake - subregion ctx-rh-superiorparietal
#'   \item CTX_RH_SUPERIORPARIETAL_SIZE N mm^3 ctx-rh-superiorparietal ROI size in mm^3
#'   \item CTX_RH_SUPERIORTEMPORAL N av1451 uptake - subregion ctx-rh-superiortemporal
#'   \item CTX_RH_SUPERIORTEMPORAL_SIZE N mm^3 ctx-rh-superiortemporal ROI size in mm^3
#'   \item CTX_RH_SUPRAMARGINAL N av1451 uptake - subregion ctx-rh-supramarginal
#'   \item CTX_RH_SUPRAMARGINAL_SIZE N mm^3 ctx-rh-supramarginal ROI size in mm^3
#'   \item CTX_RH_TEMPORALPOLE N av1451 uptake - subregion ctx-rh-temporalpole
#'   \item CTX_RH_TEMPORALPOLE_SIZE N mm^3 ctx-rh-temporalpole ROI size in mm^3
#'   \item CTX_RH_TRANSVERSETEMPORAL N av1451 uptake - subregion ctx-rh-transversetemporal
#'   \item CTX_RH_TRANSVERSETEMPORAL_SIZE N mm^3 ctx-rh-transversetemporal ROI size in mm^3
#'   \item OTHER N av1451 uptake - subregion Other regions
#'   \item OTHER_SIZE N mm^3 Other regions size in mm^3
#' }
#'
#' @examples
#' \donotrun{
#' describe(ucberkeleyav1451_pvc)
#' }
#' @docType data
#' @keywords datasets
#' @name ucberkeleyav1451_pvc
#' @usage data(ucberkeleyav1451_pvc)
#' @format A data frame with 246 rows and 178 variables
NULL

#' UC Berkeley - AV1451 analysis
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/UCBERKELEYAV1451/UCBERKELEY_AV1451_Methods_03.02.16.pdf}, \url{https://adni.bitbucket.io/reference/docs/UCBERKELEYAV1451/UCBERKELEYAV1451_Methods_FINAL.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID T  Participant roster ID
#'   \item VISCODE T  Visit code
#'   \item VISCODE2 T  Translated visit code
#'   \item EXAMDATE D  Examination Date
#'   \item CEREBELLUMGREYMATTER N av1451 uptake - reference region Cerebellum grey matter
#'   \item CEREBELLUMGREYMATTER_SIZE N mm^3 Cerebellum grey matter ROI size in mm^3
#'   \item BRAAK1 N av1451 uptake - reference region Braak region 1
#'   \item BRAAK1_SIZE N mm^3 Braak region 1 ROI size in mm^3
#'   \item BRAAK2 N av1451 uptake - subregion Braak region 2
#'   \item BRAAK2_SIZE N mm^3 Braak region 2 ROI size in mm^3
#'   \item BRAAK3 N av1451 uptake - subregion Braak region 3
#'   \item BRAAK3_SIZE N mm^3 Braak region 3 ROI size in mm^3
#'   \item BRAAK4 N av1451 uptake - subregion Braak region 4
#'   \item BRAAK4_SIZE N mm^3 Braak region 4 ROI size in mm^3
#'   \item BRAAK5 N av1451 uptake - subregion Braak region 5
#'   \item BRAAK5_SIZE N mm^3 Braak region 5 ROI size in mm^3
#'   \item BRAAK6 N av1451 uptake - subregion Braak region 6
#'   \item BRAAK6_SIZE N mm^3 Braak region 6 ROI size in mm^3
#'   \item ERODED_SUBCORTICALWM N av1451 uptake - subregion subcortical WM eroded away from cortex
#'   \item ERODED_SUBCORTICALWM_SIZE N mm^3 subcortical WM eroded away from cortex in mm^3
#'   \item BRAINSTEM N av1451 uptake - subregion brain-stem
#'   \item BRAINSTEM_SIZE N mm^3 brain-stem ROI size in mm^3
#'   \item VENTRICLE_3RD N av1451 uptake - subregion 3rd-ventricle
#'   \item VENTRICLE_3RD_SIZE N mm^3 3rd-ventricle ROI size in mm^3
#'   \item VENTRICLE_4TH N av1451 uptake - subregion 4th-ventricle
#'   \item VENTRICLE_4TH_SIZE N mm^3 4th-ventricle ROI size in mm^3
#'   \item VENTRICLE_5TH N av1451 uptake - subregion 5th-ventricle
#'   \item VENTRICLE_5TH_SIZE N mm^3 5th-ventricle ROI size in mm^3
#'   \item CC_ANTERIOR N av1451 uptake - subregion cc-anterior
#'   \item CC_ANTERIOR_SIZE N mm^3 cc-anterior ROI size in mm^3
#'   \item CC_CENTRAL N av1451 uptake - subregion cc-central
#'   \item CC_CENTRAL_SIZE N mm^3 cc-central ROI size in mm^3
#'   \item CC_MID_ANTERIOR N av1451 uptake - subregion cc-mid-anterior
#'   \item CC_MID_ANTERIOR_SIZE N mm^3 cc-mid-anterior ROI size in mm^3
#'   \item CC_MID_POSTERIOR N av1451 uptake - subregion cc-mid-posterior
#'   \item CC_MID_POSTERIOR_SIZE N mm^3 cc-mid-posterior ROI size in mm^3
#'   \item CC_POSTERIOR N av1451 uptake - subregion cc-posterior
#'   \item CC_POSTERIOR_SIZE N mm^3 cc-posterior ROI size in mm^3
#'   \item CSF N av1451 uptake - subregion csf
#'   \item CSF_SIZE N mm^3 csf ROI size in mm^3
#'   \item CTX_LH_BANKSSTS N av1451 uptake - subregion ctx-lh-bankssts
#'   \item CTX_LH_BANKSSTS_SIZE N mm^3 ctx-lh-bankssts ROI size in mm^3
#'   \item CTX_LH_CAUDALANTERIORCINGULATE N av1451 uptake - subregion ctx-lh-caudalanteriorcingulate
#'   \item CTX_LH_CAUDALANTERIORCINGULATE_SIZE N mm^3 ctx-lh-caudalanteriorcingulate ROI size in mm^3
#'   \item CTX_LH_CAUDALMIDDLEFRONTAL N av1451 uptake - subregion ctx-lh-caudalmiddlefrontal
#'   \item CTX_LH_CAUDALMIDDLEFRONTAL_SIZE N mm^3 ctx-lh-caudalmiddlefrontal ROI size in mm^3
#'   \item CTX_LH_CUNEUS N av1451 uptake - subregion ctx-lh-cuneus
#'   \item CTX_LH_CUNEUS_SIZE N mm^3 ctx-lh-cuneus ROI size in mm^3
#'   \item CTX_LH_ENTORHINAL N av1451 uptake - subregion ctx-lh-entorhinal
#'   \item CTX_LH_ENTORHINAL_SIZE N mm^3 ctx-lh-entorhinal ROI size in mm^3
#'   \item CTX_LH_FRONTALPOLE N av1451 uptake - subregion ctx-lh-frontalpole
#'   \item CTX_LH_FRONTALPOLE_SIZE N mm^3 ctx-lh-frontalpole ROI size in mm^3
#'   \item CTX_LH_FUSIFORM N av1451 uptake - subregion ctx-lh-fusiform
#'   \item CTX_LH_FUSIFORM_SIZE N mm^3 ctx-lh-fusiform ROI size in mm^3
#'   \item CTX_LH_INFERIORPARIETAL N av1451 uptake - subregion ctx-lh-inferiorparietal
#'   \item CTX_LH_INFERIORPARIETAL_SIZE N mm^3 ctx-lh-inferiorparietal ROI size in mm^3
#'   \item CTX_LH_INFERIORTEMPORAL N av1451 uptake - subregion ctx-lh-inferiortemporal
#'   \item CTX_LH_INFERIORTEMPORAL_SIZE N mm^3 ctx-lh-inferiortemporal ROI size in mm^3
#'   \item CTX_LH_INSULA N av1451 uptake - subregion ctx-lh-insula
#'   \item CTX_LH_INSULA_SIZE N mm^3 ctx-lh-insula ROI size in mm^3
#'   \item CTX_LH_ISTHMUSCINGULATE N av1451 uptake - subregion ctx-lh-isthmuscingulate
#'   \item CTX_LH_ISTHMUSCINGULATE_SIZE N mm^3 ctx-lh-isthmuscingulate ROI size in mm^3
#'   \item CTX_LH_LATERALOCCIPITAL N av1451 uptake - subregion ctx-lh-lateraloccipital
#'   \item CTX_LH_LATERALOCCIPITAL_SIZE N mm^3 ctx-lh-lateraloccipital ROI size in mm^3
#'   \item CTX_LH_LATERALORBITOFRONTAL N av1451 uptake - subregion ctx-lh-lateralorbitofrontal
#'   \item CTX_LH_LATERALORBITOFRONTAL_SIZE N mm^3 ctx-lh-lateralorbitofrontal ROI size in mm^3
#'   \item CTX_LH_LINGUAL N av1451 uptake - subregion ctx-lh-lingual
#'   \item CTX_LH_LINGUAL_SIZE N mm^3 ctx-lh-lingual ROI size in mm^3
#'   \item CTX_LH_MEDIALORBITOFRONTAL N av1451 uptake - subregion ctx-lh-medialorbitofrontal
#'   \item CTX_LH_MEDIALORBITOFRONTAL_SIZE N mm^3 ctx-lh-medialorbitofrontal ROI size in mm^3
#'   \item CTX_LH_MIDDLETEMPORAL N av1451 uptake - subregion ctx-lh-middletemporal
#'   \item CTX_LH_MIDDLETEMPORAL_SIZE N mm^3 ctx-lh-middletemporal ROI size in mm^3
#'   \item CTX_LH_PARACENTRAL N av1451 uptake - subregion ctx-lh-paracentral
#'   \item CTX_LH_PARACENTRAL_SIZE N mm^3 ctx-lh-paracentral ROI size in mm^3
#'   \item CTX_LH_PARAHIPPOCAMPAL N av1451 uptake - subregion ctx-lh-parahippocampal
#'   \item CTX_LH_PARAHIPPOCAMPAL_SIZE N mm^3 ctx-lh-parahippocampal ROI size in mm^3
#'   \item CTX_LH_PARSOPERCULARIS N av1451 uptake - subregion ctx-lh-parsopercularis
#'   \item CTX_LH_PARSOPERCULARIS_SIZE N mm^3 ctx-lh-parsopercularis ROI size in mm^3
#'   \item CTX_LH_PARSORBITALIS N av1451 uptake - subregion ctx-lh-parsorbitalis
#'   \item CTX_LH_PARSORBITALIS_SIZE N mm^3 ctx-lh-parsorbitalis ROI size in mm^3
#'   \item CTX_LH_PARSTRIANGULARIS N av1451 uptake - subregion ctx-lh-parstriangularis
#'   \item CTX_LH_PARSTRIANGULARIS_SIZE N mm^3 ctx-lh-parstriangularis ROI size in mm^3
#'   \item CTX_LH_PERICALCARINE N av1451 uptake - subregion ctx-lh-pericalcarine
#'   \item CTX_LH_PERICALCARINE_SIZE N mm^3 ctx-lh-pericalcarine ROI size in mm^3
#'   \item CTX_LH_POSTCENTRAL N av1451 uptake - subregion ctx-lh-postcentral
#'   \item CTX_LH_POSTCENTRAL_SIZE N mm^3 ctx-lh-postcentral ROI size in mm^3
#'   \item CTX_LH_POSTERIORCINGULATE N av1451 uptake - subregion ctx-lh-posteriorcingulate
#'   \item CTX_LH_POSTERIORCINGULATE_SIZE N mm^3 ctx-lh-posteriorcingulate ROI size in mm^3
#'   \item CTX_LH_PRECENTRAL N av1451 uptake - subregion ctx-lh-precentral
#'   \item CTX_LH_PRECENTRAL_SIZE N mm^3 ctx-lh-precentral ROI size in mm^3
#'   \item CTX_LH_PRECUNEUS N av1451 uptake - subregion ctx-lh-precuneus
#'   \item CTX_LH_PRECUNEUS_SIZE N mm^3 ctx-lh-precuneus ROI size in mm^3
#'   \item CTX_LH_ROSTRALANTERIORCINGULATE N av1451 uptake - subregion ctx-lh-rostralanteriorcingulate
#'   \item CTX_LH_ROSTRALANTERIORCINGULATE_SIZE N mm^3 ctx-lh-rostralanteriorcingulate ROI size in mm^3
#'   \item CTX_LH_ROSTRALMIDDLEFRONTAL N av1451 uptake - subregion ctx-lh-rostralmiddlefrontal
#'   \item CTX_LH_ROSTRALMIDDLEFRONTAL_SIZE N mm^3 ctx-lh-rostralmiddlefrontal ROI size in mm^3
#'   \item CTX_LH_SUPERIORFRONTAL N av1451 uptake - subregion ctx-lh-superiorfrontal
#'   \item CTX_LH_SUPERIORFRONTAL_SIZE N mm^3 ctx-lh-superiorfrontal ROI size in mm^3
#'   \item CTX_LH_SUPERIORPARIETAL N av1451 uptake - subregion ctx-lh-superiorparietal
#'   \item CTX_LH_SUPERIORPARIETAL_SIZE N mm^3 ctx-lh-superiorparietal ROI size in mm^3
#'   \item CTX_LH_SUPERIORTEMPORAL N av1451 uptake - subregion ctx-lh-superiortemporal
#'   \item CTX_LH_SUPERIORTEMPORAL_SIZE N mm^3 ctx-lh-superiortemporal ROI size in mm^3
#'   \item CTX_LH_SUPRAMARGINAL N av1451 uptake - subregion ctx-lh-supramarginal
#'   \item CTX_LH_SUPRAMARGINAL_SIZE N mm^3 ctx-lh-supramarginal ROI size in mm^3
#'   \item CTX_LH_TEMPORALPOLE N av1451 uptake - subregion ctx-lh-temporalpole
#'   \item CTX_LH_TEMPORALPOLE_SIZE N mm^3 ctx-lh-temporalpole ROI size in mm^3
#'   \item CTX_LH_TRANSVERSETEMPORAL N av1451 uptake - subregion ctx-lh-transversetemporal
#'   \item CTX_LH_TRANSVERSETEMPORAL_SIZE N mm^3 ctx-lh-transversetemporal ROI size in mm^3
#'   \item CTX_LH_UNKNOWN N av1451 uptake - subregion ctx-lh-unknown
#'   \item CTX_LH_UNKNOWN_SIZE N mm^3 ctx-lh-unknown ROI size in mm^3
#'   \item CTX_RH_BANKSSTS N av1451 uptake - subregion ctx-rh-bankssts
#'   \item CTX_RH_BANKSSTS_SIZE N mm^3 ctx-rh-bankssts ROI size in mm^3
#'   \item CTX_RH_CAUDALANTERIORCINGULATE N av1451 uptake - subregion ctx-rh-caudalanteriorcingulate
#'   \item CTX_RH_CAUDALANTERIORCINGULATE_SIZE N mm^3 ctx-rh-caudalanteriorcingulate ROI size in mm^3
#'   \item CTX_RH_CAUDALMIDDLEFRONTAL N av1451 uptake - subregion ctx-rh-caudalmiddlefrontal
#'   \item CTX_RH_CAUDALMIDDLEFRONTAL_SIZE N mm^3 ctx-rh-caudalmiddlefrontal ROI size in mm^3
#'   \item CTX_RH_CUNEUS N av1451 uptake - subregion ctx-rh-cuneus
#'   \item CTX_RH_CUNEUS_SIZE N mm^3 ctx-rh-cuneus ROI size in mm^3
#'   \item CTX_RH_ENTORHINAL N av1451 uptake - subregion ctx-rh-entorhinal
#'   \item CTX_RH_ENTORHINAL_SIZE N mm^3 ctx-rh-entorhinal ROI size in mm^3
#'   \item CTX_RH_FRONTALPOLE N av1451 uptake - subregion ctx-rh-frontalpole
#'   \item CTX_RH_FRONTALPOLE_SIZE N mm^3 ctx-rh-frontalpole ROI size in mm^3
#'   \item CTX_RH_FUSIFORM N av1451 uptake - subregion ctx-rh-fusiform
#'   \item CTX_RH_FUSIFORM_SIZE N mm^3 ctx-rh-fusiform ROI size in mm^3
#'   \item CTX_RH_INFERIORPARIETAL N av1451 uptake - subregion ctx-rh-inferiorparietal
#'   \item CTX_RH_INFERIORPARIETAL_SIZE N mm^3 ctx-rh-inferiorparietal ROI size in mm^3
#'   \item CTX_RH_INFERIORTEMPORAL N av1451 uptake - subregion ctx-rh-inferiortemporal
#'   \item CTX_RH_INFERIORTEMPORAL_SIZE N mm^3 ctx-rh-inferiortemporal ROI size in mm^3
#'   \item CTX_RH_INSULA N av1451 uptake - subregion ctx-rh-insula
#'   \item CTX_RH_INSULA_SIZE N mm^3 ctx-rh-insula ROI size in mm^3
#'   \item CTX_RH_ISTHMUSCINGULATE N av1451 uptake - subregion ctx-rh-isthmuscingulate
#'   \item CTX_RH_ISTHMUSCINGULATE_SIZE N mm^3 ctx-rh-isthmuscingulate ROI size in mm^3
#'   \item CTX_RH_LATERALOCCIPITAL N av1451 uptake - subregion ctx-rh-lateraloccipital
#'   \item CTX_RH_LATERALOCCIPITAL_SIZE N mm^3 ctx-rh-lateraloccipital ROI size in mm^3
#'   \item CTX_RH_LATERALORBITOFRONTAL N av1451 uptake - subregion ctx-rh-lateralorbitofrontal
#'   \item CTX_RH_LATERALORBITOFRONTAL_SIZE N mm^3 ctx-rh-lateralorbitofrontal ROI size in mm^3
#'   \item CTX_RH_LINGUAL N av1451 uptake - subregion ctx-rh-lingual
#'   \item CTX_RH_LINGUAL_SIZE N mm^3 ctx-rh-lingual ROI size in mm^3
#'   \item CTX_RH_MEDIALORBITOFRONTAL N av1451 uptake - subregion ctx-rh-medialorbitofrontal
#'   \item CTX_RH_MEDIALORBITOFRONTAL_SIZE N mm^3 ctx-rh-medialorbitofrontal ROI size in mm^3
#'   \item CTX_RH_MIDDLETEMPORAL N av1451 uptake - subregion ctx-rh-middletemporal
#'   \item CTX_RH_MIDDLETEMPORAL_SIZE N mm^3 ctx-rh-middletemporal ROI size in mm^3
#'   \item CTX_RH_PARACENTRAL N av1451 uptake - subregion ctx-rh-paracentral
#'   \item CTX_RH_PARACENTRAL_SIZE N mm^3 ctx-rh-paracentral ROI size in mm^3
#'   \item CTX_RH_PARAHIPPOCAMPAL N av1451 uptake - subregion ctx-rh-parahippocampal
#'   \item CTX_RH_PARAHIPPOCAMPAL_SIZE N mm^3 ctx-rh-parahippocampal ROI size in mm^3
#'   \item CTX_RH_PARSOPERCULARIS N av1451 uptake - subregion ctx-rh-parsopercularis
#'   \item CTX_RH_PARSOPERCULARIS_SIZE N mm^3 ctx-rh-parsopercularis ROI size in mm^3
#'   \item CTX_RH_PARSORBITALIS N av1451 uptake - subregion ctx-rh-parsorbitalis
#'   \item CTX_RH_PARSORBITALIS_SIZE N mm^3 ctx-rh-parsorbitalis ROI size in mm^3
#'   \item CTX_RH_PARSTRIANGULARIS N av1451 uptake - subregion ctx-rh-parstriangularis
#'   \item CTX_RH_PARSTRIANGULARIS_SIZE N mm^3 ctx-rh-parstriangularis ROI size in mm^3
#'   \item CTX_RH_PERICALCARINE N av1451 uptake - subregion ctx-rh-pericalcarine
#'   \item CTX_RH_PERICALCARINE_SIZE N mm^3 ctx-rh-pericalcarine ROI size in mm^3
#'   \item CTX_RH_POSTCENTRAL N av1451 uptake - subregion ctx-rh-postcentral
#'   \item CTX_RH_POSTCENTRAL_SIZE N mm^3 ctx-rh-postcentral ROI size in mm^3
#'   \item CTX_RH_POSTERIORCINGULATE N av1451 uptake - subregion ctx-rh-posteriorcingulate
#'   \item CTX_RH_POSTERIORCINGULATE_SIZE N mm^3 ctx-rh-posteriorcingulate ROI size in mm^3
#'   \item CTX_RH_PRECENTRAL N av1451 uptake - subregion ctx-rh-precentral
#'   \item CTX_RH_PRECENTRAL_SIZE N mm^3 ctx-rh-precentral ROI size in mm^3
#'   \item CTX_RH_PRECUNEUS N av1451 uptake - subregion ctx-rh-precuneus
#'   \item CTX_RH_PRECUNEUS_SIZE N mm^3 ctx-rh-precuneus ROI size in mm^3
#'   \item CTX_RH_ROSTRALANTERIORCINGULATE N av1451 uptake - subregion ctx-rh-rostralanteriorcingulate
#'   \item CTX_RH_ROSTRALANTERIORCINGULATE_SIZE N mm^3 ctx-rh-rostralanteriorcingulate ROI size in mm^3
#'   \item CTX_RH_ROSTRALMIDDLEFRONTAL N av1451 uptake - subregion ctx-rh-rostralmiddlefrontal
#'   \item CTX_RH_ROSTRALMIDDLEFRONTAL_SIZE N mm^3 ctx-rh-rostralmiddlefrontal ROI size in mm^3
#'   \item CTX_RH_SUPERIORFRONTAL N av1451 uptake - subregion ctx-rh-superiorfrontal
#'   \item CTX_RH_SUPERIORFRONTAL_SIZE N mm^3 ctx-rh-superiorfrontal ROI size in mm^3
#'   \item CTX_RH_SUPERIORPARIETAL N av1451 uptake - subregion ctx-rh-superiorparietal
#'   \item CTX_RH_SUPERIORPARIETAL_SIZE N mm^3 ctx-rh-superiorparietal ROI size in mm^3
#'   \item CTX_RH_SUPERIORTEMPORAL N av1451 uptake - subregion ctx-rh-superiortemporal
#'   \item CTX_RH_SUPERIORTEMPORAL_SIZE N mm^3 ctx-rh-superiortemporal ROI size in mm^3
#'   \item CTX_RH_SUPRAMARGINAL N av1451 uptake - subregion ctx-rh-supramarginal
#'   \item CTX_RH_SUPRAMARGINAL_SIZE N mm^3 ctx-rh-supramarginal ROI size in mm^3
#'   \item CTX_RH_TEMPORALPOLE N av1451 uptake - subregion ctx-rh-temporalpole
#'   \item CTX_RH_TEMPORALPOLE_SIZE N mm^3 ctx-rh-temporalpole ROI size in mm^3
#'   \item CTX_RH_TRANSVERSETEMPORAL N av1451 uptake - subregion ctx-rh-transversetemporal
#'   \item CTX_RH_TRANSVERSETEMPORAL_SIZE N mm^3 ctx-rh-transversetemporal ROI size in mm^3
#'   \item CTX_RH_UNKNOWN N av1451 uptake - subregion ctx-rh-unknown
#'   \item CTX_RH_UNKNOWN_SIZE N mm^3 ctx-rh-unknown ROI size in mm^3
#'   \item LEFT_ACCUMBENS_AREA N av1451 uptake - subregion left-accumbens-area
#'   \item LEFT_ACCUMBENS_AREA_SIZE N mm^3 left-accumbens-area ROI size in mm^3
#'   \item LEFT_AMYGDALA N av1451 uptake - subregion left-amygdala
#'   \item LEFT_AMYGDALA_SIZE N mm^3 left-amygdala ROI size in mm^3
#'   \item LEFT_CAUDATE N av1451 uptake - subregion left-caudate
#'   \item LEFT_CAUDATE_SIZE N mm^3 left-caudate ROI size in mm^3
#'   \item LEFT_CEREBELLUM_CORTEX N av1451 uptake - subregion left-cerebellum-cortex
#'   \item LEFT_CEREBELLUM_CORTEX_SIZE N mm^3 left-cerebellum-cortex ROI size in mm^3
#'   \item LEFT_CEREBELLUM_WHITE_MATTER N av1451 uptake - subregion left-cerebellum-white-matter
#'   \item LEFT_CEREBELLUM_WHITE_MATTER_SIZE N mm^3 left-cerebellum-white-matter ROI size in mm^3
#'   \item LEFT_CEREBRAL_WHITE_MATTER N av1451 uptake - subregion left-cerebral-white-matter
#'   \item LEFT_CEREBRAL_WHITE_MATTER_SIZE N mm^3 left-cerebral-white-matter ROI size in mm^3
#'   \item LEFT_CHOROID_PLEXUS N av1451 uptake - subregion left-choroid-plexus
#'   \item LEFT_CHOROID_PLEXUS_SIZE N mm^3 left-choroid-plexus ROI size in mm^3
#'   \item LEFT_HIPPOCAMPUS N av1451 uptake - subregion left-hippocampus
#'   \item LEFT_HIPPOCAMPUS_SIZE N mm^3 left-hippocampus ROI size in mm^3
#'   \item LEFT_INF_LAT_VENT N av1451 uptake - subregion left-inf-lat-vent
#'   \item LEFT_INF_LAT_VENT_SIZE N mm^3 left-inf-lat-vent ROI size in mm^3
#'   \item LEFT_LATERAL_VENTRICLE N av1451 uptake - subregion left-lateral-ventricle
#'   \item LEFT_LATERAL_VENTRICLE_SIZE N mm^3 left-lateral-ventricle ROI size in mm^3
#'   \item LEFT_PALLIDUM N av1451 uptake - subregion left-pallidum
#'   \item LEFT_PALLIDUM_SIZE N mm^3 left-pallidum ROI size in mm^3
#'   \item LEFT_PUTAMEN N av1451 uptake - subregion left-putamen
#'   \item LEFT_PUTAMEN_SIZE N mm^3 left-putamen ROI size in mm^3
#'   \item LEFT_THALAMUS_PROPER N av1451 uptake - subregion left-thalamus-proper
#'   \item LEFT_THALAMUS_PROPER_SIZE N mm^3 left-thalamus-proper ROI size in mm^3
#'   \item LEFT_VENTRALDC N av1451 uptake - subregion left-ventraldc
#'   \item LEFT_VENTRALDC_SIZE N mm^3 left-ventraldc ROI size in mm^3
#'   \item LEFT_VESSEL N av1451 uptake - subregion left-vessel
#'   \item LEFT_VESSEL_SIZE N mm^3 left-vessel ROI size in mm^3
#'   \item NON_WM_HYPOINTENSITIES N av1451 uptake - subregion non-wm-hypointensities
#'   \item NON_WM_HYPOINTENSITIES_SIZE N mm^3 non-wm-hypointensities ROI size in mm^3
#'   \item OPTIC_CHIASM N av1451 uptake - subregion optic-chiasm
#'   \item OPTIC_CHIASM_SIZE N mm^3 optic-chiasm ROI size in mm^3
#'   \item RIGHT_ACCUMBENS_AREA N av1451 uptake - subregion right-accumbens-area
#'   \item RIGHT_ACCUMBENS_AREA_SIZE N mm^3 right-accumbens-area ROI size in mm^3
#'   \item RIGHT_AMYGDALA N av1451 uptake - subregion right-amygdala
#'   \item RIGHT_AMYGDALA_SIZE N mm^3 right-amygdala ROI size in mm^3
#'   \item RIGHT_CAUDATE N av1451 uptake - subregion right-caudate
#'   \item RIGHT_CAUDATE_SIZE N mm^3 right-caudate ROI size in mm^3
#'   \item RIGHT_CEREBELLUM_CORTEX N av1451 uptake - subregion right-cerebellum-cortex
#'   \item RIGHT_CEREBELLUM_CORTEX_SIZE N mm^3 right-cerebellum-cortex ROI size in mm^3
#'   \item RIGHT_CEREBELLUM_WHITE_MATTER N av1451 uptake - subregion right-cerebellum-white-matter
#'   \item RIGHT_CEREBELLUM_WHITE_MATTER_SIZE N mm^3 right-cerebellum-white-matter ROI size in mm^3
#'   \item RIGHT_CEREBRAL_WHITE_MATTER N av1451 uptake - subregion right-cerebral-white-matter
#'   \item RIGHT_CEREBRAL_WHITE_MATTER_SIZE N mm^3 right-cerebral-white-matter ROI size in mm^3
#'   \item RIGHT_CHOROID_PLEXUS N av1451 uptake - subregion right-choroid-plexus
#'   \item RIGHT_CHOROID_PLEXUS_SIZE N mm^3 right-choroid-plexus ROI size in mm^3
#'   \item RIGHT_HIPPOCAMPUS N av1451 uptake - subregion right-hippocampus
#'   \item RIGHT_HIPPOCAMPUS_SIZE N mm^3 right-hippocampus ROI size in mm^3
#'   \item RIGHT_INF_LAT_VENT N av1451 uptake - subregion right-inf-lat-vent
#'   \item RIGHT_INF_LAT_VENT_SIZE N mm^3 right-inf-lat-vent ROI size in mm^3
#'   \item RIGHT_LATERAL_VENTRICLE N av1451 uptake - subregion right-lateral-ventricle
#'   \item RIGHT_LATERAL_VENTRICLE_SIZE N mm^3 right-lateral-ventricle ROI size in mm^3
#'   \item RIGHT_PALLIDUM N av1451 uptake - subregion right-pallidum
#'   \item RIGHT_PALLIDUM_SIZE N mm^3 right-pallidum ROI size in mm^3
#'   \item RIGHT_PUTAMEN N av1451 uptake - subregion right-putamen
#'   \item RIGHT_PUTAMEN_SIZE N mm^3 right-putamen ROI size in mm^3
#'   \item RIGHT_THALAMUS_PROPER N av1451 uptake - subregion right-thalamus-proper
#'   \item RIGHT_THALAMUS_PROPER_SIZE N mm^3 right-thalamus-proper ROI size in mm^3
#'   \item RIGHT_VENTRALDC N av1451 uptake - subregion right-ventraldc
#'   \item RIGHT_VENTRALDC_SIZE N mm^3 right-ventraldc ROI size in mm^3
#'   \item RIGHT_VESSEL N av1451 uptake - subregion right-vessel
#'   \item RIGHT_VESSEL_SIZE N mm^3 right-vessel ROI size in mm^3
#'   \item WM_HYPOINTENSITIES N av1451 uptake - subregion wm-hypointensities
#'   \item WM_HYPOINTENSITIES_SIZE N mm^3 wm-hypointensities ROI size in mm^3
#' }
#'
#' @examples
#' \donotrun{
#' describe(ucberkeleyav1451)
#' }
#' @docType data
#' @keywords datasets
#' @name ucberkeleyav1451
#' @usage data(ucberkeleyav1451)
#' @format A data frame with 246 rows and 246 variables
NULL

#' UC Berkeley - AV45 analysis
#'
#' @aliases AV45, Amyloid, PET
#'
#' @author Susan Landau \email{slandau@berkeley.edu} & William Jagust
#' Helen Wills Neuroscience Institute, UC Berkeley and Lawrence Berkeley National Laboratory
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/UCBERKELEYAV45/ADNI_AV45_Methods_JagustLab_01.20.15.pdf}, \url{https://adni.bitbucket.io/reference/docs/UCBERKELEYAV45/ADNI_AV45_Methods_JagustLab_04.29.14.pdf}, \url{https://adni.bitbucket.io/reference/docs/UCBERKELEYAV45/ADNI_AV45_Methods_JagustLab_06.25.15.pdf}, \url{https://adni.bitbucket.io/reference/docs/UCBERKELEYAV45/florbetapir_dataset_correction_2.pdf}, \url{https://adni.bitbucket.io/reference/docs/UCBERKELEYAV45/UCBERKELEY_AV45_Methods_11.20.15.pdf}, \url{https://adni.bitbucket.io/reference/docs/UCBERKELEYAV45/UCBERKELEY_AV45_Methods_12.03.15.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID T  Participant roster ID
#'   \item VISCODE T  Visit code
#'   \item VISCODE2 T  Translated visit code
#'   \item EXAMDATE D  Examination Date
#'   \item CEREBELLUMGREYMATTER N av45 uptake - reference region Reference region - florbetapir mean of cerebellar grey matter.  Regions defined by Freesurfer; see Jagust lab PDF on LONI for details
#'   \item WHOLECEREBELLUM N av45 uptake - reference region Reference region - florbetapir mean of whole cerebellum.  Regions defined by Freesurfer; see Jagust lab PDF on LONI for details
#'   \item ERODED_SUBCORTICALWM N av45 uptake - reference region Reference region - florbetapir mean of eroded subcortical white matter.  Regions defined by Freesurfer; see Jagust lab PDF on LONI for details
#'   \item COMPOSITE_REF N av45 uptake - reference region Reference region - florbetapir mean of composite ref region (avg of whole cerebellum, pons/brainstem, eroded WM).  Regions defined by Freesurfer; see Jagust lab PDF on LONI for details
#'   \item FRONTAL N av45 uptake in cortical grey matter Weighted florbetapir mean in frontal regions.  Regions defined by Freesurfer; see Jagust lab PDF on LONI for details
#'   \item CINGULATE N av45 uptake in cortical grey matter Weighted florbetapir mean in anterior/posterior cingulate regions.  Regions defined by Freesurfer; see Jagust lab PDF on LONI for details
#'   \item PARIETAL N av45 uptake in cortical grey matter Weighted florbetapir mean in lateral parietal regions.  Regions defined by Freesurfer; see Jagust lab PDF on LONI for details
#'   \item TEMPORAL N av45 uptake in cortical grey matter Weighted florbetapir mean in lateral temporal regions.  Regions defined by Freesurfer; see Jagust lab PDF on LONI for details
#'   \item SUMMARYSUVR_WHOLECEREBNORM N av45 ratio (cortical grey matter/whole cerebellum) Summary florbetapir cortical SUVR normalized by whole cerebellum.  See Jagust lab PDF on LONI for details and cutoff info
#'   \item SUMMARYSUVR_WHOLECEREBNORM_1.11CUTOFF N binary Amyloid positivity determined by applying a cutoff value of 1.11 to the summary florbetapir cortical SUVR normalized by whole cerebellum
#'   \item SUMMARYSUVR_COMPOSITE_REFNORM N av45 ratio (cortical grey matter/composite ref region) Summary florbetapir cortical SUVR normalized by composite ref region.  See Jagust lab PDF on LONI for details
#'   \item SUMMARYSUVR_COMPOSITE_REFNORM_0.79CUTOFF N binary Amyloid positivity determined by applying a cutoff value of 0.79 to the summary florbetapir cortical SUVR normalized by composite ref region
#'   \item BRAINSTEM N av45 uptake - reference region Reference region - florbetapir mean of brainstem.  Regions defined by Freesurfer; see Jagust lab PDF on LONI for details
#'   \item BRAINSTEM_SIZE N mm^3 brain-stem ROI size in mm^3
#'   \item VENTRICLE_3RD N av45 uptake - subregion 3rd-ventricle
#'   \item VENTRICLE_3RD_SIZE N mm^3 3rd-ventricle ROI size in mm^3
#'   \item VENTRICLE_4TH N av45 uptake - subregion 4th-ventricle
#'   \item VENTRICLE_4TH_SIZE N mm^3 4th-ventricle ROI size in mm^3
#'   \item VENTRICLE_5TH N av45 uptake - subregion 5th-ventricle
#'   \item VENTRICLE_5TH_SIZE N mm^3 5th-ventricle ROI size in mm^3
#'   \item CC_ANTERIOR N av45 uptake - subregion cc-anterior
#'   \item CC_ANTERIOR_SIZE N mm^3 cc-anterior ROI size in mm^3
#'   \item CC_CENTRAL N av45 uptake - subregion cc-central
#'   \item CC_CENTRAL_SIZE N mm^3 cc-central ROI size in mm^3
#'   \item CC_MID_ANTERIOR N av45 uptake - subregion cc-mid-anterior
#'   \item CC_MID_ANTERIOR_SIZE N mm^3 cc-mid-anterior ROI size in mm^3
#'   \item CC_MID_POSTERIOR N av45 uptake - subregion cc-mid-posterior
#'   \item CC_MID_POSTERIOR_SIZE N mm^3 cc-mid-posterior ROI size in mm^3
#'   \item CC_POSTERIOR N av45 uptake - subregion cc-posterior
#'   \item CC_POSTERIOR_SIZE N mm^3 cc-posterior ROI size in mm^3
#'   \item CSF N av45 uptake - subregion csf
#'   \item CSF_SIZE N mm^3 csf ROI size in mm^3
#'   \item CTX_LH_BANKSSTS N av45 uptake - subregion ctx-lh-bankssts
#'   \item CTX_LH_BANKSSTS_SIZE N mm^3 ctx-lh-bankssts ROI size in mm^3
#'   \item CTX_LH_CAUDALANTERIORCINGULATE N av45 uptake - subregion ctx-lh-caudalanteriorcingulate
#'   \item CTX_LH_CAUDALANTERIORCINGULATE_SIZE N mm^3 ctx-lh-caudalanteriorcingulate ROI size in mm^3
#'   \item CTX_LH_CAUDALMIDDLEFRONTAL N av45 uptake - subregion ctx-lh-caudalmiddlefrontal
#'   \item CTX_LH_CAUDALMIDDLEFRONTAL_SIZE N mm^3 ctx-lh-caudalmiddlefrontal ROI size in mm^3
#'   \item CTX_LH_CUNEUS N av45 uptake - subregion ctx-lh-cuneus
#'   \item CTX_LH_CUNEUS_SIZE N mm^3 ctx-lh-cuneus ROI size in mm^3
#'   \item CTX_LH_ENTORHINAL N av45 uptake - subregion ctx-lh-entorhinal
#'   \item CTX_LH_ENTORHINAL_SIZE N mm^3 ctx-lh-entorhinal ROI size in mm^3
#'   \item CTX_LH_FRONTALPOLE N av45 uptake - subregion ctx-lh-frontalpole
#'   \item CTX_LH_FRONTALPOLE_SIZE N mm^3 ctx-lh-frontalpole ROI size in mm^3
#'   \item CTX_LH_FUSIFORM N av45 uptake - subregion ctx-lh-fusiform
#'   \item CTX_LH_FUSIFORM_SIZE N mm^3 ctx-lh-fusiform ROI size in mm^3
#'   \item CTX_LH_INFERIORPARIETAL N av45 uptake - subregion ctx-lh-inferiorparietal
#'   \item CTX_LH_INFERIORPARIETAL_SIZE N mm^3 ctx-lh-inferiorparietal ROI size in mm^3
#'   \item CTX_LH_INFERIORTEMPORAL N av45 uptake - subregion ctx-lh-inferiortemporal
#'   \item CTX_LH_INFERIORTEMPORAL_SIZE N mm^3 ctx-lh-inferiortemporal ROI size in mm^3
#'   \item CTX_LH_INSULA N av45 uptake - subregion ctx-lh-insula
#'   \item CTX_LH_INSULA_SIZE N mm^3 ctx-lh-insula ROI size in mm^3
#'   \item CTX_LH_ISTHMUSCINGULATE N av45 uptake - subregion ctx-lh-isthmuscingulate
#'   \item CTX_LH_ISTHMUSCINGULATE_SIZE N mm^3 ctx-lh-isthmuscingulate ROI size in mm^3
#'   \item CTX_LH_LATERALOCCIPITAL N av45 uptake - subregion ctx-lh-lateraloccipital
#'   \item CTX_LH_LATERALOCCIPITAL_SIZE N mm^3 ctx-lh-lateraloccipital ROI size in mm^3
#'   \item CTX_LH_LATERALORBITOFRONTAL N av45 uptake - subregion ctx-lh-lateralorbitofrontal
#'   \item CTX_LH_LATERALORBITOFRONTAL_SIZE N mm^3 ctx-lh-lateralorbitofrontal ROI size in mm^3
#'   \item CTX_LH_LINGUAL N av45 uptake - subregion ctx-lh-lingual
#'   \item CTX_LH_LINGUAL_SIZE N mm^3 ctx-lh-lingual ROI size in mm^3
#'   \item CTX_LH_MEDIALORBITOFRONTAL N av45 uptake - subregion ctx-lh-medialorbitofrontal
#'   \item CTX_LH_MEDIALORBITOFRONTAL_SIZE N mm^3 ctx-lh-medialorbitofrontal ROI size in mm^3
#'   \item CTX_LH_MIDDLETEMPORAL N av45 uptake - subregion ctx-lh-middletemporal
#'   \item CTX_LH_MIDDLETEMPORAL_SIZE N mm^3 ctx-lh-middletemporal ROI size in mm^3
#'   \item CTX_LH_PARACENTRAL N av45 uptake - subregion ctx-lh-paracentral
#'   \item CTX_LH_PARACENTRAL_SIZE N mm^3 ctx-lh-paracentral ROI size in mm^3
#'   \item CTX_LH_PARAHIPPOCAMPAL N av45 uptake - subregion ctx-lh-parahippocampal
#'   \item CTX_LH_PARAHIPPOCAMPAL_SIZE N mm^3 ctx-lh-parahippocampal ROI size in mm^3
#'   \item CTX_LH_PARSOPERCULARIS N av45 uptake - subregion ctx-lh-parsopercularis
#'   \item CTX_LH_PARSOPERCULARIS_SIZE N mm^3 ctx-lh-parsopercularis ROI size in mm^3
#'   \item CTX_LH_PARSORBITALIS N av45 uptake - subregion ctx-lh-parsorbitalis
#'   \item CTX_LH_PARSORBITALIS_SIZE N mm^3 ctx-lh-parsorbitalis ROI size in mm^3
#'   \item CTX_LH_PARSTRIANGULARIS N av45 uptake - subregion ctx-lh-parstriangularis
#'   \item CTX_LH_PARSTRIANGULARIS_SIZE N mm^3 ctx-lh-parstriangularis ROI size in mm^3
#'   \item CTX_LH_PERICALCARINE N av45 uptake - subregion ctx-lh-pericalcarine
#'   \item CTX_LH_PERICALCARINE_SIZE N mm^3 ctx-lh-pericalcarine ROI size in mm^3
#'   \item CTX_LH_POSTCENTRAL N av45 uptake - subregion ctx-lh-postcentral
#'   \item CTX_LH_POSTCENTRAL_SIZE N mm^3 ctx-lh-postcentral ROI size in mm^3
#'   \item CTX_LH_POSTERIORCINGULATE N av45 uptake - subregion ctx-lh-posteriorcingulate
#'   \item CTX_LH_POSTERIORCINGULATE_SIZE N mm^3 ctx-lh-posteriorcingulate ROI size in mm^3
#'   \item CTX_LH_PRECENTRAL N av45 uptake - subregion ctx-lh-precentral
#'   \item CTX_LH_PRECENTRAL_SIZE N mm^3 ctx-lh-precentral ROI size in mm^3
#'   \item CTX_LH_PRECUNEUS N av45 uptake - subregion ctx-lh-precuneus
#'   \item CTX_LH_PRECUNEUS_SIZE N mm^3 ctx-lh-precuneus ROI size in mm^3
#'   \item CTX_LH_ROSTRALANTERIORCINGULATE N av45 uptake - subregion ctx-lh-rostralanteriorcingulate
#'   \item CTX_LH_ROSTRALANTERIORCINGULATE_SIZE N mm^3 ctx-lh-rostralanteriorcingulate ROI size in mm^3
#'   \item CTX_LH_ROSTRALMIDDLEFRONTAL N av45 uptake - subregion ctx-lh-rostralmiddlefrontal
#'   \item CTX_LH_ROSTRALMIDDLEFRONTAL_SIZE N mm^3 ctx-lh-rostralmiddlefrontal ROI size in mm^3
#'   \item CTX_LH_SUPERIORFRONTAL N av45 uptake - subregion ctx-lh-superiorfrontal
#'   \item CTX_LH_SUPERIORFRONTAL_SIZE N mm^3 ctx-lh-superiorfrontal ROI size in mm^3
#'   \item CTX_LH_SUPERIORPARIETAL N av45 uptake - subregion ctx-lh-superiorparietal
#'   \item CTX_LH_SUPERIORPARIETAL_SIZE N mm^3 ctx-lh-superiorparietal ROI size in mm^3
#'   \item CTX_LH_SUPERIORTEMPORAL N av45 uptake - subregion ctx-lh-superiortemporal
#'   \item CTX_LH_SUPERIORTEMPORAL_SIZE N mm^3 ctx-lh-superiortemporal ROI size in mm^3
#'   \item CTX_LH_SUPRAMARGINAL N av45 uptake - subregion ctx-lh-supramarginal
#'   \item CTX_LH_SUPRAMARGINAL_SIZE N mm^3 ctx-lh-supramarginal ROI size in mm^3
#'   \item CTX_LH_TEMPORALPOLE N av45 uptake - subregion ctx-lh-temporalpole
#'   \item CTX_LH_TEMPORALPOLE_SIZE N mm^3 ctx-lh-temporalpole ROI size in mm^3
#'   \item CTX_LH_TRANSVERSETEMPORAL N av45 uptake - subregion ctx-lh-transversetemporal
#'   \item CTX_LH_TRANSVERSETEMPORAL_SIZE N mm^3 ctx-lh-transversetemporal ROI size in mm^3
#'   \item CTX_LH_UNKNOWN N av45 uptake - subregion ctx-lh-unknown
#'   \item CTX_LH_UNKNOWN_SIZE N mm^3 ctx-lh-unknown ROI size in mm^3
#'   \item CTX_RH_BANKSSTS N av45 uptake - subregion ctx-rh-bankssts
#'   \item CTX_RH_BANKSSTS_SIZE N mm^3 ctx-rh-bankssts ROI size in mm^3
#'   \item CTX_RH_CAUDALANTERIORCINGULATE N av45 uptake - subregion ctx-rh-caudalanteriorcingulate
#'   \item CTX_RH_CAUDALANTERIORCINGULATE_SIZE N mm^3 ctx-rh-caudalanteriorcingulate ROI size in mm^3
#'   \item CTX_RH_CAUDALMIDDLEFRONTAL N av45 uptake - subregion ctx-rh-caudalmiddlefrontal
#'   \item CTX_RH_CAUDALMIDDLEFRONTAL_SIZE N mm^3 ctx-rh-caudalmiddlefrontal ROI size in mm^3
#'   \item CTX_RH_CUNEUS N av45 uptake - subregion ctx-rh-cuneus
#'   \item CTX_RH_CUNEUS_SIZE N mm^3 ctx-rh-cuneus ROI size in mm^3
#'   \item CTX_RH_ENTORHINAL N av45 uptake - subregion ctx-rh-entorhinal
#'   \item CTX_RH_ENTORHINAL_SIZE N mm^3 ctx-rh-entorhinal ROI size in mm^3
#'   \item CTX_RH_FRONTALPOLE N av45 uptake - subregion ctx-rh-frontalpole
#'   \item CTX_RH_FRONTALPOLE_SIZE N mm^3 ctx-rh-frontalpole ROI size in mm^3
#'   \item CTX_RH_FUSIFORM N av45 uptake - subregion ctx-rh-fusiform
#'   \item CTX_RH_FUSIFORM_SIZE N mm^3 ctx-rh-fusiform ROI size in mm^3
#'   \item CTX_RH_INFERIORPARIETAL N av45 uptake - subregion ctx-rh-inferiorparietal
#'   \item CTX_RH_INFERIORPARIETAL_SIZE N mm^3 ctx-rh-inferiorparietal ROI size in mm^3
#'   \item CTX_RH_INFERIORTEMPORAL N av45 uptake - subregion ctx-rh-inferiortemporal
#'   \item CTX_RH_INFERIORTEMPORAL_SIZE N mm^3 ctx-rh-inferiortemporal ROI size in mm^3
#'   \item CTX_RH_INSULA N av45 uptake - subregion ctx-rh-insula
#'   \item CTX_RH_INSULA_SIZE N mm^3 ctx-rh-insula ROI size in mm^3
#'   \item CTX_RH_ISTHMUSCINGULATE N av45 uptake - subregion ctx-rh-isthmuscingulate
#'   \item CTX_RH_ISTHMUSCINGULATE_SIZE N mm^3 ctx-rh-isthmuscingulate ROI size in mm^3
#'   \item CTX_RH_LATERALOCCIPITAL N av45 uptake - subregion ctx-rh-lateraloccipital
#'   \item CTX_RH_LATERALOCCIPITAL_SIZE N mm^3 ctx-rh-lateraloccipital ROI size in mm^3
#'   \item CTX_RH_LATERALORBITOFRONTAL N av45 uptake - subregion ctx-rh-lateralorbitofrontal
#'   \item CTX_RH_LATERALORBITOFRONTAL_SIZE N mm^3 ctx-rh-lateralorbitofrontal ROI size in mm^3
#'   \item CTX_RH_LINGUAL N av45 uptake - subregion ctx-rh-lingual
#'   \item CTX_RH_LINGUAL_SIZE N mm^3 ctx-rh-lingual ROI size in mm^3
#'   \item CTX_RH_MEDIALORBITOFRONTAL N av45 uptake - subregion ctx-rh-medialorbitofrontal
#'   \item CTX_RH_MEDIALORBITOFRONTAL_SIZE N mm^3 ctx-rh-medialorbitofrontal ROI size in mm^3
#'   \item CTX_RH_MIDDLETEMPORAL N av45 uptake - subregion ctx-rh-middletemporal
#'   \item CTX_RH_MIDDLETEMPORAL_SIZE N mm^3 ctx-rh-middletemporal ROI size in mm^3
#'   \item CTX_RH_PARACENTRAL N av45 uptake - subregion ctx-rh-paracentral
#'   \item CTX_RH_PARACENTRAL_SIZE N mm^3 ctx-rh-paracentral ROI size in mm^3
#'   \item CTX_RH_PARAHIPPOCAMPAL N av45 uptake - subregion ctx-rh-parahippocampal
#'   \item CTX_RH_PARAHIPPOCAMPAL_SIZE N mm^3 ctx-rh-parahippocampal ROI size in mm^3
#'   \item CTX_RH_PARSOPERCULARIS N av45 uptake - subregion ctx-rh-parsopercularis
#'   \item CTX_RH_PARSOPERCULARIS_SIZE N mm^3 ctx-rh-parsopercularis ROI size in mm^3
#'   \item CTX_RH_PARSORBITALIS N av45 uptake - subregion ctx-rh-parsorbitalis
#'   \item CTX_RH_PARSORBITALIS_SIZE N mm^3 ctx-rh-parsorbitalis ROI size in mm^3
#'   \item CTX_RH_PARSTRIANGULARIS N av45 uptake - subregion ctx-rh-parstriangularis
#'   \item CTX_RH_PARSTRIANGULARIS_SIZE N mm^3 ctx-rh-parstriangularis ROI size in mm^3
#'   \item CTX_RH_PERICALCARINE N av45 uptake - subregion ctx-rh-pericalcarine
#'   \item CTX_RH_PERICALCARINE_SIZE N mm^3 ctx-rh-pericalcarine ROI size in mm^3
#'   \item CTX_RH_POSTCENTRAL N av45 uptake - subregion ctx-rh-postcentral
#'   \item CTX_RH_POSTCENTRAL_SIZE N mm^3 ctx-rh-postcentral ROI size in mm^3
#'   \item CTX_RH_POSTERIORCINGULATE N av45 uptake - subregion ctx-rh-posteriorcingulate
#'   \item CTX_RH_POSTERIORCINGULATE_SIZE N mm^3 ctx-rh-posteriorcingulate ROI size in mm^3
#'   \item CTX_RH_PRECENTRAL N av45 uptake - subregion ctx-rh-precentral
#'   \item CTX_RH_PRECENTRAL_SIZE N mm^3 ctx-rh-precentral ROI size in mm^3
#'   \item CTX_RH_PRECUNEUS N av45 uptake - subregion ctx-rh-precuneus
#'   \item CTX_RH_PRECUNEUS_SIZE N mm^3 ctx-rh-precuneus ROI size in mm^3
#'   \item CTX_RH_ROSTRALANTERIORCINGULATE N av45 uptake - subregion ctx-rh-rostralanteriorcingulate
#'   \item CTX_RH_ROSTRALANTERIORCINGULATE_SIZE N mm^3 ctx-rh-rostralanteriorcingulate ROI size in mm^3
#'   \item CTX_RH_ROSTRALMIDDLEFRONTAL N av45 uptake - subregion ctx-rh-rostralmiddlefrontal
#'   \item CTX_RH_ROSTRALMIDDLEFRONTAL_SIZE N mm^3 ctx-rh-rostralmiddlefrontal ROI size in mm^3
#'   \item CTX_RH_SUPERIORFRONTAL N av45 uptake - subregion ctx-rh-superiorfrontal
#'   \item CTX_RH_SUPERIORFRONTAL_SIZE N mm^3 ctx-rh-superiorfrontal ROI size in mm^3
#'   \item CTX_RH_SUPERIORPARIETAL N av45 uptake - subregion ctx-rh-superiorparietal
#'   \item CTX_RH_SUPERIORPARIETAL_SIZE N mm^3 ctx-rh-superiorparietal ROI size in mm^3
#'   \item CTX_RH_SUPERIORTEMPORAL N av45 uptake - subregion ctx-rh-superiortemporal
#'   \item CTX_RH_SUPERIORTEMPORAL_SIZE N mm^3 ctx-rh-superiortemporal ROI size in mm^3
#'   \item CTX_RH_SUPRAMARGINAL N av45 uptake - subregion ctx-rh-supramarginal
#'   \item CTX_RH_SUPRAMARGINAL_SIZE N mm^3 ctx-rh-supramarginal ROI size in mm^3
#'   \item CTX_RH_TEMPORALPOLE N av45 uptake - subregion ctx-rh-temporalpole
#'   \item CTX_RH_TEMPORALPOLE_SIZE N mm^3 ctx-rh-temporalpole ROI size in mm^3
#'   \item CTX_RH_TRANSVERSETEMPORAL N av45 uptake - subregion ctx-rh-transversetemporal
#'   \item CTX_RH_TRANSVERSETEMPORAL_SIZE N mm^3 ctx-rh-transversetemporal ROI size in mm^3
#'   \item CTX_RH_UNKNOWN N av45 uptake - subregion ctx-rh-unknown
#'   \item CTX_RH_UNKNOWN_SIZE N mm^3 ctx-rh-unknown ROI size in mm^3
#'   \item LEFT_ACCUMBENS_AREA N av45 uptake - subregion left-accumbens-area
#'   \item LEFT_ACCUMBENS_AREA_SIZE N mm^3 left-accumbens-area ROI size in mm^3
#'   \item LEFT_AMYGDALA N av45 uptake - subregion left-amygdala
#'   \item LEFT_AMYGDALA_SIZE N mm^3 left-amygdala ROI size in mm^3
#'   \item LEFT_CAUDATE N av45 uptake - subregion left-caudate
#'   \item LEFT_CAUDATE_SIZE N mm^3 left-caudate ROI size in mm^3
#'   \item LEFT_CEREBELLUM_CORTEX N av45 uptake - subregion left-cerebellum-cortex
#'   \item LEFT_CEREBELLUM_CORTEX_SIZE N mm^3 left-cerebellum-cortex ROI size in mm^3
#'   \item LEFT_CEREBELLUM_WHITE_MATTER N av45 uptake - subregion left-cerebellum-white-matter
#'   \item LEFT_CEREBELLUM_WHITE_MATTER_SIZE N mm^3 left-cerebellum-white-matter ROI size in mm^3
#'   \item LEFT_CEREBRAL_WHITE_MATTER N av45 uptake - subregion left-cerebral-white-matter
#'   \item LEFT_CEREBRAL_WHITE_MATTER_SIZE N mm^3 left-cerebral-white-matter ROI size in mm^3
#'   \item LEFT_CHOROID_PLEXUS N av45 uptake - subregion left-choroid-plexus
#'   \item LEFT_CHOROID_PLEXUS_SIZE N mm^3 left-choroid-plexus ROI size in mm^3
#'   \item LEFT_HIPPOCAMPUS N av45 uptake - subregion left-hippocampus
#'   \item LEFT_HIPPOCAMPUS_SIZE N mm^3 left-hippocampus ROI size in mm^3
#'   \item LEFT_INF_LAT_VENT N av45 uptake - subregion left-inf-lat-vent
#'   \item LEFT_INF_LAT_VENT_SIZE N mm^3 left-inf-lat-vent ROI size in mm^3
#'   \item LEFT_LATERAL_VENTRICLE N av45 uptake - subregion left-lateral-ventricle
#'   \item LEFT_LATERAL_VENTRICLE_SIZE N mm^3 left-lateral-ventricle ROI size in mm^3
#'   \item LEFT_PALLIDUM N av45 uptake - subregion left-pallidum
#'   \item LEFT_PALLIDUM_SIZE N mm^3 left-pallidum ROI size in mm^3
#'   \item LEFT_PUTAMEN N av45 uptake - subregion left-putamen
#'   \item LEFT_PUTAMEN_SIZE N mm^3 left-putamen ROI size in mm^3
#'   \item LEFT_THALAMUS_PROPER N av45 uptake - subregion left-thalamus-proper
#'   \item LEFT_THALAMUS_PROPER_SIZE N mm^3 left-thalamus-proper ROI size in mm^3
#'   \item LEFT_VENTRALDC N av45 uptake - subregion left-ventraldc
#'   \item LEFT_VENTRALDC_SIZE N mm^3 left-ventraldc ROI size in mm^3
#'   \item LEFT_VESSEL N av45 uptake - subregion left-vessel
#'   \item LEFT_VESSEL_SIZE N mm^3 left-vessel ROI size in mm^3
#'   \item NON_WM_HYPOINTENSITIES N av45 uptake - subregion non-wm-hypointensities
#'   \item NON_WM_HYPOINTENSITIES_SIZE N mm^3 non-wm-hypointensities ROI size in mm^3
#'   \item OPTIC_CHIASM N av45 uptake - subregion optic-chiasm
#'   \item OPTIC_CHIASM_SIZE N mm^3 optic-chiasm ROI size in mm^3
#'   \item RIGHT_ACCUMBENS_AREA N av45 uptake - subregion right-accumbens-area
#'   \item RIGHT_ACCUMBENS_AREA_SIZE N mm^3 right-accumbens-area ROI size in mm^3
#'   \item RIGHT_AMYGDALA N av45 uptake - subregion right-amygdala
#'   \item RIGHT_AMYGDALA_SIZE N mm^3 right-amygdala ROI size in mm^3
#'   \item RIGHT_CAUDATE N av45 uptake - subregion right-caudate
#'   \item RIGHT_CAUDATE_SIZE N mm^3 right-caudate ROI size in mm^3
#'   \item RIGHT_CEREBELLUM_CORTEX N av45 uptake - subregion right-cerebellum-cortex
#'   \item RIGHT_CEREBELLUM_CORTEX_SIZE N mm^3 right-cerebellum-cortex ROI size in mm^3
#'   \item RIGHT_CEREBELLUM_WHITE_MATTER N av45 uptake - subregion right-cerebellum-white-matter
#'   \item RIGHT_CEREBELLUM_WHITE_MATTER_SIZE N mm^3 right-cerebellum-white-matter ROI size in mm^3
#'   \item RIGHT_CEREBRAL_WHITE_MATTER N av45 uptake - subregion right-cerebral-white-matter
#'   \item RIGHT_CEREBRAL_WHITE_MATTER_SIZE N mm^3 right-cerebral-white-matter ROI size in mm^3
#'   \item RIGHT_CHOROID_PLEXUS N av45 uptake - subregion right-choroid-plexus
#'   \item RIGHT_CHOROID_PLEXUS_SIZE N mm^3 right-choroid-plexus ROI size in mm^3
#'   \item RIGHT_HIPPOCAMPUS N av45 uptake - subregion right-hippocampus
#'   \item RIGHT_HIPPOCAMPUS_SIZE N mm^3 right-hippocampus ROI size in mm^3
#'   \item RIGHT_INF_LAT_VENT N av45 uptake - subregion right-inf-lat-vent
#'   \item RIGHT_INF_LAT_VENT_SIZE N mm^3 right-inf-lat-vent ROI size in mm^3
#'   \item RIGHT_LATERAL_VENTRICLE N av45 uptake - subregion right-lateral-ventricle
#'   \item RIGHT_LATERAL_VENTRICLE_SIZE N mm^3 right-lateral-ventricle ROI size in mm^3
#'   \item RIGHT_PALLIDUM N av45 uptake - subregion right-pallidum
#'   \item RIGHT_PALLIDUM_SIZE N mm^3 right-pallidum ROI size in mm^3
#'   \item RIGHT_PUTAMEN N av45 uptake - subregion right-putamen
#'   \item RIGHT_PUTAMEN_SIZE N mm^3 right-putamen ROI size in mm^3
#'   \item RIGHT_THALAMUS_PROPER N av45 uptake - subregion right-thalamus-proper
#'   \item RIGHT_THALAMUS_PROPER_SIZE N mm^3 right-thalamus-proper ROI size in mm^3
#'   \item RIGHT_VENTRALDC N av45 uptake - subregion right-ventraldc
#'   \item RIGHT_VENTRALDC_SIZE N mm^3 right-ventraldc ROI size in mm^3
#'   \item RIGHT_VESSEL N av45 uptake - subregion right-vessel
#'   \item RIGHT_VESSEL_SIZE N mm^3 right-vessel ROI size in mm^3
#'   \item WM_HYPOINTENSITIES N av45 uptake - subregion wm-hypointensities
#'   \item WM_HYPOINTENSITIES_SIZE N mm^3 wm-hypointensities ROI size in mm^3
#' }
#'
#' @examples
#' ucberkeleyav45$SUVR   <- rowMeans(ucberkeleyav45[, c('FRONTAL', 'CINGULATE', 'TEMPORAL', 'PARIETAL')]) /
#'   ucberkeleyav45$WHOLECEREBELLUM
#' 
#' @docType data
#' @keywords datasets
#' @name ucberkeleyav45
#' @usage data(ucberkeleyav45)
#' @format A data frame with 2310 rows and 242 variables
NULL

#' UC Berkeley - FDG analysis
#'
#' @aliases FDG, Glucose Metabolism, PET
#'
#' @author Susan Landau \email{slandau@berkeley.edu} & William Jagust
#' Helen Wills Neuroscience Institute, UC Berkeley and Lawrence Berkeley National Laboratory
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/UCBERKELEYFDG/ADNI_FDG_Methods_JagustLab_10.22.12.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item VISCODE T  Visit code
#'   \item VISCODE2 -4 -4 Translated visit code
#'   \item EXAMDATE D  Examination Date
#'   \item UID T  
#'   \item ROINAME T  Location of Meta ROI (for methods, see Landau et al., Neurology, 2010 or email slandau@berkeley.edu)
#'   \item ROILAT T  Laterality of ROI
#'   \item MEAN N glucose metabolism normalized to pons mean of FDG-PET within ROI
#'   \item MEDIAN N glucose metabolism normalized to pons median of FDG-PET within ROI
#'   \item MODE N glucose metabolism normalized to pons mode of FDG-PET within ROI
#'   \item MIN N glucose metabolism normalized to pons min of FDG-PET within ROI
#'   \item MAX N glucose metabolism normalized to pons max of FDG-PET within ROI
#'   \item STDEV N glucose metabolism normalized to pons standard deviation of FDG-PET within ROI
#'   \item NANVOX N voxels total number of zero or NaN voxels within ROI
#'   \item TOTVOX N voxels total number of voxels within ROI
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name ucberkeleyfdg
#' @usage data(ucberkeleyfdg)
#' @format A data frame with 16805 rows and 15 variables
NULL

#' Univerity of California Davis White Matter Hyperintensity Volumes (ADNI1)
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/UCD_ADNI1_WMH/UCD%20ADNI%20WMH%20Segmentation%20Method.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID T  Participant roster ID
#'   \item EXAMDATE D  Examination Date
#'   \item VISCODE -4 -4 Visit code
#'   \item WHITMATHYP N cc Adjusted WMH
#'   \item MANUFACTURER T  MRI Machine Manufacturer
#'   \item MODEL T  MRI Machine Model
#'   \item MAGSTRENGTH T  MRI Machine Magnetic Field Strength
#'   \item SEGPROCIMG T  Images used for segmentation
#'   \item SEGPROC T  Analysis method used for segmentation
#' }
#'
#' @examples
#' \donotrun{
#' describe(ucd_adni1_wmh)
#' }
#' @docType data
#' @keywords datasets
#' @name ucd_adni1_wmh
#' @usage data(ucd_adni1_wmh)
#' @format A data frame with 3469 rows and 10 variables
NULL

#' Univerity of California Davis White Matter Hyperintensity Volumes (ADNI2)
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/UCD_ADNI2_WMH/UCD%20ADNI%20II%204%20tissue%20segmentation%20Method.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item VISCODE2 -4 -4 Translated visit code
#'   \item EXAMDATE D  Examination Date
#'   \item CSF N cc intracranial CSF volume
#'   \item GRAY N cc Intracranial gray matter volume
#'   \item WHITE N cc Intracranial white matter volume
#'   \item WHITMATHYP N cc WMH volume
#'   \item ICV N cc Intracranial volume
#'   \item STATUS N  ADNI Participant status
#'   \item MAGSTRENGTH T  MRI Machine Magnetic Field Strength
#'   \item MANUFACTURER T  MRI Machine Manufacturer
#'   \item MANUFACTURERSMODEL T  MRI Machine Model
#'   \item SEGPROC T  Images used for segmentation
#'   \item SEGPROCIMG T  Analysis method used for segmentation
#' }
#'
#' @examples
#' \donotrun{
#' describe(ucd_adni2_wmh)
#' }
#' @docType data
#' @keywords datasets
#' @name ucd_adni2_wmh
#' @usage data(ucd_adni2_wmh)
#' @format A data frame with 3734 rows and 15 variables
NULL

#' Anders Dale Lab (UCSD) - Derived Volumes
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/UCSDVOL/ADpower.jpg}, \url{https://adni.bitbucket.io/reference/docs/UCSDVOL/MCIpower.jpg}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N -4 Participant roster ID
#'   \item VISITNUM N -4 
#'   \item VISCODE T -4 Visit code
#'   \item EXAMDATE D -4 Examination Date
#'   \item LONISID T -4 LONISID
#'   \item QCPASS N -4 
#'   \item BRAIN N mm3 Whole Brain. A summary measure of total brain parenchyma, including the Cerebral-Cortex, Cerebellum-Cortex, Thalamus-Proper, CaudatePutamen, Pallidum, Hippocampus, Amygdala, Accumbens-area, VentralDC, Cerebral-White-Matter, Cerebellum-White-Matter, and WM-hypointensities. As such, it does not include ventricles or other CSF spaces, and is not intended to be used as a measure of intracranial volume.
#'   \item EICV N mm3 Estimated Intracranial Volume, aka eTIV. To generate the mask, the baseline image is automatically segmented; all thus-defined brain and ventricular voxels are given the value 1 with all other voxels 0. This binary mask is then repeatedly smoothed with a Gaussian kernel to produce a simply connected uniform mask, covering all sulci, whose boundary tapers smoothly from 1 to 0 over the length of a few voxels. Ideally, the mask would end on the skull and include the brain stem down to where it starts to bend with the neck. The smoothing can be controlled fairly nicely to begin tapering at the skull, so that voxels with a mask value less than 1 can  be considered outside the ICV and therefore ignored.
#'   \item VENTRICLES N mm3 Ventricles
#'   \item LHIPPOC N mm3 Left Hippocampus
#'   \item RHIPPOC N mm3 Right Hippocampus
#'   \item LINFLATVEN N mm3 Left inferior lateral ventricle
#'   \item RINFLATVEN N mm3 Right inferior lateral ventricle
#'   \item LMIDTEMP N mm Left Middle Temporal
#'   \item RMIDTEMP N mm Right Middle Temporal
#'   \item LINFTEMP N mm Left Inferior Temporal
#'   \item RINFTEMP N mm Right Inferior Temporal
#'   \item LFUSIFORM N mm Left Fusiform
#'   \item RFUSIFORM N mm Right Fusiform
#'   \item LENTORHIN N mm Left Entorhinal
#'   \item RENTORHIN N mm Right Entorhinal
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name ucsdvol
#' @usage data(ucsdvol)
#' @format A data frame with 3212 rows and 22 variables
NULL

#' ASL Perfusion CBF by FreeSurfer ROI
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item COLPROT -4 -4 Study protocol of data collection
#'   \item RID N  Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item VISCODE2 -4 -4 Translated visit code
#'   \item EXAMDATE D  Examination Date
#'   \item VERSION D  
#'   \item LONIUID N  
#'   \item IMAGEUID N  
#'   \item RUNDATE D  
#'   \item RAWQC T  A QC rating of the raw Perfusion Weighted Image
#'   \item MODEQC -4 -4 -4
#'   \item MBLOODQC -4 -4 -4
#'   \item FSROIQC -4 -4 -4
#'   \item FSOVERALLQC -4 -4 -4
#'   \item FSTEMPQC -4 -4 -4
#'   \item FSFRONTQC -4 -4 -4
#'   \item FSPARQC -4 -4 -4
#'   \item FSINSULAQC -4 -4 -4
#'   \item FSOCCQC -4 -4 -4
#'   \item FSBGQC -4 -4 -4
#'   \item FSCWMQC -4 -4 -4
#'   \item FSVENTQC -4 -4 -4
#'   \item ST1MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: Brain-Stem
#'   \item ST1MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: Brain-Stem
#'   \item ST1MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: Brain-Stem
#'   \item ST1AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: Brain-Stem
#'   \item ST1SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: Brain-Stem
#'   \item ST1CT N  Count of CBF voxels in FreeSurfer ROI: Brain-Stem
#'   \item ST2MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: CC_Anterior
#'   \item ST2MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: CC_Anterior
#'   \item ST2MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: CC_Anterior
#'   \item ST2AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: CC_Anterior
#'   \item ST2SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: CC_Anterior
#'   \item ST2CT N  Count of CBF voxels in FreeSurfer ROI: CC_Anterior
#'   \item ST3MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: CC_Central
#'   \item ST3MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: CC_Central
#'   \item ST3MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: CC_Central
#'   \item ST3AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: CC_Central
#'   \item ST3SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: CC_Central
#'   \item ST3CT N  Count of CBF voxels in FreeSurfer ROI: CC_Central
#'   \item ST4MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: CC_Mid_Anterior
#'   \item ST4MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: CC_Mid_Anterior
#'   \item ST4MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: CC_Mid_Anterior
#'   \item ST4AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: CC_Mid_Anterior
#'   \item ST4SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: CC_Mid_Anterior
#'   \item ST4CT N  Count of CBF voxels in FreeSurfer ROI: CC_Mid_Anterior
#'   \item ST5MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: CC_Mid_Posterior
#'   \item ST5MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: CC_Mid_Posterior
#'   \item ST5MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: CC_Mid_Posterior
#'   \item ST5AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: CC_Mid_Posterior
#'   \item ST5SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: CC_Mid_Posterior
#'   \item ST5CT N  Count of CBF voxels in FreeSurfer ROI: CC_Mid_Posterior
#'   \item ST6MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: CC_Posterior
#'   \item ST6MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: CC_Posterior
#'   \item ST6MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: CC_Posterior
#'   \item ST6AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: CC_Posterior
#'   \item ST6SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: CC_Posterior
#'   \item ST6CT N  Count of CBF voxels in FreeSurfer ROI: CC_Posterior
#'   \item ST7MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: CSF
#'   \item ST7MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: CSF
#'   \item ST7MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: CSF
#'   \item ST7AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: CSF
#'   \item ST7SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: CSF
#'   \item ST7CT N  Count of CBF voxels in FreeSurfer ROI: CSF
#'   \item ST8MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: 5th-Ventricle
#'   \item ST8MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: 5th-Ventricle
#'   \item ST8MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: 5th-Ventricle
#'   \item ST8AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: 5th-Ventricle
#'   \item ST8SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: 5th-Ventricle
#'   \item ST8CT N  Count of CBF voxels in FreeSurfer ROI: 5th-Ventricle
#'   \item ST9MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: 4th-Ventricle
#'   \item ST9MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: 4th-Ventricle
#'   \item ST9MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: 4th-Ventricle
#'   \item ST9AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: 4th-Ventricle
#'   \item ST9SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: 4th-Ventricle
#'   \item ST9CT N  Count of CBF voxels in FreeSurfer ROI: 4th-Ventricle
#'   \item ST11MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: Left-Accumbens-area
#'   \item ST11MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: Left-Accumbens-area
#'   \item ST11MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: Left-Accumbens-area
#'   \item ST11AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: Left-Accumbens-area
#'   \item ST11SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: Left-Accumbens-area
#'   \item ST11CT N  Count of CBF voxels in FreeSurfer ROI: Left-Accumbens-area
#'   \item ST12MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: Left-Amygdala
#'   \item ST12MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: Left-Amygdala
#'   \item ST12MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: Left-Amygdala
#'   \item ST12AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: Left-Amygdala
#'   \item ST12SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: Left-Amygdala
#'   \item ST12CT N  Count of CBF voxels in FreeSurfer ROI: Left-Amygdala
#'   \item ST13MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-bankssts
#'   \item ST13MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-bankssts
#'   \item ST13MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-bankssts
#'   \item ST13AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-bankssts
#'   \item ST13SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-bankssts
#'   \item ST13CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-bankssts
#'   \item ST14MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-caudalanteriorcingulate
#'   \item ST14MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-caudalanteriorcingulate
#'   \item ST14MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-caudalanteriorcingulate
#'   \item ST14AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-caudalanteriorcingulate
#'   \item ST14SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-caudalanteriorcingulate
#'   \item ST14CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-caudalanteriorcingulate
#'   \item ST15MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-caudalmiddlefrontal
#'   \item ST15MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-caudalmiddlefrontal
#'   \item ST15MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-caudalmiddlefrontal
#'   \item ST15AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-caudalmiddlefrontal
#'   \item ST15SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-caudalmiddlefrontal
#'   \item ST15CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-caudalmiddlefrontal
#'   \item ST16MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: Left-Caudate
#'   \item ST16MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: Left-Caudate
#'   \item ST16MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: Left-Caudate
#'   \item ST16AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: Left-Caudate
#'   \item ST16SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: Left-Caudate
#'   \item ST16CT N  Count of CBF voxels in FreeSurfer ROI: Left-Caudate
#'   \item ST17MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: Left-Cerebellum-Cortex
#'   \item ST17MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: Left-Cerebellum-Cortex
#'   \item ST17MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: Left-Cerebellum-Cortex
#'   \item ST17AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: Left-Cerebellum-Cortex
#'   \item ST17SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: Left-Cerebellum-Cortex
#'   \item ST17CT N  Count of CBF voxels in FreeSurfer ROI: Left-Cerebellum-Cortex
#'   \item ST18MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: Left-Cerebellum-White-Matter
#'   \item ST18MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: Left-Cerebellum-White-Matter
#'   \item ST18MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: Left-Cerebellum-White-Matter
#'   \item ST18AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: Left-Cerebellum-White-Matter
#'   \item ST18SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: Left-Cerebellum-White-Matter
#'   \item ST18CT N  Count of CBF voxels in FreeSurfer ROI: Left-Cerebellum-White-Matter
#'   \item ST20MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: Left-Cerebral-White-Matter
#'   \item ST20MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: Left-Cerebral-White-Matter
#'   \item ST20MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: Left-Cerebral-White-Matter
#'   \item ST20AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: Left-Cerebral-White-Matter
#'   \item ST20SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: Left-Cerebral-White-Matter
#'   \item ST20CT N  Count of CBF voxels in FreeSurfer ROI: Left-Cerebral-White-Matter
#'   \item ST21MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: Left-choroid-plexus
#'   \item ST21MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: Left-choroid-plexus
#'   \item ST21MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: Left-choroid-plexus
#'   \item ST21AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: Left-choroid-plexus
#'   \item ST21SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: Left-choroid-plexus
#'   \item ST21CT N  Count of CBF voxels in FreeSurfer ROI: Left-choroid-plexus
#'   \item ST22MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-corpuscallosum
#'   \item ST22MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-corpuscallosum
#'   \item ST22MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-corpuscallosum
#'   \item ST22AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-corpuscallosum
#'   \item ST22SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-corpuscallosum
#'   \item ST22CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-corpuscallosum
#'   \item ST23MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-cuneus
#'   \item ST23MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-cuneus
#'   \item ST23MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-cuneus
#'   \item ST23AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-cuneus
#'   \item ST23SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-cuneus
#'   \item ST23CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-cuneus
#'   \item ST24MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-entorhinal
#'   \item ST24MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-entorhinal
#'   \item ST24MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-entorhinal
#'   \item ST24AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-entorhinal
#'   \item ST24SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-entorhinal
#'   \item ST24CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-entorhinal
#'   \item ST25MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-frontalpole
#'   \item ST25MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-frontalpole
#'   \item ST25MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-frontalpole
#'   \item ST25AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-frontalpole
#'   \item ST25SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-frontalpole
#'   \item ST25CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-frontalpole
#'   \item ST26MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-fusiform
#'   \item ST26MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-fusiform
#'   \item ST26MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-fusiform
#'   \item ST26AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-fusiform
#'   \item ST26SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-fusiform
#'   \item ST26CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-fusiform
#'   \item ST29MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: Left-Hippocampus
#'   \item ST29MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: Left-Hippocampus
#'   \item ST29MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: Left-Hippocampus
#'   \item ST29AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: Left-Hippocampus
#'   \item ST29SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: Left-Hippocampus
#'   \item ST29CT N  Count of CBF voxels in FreeSurfer ROI: Left-Hippocampus
#'   \item ST30MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: Left-Inf-Lat-Vent
#'   \item ST30MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: Left-Inf-Lat-Vent
#'   \item ST30MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: Left-Inf-Lat-Vent
#'   \item ST30AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: Left-Inf-Lat-Vent
#'   \item ST30SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: Left-Inf-Lat-Vent
#'   \item ST30CT N  Count of CBF voxels in FreeSurfer ROI: Left-Inf-Lat-Vent
#'   \item ST31MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-inferiorparietal
#'   \item ST31MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-inferiorparietal
#'   \item ST31MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-inferiorparietal
#'   \item ST31AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-inferiorparietal
#'   \item ST31SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-inferiorparietal
#'   \item ST31CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-inferiorparietal
#'   \item ST32MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-inferiortemporal
#'   \item ST32MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-inferiortemporal
#'   \item ST32MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-inferiortemporal
#'   \item ST32AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-inferiortemporal
#'   \item ST32SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-inferiortemporal
#'   \item ST32CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-inferiortemporal
#'   \item ST34MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-isthmuscingulate
#'   \item ST34MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-isthmuscingulate
#'   \item ST34MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-isthmuscingulate
#'   \item ST34AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-isthmuscingulate
#'   \item ST34SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-isthmuscingulate
#'   \item ST34CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-isthmuscingulate
#'   \item ST35MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-lateraloccipital
#'   \item ST35MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-lateraloccipital
#'   \item ST35MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-lateraloccipital
#'   \item ST35AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-lateraloccipital
#'   \item ST35SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-lateraloccipital
#'   \item ST35CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-lateraloccipital
#'   \item ST36MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-lateralorbitofrontal
#'   \item ST36MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-lateralorbitofrontal
#'   \item ST36MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-lateralorbitofrontal
#'   \item ST36AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-lateralorbitofrontal
#'   \item ST36SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-lateralorbitofrontal
#'   \item ST36CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-lateralorbitofrontal
#'   \item ST37MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: Left-Lateral-Ventricle
#'   \item ST37MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: Left-Lateral-Ventricle
#'   \item ST37MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: Left-Lateral-Ventricle
#'   \item ST37AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: Left-Lateral-Ventricle
#'   \item ST37SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: Left-Lateral-Ventricle
#'   \item ST37CT N  Count of CBF voxels in FreeSurfer ROI: Left-Lateral-Ventricle
#'   \item ST38MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-lingual
#'   \item ST38MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-lingual
#'   \item ST38MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-lingual
#'   \item ST38AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-lingual
#'   \item ST38SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-lingual
#'   \item ST38CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-lingual
#'   \item ST39MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-medialorbitofrontal
#'   \item ST39MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-medialorbitofrontal
#'   \item ST39MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-medialorbitofrontal
#'   \item ST39AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-medialorbitofrontal
#'   \item ST39SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-medialorbitofrontal
#'   \item ST39CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-medialorbitofrontal
#'   \item ST40MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-middletemporal
#'   \item ST40MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-middletemporal
#'   \item ST40MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-middletemporal
#'   \item ST40AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-middletemporal
#'   \item ST40SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-middletemporal
#'   \item ST40CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-middletemporal
#'   \item ST42MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: Left-Pallidum
#'   \item ST42MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: Left-Pallidum
#'   \item ST42MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: Left-Pallidum
#'   \item ST42AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: Left-Pallidum
#'   \item ST42SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: Left-Pallidum
#'   \item ST42CT N  Count of CBF voxels in FreeSurfer ROI: Left-Pallidum
#'   \item ST43MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-paracentral
#'   \item ST43MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-paracentral
#'   \item ST43MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-paracentral
#'   \item ST43AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-paracentral
#'   \item ST43SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-paracentral
#'   \item ST43CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-paracentral
#'   \item ST44MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-parahippocampal
#'   \item ST44MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-parahippocampal
#'   \item ST44MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-parahippocampal
#'   \item ST44AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-parahippocampal
#'   \item ST44SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-parahippocampal
#'   \item ST44CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-parahippocampal
#'   \item ST45MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-parsopercularis
#'   \item ST45MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-parsopercularis
#'   \item ST45MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-parsopercularis
#'   \item ST45AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-parsopercularis
#'   \item ST45SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-parsopercularis
#'   \item ST45CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-parsopercularis
#'   \item ST46MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-parsorbitalis
#'   \item ST46MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-parsorbitalis
#'   \item ST46MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-parsorbitalis
#'   \item ST46AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-parsorbitalis
#'   \item ST46SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-parsorbitalis
#'   \item ST46CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-parsorbitalis
#'   \item ST47MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-parstriangularis
#'   \item ST47MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-parstriangularis
#'   \item ST47MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-parstriangularis
#'   \item ST47AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-parstriangularis
#'   \item ST47SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-parstriangularis
#'   \item ST47CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-parstriangularis
#'   \item ST48MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-pericalcarine
#'   \item ST48MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-pericalcarine
#'   \item ST48MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-pericalcarine
#'   \item ST48AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-pericalcarine
#'   \item ST48SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-pericalcarine
#'   \item ST48CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-pericalcarine
#'   \item ST49MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-postcentral
#'   \item ST49MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-postcentral
#'   \item ST49MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-postcentral
#'   \item ST49AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-postcentral
#'   \item ST49SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-postcentral
#'   \item ST49CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-postcentral
#'   \item ST50MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-posteriorcingulate
#'   \item ST50MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-posteriorcingulate
#'   \item ST50MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-posteriorcingulate
#'   \item ST50AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-posteriorcingulate
#'   \item ST50SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-posteriorcingulate
#'   \item ST50CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-posteriorcingulate
#'   \item ST51MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-precentral
#'   \item ST51MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-precentral
#'   \item ST51MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-precentral
#'   \item ST51AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-precentral
#'   \item ST51SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-precentral
#'   \item ST51CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-precentral
#'   \item ST52MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-precuneus
#'   \item ST52MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-precuneus
#'   \item ST52MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-precuneus
#'   \item ST52AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-precuneus
#'   \item ST52SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-precuneus
#'   \item ST52CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-precuneus
#'   \item ST53MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: Left-Putamen
#'   \item ST53MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: Left-Putamen
#'   \item ST53MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: Left-Putamen
#'   \item ST53AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: Left-Putamen
#'   \item ST53SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: Left-Putamen
#'   \item ST53CT N  Count of CBF voxels in FreeSurfer ROI: Left-Putamen
#'   \item ST54MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-rostralanteriorcingulate
#'   \item ST54MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-rostralanteriorcingulate
#'   \item ST54MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-rostralanteriorcingulate
#'   \item ST54AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-rostralanteriorcingulate
#'   \item ST54SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-rostralanteriorcingulate
#'   \item ST54CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-rostralanteriorcingulate
#'   \item ST55MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-rostralmiddlefrontal
#'   \item ST55MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-rostralmiddlefrontal
#'   \item ST55MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-rostralmiddlefrontal
#'   \item ST55AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-rostralmiddlefrontal
#'   \item ST55SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-rostralmiddlefrontal
#'   \item ST55CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-rostralmiddlefrontal
#'   \item ST56MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-superiorfrontal
#'   \item ST56MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-superiorfrontal
#'   \item ST56MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-superiorfrontal
#'   \item ST56AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-superiorfrontal
#'   \item ST56SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-superiorfrontal
#'   \item ST56CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-superiorfrontal
#'   \item ST57MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-superiorparietal
#'   \item ST57MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-superiorparietal
#'   \item ST57MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-superiorparietal
#'   \item ST57AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-superiorparietal
#'   \item ST57SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-superiorparietal
#'   \item ST57CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-superiorparietal
#'   \item ST58MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-superiortemporal
#'   \item ST58MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-superiortemporal
#'   \item ST58MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-superiortemporal
#'   \item ST58AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-superiortemporal
#'   \item ST58SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-superiortemporal
#'   \item ST58CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-superiortemporal
#'   \item ST59MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-supramarginal
#'   \item ST59MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-supramarginal
#'   \item ST59MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-supramarginal
#'   \item ST59AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-supramarginal
#'   \item ST59SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-supramarginal
#'   \item ST59CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-supramarginal
#'   \item ST60MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-temporalpole
#'   \item ST60MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-temporalpole
#'   \item ST60MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-temporalpole
#'   \item ST60AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-temporalpole
#'   \item ST60SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-temporalpole
#'   \item ST60CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-temporalpole
#'   \item ST61MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: Left-Thalamus-Proper
#'   \item ST61MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: Left-Thalamus-Proper
#'   \item ST61MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: Left-Thalamus-Proper
#'   \item ST61AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: Left-Thalamus-Proper
#'   \item ST61SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: Left-Thalamus-Proper
#'   \item ST61CT N  Count of CBF voxels in FreeSurfer ROI: Left-Thalamus-Proper
#'   \item ST62MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-transversetemporal
#'   \item ST62MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-transversetemporal
#'   \item ST62MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-transversetemporal
#'   \item ST62AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-transversetemporal
#'   \item ST62SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-transversetemporal
#'   \item ST62CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-transversetemporal
#'   \item ST64MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-unknown
#'   \item ST64MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-unknown
#'   \item ST64MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-unknown
#'   \item ST64AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-unknown
#'   \item ST64SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-unknown
#'   \item ST64CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-unknown
#'   \item ST65MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: Left-VentralDC
#'   \item ST65MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: Left-VentralDC
#'   \item ST65MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: Left-VentralDC
#'   \item ST65AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: Left-VentralDC
#'   \item ST65SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: Left-VentralDC
#'   \item ST65CT N  Count of CBF voxels in FreeSurfer ROI: Left-VentralDC
#'   \item ST66MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: Left-vessel
#'   \item ST66MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: Left-vessel
#'   \item ST66MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: Left-vessel
#'   \item ST66AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: Left-vessel
#'   \item ST66SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: Left-vessel
#'   \item ST66CT N  Count of CBF voxels in FreeSurfer ROI: Left-vessel
#'   \item ST68MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: non-WM-hypointensities
#'   \item ST68MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: non-WM-hypointensities
#'   \item ST68MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: non-WM-hypointensities
#'   \item ST68AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: non-WM-hypointensities
#'   \item ST68SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: non-WM-hypointensities
#'   \item ST68CT N  Count of CBF voxels in FreeSurfer ROI: non-WM-hypointensities
#'   \item ST69MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: Optic-Chiasm
#'   \item ST69MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: Optic-Chiasm
#'   \item ST69MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: Optic-Chiasm
#'   \item ST69AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: Optic-Chiasm
#'   \item ST69SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: Optic-Chiasm
#'   \item ST69CT N  Count of CBF voxels in FreeSurfer ROI: Optic-Chiasm
#'   \item ST70MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: Right-Accumbens-area
#'   \item ST70MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: Right-Accumbens-area
#'   \item ST70MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: Right-Accumbens-area
#'   \item ST70AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: Right-Accumbens-area
#'   \item ST70SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: Right-Accumbens-area
#'   \item ST70CT N  Count of CBF voxels in FreeSurfer ROI: Right-Accumbens-area
#'   \item ST71MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: Right-Amygdala
#'   \item ST71MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: Right-Amygdala
#'   \item ST71MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: Right-Amygdala
#'   \item ST71AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: Right-Amygdala
#'   \item ST71SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: Right-Amygdala
#'   \item ST71CT N  Count of CBF voxels in FreeSurfer ROI: Right-Amygdala
#'   \item ST72MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-bankssts
#'   \item ST72MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-bankssts
#'   \item ST72MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-bankssts
#'   \item ST72AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-bankssts
#'   \item ST72SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-bankssts
#'   \item ST72CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-bankssts
#'   \item ST73MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-caudalanteriorcingulate
#'   \item ST73MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-caudalanteriorcingulate
#'   \item ST73MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-caudalanteriorcingulate
#'   \item ST73AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-caudalanteriorcingulate
#'   \item ST73SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-caudalanteriorcingulate
#'   \item ST73CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-caudalanteriorcingulate
#'   \item ST74MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-caudalmiddlefrontal
#'   \item ST74MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-caudalmiddlefrontal
#'   \item ST74MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-caudalmiddlefrontal
#'   \item ST74AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-caudalmiddlefrontal
#'   \item ST74SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-caudalmiddlefrontal
#'   \item ST74CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-caudalmiddlefrontal
#'   \item ST75MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: Right-Caudate
#'   \item ST75MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: Right-Caudate
#'   \item ST75MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: Right-Caudate
#'   \item ST75AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: Right-Caudate
#'   \item ST75SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: Right-Caudate
#'   \item ST75CT N  Count of CBF voxels in FreeSurfer ROI: Right-Caudate
#'   \item ST76MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: Right-Cerebellum-Cortex
#'   \item ST76MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: Right-Cerebellum-Cortex
#'   \item ST76MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: Right-Cerebellum-Cortex
#'   \item ST76AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: Right-Cerebellum-Cortex
#'   \item ST76SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: Right-Cerebellum-Cortex
#'   \item ST76CT N  Count of CBF voxels in FreeSurfer ROI: Right-Cerebellum-Cortex
#'   \item ST77MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: Right-Cerebellum-White-Matter
#'   \item ST77MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: Right-Cerebellum-White-Matter
#'   \item ST77MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: Right-Cerebellum-White-Matter
#'   \item ST77AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: Right-Cerebellum-White-Matter
#'   \item ST77SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: Right-Cerebellum-White-Matter
#'   \item ST77CT N  Count of CBF voxels in FreeSurfer ROI: Right-Cerebellum-White-Matter
#'   \item ST79MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: Right-Cerebral-White-Matter
#'   \item ST79MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: Right-Cerebral-White-Matter
#'   \item ST79MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: Right-Cerebral-White-Matter
#'   \item ST79AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: Right-Cerebral-White-Matter
#'   \item ST79SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: Right-Cerebral-White-Matter
#'   \item ST79CT N  Count of CBF voxels in FreeSurfer ROI: Right-Cerebral-White-Matter
#'   \item ST80MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: Right-choroid-plexus
#'   \item ST80MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: Right-choroid-plexus
#'   \item ST80MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: Right-choroid-plexus
#'   \item ST80AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: Right-choroid-plexus
#'   \item ST80SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: Right-choroid-plexus
#'   \item ST80CT N  Count of CBF voxels in FreeSurfer ROI: Right-choroid-plexus
#'   \item ST81MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-corpuscallosum
#'   \item ST81MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-corpuscallosum
#'   \item ST81MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-corpuscallosum
#'   \item ST81AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-corpuscallosum
#'   \item ST81SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-corpuscallosum
#'   \item ST81CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-corpuscallosum
#'   \item ST82MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-cuneus
#'   \item ST82MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-cuneus
#'   \item ST82MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-cuneus
#'   \item ST82AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-cuneus
#'   \item ST82SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-cuneus
#'   \item ST82CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-cuneus
#'   \item ST83MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-entorhinal
#'   \item ST83MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-entorhinal
#'   \item ST83MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-entorhinal
#'   \item ST83AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-entorhinal
#'   \item ST83SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-entorhinal
#'   \item ST83CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-entorhinal
#'   \item ST84MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-frontalpole
#'   \item ST84MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-frontalpole
#'   \item ST84MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-frontalpole
#'   \item ST84AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-frontalpole
#'   \item ST84SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-frontalpole
#'   \item ST84CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-frontalpole
#'   \item ST85MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-fusiform
#'   \item ST85MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-fusiform
#'   \item ST85MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-fusiform
#'   \item ST85AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-fusiform
#'   \item ST85SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-fusiform
#'   \item ST85CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-fusiform
#'   \item ST88MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: Right-Hippocampus
#'   \item ST88MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: Right-Hippocampus
#'   \item ST88MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: Right-Hippocampus
#'   \item ST88AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: Right-Hippocampus
#'   \item ST88SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: Right-Hippocampus
#'   \item ST88CT N  Count of CBF voxels in FreeSurfer ROI: Right-Hippocampus
#'   \item ST89MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: Right-Inf-Lat-Vent
#'   \item ST89MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: Right-Inf-Lat-Vent
#'   \item ST89MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: Right-Inf-Lat-Vent
#'   \item ST89AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: Right-Inf-Lat-Vent
#'   \item ST89SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: Right-Inf-Lat-Vent
#'   \item ST89CT N  Count of CBF voxels in FreeSurfer ROI: Right-Inf-Lat-Vent
#'   \item ST90MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-inferiorparietal
#'   \item ST90MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-inferiorparietal
#'   \item ST90MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-inferiorparietal
#'   \item ST90AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-inferiorparietal
#'   \item ST90SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-inferiorparietal
#'   \item ST90CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-inferiorparietal
#'   \item ST91MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-inferiortemporal
#'   \item ST91MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-inferiortemporal
#'   \item ST91MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-inferiortemporal
#'   \item ST91AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-inferiortemporal
#'   \item ST91SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-inferiortemporal
#'   \item ST91CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-inferiortemporal
#'   \item ST93MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-isthmuscingulate
#'   \item ST93MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-isthmuscingulate
#'   \item ST93MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-isthmuscingulate
#'   \item ST93AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-isthmuscingulate
#'   \item ST93SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-isthmuscingulate
#'   \item ST93CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-isthmuscingulate
#'   \item ST94MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-lateraloccipital
#'   \item ST94MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-lateraloccipital
#'   \item ST94MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-lateraloccipital
#'   \item ST94AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-lateraloccipital
#'   \item ST94SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-lateraloccipital
#'   \item ST94CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-lateraloccipital
#'   \item ST95MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-lateralorbitofrontal
#'   \item ST95MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-lateralorbitofrontal
#'   \item ST95MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-lateralorbitofrontal
#'   \item ST95AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-lateralorbitofrontal
#'   \item ST95SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-lateralorbitofrontal
#'   \item ST95CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-lateralorbitofrontal
#'   \item ST96MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: Right-Lateral-Ventricle
#'   \item ST96MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: Right-Lateral-Ventricle
#'   \item ST96MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: Right-Lateral-Ventricle
#'   \item ST96AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: Right-Lateral-Ventricle
#'   \item ST96SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: Right-Lateral-Ventricle
#'   \item ST96CT N  Count of CBF voxels in FreeSurfer ROI: Right-Lateral-Ventricle
#'   \item ST97MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-lingual
#'   \item ST97MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-lingual
#'   \item ST97MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-lingual
#'   \item ST97AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-lingual
#'   \item ST97SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-lingual
#'   \item ST97CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-lingual
#'   \item ST98MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-medialorbitofrontal
#'   \item ST98MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-medialorbitofrontal
#'   \item ST98MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-medialorbitofrontal
#'   \item ST98AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-medialorbitofrontal
#'   \item ST98SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-medialorbitofrontal
#'   \item ST98CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-medialorbitofrontal
#'   \item ST99MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-middletemporal
#'   \item ST99MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-middletemporal
#'   \item ST99MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-middletemporal
#'   \item ST99AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-middletemporal
#'   \item ST99SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-middletemporal
#'   \item ST99CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-middletemporal
#'   \item ST101MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: Right-Pallidum
#'   \item ST101MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: Right-Pallidum
#'   \item ST101MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: Right-Pallidum
#'   \item ST101AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: Right-Pallidum
#'   \item ST101SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: Right-Pallidum
#'   \item ST101CT N  Count of CBF voxels in FreeSurfer ROI: Right-Pallidum
#'   \item ST102MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-paracentral
#'   \item ST102MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-paracentral
#'   \item ST102MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-paracentral
#'   \item ST102AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-paracentral
#'   \item ST102SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-paracentral
#'   \item ST102CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-paracentral
#'   \item ST103MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-parahippocampal
#'   \item ST103MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-parahippocampal
#'   \item ST103MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-parahippocampal
#'   \item ST103AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-parahippocampal
#'   \item ST103SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-parahippocampal
#'   \item ST103CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-parahippocampal
#'   \item ST104MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-parsopercularis
#'   \item ST104MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-parsopercularis
#'   \item ST104MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-parsopercularis
#'   \item ST104AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-parsopercularis
#'   \item ST104SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-parsopercularis
#'   \item ST104CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-parsopercularis
#'   \item ST105MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-parsorbitalis
#'   \item ST105MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-parsorbitalis
#'   \item ST105MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-parsorbitalis
#'   \item ST105AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-parsorbitalis
#'   \item ST105SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-parsorbitalis
#'   \item ST105CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-parsorbitalis
#'   \item ST106MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-parstriangularis
#'   \item ST106MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-parstriangularis
#'   \item ST106MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-parstriangularis
#'   \item ST106AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-parstriangularis
#'   \item ST106SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-parstriangularis
#'   \item ST106CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-parstriangularis
#'   \item ST107MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-pericalcarine
#'   \item ST107MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-pericalcarine
#'   \item ST107MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-pericalcarine
#'   \item ST107AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-pericalcarine
#'   \item ST107SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-pericalcarine
#'   \item ST107CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-pericalcarine
#'   \item ST108MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-postcentral
#'   \item ST108MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-postcentral
#'   \item ST108MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-postcentral
#'   \item ST108AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-postcentral
#'   \item ST108SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-postcentral
#'   \item ST108CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-postcentral
#'   \item ST109MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-posteriorcingulate
#'   \item ST109MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-posteriorcingulate
#'   \item ST109MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-posteriorcingulate
#'   \item ST109AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-posteriorcingulate
#'   \item ST109SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-posteriorcingulate
#'   \item ST109CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-posteriorcingulate
#'   \item ST110MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-precentral
#'   \item ST110MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-precentral
#'   \item ST110MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-precentral
#'   \item ST110AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-precentral
#'   \item ST110SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-precentral
#'   \item ST110CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-precentral
#'   \item ST111MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-precuneus
#'   \item ST111MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-precuneus
#'   \item ST111MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-precuneus
#'   \item ST111AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-precuneus
#'   \item ST111SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-precuneus
#'   \item ST111CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-precuneus
#'   \item ST112MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: Right-Putamen
#'   \item ST112MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: Right-Putamen
#'   \item ST112MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: Right-Putamen
#'   \item ST112AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: Right-Putamen
#'   \item ST112SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: Right-Putamen
#'   \item ST112CT N  Count of CBF voxels in FreeSurfer ROI: Right-Putamen
#'   \item ST113MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-rostralanteriorcingulate
#'   \item ST113MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-rostralanteriorcingulate
#'   \item ST113MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-rostralanteriorcingulate
#'   \item ST113AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-rostralanteriorcingulate
#'   \item ST113SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-rostralanteriorcingulate
#'   \item ST113CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-rostralanteriorcingulate
#'   \item ST114MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-rostralmiddlefrontal
#'   \item ST114MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-rostralmiddlefrontal
#'   \item ST114MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-rostralmiddlefrontal
#'   \item ST114AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-rostralmiddlefrontal
#'   \item ST114SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-rostralmiddlefrontal
#'   \item ST114CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-rostralmiddlefrontal
#'   \item ST115MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-superiorfrontal
#'   \item ST115MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-superiorfrontal
#'   \item ST115MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-superiorfrontal
#'   \item ST115AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-superiorfrontal
#'   \item ST115SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-superiorfrontal
#'   \item ST115CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-superiorfrontal
#'   \item ST116MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-superiorparietal
#'   \item ST116MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-superiorparietal
#'   \item ST116MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-superiorparietal
#'   \item ST116AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-superiorparietal
#'   \item ST116SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-superiorparietal
#'   \item ST116CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-superiorparietal
#'   \item ST117MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-superiortemporal
#'   \item ST117MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-superiortemporal
#'   \item ST117MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-superiortemporal
#'   \item ST117AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-superiortemporal
#'   \item ST117SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-superiortemporal
#'   \item ST117CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-superiortemporal
#'   \item ST118MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-supramarginal
#'   \item ST118MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-supramarginal
#'   \item ST118MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-supramarginal
#'   \item ST118AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-supramarginal
#'   \item ST118SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-supramarginal
#'   \item ST118CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-supramarginal
#'   \item ST119MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-temporalpole
#'   \item ST119MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-temporalpole
#'   \item ST119MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-temporalpole
#'   \item ST119AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-temporalpole
#'   \item ST119SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-temporalpole
#'   \item ST119CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-temporalpole
#'   \item ST120MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: Right-Thalamus-Proper
#'   \item ST120MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: Right-Thalamus-Proper
#'   \item ST120MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: Right-Thalamus-Proper
#'   \item ST120AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: Right-Thalamus-Proper
#'   \item ST120SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: Right-Thalamus-Proper
#'   \item ST120CT N  Count of CBF voxels in FreeSurfer ROI: Right-Thalamus-Proper
#'   \item ST121MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-transversetemporal
#'   \item ST121MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-transversetemporal
#'   \item ST121MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-transversetemporal
#'   \item ST121AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-transversetemporal
#'   \item ST121SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-transversetemporal
#'   \item ST121CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-transversetemporal
#'   \item ST123MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-unknown
#'   \item ST123MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-unknown
#'   \item ST123MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-unknown
#'   \item ST123AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-unknown
#'   \item ST123SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-unknown
#'   \item ST123CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-unknown
#'   \item ST124MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: Right-VentralDC
#'   \item ST124MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: Right-VentralDC
#'   \item ST124MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: Right-VentralDC
#'   \item ST124AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: Right-VentralDC
#'   \item ST124SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: Right-VentralDC
#'   \item ST124CT N  Count of CBF voxels in FreeSurfer ROI: Right-VentralDC
#'   \item ST125MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: Right-vessel
#'   \item ST125MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: Right-vessel
#'   \item ST125MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: Right-vessel
#'   \item ST125AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: Right-vessel
#'   \item ST125SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: Right-vessel
#'   \item ST125CT N  Count of CBF voxels in FreeSurfer ROI: Right-vessel
#'   \item ST127MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: 3rd-Ventricle
#'   \item ST127MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: 3rd-Ventricle
#'   \item ST127MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: 3rd-Ventricle
#'   \item ST127AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: 3rd-Ventricle
#'   \item ST127SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: 3rd-Ventricle
#'   \item ST127CT N  Count of CBF voxels in FreeSurfer ROI: 3rd-Ventricle
#'   \item ST128MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: WM-hypointensities
#'   \item ST128MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: WM-hypointensities
#'   \item ST128MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: WM-hypointensities
#'   \item ST128AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: WM-hypointensities
#'   \item ST128SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: WM-hypointensities
#'   \item ST128CT N  Count of CBF voxels in FreeSurfer ROI: WM-hypointensities
#'   \item ST129MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-lh-insula
#'   \item ST129MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-lh-insula
#'   \item ST129MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-lh-insula
#'   \item ST129AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-lh-insula
#'   \item ST129SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-lh-insula
#'   \item ST129CT N  Count of CBF voxels in FreeSurfer ROI: ctx-lh-insula
#'   \item ST130MIN N ml / 100g tissue / min Min CBF value for FreeSurfer ROI: ctx-rh-insula
#'   \item ST130MAX N ml / 100g tissue / min Max CBF value for FreeSurfer ROI: ctx-rh-insula
#'   \item ST130MD F ml / 100g tissue / min Median CBF value for FreeSurfer ROI: ctx-rh-insula
#'   \item ST130AVG F ml / 100g tissue / min Mean CBF value for FreeSurfer ROI: ctx-rh-insula
#'   \item ST130SD F ml / 100g tissue / min Standard Deviation of Mean CBF value for FreeSurfer ROI: ctx-rh-insula
#'   \item ST130CT N  Count of CBF voxels in FreeSurfer ROI: ctx-rh-insula
#' }
#'
#' @examples
#' \donotrun{
#' describe(ucsfaslfs)
#' }
#' @docType data
#' @keywords datasets
#' @name ucsfaslfs
#' @usage data(ucsfaslfs)
#' @format A data frame with 950 rows and 712 variables
NULL

#' UCSF (Colin Studholme) Regional Atrophy Rates
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item USERDATE S -4 Date record created
#'   \item RECNO N -4 
#'   \item RID N -4 Participant roster ID
#'   \item SITEID N -4 Site ID
#'   \item VISCODE1 T -4 
#'   \item EXAMDATE1 D -4 
#'   \item IMAGEUID1 D -4 
#'   \item VISCODE2 T -4 Translated visit code
#'   \item EXAMDATE2 D -4 
#'   \item IMAGEUID2 D -4 
#'   \item FLDSTRENG D -4 Field Strength
#'   \item PCTCHANGE N -4 Summaries of regional atrophy rates between first and last scan (i.e. 12 month interval). There is one percent change for each subject summarizing changes in both temporal lobes together (minus superior temporal gyrus).
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name ucsfatrphy
#' @usage data(ucsfatrphy)
#' @format A data frame with 1721 rows and 13 variables
NULL

#' Longitudinal FreeSurfer
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/UCSFFRESFR/UCSFFreeSurferMethodsSummary.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID T  Participant roster ID
#'   \item SITEID   Site ID
#'   \item RECNO   
#'   \item FLDSTRENG   
#'   \item VISCODE1 T  The visit code for the image used as prior information.
#'   \item EXAMDATE1 D  The scan date for the image used as prior information.
#'   \item LONISID1 T  The LONI study UID for the image used as prior information.
#'   \item LONIUID1 T  The LONI Series UID for the image used as prior information.
#'   \item IMAGEUID1 T  The ImageUID for the image used as prior information.
#'   \item VISCODE2 T  Translated visit code
#'   \item EXAMDATE2 D  The scan date for the image processed
#'   \item LONISID2 T  The LONI study UID for the image processed
#'   \item LONIUID2 T  The LONI series UID for the image processed.
#'   \item IMAGEUID2 T  The ImageUID for the image processed.
#'   \item OVERALLQC T  An overall quality rating. Refer to additional QC variables for Partial rating.
#'   \item TEMPQC T  QC rating of temporal lobe. Fail affects the following regions: LeftTemporalPole (ST60), RightTemporalPole (ST119), LeftFusiform (ST26), RightFusiform (ST85), LeftSuperiorTemporal (ST58), RightSuperiorTemporal (ST117), LeftInferiorTemporal (ST32), RightInferiorTemporal (ST91)
#'   \item SUPRQC   QC rating of the superior cortex. Fail affects the following regions: LeftPrecentral (ST51), RightPrecentral (ST110), LeftPostcentral (ST49), RightPostcentral (ST108), LeftSuperiorParietal (ST57), RightSuperiorParietal (ST116), LeftCuneus (ST23), RightCuneus (ST82), LeftParacentral (ST43), RightParacentral (ST102), LeftCaudalMiddleFrontal (ST15), RightCaudalMiddleFrontal (ST74), LeftCerebralWM (ST20), RightCerebralWM (ST79)
#'   \item INSULAQC   QC rating of the insula. Fail affects the following regions: LeftUnknown (ST64), RightUnknown (ST123)
#'   \item OCCQC   QC rating of the occipital lobe. Fail affects the following regions: LeftLingual (ST38), RightLingual (ST97), LeftLateralOccipital (ST35), RightLateralOccipital (ST94)
#'   \item ST100SV N mm3 Volume (WM Parcellation) of RightNonWMHypoIntensities
#'   \item ST101SV N mm3 Volume (WM Parcellation) of RightPallidum
#'   \item ST102CV N mm3 Volume (Cortical Parcellation) of RightParacentral
#'   \item ST102SA N mm2 Surface Area of RightParacentral
#'   \item ST102TA N mm Cortical Thickness Average of RightParacentral
#'   \item ST102TS N mm Cortical Thickness Standard Deviation of RightParacentral
#'   \item ST103CV N mm3 Volume (Cortical Parcellation) of RightParahippocampal
#'   \item ST103SA N mm2 Surface Area of RightParahippocampal
#'   \item ST103TA N mm Cortical Thickness Average of RightParahippocampal
#'   \item ST103TS N mm Cortical Thickness Standard Deviation of RightParahippocampal
#'   \item ST104CV N mm3 Volume (Cortical Parcellation) of RightParsOpercularis
#'   \item ST104SA N mm2 Surface Area of RightParsOpercularis
#'   \item ST104TA N mm Cortical Thickness Average of RightParsOpercularis
#'   \item ST104TS N mm Cortical Thickness Standard Deviation of RightParsOpercularis
#'   \item ST105CV N mm3 Volume (Cortical Parcellation) of RightParsOrbitalis
#'   \item ST105SA N mm2 Surface Area of RightParsOrbitalis
#'   \item ST105TA N mm Cortical Thickness Average of RightParsOrbitalis
#'   \item ST105TS N mm Cortical Thickness Standard Deviation of RightParsOrbitalis
#'   \item ST106CV N mm3 Volume (Cortical Parcellation) of RightParsTriangularis
#'   \item ST106SA N mm2 Surface Area of RightParsTriangularis
#'   \item ST106TA N mm Cortical Thickness Average of RightParsTriangularis
#'   \item ST106TS N mm Cortical Thickness Standard Deviation of RightParsTriangularis
#'   \item ST107CV N mm3 Volume (Cortical Parcellation) of RightPericalcarine
#'   \item ST107SA N mm2 Surface Area of RightPericalcarine
#'   \item ST107TA N mm Cortical Thickness Average of RightPericalcarine
#'   \item ST107TS N mm Cortical Thickness Standard Deviation of RightPericalcarine
#'   \item ST108CV N mm3 Volume (Cortical Parcellation) of RightPostcentral
#'   \item ST108SA N mm2 Surface Area of RightPostcentral
#'   \item ST108TA N mm Cortical Thickness Average of RightPostcentral
#'   \item ST108TS N mm Cortical Thickness Standard Deviation of RightPostcentral
#'   \item ST109CV N mm3 Volume (Cortical Parcellation) of RightPosteriorCingulate
#'   \item ST109SA N mm2 Surface Area of RightPosteriorCingulate
#'   \item ST109TA N mm Cortical Thickness Average of RightPosteriorCingulate
#'   \item ST109TS N mm Cortical Thickness Standard Deviation of RightPosteriorCingulate
#'   \item ST10CV N mm3 Volume (Cortical Parcellation) of Icv
#'   \item ST110CV N mm3 Volume (Cortical Parcellation) of RightPrecentral
#'   \item ST110SA N mm2 Surface Area of RightPrecentral
#'   \item ST110TA N mm Cortical Thickness Average of RightPrecentral
#'   \item ST110TS N mm Cortical Thickness Standard Deviation of RightPrecentral
#'   \item ST111CV N mm3 Volume (Cortical Parcellation) of RightPrecuneus
#'   \item ST111SA N mm2 Surface Area of RightPrecuneus
#'   \item ST111TA N mm Cortical Thickness Average of RightPrecuneus
#'   \item ST111TS N mm Cortical Thickness Standard Deviation of RightPrecuneus
#'   \item ST112SV N mm3 Volume (WM Parcellation) of RightPutamen
#'   \item ST113CV N mm3 Volume (Cortical Parcellation) of RightRostralAnteriorCingulate
#'   \item ST113SA N mm2 Surface Area of RightRostralAnteriorCingulate
#'   \item ST113TA N mm Cortical Thickness Average of RightRostralAnteriorCingulate
#'   \item ST113TS N mm Cortical Thickness Standard Deviation of RightRostralAnteriorCingulate
#'   \item ST114CV N mm3 Volume (Cortical Parcellation) of RightRostralMiddleFrontal
#'   \item ST114SA N mm2 Surface Area of RightRostralMiddleFrontal
#'   \item ST114TA N mm Cortical Thickness Average of RightRostralMiddleFrontal
#'   \item ST114TS N mm Cortical Thickness Standard Deviation of RightRostralMiddleFrontal
#'   \item ST115CV N mm3 Volume (Cortical Parcellation) of RightSuperiorFrontal
#'   \item ST115SA N mm2 Surface Area of RightSuperiorFrontal
#'   \item ST115TA N mm Cortical Thickness Average of RightSuperiorFrontal
#'   \item ST115TS N mm Cortical Thickness Standard Deviation of RightSuperiorFrontal
#'   \item ST116CV N mm3 Volume (Cortical Parcellation) of RightSuperiorParietal
#'   \item ST116SA N mm2 Surface Area of RightSuperiorParietal
#'   \item ST116TA N mm Cortical Thickness Average of RightSuperiorParietal
#'   \item ST116TS N mm Cortical Thickness Standard Deviation of RightSuperiorParietal
#'   \item ST117CV N mm3 Volume (Cortical Parcellation) of RightSuperiorTemporal
#'   \item ST117SA N mm2 Surface Area of RightSuperiorTemporal
#'   \item ST117TA N mm Cortical Thickness Average of RightSuperiorTemporal
#'   \item ST117TS N mm Cortical Thickness Standard Deviation of RightSuperiorTemporal
#'   \item ST118CV N mm3 Volume (Cortical Parcellation) of RightSupramarginal
#'   \item ST118SA N mm2 Surface Area of RightSupramarginal
#'   \item ST118TA N mm Cortical Thickness Average of RightSupramarginal
#'   \item ST118TS N mm Cortical Thickness Standard Deviation of RightSupramarginal
#'   \item ST119CV N mm3 Volume (Cortical Parcellation) of RightTemporalPole
#'   \item ST119SA N mm2 Surface Area of RightTemporalPole
#'   \item ST119TA N mm Cortical Thickness Average of RightTemporalPole
#'   \item ST119TS N mm Cortical Thickness Standard Deviation of RightTemporalPole
#'   \item ST11SV N mm3 Volume (WM Parcellation) of LeftAccumbensArea
#'   \item ST120SV N mm3 Volume (WM Parcellation) of RightThalamus
#'   \item ST121CV N mm3 Volume (Cortical Parcellation) of RightTransverseTemporal
#'   \item ST121SA N mm2 Surface Area of RightTransverseTemporal
#'   \item ST121TA N mm Cortical Thickness Average of RightTransverseTemporal
#'   \item ST121TS N mm Cortical Thickness Standard Deviation of RightTransverseTemporal
#'   \item ST122SV N mm3 Volume (WM Parcellation) of RightUndetermined
#'   \item ST123CV N mm3 Volume (Cortical Parcellation) of RightUnknown
#'   \item ST123SA N mm2 Surface Area of RightUnknown
#'   \item ST123TA N mm Cortical Thickness Average of RightUnknown
#'   \item ST123TS N mm Cortical Thickness Standard Deviation of RightUnknown
#'   \item ST124SV N mm3 Volume (WM Parcellation) of RightVentralDC
#'   \item ST125SV N mm3 Volume (WM Parcellation) of RightVessel
#'   \item ST126SV N mm3 Volume (WM Parcellation) of RightWMHypoIntensities
#'   \item ST127SV N mm3 Volume (WM Parcellation) of ThirdVentricle
#'   \item ST128SV N mm3 Volume (WM Parcellation) of WMHypoIntensities
#'   \item ST12SV N mm3 Volume (WM Parcellation) of LeftAmygdala
#'   \item ST13CV N mm3 Volume (Cortical Parcellation) of LeftBankssts
#'   \item ST13SA N mm2 Surface Area of LeftBankssts
#'   \item ST13TA N mm Cortical Thickness Average of LeftBankssts
#'   \item ST13TS N mm Cortical Thickness Standard Deviation of LeftBankssts
#'   \item ST14CV N mm3 Volume (Cortical Parcellation) of LeftCaudalAnteriorCingulate
#'   \item ST14SA N mm2 Surface Area of LeftCaudalAnteriorCingulate
#'   \item ST14TA N mm Cortical Thickness Average of LeftCaudalAnteriorCingulate
#'   \item ST14TS N mm Cortical Thickness Standard Deviation of LeftCaudalAnteriorCingulate
#'   \item ST15CV N mm3 Volume (Cortical Parcellation) of LeftCaudalMiddleFrontal
#'   \item ST15SA N mm2 Surface Area of LeftCaudalMiddleFrontal
#'   \item ST15TA N mm Cortical Thickness Average of LeftCaudalMiddleFrontal
#'   \item ST15TS N mm Cortical Thickness Standard Deviation of LeftCaudalMiddleFrontal
#'   \item ST16SV N mm3 Volume (WM Parcellation) of LeftCaudate
#'   \item ST17SV N mm3 Volume (WM Parcellation) of LeftCerebellumCortex
#'   \item ST18SV N mm3 Volume (WM Parcellation) of LeftCerebellumWM
#'   \item ST19SV N mm3 Volume (WM Parcellation) of LeftCerebralCortex
#'   \item ST1SV N mm3 Volume (WM Parcellation) of Brainstem
#'   \item ST20SV N mm3 Volume (WM Parcellation) of LeftCerebralWM
#'   \item ST21SV N mm3 Volume (WM Parcellation) of LeftChoroidPlexus
#'   \item ST22CV N mm3 Volume (Cortical Parcellation) of LeftCorpusCallosum
#'   \item ST22SA N mm2 Surface Area of LeftCorpusCallosum
#'   \item ST22TA N mm Cortical Thickness Average of LeftCorpusCallosum
#'   \item ST22TS N mm Cortical Thickness Standard Deviation of LeftCorpusCallosum
#'   \item ST23CV N mm3 Volume (Cortical Parcellation) of LeftCuneus
#'   \item ST23SA N mm2 Surface Area of LeftCuneus
#'   \item ST23TA N mm Cortical Thickness Average of LeftCuneus
#'   \item ST23TS N mm Cortical Thickness Standard Deviation of LeftCuneus
#'   \item ST24CV N mm3 Volume (Cortical Parcellation) of LeftEntorhinal
#'   \item ST24SA N mm2 Surface Area of LeftEntorhinal
#'   \item ST24TA N mm Cortical Thickness Average of LeftEntorhinal
#'   \item ST24TS N mm Cortical Thickness Standard Deviation of LeftEntorhinal
#'   \item ST25CV N mm3 Volume (Cortical Parcellation) of LeftFrontalPole
#'   \item ST25SA N mm2 Surface Area of LeftFrontalPole
#'   \item ST25TA N mm Cortical Thickness Average of LeftFrontalPole
#'   \item ST25TS N mm Cortical Thickness Standard Deviation of LeftFrontalPole
#'   \item ST26CV N mm3 Volume (Cortical Parcellation) of LeftFusiform
#'   \item ST26SA N mm2 Surface Area of LeftFusiform
#'   \item ST26TA N mm Cortical Thickness Average of LeftFusiform
#'   \item ST26TS N mm Cortical Thickness Standard Deviation of LeftFusiform
#'   \item ST27SA N mm2 Surface Area of LeftHemisphere
#'   \item ST28CV N mm3 Volume (Cortical Parcellation) of LeftHemisphereWM
#'   \item ST29SV N mm3 Volume (WM Parcellation) of LeftHippocampus
#'   \item ST2SV N mm3 Volume (WM Parcellation) of CorpusCallosumAnterior
#'   \item ST30SV N mm3 Volume (WM Parcellation) of LeftInferiorLateralVentricle
#'   \item ST31CV N mm3 Volume (Cortical Parcellation) of LeftInferiorParietal
#'   \item ST31SA N mm2 Surface Area of LeftInferiorParietal
#'   \item ST31TA N mm Cortical Thickness Average of LeftInferiorParietal
#'   \item ST31TS N mm Cortical Thickness Standard Deviation of LeftInferiorParietal
#'   \item ST32CV N mm3 Volume (Cortical Parcellation) of LeftInferiorTemporal
#'   \item ST32SA N mm2 Surface Area of LeftInferiorTemporal
#'   \item ST32TA N mm Cortical Thickness Average of LeftInferiorTemporal
#'   \item ST32TS N mm Cortical Thickness Standard Deviation of LeftInferiorTemporal
#'   \item ST33SV N mm3 Volume (WM Parcellation) of LeftInterior
#'   \item ST34CV N mm3 Volume (Cortical Parcellation) of LeftIsthmusCingulate
#'   \item ST34SA N mm2 Surface Area of LeftIsthmusCingulate
#'   \item ST34TA N mm Cortical Thickness Average of LeftIsthmusCingulate
#'   \item ST34TS N mm Cortical Thickness Standard Deviation of LeftIsthmusCingulate
#'   \item ST35CV N mm3 Volume (Cortical Parcellation) of LeftLateralOccipital
#'   \item ST35SA N mm2 Surface Area of LeftLateralOccipital
#'   \item ST35TA N mm Cortical Thickness Average of LeftLateralOccipital
#'   \item ST35TS N mm Cortical Thickness Standard Deviation of LeftLateralOccipital
#'   \item ST36CV N mm3 Volume (Cortical Parcellation) of LeftLateralOrbitofrontal
#'   \item ST36SA N mm2 Surface Area of LeftLateralOrbitofrontal
#'   \item ST36TA N mm Cortical Thickness Average of LeftLateralOrbitofrontal
#'   \item ST36TS N mm Cortical Thickness Standard Deviation of LeftLateralOrbitofrontal
#'   \item ST37SV N mm3 Volume (WM Parcellation) of LeftLateralVentricle
#'   \item ST38CV N mm3 Volume (Cortical Parcellation) of LeftLingual
#'   \item ST38SA N mm2 Surface Area of LeftLingual
#'   \item ST38TA N mm Cortical Thickness Average of LeftLingual
#'   \item ST38TS N mm Cortical Thickness Standard Deviation of LeftLingual
#'   \item ST39CV N mm3 Volume (Cortical Parcellation) of LeftMedialOrbitofrontal
#'   \item ST39SA N mm2 Surface Area of LeftMedialOrbitofrontal
#'   \item ST39TA N mm Cortical Thickness Average of LeftMedialOrbitofrontal
#'   \item ST39TS N mm Cortical Thickness Standard Deviation of LeftMedialOrbitofrontal
#'   \item ST3SV N mm3 Volume (WM Parcellation) of CorpusCallosumCentral
#'   \item ST40CV N mm3 Volume (Cortical Parcellation) of LeftMiddleTemporal
#'   \item ST40SA N mm2 Surface Area of LeftMiddleTemporal
#'   \item ST40TA N mm Cortical Thickness Average of LeftMiddleTemporal
#'   \item ST40TS N mm Cortical Thickness Standard Deviation of LeftMiddleTemporal
#'   \item ST41SV N mm3 Volume (WM Parcellation) of LeftNonWMHypoIntensities
#'   \item ST42SV N mm3 Volume (WM Parcellation) of LeftPallidum
#'   \item ST43CV N mm3 Volume (Cortical Parcellation) of LeftParacentral
#'   \item ST43SA N mm2 Surface Area of LeftParacentral
#'   \item ST43TA N mm Cortical Thickness Average of LeftParacentral
#'   \item ST43TS N mm Cortical Thickness Standard Deviation of LeftParacentral
#'   \item ST44CV N mm3 Volume (Cortical Parcellation) of LeftParahippocampal
#'   \item ST44SA N mm2 Surface Area of LeftParahippocampal
#'   \item ST44TA N mm Cortical Thickness Average of LeftParahippocampal
#'   \item ST44TS N mm Cortical Thickness Standard Deviation of LeftParahippocampal
#'   \item ST45CV N mm3 Volume (Cortical Parcellation) of LeftParsOpercularis
#'   \item ST45SA N mm2 Surface Area of LeftParsOpercularis
#'   \item ST45TA N mm Cortical Thickness Average of LeftParsOpercularis
#'   \item ST45TS N mm Cortical Thickness Standard Deviation of LeftParsOpercularis
#'   \item ST46CV N mm3 Volume (Cortical Parcellation) of LeftParsOrbitalis
#'   \item ST46SA N mm2 Surface Area of LeftParsOrbitalis
#'   \item ST46TA N mm Cortical Thickness Average of LeftParsOrbitalis
#'   \item ST46TS N mm Cortical Thickness Standard Deviation of LeftParsOrbitalis
#'   \item ST47CV N mm3 Volume (Cortical Parcellation) of LeftParsTriangularis
#'   \item ST47SA N mm2 Surface Area of LeftParsTriangularis
#'   \item ST47TA N mm Cortical Thickness Average of LeftParsTriangularis
#'   \item ST47TS N mm Cortical Thickness Standard Deviation of LeftParsTriangularis
#'   \item ST48CV N mm3 Volume (Cortical Parcellation) of LeftPericalcarine
#'   \item ST48SA N mm2 Surface Area of LeftPericalcarine
#'   \item ST48TA N mm Cortical Thickness Average of LeftPericalcarine
#'   \item ST48TS N mm Cortical Thickness Standard Deviation of LeftPericalcarine
#'   \item ST49CV N mm3 Volume (Cortical Parcellation) of LeftPostcentral
#'   \item ST49SA N mm2 Surface Area of LeftPostcentral
#'   \item ST49TA N mm Cortical Thickness Average of LeftPostcentral
#'   \item ST49TS N mm Cortical Thickness Standard Deviation of LeftPostcentral
#'   \item ST4SV N mm3 Volume (WM Parcellation) of CorpusCallosumMidAnterior
#'   \item ST50CV N mm3 Volume (Cortical Parcellation) of LeftPosteriorCingulate
#'   \item ST50SA N mm2 Surface Area of LeftPosteriorCingulate
#'   \item ST50TA N mm Cortical Thickness Average of LeftPosteriorCingulate
#'   \item ST50TS N mm Cortical Thickness Standard Deviation of LeftPosteriorCingulate
#'   \item ST51CV N mm3 Volume (Cortical Parcellation) of LeftPrecentral
#'   \item ST51SA N mm2 Surface Area of LeftPrecentral
#'   \item ST51TA N mm Cortical Thickness Average of LeftPrecentral
#'   \item ST51TS N mm Cortical Thickness Standard Deviation of LeftPrecentral
#'   \item ST52CV N mm3 Volume (Cortical Parcellation) of LeftPrecuneus
#'   \item ST52SA N mm2 Surface Area of LeftPrecuneus
#'   \item ST52TA N mm Cortical Thickness Average of LeftPrecuneus
#'   \item ST52TS N mm Cortical Thickness Standard Deviation of LeftPrecuneus
#'   \item ST53SV N mm3 Volume (WM Parcellation) of LeftPutamen
#'   \item ST54CV N mm3 Volume (Cortical Parcellation) of LeftRostralAnteriorCingulate
#'   \item ST54SA N mm2 Surface Area of LeftRostralAnteriorCingulate
#'   \item ST54TA N mm Cortical Thickness Average of LeftRostralAnteriorCingulate
#'   \item ST54TS N mm Cortical Thickness Standard Deviation of LeftRostralAnteriorCingulate
#'   \item ST55CV N mm3 Volume (Cortical Parcellation) of LeftRostralMiddleFrontal
#'   \item ST55SA N mm2 Surface Area of LeftRostralMiddleFrontal
#'   \item ST55TA N mm Cortical Thickness Average of LeftRostralMiddleFrontal
#'   \item ST55TS N mm Cortical Thickness Standard Deviation of LeftRostralMiddleFrontal
#'   \item ST56CV N mm3 Volume (Cortical Parcellation) of LeftSuperiorFrontal
#'   \item ST56SA N mm2 Surface Area of LeftSuperiorFrontal
#'   \item ST56TA N mm Cortical Thickness Average of LeftSuperiorFrontal
#'   \item ST56TS N mm Cortical Thickness Standard Deviation of LeftSuperiorFrontal
#'   \item ST57CV N mm3 Volume (Cortical Parcellation) of LeftSuperiorParietal
#'   \item ST57SA N mm2 Surface Area of LeftSuperiorParietal
#'   \item ST57TA N mm Cortical Thickness Average of LeftSuperiorParietal
#'   \item ST57TS N mm Cortical Thickness Standard Deviation of LeftSuperiorParietal
#'   \item ST58CV N mm3 Volume (Cortical Parcellation) of LeftSuperiorTemporal
#'   \item ST58SA N mm2 Surface Area of LeftSuperiorTemporal
#'   \item ST58TA N mm Cortical Thickness Average of LeftSuperiorTemporal
#'   \item ST58TS N mm Cortical Thickness Standard Deviation of LeftSuperiorTemporal
#'   \item ST59CV N mm3 Volume (Cortical Parcellation) of LeftSupramarginal
#'   \item ST59SA N mm2 Surface Area of LeftSupramarginal
#'   \item ST59TA N mm Cortical Thickness Average of LeftSupramarginal
#'   \item ST59TS N mm Cortical Thickness Standard Deviation of LeftSupramarginal
#'   \item ST5SV N mm3 Volume (WM Parcellation) of CorpusCallosumMidPosterior
#'   \item ST60CV N mm3 Volume (Cortical Parcellation) of LeftTemporalPole
#'   \item ST60SA N mm2 Surface Area of LeftTemporalPole
#'   \item ST60TA N mm Cortical Thickness Average of LeftTemporalPole
#'   \item ST60TS N mm Cortical Thickness Standard Deviation of LeftTemporalPole
#'   \item ST61SV N mm3 Volume (WM Parcellation) of LeftThalamus
#'   \item ST62CV N mm3 Volume (Cortical Parcellation) of LeftTransverseTemporal
#'   \item ST62SA N mm2 Surface Area of LeftTransverseTemporal
#'   \item ST62TA N mm Cortical Thickness Average of LeftTransverseTemporal
#'   \item ST62TS N mm Cortical Thickness Standard Deviation of LeftTransverseTemporal
#'   \item ST63SV N mm3 Volume (WM Parcellation) of LeftUndetermined
#'   \item ST64CV N mm3 Volume (Cortical Parcellation) of LeftUnknown
#'   \item ST64SA N mm2 Surface Area of LeftUnknown
#'   \item ST64TA N mm Cortical Thickness Average of LeftUnknown
#'   \item ST64TS N mm Cortical Thickness Standard Deviation of LeftUnknown
#'   \item ST65SV N mm3 Volume (WM Parcellation) of LeftVentralDC
#'   \item ST66SV N mm3 Volume (WM Parcellation) of LeftVessel
#'   \item ST67SV N mm3 Volume (WM Parcellation) of LeftWMHypoIntensities
#'   \item ST68SV N mm3 Volume (WM Parcellation) of NonWMHypoIntensities
#'   \item ST69SV N mm3 Volume (WM Parcellation) of OpticChiasm
#'   \item ST6SV N mm3 Volume (WM Parcellation) of CorpusCallosumPosterior
#'   \item ST70SV N mm3 Volume (WM Parcellation) of RightAccumbensArea
#'   \item ST71SV N mm3 Volume (WM Parcellation) of RightAmygdala
#'   \item ST72CV N mm3 Volume (Cortical Parcellation) of RightBankssts
#'   \item ST72SA N mm2 Surface Area of RightBankssts
#'   \item ST72TA N mm Cortical Thickness Average of RightBankssts
#'   \item ST72TS N mm Cortical Thickness Standard Deviation of RightBankssts
#'   \item ST73CV N mm3 Volume (Cortical Parcellation) of RightCaudalAnteriorCingulate
#'   \item ST73SA N mm2 Surface Area of RightCaudalAnteriorCingulate
#'   \item ST73TA N mm Cortical Thickness Average of RightCaudalAnteriorCingulate
#'   \item ST73TS N mm Cortical Thickness Standard Deviation of RightCaudalAnteriorCingulate
#'   \item ST74CV N mm3 Volume (Cortical Parcellation) of RightCaudalMiddleFrontal
#'   \item ST74SA N mm2 Surface Area of RightCaudalMiddleFrontal
#'   \item ST74TA N mm Cortical Thickness Average of RightCaudalMiddleFrontal
#'   \item ST74TS N mm Cortical Thickness Standard Deviation of RightCaudalMiddleFrontal
#'   \item ST75SV N mm3 Volume (WM Parcellation) of RightCaudate
#'   \item ST76SV N mm3 Volume (WM Parcellation) of RightCerebellumCortex
#'   \item ST77SV N mm3 Volume (WM Parcellation) of RightCerebellumWM
#'   \item ST78SV N mm3 Volume (WM Parcellation) of RightCerebralCortex
#'   \item ST79SV N mm3 Volume (WM Parcellation) of RightCerebralWM
#'   \item ST7SV N mm3 Volume (WM Parcellation) of Csf
#'   \item ST80SV N mm3 Volume (WM Parcellation) of RightChoroidPlexus
#'   \item ST81CV N mm3 Volume (Cortical Parcellation) of RightCorpusCallosum
#'   \item ST81SA N mm2 Surface Area of RightCorpusCallosum
#'   \item ST81TA N mm Cortical Thickness Average of RightCorpusCallosum
#'   \item ST81TS N mm Cortical Thickness Standard Deviation of RightCorpusCallosum
#'   \item ST82CV N mm3 Volume (Cortical Parcellation) of RightCuneus
#'   \item ST82SA N mm2 Surface Area of RightCuneus
#'   \item ST82TA N mm Cortical Thickness Average of RightCuneus
#'   \item ST82TS N mm Cortical Thickness Standard Deviation of RightCuneus
#'   \item ST83CV N mm3 Volume (Cortical Parcellation) of RightEntorhinal
#'   \item ST83SA N mm2 Surface Area of RightEntorhinal
#'   \item ST83TA N mm Cortical Thickness Average of RightEntorhinal
#'   \item ST83TS N mm Cortical Thickness Standard Deviation of RightEntorhinal
#'   \item ST84CV N mm3 Volume (Cortical Parcellation) of RightFrontalPole
#'   \item ST84SA N mm2 Surface Area of RightFrontalPole
#'   \item ST84TA N mm Cortical Thickness Average of RightFrontalPole
#'   \item ST84TS N mm Cortical Thickness Standard Deviation of RightFrontalPole
#'   \item ST85CV N mm3 Volume (Cortical Parcellation) of RightFusiform
#'   \item ST85SA N mm2 Surface Area of RightFusiform
#'   \item ST85TA N mm Cortical Thickness Average of RightFusiform
#'   \item ST85TS N mm Cortical Thickness Standard Deviation of RightFusiform
#'   \item ST86SA N mm2 Surface Area of RightHemisphere
#'   \item ST87CV N mm3 Volume (Cortical Parcellation) of RightHemisphereWM
#'   \item ST88SV N mm3 Volume (WM Parcellation) of RightHippocampus
#'   \item ST89SV N mm3 Volume (WM Parcellation) of RightInferiorLateralVentricle
#'   \item ST8SV N mm3 Volume (WM Parcellation) of FifthVentricle
#'   \item ST90CV N mm3 Volume (Cortical Parcellation) of RightInferiorParietal
#'   \item ST90SA N mm2 Surface Area of RightInferiorParietal
#'   \item ST90TA N mm Cortical Thickness Average of RightInferiorParietal
#'   \item ST90TS N mm Cortical Thickness Standard Deviation of RightInferiorParietal
#'   \item ST91CV N mm3 Volume (Cortical Parcellation) of RightInferiorTemporal
#'   \item ST91SA N mm2 Surface Area of RightInferiorTemporal
#'   \item ST91TA N mm Cortical Thickness Average of RightInferiorTemporal
#'   \item ST91TS N mm Cortical Thickness Standard Deviation of RightInferiorTemporal
#'   \item ST92SV N mm3 Volume (WM Parcellation) of RightInterior
#'   \item ST93CV N mm3 Volume (Cortical Parcellation) of RightIsthmusCingulate
#'   \item ST93SA N mm2 Surface Area of RightIsthmusCingulate
#'   \item ST93TA N mm Cortical Thickness Average of RightIsthmusCingulate
#'   \item ST93TS N mm Cortical Thickness Standard Deviation of RightIsthmusCingulate
#'   \item ST94CV N mm3 Volume (Cortical Parcellation) of RightLateralOccipital
#'   \item ST94SA N mm2 Surface Area of RightLateralOccipital
#'   \item ST94TA N mm Cortical Thickness Average of RightLateralOccipital
#'   \item ST94TS N mm Cortical Thickness Standard Deviation of RightLateralOccipital
#'   \item ST95CV N mm3 Volume (Cortical Parcellation) of RightLateralOrbitofrontal
#'   \item ST95SA N mm2 Surface Area of RightLateralOrbitofrontal
#'   \item ST95TA N mm Cortical Thickness Average of RightLateralOrbitofrontal
#'   \item ST95TS N mm Cortical Thickness Standard Deviation of RightLateralOrbitofrontal
#'   \item ST96SV N mm3 Volume (WM Parcellation) of RightLateralVentricle
#'   \item ST97CV N mm3 Volume (Cortical Parcellation) of RightLingual
#'   \item ST97SA N mm2 Surface Area of RightLingual
#'   \item ST97TA N mm Cortical Thickness Average of RightLingual
#'   \item ST97TS N mm Cortical Thickness Standard Deviation of RightLingual
#'   \item ST98CV N mm3 Volume (Cortical Parcellation) of RightMedialOrbitofrontal
#'   \item ST98SA N mm2 Surface Area of RightMedialOrbitofrontal
#'   \item ST98TA N mm Cortical Thickness Average of RightMedialOrbitofrontal
#'   \item ST98TS N mm Cortical Thickness Standard Deviation of RightMedialOrbitofrontal
#'   \item ST99CV N mm3 Volume (Cortical Parcellation) of RightMiddleTemporal
#'   \item ST99SA N mm2 Surface Area of RightMiddleTemporal
#'   \item ST99TA N mm Cortical Thickness Average of RightMiddleTemporal
#'   \item ST99TS N mm Cortical Thickness Standard Deviation of RightMiddleTemporal
#'   \item ST9SV N mm3 Volume (WM Parcellation) of FourthVentricle
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name ucsffresfr
#' @usage data(ucsffresfr)
#' @format A data frame with 1675 rows and 358 variables
NULL

#' Longitudinal FreeSurfer (5.1) - All Available Base Image
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item COLPROT -4 -4 Study protocol of data collection
#'   \item RID T  Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item VISCODE2 -4 -4 Translated visit code
#'   \item EXAMDATE D  Examination Date
#'   \item VERSION D  
#'   \item LONISID T  The LONI study UID for the image processed
#'   \item LONIUID T  The LONI series UID for the image processed.
#'   \item IMAGEUID T  The ImageUID for the image processed.
#'   \item RUNDATE D  
#'   \item STATUS T  
#'   \item OVERALLQC T  An overall quality rating. Refer to additional QC variables for Partial rating.
#'   \item TEMPQC T  QC rating of temporal lobe. Fail affects the following regions: LeftTemporalPole (ST60); RightTemporalPole (ST119); LeftFusiform (ST26); RightFusiform (ST85); LeftSuperiorTemporal (ST58); RightSuperiorTemporal (ST117); LeftInferiorTemporal (ST32); RightInferiorTemporal (ST91); LeftMiddleTemporal (ST40); RightMiddleTemporal (ST99)
#'   \item FRONTQC T  QC rating of the frontal lobe. Fail affects the following regions: LeftFrontalPole (ST25); RightFrontalPole (ST84); LeftPrecentral (ST51); RightPrecentral (ST110); LeftSuperiorFrontal (ST56); RightSuperiorFrontal (ST115); LeftCaudalMiddleFrontal (ST15); RightCaudalMiddleFrontal (ST74); LeftRostralMiddleFrontal (ST55); RightRostralMiddleFrontal (ST114); LeftMedialOrbitofrontal (ST39); RightMedialOrbitofrontal (ST98)
#'   \item PARQC T  QC rating of the parietal lobe. Fail affects the following regions: LeftPostcentral (ST49); RightPostcentral (ST108); LeftSuperiorParietal (ST57); RightSuperiorParietal (ST116); LeftSupraMarginal (ST59); RightSupraMarginal (ST118); LeftParacentral (ST43); RightParacentral (ST102); LeftInferiorParietal (ST31); RightInferiorParietal (ST90)
#'   \item INSULAQC T  QC rating of the insula. Fail affects the following regions: LeftInsula (ST129); RightInsula (ST130)
#'   \item OCCQC T  QC rating of the occipital lobe. Fail affects the following regions: LeftLingual (ST38); RightLingual (ST97); LeftLateralOccipital (ST35); RightLateralOccipital (ST94); LeftPericalcarine (ST48); RightPericalcarine (ST107); LeftCuneus (ST23); RightCuneus (ST82)
#'   \item BGQC T  QC rating of the basal ganglia. Fail affects the following regions: LeftPutamen (ST53); RightPutamen (ST112); LeftCaudate (ST16); RightCaudate (ST75); LeftPallidum (ST42); RightPallidum (ST101)
#'   \item CWMQC T  QC rating of the cerebral WM. Fail affects the following regions: LeftCerebralWM (ST20); RightCerebralWM (ST79); LeftCorticalWM (ST150); RightCorticalWM (ST151); CorticalWM (ST152); LeftHemisphereWM (ST28); RightHemisphereWM (ST87)
#'   \item VENTQC T  QC rating of the ventricles. Fail affects the following regions: LeftLateralVentricle (ST37); RightLateralVentricle (ST96); LeftInferiorLateralVentricle (ST30); RightInferiorLateralVentricle (ST89); ThirdVentricle (ST127); FourthVentricle (ST9); FifthVentrical (ST8); LeftChoroidPlexus (ST21); RightChoroidPlexus (ST80)
#'   \item LHIPQC T  QC rating of the left hippocampal subfields. Fail affects the following regions: Left CA1 (ST131HS); Left CA2-3 (ST132HS); Left CA4-DG (ST133HS); Left Fimbria (ST134HS); Left Hippocampal Fissure (ST135HS); Left Presubiculum (ST136HS); Left Subiculum (ST137HS); Left Tail (ST138HS) 
#'   \item RHIPQC T  QC rating of the right hippocampal subfields. Fail affects the following regions: Right CA1 (ST139HS); Right CA2-3 (ST140HS); Right CA4-DG (ST141HS); Right Fimbria (ST142HS); Right Hippocampal Fissure (ST143HS); Right Presubiculum (ST144HS); Right Subiculum (ST145HS); Right Tail (ST146HS) 
#'   \item ST149SV N mm3 Subcortical Volume (aseg.stats) of CorticalGM
#'   \item ST28SA N mm2 Surface Area (aparc.stats) of LeftHemisphereWM
#'   \item ST87SA N mm2 Surface Area (aparc.stats) of RightHemisphereWM
#'   \item ST1SV N mm3 Subcortical Volume (aseg.stats) of Brainstem
#'   \item ST2SV N mm3 Subcortical Volume (aseg.stats) of CorpusCallosumAnterior
#'   \item ST3SV N mm3 Subcortical Volume (aseg.stats) of CorpusCallosumCentral
#'   \item ST4SV N mm3 Subcortical Volume (aseg.stats) of CorpusCallosumMidAnterior
#'   \item ST5SV N mm3 Subcortical Volume (aseg.stats) of CorpusCallosumMidPosterior
#'   \item ST6SV N mm3 Subcortical Volume (aseg.stats) of CorpusCallosumPosterior
#'   \item ST7SV N mm3 Subcortical Volume (aseg.stats) of Csf
#'   \item ST8SV N mm3 Subcortical Volume (aseg.stats) of FifthVentricle
#'   \item ST9SV N mm3 Subcortical Volume (aseg.stats) of FourthVentricle
#'   \item ST10CV N mm3 Cortical Volume (aparc.stats) of Icv
#'   \item ST11SV N mm3 Subcortical Volume (aseg.stats) of LeftAccumbensArea
#'   \item ST12SV N mm3 Subcortical Volume (aseg.stats) of LeftAmygdala
#'   \item ST13SA N mm2 Surface Area (aparc.stats) of LeftBankssts
#'   \item ST13TA N mm Thickness Average (aparc.stats) of LeftBankssts
#'   \item ST13TS N mm Thickness Stardard Deviation (aparc.stats) of LeftBankssts
#'   \item ST13CV N mm3 Cortical Volume (aparc.stats) of LeftBankssts
#'   \item ST14SA N mm2 Surface Area (aparc.stats) of LeftCaudalAnteriorCingulate
#'   \item ST14TA N mm Thickness Average (aparc.stats) of LeftCaudalAnteriorCingulate
#'   \item ST14TS N mm Thickness Stardard Deviation (aparc.stats) of LeftCaudalAnteriorCingulate
#'   \item ST14CV N mm3 Cortical Volume (aparc.stats) of LeftCaudalAnteriorCingulate
#'   \item ST15SA N mm2 Surface Area (aparc.stats) of LeftCaudalMiddleFrontal
#'   \item ST15TA N mm Thickness Average (aparc.stats) of LeftCaudalMiddleFrontal
#'   \item ST15TS N mm Thickness Stardard Deviation (aparc.stats) of LeftCaudalMiddleFrontal
#'   \item ST15CV N mm3 Cortical Volume (aparc.stats) of LeftCaudalMiddleFrontal
#'   \item ST16SV N mm3 Subcortical Volume (aseg.stats) of LeftCaudate
#'   \item ST17SV N mm3 Subcortical Volume (aseg.stats) of LeftCerebellumCortex
#'   \item ST18SV N mm3 Subcortical Volume (aseg.stats) of LeftCerebellumWM
#'   \item ST21SV N mm3 Subcortical Volume (aseg.stats) of LeftChoroidPlexus
#'   \item ST23SA N mm2 Surface Area (aparc.stats) of LeftCuneus
#'   \item ST23TA N mm Thickness Average (aparc.stats) of LeftCuneus
#'   \item ST23TS N mm Thickness Stardard Deviation (aparc.stats) of LeftCuneus
#'   \item ST23CV N mm3 Cortical Volume (aparc.stats) of LeftCuneus
#'   \item ST24SA N mm2 Surface Area (aparc.stats) of LeftEntorhinal
#'   \item ST24TA N mm Thickness Average (aparc.stats) of LeftEntorhinal
#'   \item ST24TS N mm Thickness Stardard Deviation (aparc.stats) of LeftEntorhinal
#'   \item ST24CV N mm3 Cortical Volume (aparc.stats) of LeftEntorhinal
#'   \item ST25SA N mm2 Surface Area (aparc.stats) of LeftFrontalPole
#'   \item ST25TA N mm Thickness Average (aparc.stats) of LeftFrontalPole
#'   \item ST25TS N mm Thickness Stardard Deviation (aparc.stats) of LeftFrontalPole
#'   \item ST25CV N mm3 Cortical Volume (aparc.stats) of LeftFrontalPole
#'   \item ST26SA N mm2 Surface Area (aparc.stats) of LeftFusiform
#'   \item ST26TA N mm Thickness Average (aparc.stats) of LeftFusiform
#'   \item ST26TS N mm Thickness Stardard Deviation (aparc.stats) of LeftFusiform
#'   \item ST26CV N mm3 Cortical Volume (aparc.stats) of LeftFusiform
#'   \item ST29SV N mm3 Subcortical Volume (aseg.stats) of LeftHippocampus
#'   \item ST30SV N mm3 Subcortical Volume (aseg.stats) of LeftInferiorLateralVentricle
#'   \item ST31SA N mm2 Surface Area (aparc.stats) of LeftInferiorParietal
#'   \item ST31TA N mm Thickness Average (aparc.stats) of LeftInferiorParietal
#'   \item ST31TS N mm Thickness Stardard Deviation (aparc.stats) of LeftInferiorParietal
#'   \item ST31CV N mm3 Cortical Volume (aparc.stats) of LeftInferiorParietal
#'   \item ST32SA N mm2 Surface Area (aparc.stats) of LeftInferiorTemporal
#'   \item ST32TA N mm Thickness Average (aparc.stats) of LeftInferiorTemporal
#'   \item ST32TS N mm Thickness Stardard Deviation (aparc.stats) of LeftInferiorTemporal
#'   \item ST32CV N mm3 Cortical Volume (aparc.stats) of LeftInferiorTemporal
#'   \item ST34SA N mm2 Surface Area (aparc.stats) of LeftIsthmusCingulate
#'   \item ST34TA N mm Thickness Average (aparc.stats) of LeftIsthmusCingulate
#'   \item ST34TS N mm Thickness Stardard Deviation (aparc.stats) of LeftIsthmusCingulate
#'   \item ST34CV N mm3 Cortical Volume (aparc.stats) of LeftIsthmusCingulate
#'   \item ST35SA N mm2 Surface Area (aparc.stats) of LeftLateralOccipital
#'   \item ST35TA N mm Thickness Average (aparc.stats) of LeftLateralOccipital
#'   \item ST35TS N mm Thickness Stardard Deviation (aparc.stats) of LeftLateralOccipital
#'   \item ST35CV N mm3 Cortical Volume (aparc.stats) of LeftLateralOccipital
#'   \item ST36SA N mm2 Surface Area (aparc.stats) of LeftLateralOrbitofrontal
#'   \item ST36TA N mm Thickness Average (aparc.stats) of LeftLateralOrbitofrontal
#'   \item ST36TS N mm Thickness Stardard Deviation (aparc.stats) of LeftLateralOrbitofrontal
#'   \item ST36CV N mm3 Cortical Volume (aparc.stats) of LeftLateralOrbitofrontal
#'   \item ST37SV N mm3 Subcortical Volume (aseg.stats) of LeftLateralVentricle
#'   \item ST38SA N mm2 Surface Area (aparc.stats) of LeftLingual
#'   \item ST38TA N mm Thickness Average (aparc.stats) of LeftLingual
#'   \item ST38TS N mm Thickness Stardard Deviation (aparc.stats) of LeftLingual
#'   \item ST38CV N mm3 Cortical Volume (aparc.stats) of LeftLingual
#'   \item ST39SA N mm2 Surface Area (aparc.stats) of LeftMedialOrbitofrontal
#'   \item ST39TA N mm Thickness Average (aparc.stats) of LeftMedialOrbitofrontal
#'   \item ST39TS N mm Thickness Stardard Deviation (aparc.stats) of LeftMedialOrbitofrontal
#'   \item ST39CV N mm3 Cortical Volume (aparc.stats) of LeftMedialOrbitofrontal
#'   \item ST40SA N mm2 Surface Area (aparc.stats) of LeftMiddleTemporal
#'   \item ST40TA N mm Thickness Average (aparc.stats) of LeftMiddleTemporal
#'   \item ST40TS N mm Thickness Stardard Deviation (aparc.stats) of LeftMiddleTemporal
#'   \item ST40CV N mm3 Cortical Volume (aparc.stats) of LeftMiddleTemporal
#'   \item ST42SV N mm3 Subcortical Volume (aseg.stats) of LeftPallidum
#'   \item ST43SA N mm2 Surface Area (aparc.stats) of LeftParacentral
#'   \item ST43TA N mm Thickness Average (aparc.stats) of LeftParacentral
#'   \item ST43TS N mm Thickness Stardard Deviation (aparc.stats) of LeftParacentral
#'   \item ST43CV N mm3 Cortical Volume (aparc.stats) of LeftParacentral
#'   \item ST44SA N mm2 Surface Area (aparc.stats) of LeftParahippocampal
#'   \item ST44TA N mm Thickness Average (aparc.stats) of LeftParahippocampal
#'   \item ST44TS N mm Thickness Stardard Deviation (aparc.stats) of LeftParahippocampal
#'   \item ST44CV N mm3 Cortical Volume (aparc.stats) of LeftParahippocampal
#'   \item ST45SA N mm2 Surface Area (aparc.stats) of LeftParsOpercularis
#'   \item ST45TA N mm Thickness Average (aparc.stats) of LeftParsOpercularis
#'   \item ST45TS N mm Thickness Stardard Deviation (aparc.stats) of LeftParsOpercularis
#'   \item ST45CV N mm3 Cortical Volume (aparc.stats) of LeftParsOpercularis
#'   \item ST46SA N mm2 Surface Area (aparc.stats) of LeftParsOrbitalis
#'   \item ST46TA N mm Thickness Average (aparc.stats) of LeftParsOrbitalis
#'   \item ST46TS N mm Thickness Stardard Deviation (aparc.stats) of LeftParsOrbitalis
#'   \item ST46CV N mm3 Cortical Volume (aparc.stats) of LeftParsOrbitalis
#'   \item ST47SA N mm2 Surface Area (aparc.stats) of LeftParsTriangularis
#'   \item ST47TA N mm Thickness Average (aparc.stats) of LeftParsTriangularis
#'   \item ST47TS N mm Thickness Stardard Deviation (aparc.stats) of LeftParsTriangularis
#'   \item ST47CV N mm3 Cortical Volume (aparc.stats) of LeftParsTriangularis
#'   \item ST48SA N mm2 Surface Area (aparc.stats) of LeftPericalcarine
#'   \item ST48TA N mm Thickness Average (aparc.stats) of LeftPericalcarine
#'   \item ST48TS N mm Thickness Stardard Deviation (aparc.stats) of LeftPericalcarine
#'   \item ST48CV N mm3 Cortical Volume (aparc.stats) of LeftPericalcarine
#'   \item ST49SA N mm2 Surface Area (aparc.stats) of LeftPostcentral
#'   \item ST49TA N mm Thickness Average (aparc.stats) of LeftPostcentral
#'   \item ST49TS N mm Thickness Stardard Deviation (aparc.stats) of LeftPostcentral
#'   \item ST49CV N mm3 Cortical Volume (aparc.stats) of LeftPostcentral
#'   \item ST50SA N mm2 Surface Area (aparc.stats) of LeftPosteriorCingulate
#'   \item ST50TA N mm Thickness Average (aparc.stats) of LeftPosteriorCingulate
#'   \item ST50TS N mm Thickness Stardard Deviation (aparc.stats) of LeftPosteriorCingulate
#'   \item ST50CV N mm3 Cortical Volume (aparc.stats) of LeftPosteriorCingulate
#'   \item ST51SA N mm2 Surface Area (aparc.stats) of LeftPrecentral
#'   \item ST51TA N mm Thickness Average (aparc.stats) of LeftPrecentral
#'   \item ST51TS N mm Thickness Stardard Deviation (aparc.stats) of LeftPrecentral
#'   \item ST51CV N mm3 Cortical Volume (aparc.stats) of LeftPrecentral
#'   \item ST52SA N mm2 Surface Area (aparc.stats) of LeftPrecuneus
#'   \item ST52TA N mm Thickness Average (aparc.stats) of LeftPrecuneus
#'   \item ST52TS N mm Thickness Stardard Deviation (aparc.stats) of LeftPrecuneus
#'   \item ST52CV N mm3 Cortical Volume (aparc.stats) of LeftPrecuneus
#'   \item ST53SV N mm3 Subcortical Volume (aseg.stats) of LeftPutamen
#'   \item ST54SA N mm2 Surface Area (aparc.stats) of LeftRostralAnteriorCingulate
#'   \item ST54TA N mm Thickness Average (aparc.stats) of LeftRostralAnteriorCingulate
#'   \item ST54TS N mm Thickness Stardard Deviation (aparc.stats) of LeftRostralAnteriorCingulate
#'   \item ST54CV N mm3 Cortical Volume (aparc.stats) of LeftRostralAnteriorCingulate
#'   \item ST55SA N mm2 Surface Area (aparc.stats) of LeftRostralMiddleFrontal
#'   \item ST55TA N mm Thickness Average (aparc.stats) of LeftRostralMiddleFrontal
#'   \item ST55TS N mm Thickness Stardard Deviation (aparc.stats) of LeftRostralMiddleFrontal
#'   \item ST55CV N mm3 Cortical Volume (aparc.stats) of LeftRostralMiddleFrontal
#'   \item ST56SA N mm2 Surface Area (aparc.stats) of LeftSuperiorFrontal
#'   \item ST56TA N mm Thickness Average (aparc.stats) of LeftSuperiorFrontal
#'   \item ST56TS N mm Thickness Stardard Deviation (aparc.stats) of LeftSuperiorFrontal
#'   \item ST56CV N mm3 Cortical Volume (aparc.stats) of LeftSuperiorFrontal
#'   \item ST57SA N mm2 Surface Area (aparc.stats) of LeftSuperiorParietal
#'   \item ST57TA N mm Thickness Average (aparc.stats) of LeftSuperiorParietal
#'   \item ST57TS N mm Thickness Stardard Deviation (aparc.stats) of LeftSuperiorParietal
#'   \item ST57CV N mm3 Cortical Volume (aparc.stats) of LeftSuperiorParietal
#'   \item ST58SA N mm2 Surface Area (aparc.stats) of LeftSuperiorTemporal
#'   \item ST58TA N mm Thickness Average (aparc.stats) of LeftSuperiorTemporal
#'   \item ST58TS N mm Thickness Stardard Deviation (aparc.stats) of LeftSuperiorTemporal
#'   \item ST58CV N mm3 Cortical Volume (aparc.stats) of LeftSuperiorTemporal
#'   \item ST59SA N mm2 Surface Area (aparc.stats) of LeftSupramarginal
#'   \item ST59TA N mm Thickness Average (aparc.stats) of LeftSupramarginal
#'   \item ST59TS N mm Thickness Stardard Deviation (aparc.stats) of LeftSupramarginal
#'   \item ST59CV N mm3 Cortical Volume (aparc.stats) of LeftSupramarginal
#'   \item ST60SA N mm2 Surface Area (aparc.stats) of LeftTemporalPole
#'   \item ST60TA N mm Thickness Average (aparc.stats) of LeftTemporalPole
#'   \item ST60TS N mm Thickness Stardard Deviation (aparc.stats) of LeftTemporalPole
#'   \item ST60CV N mm3 Cortical Volume (aparc.stats) of LeftTemporalPole
#'   \item ST61SV N mm3 Subcortical Volume (aseg.stats) of LeftThalamus
#'   \item ST62SA N mm2 Surface Area (aparc.stats) of LeftTransverseTemporal
#'   \item ST62TA N mm Thickness Average (aparc.stats) of LeftTransverseTemporal
#'   \item ST62TS N mm Thickness Stardard Deviation (aparc.stats) of LeftTransverseTemporal
#'   \item ST62CV N mm3 Cortical Volume (aparc.stats) of LeftTransverseTemporal
#'   \item ST65SV N mm3 Subcortical Volume (aseg.stats) of LeftVentralDC
#'   \item ST66SV N mm3 Subcortical Volume (aseg.stats) of LeftVessel
#'   \item ST68SV N mm3 Subcortical Volume (aseg.stats) of NonWMHypoIntensities
#'   \item ST69SV N mm3 Subcortical Volume (aseg.stats) of OpticChiasm
#'   \item ST70SV N mm3 Subcortical Volume (aseg.stats) of RightAccumbensArea
#'   \item ST71SV N mm3 Subcortical Volume (aseg.stats) of RightAmygdala
#'   \item ST72SA N mm2 Surface Area (aparc.stats) of RightBankssts
#'   \item ST72TA N mm Thickness Average (aparc.stats) of RightBankssts
#'   \item ST72TS N mm Thickness Stardard Deviation (aparc.stats) of RightBankssts
#'   \item ST72CV N mm3 Cortical Volume (aparc.stats) of RightBankssts
#'   \item ST73SA N mm2 Surface Area (aparc.stats) of RightCaudalAnteriorCingulate
#'   \item ST73TA N mm Thickness Average (aparc.stats) of RightCaudalAnteriorCingulate
#'   \item ST73TS N mm Thickness Stardard Deviation (aparc.stats) of RightCaudalAnteriorCingulate
#'   \item ST73CV N mm3 Cortical Volume (aparc.stats) of RightCaudalAnteriorCingulate
#'   \item ST74SA N mm2 Surface Area (aparc.stats) of RightCaudalMiddleFrontal
#'   \item ST74TA N mm Thickness Average (aparc.stats) of RightCaudalMiddleFrontal
#'   \item ST74TS N mm Thickness Stardard Deviation (aparc.stats) of RightCaudalMiddleFrontal
#'   \item ST74CV N mm3 Cortical Volume (aparc.stats) of RightCaudalMiddleFrontal
#'   \item ST75SV N mm3 Subcortical Volume (aseg.stats) of RightCaudate
#'   \item ST76SV N mm3 Subcortical Volume (aseg.stats) of RightCerebellumCortex
#'   \item ST77SV N mm3 Subcortical Volume (aseg.stats) of RightCerebellumWM
#'   \item ST80SV N mm3 Subcortical Volume (aseg.stats) of RightChoroidPlexus
#'   \item ST82SA N mm2 Surface Area (aparc.stats) of RightCuneus
#'   \item ST82TA N mm Thickness Average (aparc.stats) of RightCuneus
#'   \item ST82TS N mm Thickness Stardard Deviation (aparc.stats) of RightCuneus
#'   \item ST82CV N mm3 Cortical Volume (aparc.stats) of RightCuneus
#'   \item ST83SA N mm2 Surface Area (aparc.stats) of RightEntorhinal
#'   \item ST83TA N mm Thickness Average (aparc.stats) of RightEntorhinal
#'   \item ST83TS N mm Thickness Stardard Deviation (aparc.stats) of RightEntorhinal
#'   \item ST83CV N mm3 Cortical Volume (aparc.stats) of RightEntorhinal
#'   \item ST84SA N mm2 Surface Area (aparc.stats) of RightFrontalPole
#'   \item ST84TA N mm Thickness Average (aparc.stats) of RightFrontalPole
#'   \item ST84TS N mm Thickness Stardard Deviation (aparc.stats) of RightFrontalPole
#'   \item ST84CV N mm3 Cortical Volume (aparc.stats) of RightFrontalPole
#'   \item ST85SA N mm2 Surface Area (aparc.stats) of RightFusiform
#'   \item ST85TA N mm Thickness Average (aparc.stats) of RightFusiform
#'   \item ST85TS N mm Thickness Stardard Deviation (aparc.stats) of RightFusiform
#'   \item ST85CV N mm3 Cortical Volume (aparc.stats) of RightFusiform
#'   \item ST88SV N mm3 Subcortical Volume (aseg.stats) of RightHippocampus
#'   \item ST89SV N mm3 Subcortical Volume (aseg.stats) of RightInferiorLateralVentricle
#'   \item ST90SA N mm2 Surface Area (aparc.stats) of RightInferiorParietal
#'   \item ST90TA N mm Thickness Average (aparc.stats) of RightInferiorParietal
#'   \item ST90TS N mm Thickness Stardard Deviation (aparc.stats) of RightInferiorParietal
#'   \item ST90CV N mm3 Cortical Volume (aparc.stats) of RightInferiorParietal
#'   \item ST91SA N mm2 Surface Area (aparc.stats) of RightInferiorTemporal
#'   \item ST91TA N mm Thickness Average (aparc.stats) of RightInferiorTemporal
#'   \item ST91TS N mm Thickness Stardard Deviation (aparc.stats) of RightInferiorTemporal
#'   \item ST91CV N mm3 Cortical Volume (aparc.stats) of RightInferiorTemporal
#'   \item ST93SA N mm2 Surface Area (aparc.stats) of RightIsthmusCingulate
#'   \item ST93TA N mm Thickness Average (aparc.stats) of RightIsthmusCingulate
#'   \item ST93TS N mm Thickness Stardard Deviation (aparc.stats) of RightIsthmusCingulate
#'   \item ST93CV N mm3 Cortical Volume (aparc.stats) of RightIsthmusCingulate
#'   \item ST94SA N mm2 Surface Area (aparc.stats) of RightLateralOccipital
#'   \item ST94TA N mm Thickness Average (aparc.stats) of RightLateralOccipital
#'   \item ST94TS N mm Thickness Stardard Deviation (aparc.stats) of RightLateralOccipital
#'   \item ST94CV N mm3 Cortical Volume (aparc.stats) of RightLateralOccipital
#'   \item ST95SA N mm2 Surface Area (aparc.stats) of RightLateralOrbitofrontal
#'   \item ST95TA N mm Thickness Average (aparc.stats) of RightLateralOrbitofrontal
#'   \item ST95TS N mm Thickness Stardard Deviation (aparc.stats) of RightLateralOrbitofrontal
#'   \item ST95CV N mm3 Cortical Volume (aparc.stats) of RightLateralOrbitofrontal
#'   \item ST96SV N mm3 Subcortical Volume (aseg.stats) of RightLateralVentricle
#'   \item ST97SA N mm2 Surface Area (aparc.stats) of RightLingual
#'   \item ST97TA N mm Thickness Average (aparc.stats) of RightLingual
#'   \item ST97TS N mm Thickness Stardard Deviation (aparc.stats) of RightLingual
#'   \item ST97CV N mm3 Cortical Volume (aparc.stats) of RightLingual
#'   \item ST98SA N mm2 Surface Area (aparc.stats) of RightMedialOrbitofrontal
#'   \item ST98TA N mm Thickness Average (aparc.stats) of RightMedialOrbitofrontal
#'   \item ST98TS N mm Thickness Stardard Deviation (aparc.stats) of RightMedialOrbitofrontal
#'   \item ST98CV N mm3 Cortical Volume (aparc.stats) of RightMedialOrbitofrontal
#'   \item ST99SA N mm2 Surface Area (aparc.stats) of RightMiddleTemporal
#'   \item ST99TA N mm Thickness Average (aparc.stats) of RightMiddleTemporal
#'   \item ST99TS N mm Thickness Stardard Deviation (aparc.stats) of RightMiddleTemporal
#'   \item ST99CV N mm3 Cortical Volume (aparc.stats) of RightMiddleTemporal
#'   \item ST101SV N mm3 Subcortical Volume (aseg.stats) of RightPallidum
#'   \item ST102SA N mm2 Surface Area (aparc.stats) of RightParacentral
#'   \item ST102TA N mm Thickness Average (aparc.stats) of RightParacentral
#'   \item ST102TS N mm Thickness Stardard Deviation (aparc.stats) of RightParacentral
#'   \item ST102CV N mm3 Cortical Volume (aparc.stats) of RightParacentral
#'   \item ST103SA N mm2 Surface Area (aparc.stats) of RightParahippocampal
#'   \item ST103TA N mm Thickness Average (aparc.stats) of RightParahippocampal
#'   \item ST103TS N mm Thickness Stardard Deviation (aparc.stats) of RightParahippocampal
#'   \item ST103CV N mm3 Cortical Volume (aparc.stats) of RightParahippocampal
#'   \item ST104SA N mm2 Surface Area (aparc.stats) of RightParsOpercularis
#'   \item ST104TA N mm Thickness Average (aparc.stats) of RightParsOpercularis
#'   \item ST104TS N mm Thickness Stardard Deviation (aparc.stats) of RightParsOpercularis
#'   \item ST104CV N mm3 Cortical Volume (aparc.stats) of RightParsOpercularis
#'   \item ST105SA N mm2 Surface Area (aparc.stats) of RightParsOrbitalis
#'   \item ST105TA N mm Thickness Average (aparc.stats) of RightParsOrbitalis
#'   \item ST105TS N mm Thickness Stardard Deviation (aparc.stats) of RightParsOrbitalis
#'   \item ST105CV N mm3 Cortical Volume (aparc.stats) of RightParsOrbitalis
#'   \item ST106SA N mm2 Surface Area (aparc.stats) of RightParsTriangularis
#'   \item ST106TA N mm Thickness Average (aparc.stats) of RightParsTriangularis
#'   \item ST106TS N mm Thickness Stardard Deviation (aparc.stats) of RightParsTriangularis
#'   \item ST106CV N mm3 Cortical Volume (aparc.stats) of RightParsTriangularis
#'   \item ST107SA N mm2 Surface Area (aparc.stats) of RightPericalcarine
#'   \item ST107TA N mm Thickness Average (aparc.stats) of RightPericalcarine
#'   \item ST107TS N mm Thickness Stardard Deviation (aparc.stats) of RightPericalcarine
#'   \item ST107CV N mm3 Cortical Volume (aparc.stats) of RightPericalcarine
#'   \item ST108SA N mm2 Surface Area (aparc.stats) of RightPostcentral
#'   \item ST108TA N mm Thickness Average (aparc.stats) of RightPostcentral
#'   \item ST108TS N mm Thickness Stardard Deviation (aparc.stats) of RightPostcentral
#'   \item ST108CV N mm3 Cortical Volume (aparc.stats) of RightPostcentral
#'   \item ST109SA N mm2 Surface Area (aparc.stats) of RightPosteriorCingulate
#'   \item ST109TA N mm Thickness Average (aparc.stats) of RightPosteriorCingulate
#'   \item ST109TS N mm Thickness Stardard Deviation (aparc.stats) of RightPosteriorCingulate
#'   \item ST109CV N mm3 Cortical Volume (aparc.stats) of RightPosteriorCingulate
#'   \item ST110SA N mm2 Surface Area (aparc.stats) of RightPrecentral
#'   \item ST110TA N mm Thickness Average (aparc.stats) of RightPrecentral
#'   \item ST110TS N mm Thickness Stardard Deviation (aparc.stats) of RightPrecentral
#'   \item ST110CV N mm3 Cortical Volume (aparc.stats) of RightPrecentral
#'   \item ST111SA N mm2 Surface Area (aparc.stats) of RightPrecuneus
#'   \item ST111TA N mm Thickness Average (aparc.stats) of RightPrecuneus
#'   \item ST111TS N mm Thickness Stardard Deviation (aparc.stats) of RightPrecuneus
#'   \item ST111CV N mm3 Cortical Volume (aparc.stats) of RightPrecuneus
#'   \item ST112SV N mm3 Subcortical Volume (aseg.stats) of RightPutamen
#'   \item ST113SA N mm2 Surface Area (aparc.stats) of RightRostralAnteriorCingulate
#'   \item ST113TA N mm Thickness Average (aparc.stats) of RightRostralAnteriorCingulate
#'   \item ST113TS N mm Thickness Stardard Deviation (aparc.stats) of RightRostralAnteriorCingulate
#'   \item ST113CV N mm3 Cortical Volume (aparc.stats) of RightRostralAnteriorCingulate
#'   \item ST114SA N mm2 Surface Area (aparc.stats) of RightRostralMiddleFrontal
#'   \item ST114TA N mm Thickness Average (aparc.stats) of RightRostralMiddleFrontal
#'   \item ST114TS N mm Thickness Stardard Deviation (aparc.stats) of RightRostralMiddleFrontal
#'   \item ST114CV N mm3 Cortical Volume (aparc.stats) of RightRostralMiddleFrontal
#'   \item ST115SA N mm2 Surface Area (aparc.stats) of RightSuperiorFrontal
#'   \item ST115TA N mm Thickness Average (aparc.stats) of RightSuperiorFrontal
#'   \item ST115TS N mm Thickness Stardard Deviation (aparc.stats) of RightSuperiorFrontal
#'   \item ST115CV N mm3 Cortical Volume (aparc.stats) of RightSuperiorFrontal
#'   \item ST116SA N mm2 Surface Area (aparc.stats) of RightSuperiorParietal
#'   \item ST116TA N mm Thickness Average (aparc.stats) of RightSuperiorParietal
#'   \item ST116TS N mm Thickness Stardard Deviation (aparc.stats) of RightSuperiorParietal
#'   \item ST116CV N mm3 Cortical Volume (aparc.stats) of RightSuperiorParietal
#'   \item ST117SA N mm2 Surface Area (aparc.stats) of RightSuperiorTemporal
#'   \item ST117TA N mm Thickness Average (aparc.stats) of RightSuperiorTemporal
#'   \item ST117TS N mm Thickness Stardard Deviation (aparc.stats) of RightSuperiorTemporal
#'   \item ST117CV N mm3 Cortical Volume (aparc.stats) of RightSuperiorTemporal
#'   \item ST118SA N mm2 Surface Area (aparc.stats) of RightSupramarginal
#'   \item ST118TA N mm Thickness Average (aparc.stats) of RightSupramarginal
#'   \item ST118TS N mm Thickness Stardard Deviation (aparc.stats) of RightSupramarginal
#'   \item ST118CV N mm3 Cortical Volume (aparc.stats) of RightSupramarginal
#'   \item ST119SA N mm2 Surface Area (aparc.stats) of RightTemporalPole
#'   \item ST119TA N mm Thickness Average (aparc.stats) of RightTemporalPole
#'   \item ST119TS N mm Thickness Stardard Deviation (aparc.stats) of RightTemporalPole
#'   \item ST119CV N mm3 Cortical Volume (aparc.stats) of RightTemporalPole
#'   \item ST120SV N mm3 Subcortical Volume (aseg.stats) of RightThalamus
#'   \item ST121SA N mm2 Surface Area (aparc.stats) of RightTransverseTemporal
#'   \item ST121TA N mm Thickness Average (aparc.stats) of RightTransverseTemporal
#'   \item ST121TS N mm Thickness Stardard Deviation (aparc.stats) of RightTransverseTemporal
#'   \item ST121CV N mm3 Cortical Volume (aparc.stats) of RightTransverseTemporal
#'   \item ST124SV N mm3 Subcortical Volume (aseg.stats) of RightVentralDC
#'   \item ST125SV N mm3 Subcortical Volume (aseg.stats) of RightVessel
#'   \item ST127SV N mm3 Subcortical Volume (aseg.stats) of ThirdVentricle
#'   \item ST128SV N mm3 Subcortical Volume (aseg.stats) of WMHypoIntensities
#'   \item ST129SA N mm2 Surface Area (aparc.stats) of LeftInsula
#'   \item ST129TA N mm Thickness Average (aparc.stats) of LeftInsula
#'   \item ST129TS N mm Thickness Stardard Deviation (aparc.stats) of LeftInsula
#'   \item ST129CV N mm3 Cortical Volume (aparc.stats) of LeftInsula
#'   \item ST130SA N mm2 Surface Area (aparc.stats) of RightInsula
#'   \item ST130TA N mm Thickness Average (aparc.stats) of RightInsula
#'   \item ST130TS N mm Thickness Stardard Deviation (aparc.stats) of RightInsula
#'   \item ST130CV N mm3 Cortical Volume (aparc.stats) of RightInsula
#'   \item ST131HS N mm3 Hippocampal Subfields Volume of LeftCA1
#'   \item ST132HS N mm3 Hippocampal Subfields Volume of LeftCA2_3
#'   \item ST133HS N mm3 Hippocampal Subfields Volume of LeftCA4_DG
#'   \item ST134HS N mm3 Hippocampal Subfields Volume of LeftFimbria
#'   \item ST135HS N mm3 Hippocampal Subfields Volume of LeftHippocampalFissure
#'   \item ST136HS N mm3 Hippocampal Subfields Volume of LeftPresubiculum
#'   \item ST137HS N mm3 Hippocampal Subfields Volume of LeftSubiculum
#'   \item ST138HS N mm3 Hippocampal Subfields Volume of LeftTail
#'   \item ST139HS N mm3 Hippocampal Subfields Volume of RightCA1
#'   \item ST140HS N mm3 Hippocampal Subfields Volume of RightCA2_3
#'   \item ST141HS N mm3 Hippocampal Subfields Volume of RightCA4_DG
#'   \item ST142HS N mm3 Hippocampal Subfields Volume of RightFimbria
#'   \item ST143HS N mm3 Hippocampal Subfields Volume of RightHippocampalFissure
#'   \item ST144HS N mm3 Hippocampal Subfields Volume of RightPresubiculum
#'   \item ST145HS N mm3 Hippocampal Subfields Volume of RightSubiculum
#'   \item ST146HS N mm3 Hippocampal Subfields Volume of RightTail
#'   \item ST147SV N mm3 Subcortical Volume (aseg.stats) of LeftCorticalGM
#'   \item ST148SV N mm3 Subcortical Volume (aseg.stats) of RightCorticalGM
#'   \item ST150SV N mm3 Subcortical Volume (aseg.stats) of LeftCorticalWM
#'   \item ST151SV N mm3 Subcortical Volume (aseg.stats) of RightCorticalWM
#'   \item ST152SV N mm3 Subcortical Volume (aseg.stats) of CorticalWM
#'   \item ST153SV N mm3 Subcortical Volume (aseg.stats) of SubcorticalGM
#'   \item ST154SV N mm3 Subcortical Volume (aseg.stats) of TotalGM
#'   \item ST155SV N mm3 Subcortical Volume (aseg.stats) of SupraTentorial
#' }
#'
#' @examples
#' \donotrun{
#' describe(ucsffsl51all)
#' }
#' @docType data
#' @keywords datasets
#' @name ucsffsl51all
#' @usage data(ucsffsl51all)
#' @format A data frame with 2010 rows and 363 variables
NULL

#' Longitudinal FreeSurfer (5.1) - Year 1 Base Image
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item COLPROT -4 -4 Study protocol of data collection
#'   \item RID T  Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item VISCODE2 -4 -4 Translated visit code
#'   \item EXAMDATE D  Examination Date
#'   \item VERSION D  
#'   \item LONISID T  The LONI study UID for the image processed
#'   \item LONIUID T  The LONI series UID for the image processed.
#'   \item IMAGEUID T  The ImageUID for the image processed.
#'   \item RUNDATE D  
#'   \item STATUS T  
#'   \item OVERALLQC T  An overall quality rating. Refer to additional QC variables for Partial rating.
#'   \item TEMPQC T  QC rating of temporal lobe. Fail affects the following regions: LeftTemporalPole (ST60); RightTemporalPole (ST119); LeftFusiform (ST26); RightFusiform (ST85); LeftSuperiorTemporal (ST58); RightSuperiorTemporal (ST117); LeftInferiorTemporal (ST32); RightInferiorTemporal (ST91); LeftMiddleTemporal (ST40); RightMiddleTemporal (ST99)
#'   \item FRONTQC T  QC rating of the frontal lobe. Fail affects the following regions: LeftFrontalPole (ST25); RightFrontalPole (ST84); LeftPrecentral (ST51); RightPrecentral (ST110); LeftSuperiorFrontal (ST56); RightSuperiorFrontal (ST115); LeftCaudalMiddleFrontal (ST15); RightCaudalMiddleFrontal (ST74); LeftRostralMiddleFrontal (ST55); RightRostralMiddleFrontal (ST114); LeftMedialOrbitofrontal (ST39); RightMedialOrbitofrontal (ST98)
#'   \item PARQC T  QC rating of the parietal lobe. Fail affects the following regions: LeftPostcentral (ST49); RightPostcentral (ST108); LeftSuperiorParietal (ST57); RightSuperiorParietal (ST116); LeftSupraMarginal (ST59); RightSupraMarginal (ST118); LeftParacentral (ST43); RightParacentral (ST102); LeftInferiorParietal (ST31); RightInferiorParietal (ST90)
#'   \item INSULAQC T  QC rating of the insula. Fail affects the following regions: LeftInsula (ST129); RightInsula (ST130)
#'   \item OCCQC T  QC rating of the occipital lobe. Fail affects the following regions: LeftLingual (ST38); RightLingual (ST97); LeftLateralOccipital (ST35); RightLateralOccipital (ST94); LeftPericalcarine (ST48); RightPericalcarine (ST107); LeftCuneus (ST23); RightCuneus (ST82)
#'   \item BGQC T  QC rating of the basal ganglia. Fail affects the following regions: LeftPutamen (ST53); RightPutamen (ST112); LeftCaudate (ST16); RightCaudate (ST75); LeftPallidum (ST42); RightPallidum (ST101)
#'   \item CWMQC T  QC rating of the cerebral WM. Fail affects the following regions: LeftCerebralWM (ST20); RightCerebralWM (ST79); LeftCorticalWM (ST150); RightCorticalWM (ST151); CorticalWM (ST152); LeftHemisphereWM (ST28); RightHemisphereWM (ST87)
#'   \item VENTQC T  QC rating of the ventricles. Fail affects the following regions: LeftLateralVentricle (ST37); RightLateralVentricle (ST96); LeftInferiorLateralVentricle (ST30); RightInferiorLateralVentricle (ST89); ThirdVentricle (ST127); FourthVentricle (ST9); FifthVentrical (ST8); LeftChoroidPlexus (ST21); RightChoroidPlexus (ST80)
#'   \item LHIPQC T  QC rating of the left hippocampal subfields. Fail affects the following regions: Left CA1 (ST131HS); Left CA2-3 (ST132HS); Left CA4-DG (ST133HS); Left Fimbria (ST134HS); Left Hippocampal Fissure (ST135HS); Left Presubiculum (ST136HS); Left Subiculum (ST137HS); Left Tail (ST138HS) 
#'   \item RHIPQC T  QC rating of the right hippocampal subfields. Fail affects the following regions: Right CA1 (ST139HS); Right CA2-3 (ST140HS); Right CA4-DG (ST141HS); Right Fimbria (ST142HS); Right Hippocampal Fissure (ST143HS); Right Presubiculum (ST144HS); Right Subiculum (ST145HS); Right Tail (ST146HS) 
#'   \item ST149SV N mm3 Subcortical Volume (aseg.stats) of CorticalGM
#'   \item ST28SA N mm2 Surface Area (aparc.stats) of LeftHemisphereWM
#'   \item ST87SA N mm2 Surface Area (aparc.stats) of RightHemisphereWM
#'   \item ST1SV N mm3 Subcortical Volume (aseg.stats) of Brainstem
#'   \item ST2SV N mm3 Subcortical Volume (aseg.stats) of CorpusCallosumAnterior
#'   \item ST3SV N mm3 Subcortical Volume (aseg.stats) of CorpusCallosumCentral
#'   \item ST4SV N mm3 Subcortical Volume (aseg.stats) of CorpusCallosumMidAnterior
#'   \item ST5SV N mm3 Subcortical Volume (aseg.stats) of CorpusCallosumMidPosterior
#'   \item ST6SV N mm3 Subcortical Volume (aseg.stats) of CorpusCallosumPosterior
#'   \item ST7SV N mm3 Subcortical Volume (aseg.stats) of Csf
#'   \item ST8SV N mm3 Subcortical Volume (aseg.stats) of FifthVentricle
#'   \item ST9SV N mm3 Subcortical Volume (aseg.stats) of FourthVentricle
#'   \item ST10CV N mm3 Cortical Volume (aparc.stats) of Icv
#'   \item ST11SV N mm3 Subcortical Volume (aseg.stats) of LeftAccumbensArea
#'   \item ST12SV N mm3 Subcortical Volume (aseg.stats) of LeftAmygdala
#'   \item ST13SA N mm2 Surface Area (aparc.stats) of LeftBankssts
#'   \item ST13TA N mm Thickness Average (aparc.stats) of LeftBankssts
#'   \item ST13TS N mm Thickness Stardard Deviation (aparc.stats) of LeftBankssts
#'   \item ST13CV N mm3 Cortical Volume (aparc.stats) of LeftBankssts
#'   \item ST14SA N mm2 Surface Area (aparc.stats) of LeftCaudalAnteriorCingulate
#'   \item ST14TA N mm Thickness Average (aparc.stats) of LeftCaudalAnteriorCingulate
#'   \item ST14TS N mm Thickness Stardard Deviation (aparc.stats) of LeftCaudalAnteriorCingulate
#'   \item ST14CV N mm3 Cortical Volume (aparc.stats) of LeftCaudalAnteriorCingulate
#'   \item ST15SA N mm2 Surface Area (aparc.stats) of LeftCaudalMiddleFrontal
#'   \item ST15TA N mm Thickness Average (aparc.stats) of LeftCaudalMiddleFrontal
#'   \item ST15TS N mm Thickness Stardard Deviation (aparc.stats) of LeftCaudalMiddleFrontal
#'   \item ST15CV N mm3 Cortical Volume (aparc.stats) of LeftCaudalMiddleFrontal
#'   \item ST16SV N mm3 Subcortical Volume (aseg.stats) of LeftCaudate
#'   \item ST17SV N mm3 Subcortical Volume (aseg.stats) of LeftCerebellumCortex
#'   \item ST18SV N mm3 Subcortical Volume (aseg.stats) of LeftCerebellumWM
#'   \item ST21SV N mm3 Subcortical Volume (aseg.stats) of LeftChoroidPlexus
#'   \item ST23SA N mm2 Surface Area (aparc.stats) of LeftCuneus
#'   \item ST23TA N mm Thickness Average (aparc.stats) of LeftCuneus
#'   \item ST23TS N mm Thickness Stardard Deviation (aparc.stats) of LeftCuneus
#'   \item ST23CV N mm3 Cortical Volume (aparc.stats) of LeftCuneus
#'   \item ST24SA N mm2 Surface Area (aparc.stats) of LeftEntorhinal
#'   \item ST24TA N mm Thickness Average (aparc.stats) of LeftEntorhinal
#'   \item ST24TS N mm Thickness Stardard Deviation (aparc.stats) of LeftEntorhinal
#'   \item ST24CV N mm3 Cortical Volume (aparc.stats) of LeftEntorhinal
#'   \item ST25SA N mm2 Surface Area (aparc.stats) of LeftFrontalPole
#'   \item ST25TA N mm Thickness Average (aparc.stats) of LeftFrontalPole
#'   \item ST25TS N mm Thickness Stardard Deviation (aparc.stats) of LeftFrontalPole
#'   \item ST25CV N mm3 Cortical Volume (aparc.stats) of LeftFrontalPole
#'   \item ST26SA N mm2 Surface Area (aparc.stats) of LeftFusiform
#'   \item ST26TA N mm Thickness Average (aparc.stats) of LeftFusiform
#'   \item ST26TS N mm Thickness Stardard Deviation (aparc.stats) of LeftFusiform
#'   \item ST26CV N mm3 Cortical Volume (aparc.stats) of LeftFusiform
#'   \item ST29SV N mm3 Subcortical Volume (aseg.stats) of LeftHippocampus
#'   \item ST30SV N mm3 Subcortical Volume (aseg.stats) of LeftInferiorLateralVentricle
#'   \item ST31SA N mm2 Surface Area (aparc.stats) of LeftInferiorParietal
#'   \item ST31TA N mm Thickness Average (aparc.stats) of LeftInferiorParietal
#'   \item ST31TS N mm Thickness Stardard Deviation (aparc.stats) of LeftInferiorParietal
#'   \item ST31CV N mm3 Cortical Volume (aparc.stats) of LeftInferiorParietal
#'   \item ST32SA N mm2 Surface Area (aparc.stats) of LeftInferiorTemporal
#'   \item ST32TA N mm Thickness Average (aparc.stats) of LeftInferiorTemporal
#'   \item ST32TS N mm Thickness Stardard Deviation (aparc.stats) of LeftInferiorTemporal
#'   \item ST32CV N mm3 Cortical Volume (aparc.stats) of LeftInferiorTemporal
#'   \item ST34SA N mm2 Surface Area (aparc.stats) of LeftIsthmusCingulate
#'   \item ST34TA N mm Thickness Average (aparc.stats) of LeftIsthmusCingulate
#'   \item ST34TS N mm Thickness Stardard Deviation (aparc.stats) of LeftIsthmusCingulate
#'   \item ST34CV N mm3 Cortical Volume (aparc.stats) of LeftIsthmusCingulate
#'   \item ST35SA N mm2 Surface Area (aparc.stats) of LeftLateralOccipital
#'   \item ST35TA N mm Thickness Average (aparc.stats) of LeftLateralOccipital
#'   \item ST35TS N mm Thickness Stardard Deviation (aparc.stats) of LeftLateralOccipital
#'   \item ST35CV N mm3 Cortical Volume (aparc.stats) of LeftLateralOccipital
#'   \item ST36SA N mm2 Surface Area (aparc.stats) of LeftLateralOrbitofrontal
#'   \item ST36TA N mm Thickness Average (aparc.stats) of LeftLateralOrbitofrontal
#'   \item ST36TS N mm Thickness Stardard Deviation (aparc.stats) of LeftLateralOrbitofrontal
#'   \item ST36CV N mm3 Cortical Volume (aparc.stats) of LeftLateralOrbitofrontal
#'   \item ST37SV N mm3 Subcortical Volume (aseg.stats) of LeftLateralVentricle
#'   \item ST38SA N mm2 Surface Area (aparc.stats) of LeftLingual
#'   \item ST38TA N mm Thickness Average (aparc.stats) of LeftLingual
#'   \item ST38TS N mm Thickness Stardard Deviation (aparc.stats) of LeftLingual
#'   \item ST38CV N mm3 Cortical Volume (aparc.stats) of LeftLingual
#'   \item ST39SA N mm2 Surface Area (aparc.stats) of LeftMedialOrbitofrontal
#'   \item ST39TA N mm Thickness Average (aparc.stats) of LeftMedialOrbitofrontal
#'   \item ST39TS N mm Thickness Stardard Deviation (aparc.stats) of LeftMedialOrbitofrontal
#'   \item ST39CV N mm3 Cortical Volume (aparc.stats) of LeftMedialOrbitofrontal
#'   \item ST40SA N mm2 Surface Area (aparc.stats) of LeftMiddleTemporal
#'   \item ST40TA N mm Thickness Average (aparc.stats) of LeftMiddleTemporal
#'   \item ST40TS N mm Thickness Stardard Deviation (aparc.stats) of LeftMiddleTemporal
#'   \item ST40CV N mm3 Cortical Volume (aparc.stats) of LeftMiddleTemporal
#'   \item ST42SV N mm3 Subcortical Volume (aseg.stats) of LeftPallidum
#'   \item ST43SA N mm2 Surface Area (aparc.stats) of LeftParacentral
#'   \item ST43TA N mm Thickness Average (aparc.stats) of LeftParacentral
#'   \item ST43TS N mm Thickness Stardard Deviation (aparc.stats) of LeftParacentral
#'   \item ST43CV N mm3 Cortical Volume (aparc.stats) of LeftParacentral
#'   \item ST44SA N mm2 Surface Area (aparc.stats) of LeftParahippocampal
#'   \item ST44TA N mm Thickness Average (aparc.stats) of LeftParahippocampal
#'   \item ST44TS N mm Thickness Stardard Deviation (aparc.stats) of LeftParahippocampal
#'   \item ST44CV N mm3 Cortical Volume (aparc.stats) of LeftParahippocampal
#'   \item ST45SA N mm2 Surface Area (aparc.stats) of LeftParsOpercularis
#'   \item ST45TA N mm Thickness Average (aparc.stats) of LeftParsOpercularis
#'   \item ST45TS N mm Thickness Stardard Deviation (aparc.stats) of LeftParsOpercularis
#'   \item ST45CV N mm3 Cortical Volume (aparc.stats) of LeftParsOpercularis
#'   \item ST46SA N mm2 Surface Area (aparc.stats) of LeftParsOrbitalis
#'   \item ST46TA N mm Thickness Average (aparc.stats) of LeftParsOrbitalis
#'   \item ST46TS N mm Thickness Stardard Deviation (aparc.stats) of LeftParsOrbitalis
#'   \item ST46CV N mm3 Cortical Volume (aparc.stats) of LeftParsOrbitalis
#'   \item ST47SA N mm2 Surface Area (aparc.stats) of LeftParsTriangularis
#'   \item ST47TA N mm Thickness Average (aparc.stats) of LeftParsTriangularis
#'   \item ST47TS N mm Thickness Stardard Deviation (aparc.stats) of LeftParsTriangularis
#'   \item ST47CV N mm3 Cortical Volume (aparc.stats) of LeftParsTriangularis
#'   \item ST48SA N mm2 Surface Area (aparc.stats) of LeftPericalcarine
#'   \item ST48TA N mm Thickness Average (aparc.stats) of LeftPericalcarine
#'   \item ST48TS N mm Thickness Stardard Deviation (aparc.stats) of LeftPericalcarine
#'   \item ST48CV N mm3 Cortical Volume (aparc.stats) of LeftPericalcarine
#'   \item ST49SA N mm2 Surface Area (aparc.stats) of LeftPostcentral
#'   \item ST49TA N mm Thickness Average (aparc.stats) of LeftPostcentral
#'   \item ST49TS N mm Thickness Stardard Deviation (aparc.stats) of LeftPostcentral
#'   \item ST49CV N mm3 Cortical Volume (aparc.stats) of LeftPostcentral
#'   \item ST50SA N mm2 Surface Area (aparc.stats) of LeftPosteriorCingulate
#'   \item ST50TA N mm Thickness Average (aparc.stats) of LeftPosteriorCingulate
#'   \item ST50TS N mm Thickness Stardard Deviation (aparc.stats) of LeftPosteriorCingulate
#'   \item ST50CV N mm3 Cortical Volume (aparc.stats) of LeftPosteriorCingulate
#'   \item ST51SA N mm2 Surface Area (aparc.stats) of LeftPrecentral
#'   \item ST51TA N mm Thickness Average (aparc.stats) of LeftPrecentral
#'   \item ST51TS N mm Thickness Stardard Deviation (aparc.stats) of LeftPrecentral
#'   \item ST51CV N mm3 Cortical Volume (aparc.stats) of LeftPrecentral
#'   \item ST52SA N mm2 Surface Area (aparc.stats) of LeftPrecuneus
#'   \item ST52TA N mm Thickness Average (aparc.stats) of LeftPrecuneus
#'   \item ST52TS N mm Thickness Stardard Deviation (aparc.stats) of LeftPrecuneus
#'   \item ST52CV N mm3 Cortical Volume (aparc.stats) of LeftPrecuneus
#'   \item ST53SV N mm3 Subcortical Volume (aseg.stats) of LeftPutamen
#'   \item ST54SA N mm2 Surface Area (aparc.stats) of LeftRostralAnteriorCingulate
#'   \item ST54TA N mm Thickness Average (aparc.stats) of LeftRostralAnteriorCingulate
#'   \item ST54TS N mm Thickness Stardard Deviation (aparc.stats) of LeftRostralAnteriorCingulate
#'   \item ST54CV N mm3 Cortical Volume (aparc.stats) of LeftRostralAnteriorCingulate
#'   \item ST55SA N mm2 Surface Area (aparc.stats) of LeftRostralMiddleFrontal
#'   \item ST55TA N mm Thickness Average (aparc.stats) of LeftRostralMiddleFrontal
#'   \item ST55TS N mm Thickness Stardard Deviation (aparc.stats) of LeftRostralMiddleFrontal
#'   \item ST55CV N mm3 Cortical Volume (aparc.stats) of LeftRostralMiddleFrontal
#'   \item ST56SA N mm2 Surface Area (aparc.stats) of LeftSuperiorFrontal
#'   \item ST56TA N mm Thickness Average (aparc.stats) of LeftSuperiorFrontal
#'   \item ST56TS N mm Thickness Stardard Deviation (aparc.stats) of LeftSuperiorFrontal
#'   \item ST56CV N mm3 Cortical Volume (aparc.stats) of LeftSuperiorFrontal
#'   \item ST57SA N mm2 Surface Area (aparc.stats) of LeftSuperiorParietal
#'   \item ST57TA N mm Thickness Average (aparc.stats) of LeftSuperiorParietal
#'   \item ST57TS N mm Thickness Stardard Deviation (aparc.stats) of LeftSuperiorParietal
#'   \item ST57CV N mm3 Cortical Volume (aparc.stats) of LeftSuperiorParietal
#'   \item ST58SA N mm2 Surface Area (aparc.stats) of LeftSuperiorTemporal
#'   \item ST58TA N mm Thickness Average (aparc.stats) of LeftSuperiorTemporal
#'   \item ST58TS N mm Thickness Stardard Deviation (aparc.stats) of LeftSuperiorTemporal
#'   \item ST58CV N mm3 Cortical Volume (aparc.stats) of LeftSuperiorTemporal
#'   \item ST59SA N mm2 Surface Area (aparc.stats) of LeftSupramarginal
#'   \item ST59TA N mm Thickness Average (aparc.stats) of LeftSupramarginal
#'   \item ST59TS N mm Thickness Stardard Deviation (aparc.stats) of LeftSupramarginal
#'   \item ST59CV N mm3 Cortical Volume (aparc.stats) of LeftSupramarginal
#'   \item ST60SA N mm2 Surface Area (aparc.stats) of LeftTemporalPole
#'   \item ST60TA N mm Thickness Average (aparc.stats) of LeftTemporalPole
#'   \item ST60TS N mm Thickness Stardard Deviation (aparc.stats) of LeftTemporalPole
#'   \item ST60CV N mm3 Cortical Volume (aparc.stats) of LeftTemporalPole
#'   \item ST61SV N mm3 Subcortical Volume (aseg.stats) of LeftThalamus
#'   \item ST62SA N mm2 Surface Area (aparc.stats) of LeftTransverseTemporal
#'   \item ST62TA N mm Thickness Average (aparc.stats) of LeftTransverseTemporal
#'   \item ST62TS N mm Thickness Stardard Deviation (aparc.stats) of LeftTransverseTemporal
#'   \item ST62CV N mm3 Cortical Volume (aparc.stats) of LeftTransverseTemporal
#'   \item ST65SV N mm3 Subcortical Volume (aseg.stats) of LeftVentralDC
#'   \item ST66SV N mm3 Subcortical Volume (aseg.stats) of LeftVessel
#'   \item ST68SV N mm3 Subcortical Volume (aseg.stats) of NonWMHypoIntensities
#'   \item ST69SV N mm3 Subcortical Volume (aseg.stats) of OpticChiasm
#'   \item ST70SV N mm3 Subcortical Volume (aseg.stats) of RightAccumbensArea
#'   \item ST71SV N mm3 Subcortical Volume (aseg.stats) of RightAmygdala
#'   \item ST72SA N mm2 Surface Area (aparc.stats) of RightBankssts
#'   \item ST72TA N mm Thickness Average (aparc.stats) of RightBankssts
#'   \item ST72TS N mm Thickness Stardard Deviation (aparc.stats) of RightBankssts
#'   \item ST72CV N mm3 Cortical Volume (aparc.stats) of RightBankssts
#'   \item ST73SA N mm2 Surface Area (aparc.stats) of RightCaudalAnteriorCingulate
#'   \item ST73TA N mm Thickness Average (aparc.stats) of RightCaudalAnteriorCingulate
#'   \item ST73TS N mm Thickness Stardard Deviation (aparc.stats) of RightCaudalAnteriorCingulate
#'   \item ST73CV N mm3 Cortical Volume (aparc.stats) of RightCaudalAnteriorCingulate
#'   \item ST74SA N mm2 Surface Area (aparc.stats) of RightCaudalMiddleFrontal
#'   \item ST74TA N mm Thickness Average (aparc.stats) of RightCaudalMiddleFrontal
#'   \item ST74TS N mm Thickness Stardard Deviation (aparc.stats) of RightCaudalMiddleFrontal
#'   \item ST74CV N mm3 Cortical Volume (aparc.stats) of RightCaudalMiddleFrontal
#'   \item ST75SV N mm3 Subcortical Volume (aseg.stats) of RightCaudate
#'   \item ST76SV N mm3 Subcortical Volume (aseg.stats) of RightCerebellumCortex
#'   \item ST77SV N mm3 Subcortical Volume (aseg.stats) of RightCerebellumWM
#'   \item ST80SV N mm3 Subcortical Volume (aseg.stats) of RightChoroidPlexus
#'   \item ST82SA N mm2 Surface Area (aparc.stats) of RightCuneus
#'   \item ST82TA N mm Thickness Average (aparc.stats) of RightCuneus
#'   \item ST82TS N mm Thickness Stardard Deviation (aparc.stats) of RightCuneus
#'   \item ST82CV N mm3 Cortical Volume (aparc.stats) of RightCuneus
#'   \item ST83SA N mm2 Surface Area (aparc.stats) of RightEntorhinal
#'   \item ST83TA N mm Thickness Average (aparc.stats) of RightEntorhinal
#'   \item ST83TS N mm Thickness Stardard Deviation (aparc.stats) of RightEntorhinal
#'   \item ST83CV N mm3 Cortical Volume (aparc.stats) of RightEntorhinal
#'   \item ST84SA N mm2 Surface Area (aparc.stats) of RightFrontalPole
#'   \item ST84TA N mm Thickness Average (aparc.stats) of RightFrontalPole
#'   \item ST84TS N mm Thickness Stardard Deviation (aparc.stats) of RightFrontalPole
#'   \item ST84CV N mm3 Cortical Volume (aparc.stats) of RightFrontalPole
#'   \item ST85SA N mm2 Surface Area (aparc.stats) of RightFusiform
#'   \item ST85TA N mm Thickness Average (aparc.stats) of RightFusiform
#'   \item ST85TS N mm Thickness Stardard Deviation (aparc.stats) of RightFusiform
#'   \item ST85CV N mm3 Cortical Volume (aparc.stats) of RightFusiform
#'   \item ST88SV N mm3 Subcortical Volume (aseg.stats) of RightHippocampus
#'   \item ST89SV N mm3 Subcortical Volume (aseg.stats) of RightInferiorLateralVentricle
#'   \item ST90SA N mm2 Surface Area (aparc.stats) of RightInferiorParietal
#'   \item ST90TA N mm Thickness Average (aparc.stats) of RightInferiorParietal
#'   \item ST90TS N mm Thickness Stardard Deviation (aparc.stats) of RightInferiorParietal
#'   \item ST90CV N mm3 Cortical Volume (aparc.stats) of RightInferiorParietal
#'   \item ST91SA N mm2 Surface Area (aparc.stats) of RightInferiorTemporal
#'   \item ST91TA N mm Thickness Average (aparc.stats) of RightInferiorTemporal
#'   \item ST91TS N mm Thickness Stardard Deviation (aparc.stats) of RightInferiorTemporal
#'   \item ST91CV N mm3 Cortical Volume (aparc.stats) of RightInferiorTemporal
#'   \item ST93SA N mm2 Surface Area (aparc.stats) of RightIsthmusCingulate
#'   \item ST93TA N mm Thickness Average (aparc.stats) of RightIsthmusCingulate
#'   \item ST93TS N mm Thickness Stardard Deviation (aparc.stats) of RightIsthmusCingulate
#'   \item ST93CV N mm3 Cortical Volume (aparc.stats) of RightIsthmusCingulate
#'   \item ST94SA N mm2 Surface Area (aparc.stats) of RightLateralOccipital
#'   \item ST94TA N mm Thickness Average (aparc.stats) of RightLateralOccipital
#'   \item ST94TS N mm Thickness Stardard Deviation (aparc.stats) of RightLateralOccipital
#'   \item ST94CV N mm3 Cortical Volume (aparc.stats) of RightLateralOccipital
#'   \item ST95SA N mm2 Surface Area (aparc.stats) of RightLateralOrbitofrontal
#'   \item ST95TA N mm Thickness Average (aparc.stats) of RightLateralOrbitofrontal
#'   \item ST95TS N mm Thickness Stardard Deviation (aparc.stats) of RightLateralOrbitofrontal
#'   \item ST95CV N mm3 Cortical Volume (aparc.stats) of RightLateralOrbitofrontal
#'   \item ST96SV N mm3 Subcortical Volume (aseg.stats) of RightLateralVentricle
#'   \item ST97SA N mm2 Surface Area (aparc.stats) of RightLingual
#'   \item ST97TA N mm Thickness Average (aparc.stats) of RightLingual
#'   \item ST97TS N mm Thickness Stardard Deviation (aparc.stats) of RightLingual
#'   \item ST97CV N mm3 Cortical Volume (aparc.stats) of RightLingual
#'   \item ST98SA N mm2 Surface Area (aparc.stats) of RightMedialOrbitofrontal
#'   \item ST98TA N mm Thickness Average (aparc.stats) of RightMedialOrbitofrontal
#'   \item ST98TS N mm Thickness Stardard Deviation (aparc.stats) of RightMedialOrbitofrontal
#'   \item ST98CV N mm3 Cortical Volume (aparc.stats) of RightMedialOrbitofrontal
#'   \item ST99SA N mm2 Surface Area (aparc.stats) of RightMiddleTemporal
#'   \item ST99TA N mm Thickness Average (aparc.stats) of RightMiddleTemporal
#'   \item ST99TS N mm Thickness Stardard Deviation (aparc.stats) of RightMiddleTemporal
#'   \item ST99CV N mm3 Cortical Volume (aparc.stats) of RightMiddleTemporal
#'   \item ST101SV N mm3 Subcortical Volume (aseg.stats) of RightPallidum
#'   \item ST102SA N mm2 Surface Area (aparc.stats) of RightParacentral
#'   \item ST102TA N mm Thickness Average (aparc.stats) of RightParacentral
#'   \item ST102TS N mm Thickness Stardard Deviation (aparc.stats) of RightParacentral
#'   \item ST102CV N mm3 Cortical Volume (aparc.stats) of RightParacentral
#'   \item ST103SA N mm2 Surface Area (aparc.stats) of RightParahippocampal
#'   \item ST103TA N mm Thickness Average (aparc.stats) of RightParahippocampal
#'   \item ST103TS N mm Thickness Stardard Deviation (aparc.stats) of RightParahippocampal
#'   \item ST103CV N mm3 Cortical Volume (aparc.stats) of RightParahippocampal
#'   \item ST104SA N mm2 Surface Area (aparc.stats) of RightParsOpercularis
#'   \item ST104TA N mm Thickness Average (aparc.stats) of RightParsOpercularis
#'   \item ST104TS N mm Thickness Stardard Deviation (aparc.stats) of RightParsOpercularis
#'   \item ST104CV N mm3 Cortical Volume (aparc.stats) of RightParsOpercularis
#'   \item ST105SA N mm2 Surface Area (aparc.stats) of RightParsOrbitalis
#'   \item ST105TA N mm Thickness Average (aparc.stats) of RightParsOrbitalis
#'   \item ST105TS N mm Thickness Stardard Deviation (aparc.stats) of RightParsOrbitalis
#'   \item ST105CV N mm3 Cortical Volume (aparc.stats) of RightParsOrbitalis
#'   \item ST106SA N mm2 Surface Area (aparc.stats) of RightParsTriangularis
#'   \item ST106TA N mm Thickness Average (aparc.stats) of RightParsTriangularis
#'   \item ST106TS N mm Thickness Stardard Deviation (aparc.stats) of RightParsTriangularis
#'   \item ST106CV N mm3 Cortical Volume (aparc.stats) of RightParsTriangularis
#'   \item ST107SA N mm2 Surface Area (aparc.stats) of RightPericalcarine
#'   \item ST107TA N mm Thickness Average (aparc.stats) of RightPericalcarine
#'   \item ST107TS N mm Thickness Stardard Deviation (aparc.stats) of RightPericalcarine
#'   \item ST107CV N mm3 Cortical Volume (aparc.stats) of RightPericalcarine
#'   \item ST108SA N mm2 Surface Area (aparc.stats) of RightPostcentral
#'   \item ST108TA N mm Thickness Average (aparc.stats) of RightPostcentral
#'   \item ST108TS N mm Thickness Stardard Deviation (aparc.stats) of RightPostcentral
#'   \item ST108CV N mm3 Cortical Volume (aparc.stats) of RightPostcentral
#'   \item ST109SA N mm2 Surface Area (aparc.stats) of RightPosteriorCingulate
#'   \item ST109TA N mm Thickness Average (aparc.stats) of RightPosteriorCingulate
#'   \item ST109TS N mm Thickness Stardard Deviation (aparc.stats) of RightPosteriorCingulate
#'   \item ST109CV N mm3 Cortical Volume (aparc.stats) of RightPosteriorCingulate
#'   \item ST110SA N mm2 Surface Area (aparc.stats) of RightPrecentral
#'   \item ST110TA N mm Thickness Average (aparc.stats) of RightPrecentral
#'   \item ST110TS N mm Thickness Stardard Deviation (aparc.stats) of RightPrecentral
#'   \item ST110CV N mm3 Cortical Volume (aparc.stats) of RightPrecentral
#'   \item ST111SA N mm2 Surface Area (aparc.stats) of RightPrecuneus
#'   \item ST111TA N mm Thickness Average (aparc.stats) of RightPrecuneus
#'   \item ST111TS N mm Thickness Stardard Deviation (aparc.stats) of RightPrecuneus
#'   \item ST111CV N mm3 Cortical Volume (aparc.stats) of RightPrecuneus
#'   \item ST112SV N mm3 Subcortical Volume (aseg.stats) of RightPutamen
#'   \item ST113SA N mm2 Surface Area (aparc.stats) of RightRostralAnteriorCingulate
#'   \item ST113TA N mm Thickness Average (aparc.stats) of RightRostralAnteriorCingulate
#'   \item ST113TS N mm Thickness Stardard Deviation (aparc.stats) of RightRostralAnteriorCingulate
#'   \item ST113CV N mm3 Cortical Volume (aparc.stats) of RightRostralAnteriorCingulate
#'   \item ST114SA N mm2 Surface Area (aparc.stats) of RightRostralMiddleFrontal
#'   \item ST114TA N mm Thickness Average (aparc.stats) of RightRostralMiddleFrontal
#'   \item ST114TS N mm Thickness Stardard Deviation (aparc.stats) of RightRostralMiddleFrontal
#'   \item ST114CV N mm3 Cortical Volume (aparc.stats) of RightRostralMiddleFrontal
#'   \item ST115SA N mm2 Surface Area (aparc.stats) of RightSuperiorFrontal
#'   \item ST115TA N mm Thickness Average (aparc.stats) of RightSuperiorFrontal
#'   \item ST115TS N mm Thickness Stardard Deviation (aparc.stats) of RightSuperiorFrontal
#'   \item ST115CV N mm3 Cortical Volume (aparc.stats) of RightSuperiorFrontal
#'   \item ST116SA N mm2 Surface Area (aparc.stats) of RightSuperiorParietal
#'   \item ST116TA N mm Thickness Average (aparc.stats) of RightSuperiorParietal
#'   \item ST116TS N mm Thickness Stardard Deviation (aparc.stats) of RightSuperiorParietal
#'   \item ST116CV N mm3 Cortical Volume (aparc.stats) of RightSuperiorParietal
#'   \item ST117SA N mm2 Surface Area (aparc.stats) of RightSuperiorTemporal
#'   \item ST117TA N mm Thickness Average (aparc.stats) of RightSuperiorTemporal
#'   \item ST117TS N mm Thickness Stardard Deviation (aparc.stats) of RightSuperiorTemporal
#'   \item ST117CV N mm3 Cortical Volume (aparc.stats) of RightSuperiorTemporal
#'   \item ST118SA N mm2 Surface Area (aparc.stats) of RightSupramarginal
#'   \item ST118TA N mm Thickness Average (aparc.stats) of RightSupramarginal
#'   \item ST118TS N mm Thickness Stardard Deviation (aparc.stats) of RightSupramarginal
#'   \item ST118CV N mm3 Cortical Volume (aparc.stats) of RightSupramarginal
#'   \item ST119SA N mm2 Surface Area (aparc.stats) of RightTemporalPole
#'   \item ST119TA N mm Thickness Average (aparc.stats) of RightTemporalPole
#'   \item ST119TS N mm Thickness Stardard Deviation (aparc.stats) of RightTemporalPole
#'   \item ST119CV N mm3 Cortical Volume (aparc.stats) of RightTemporalPole
#'   \item ST120SV N mm3 Subcortical Volume (aseg.stats) of RightThalamus
#'   \item ST121SA N mm2 Surface Area (aparc.stats) of RightTransverseTemporal
#'   \item ST121TA N mm Thickness Average (aparc.stats) of RightTransverseTemporal
#'   \item ST121TS N mm Thickness Stardard Deviation (aparc.stats) of RightTransverseTemporal
#'   \item ST121CV N mm3 Cortical Volume (aparc.stats) of RightTransverseTemporal
#'   \item ST124SV N mm3 Subcortical Volume (aseg.stats) of RightVentralDC
#'   \item ST125SV N mm3 Subcortical Volume (aseg.stats) of RightVessel
#'   \item ST127SV N mm3 Subcortical Volume (aseg.stats) of ThirdVentricle
#'   \item ST128SV N mm3 Subcortical Volume (aseg.stats) of WMHypoIntensities
#'   \item ST129SA N mm2 Surface Area (aparc.stats) of LeftInsula
#'   \item ST129TA N mm Thickness Average (aparc.stats) of LeftInsula
#'   \item ST129TS N mm Thickness Stardard Deviation (aparc.stats) of LeftInsula
#'   \item ST129CV N mm3 Cortical Volume (aparc.stats) of LeftInsula
#'   \item ST130SA N mm2 Surface Area (aparc.stats) of RightInsula
#'   \item ST130TA N mm Thickness Average (aparc.stats) of RightInsula
#'   \item ST130TS N mm Thickness Stardard Deviation (aparc.stats) of RightInsula
#'   \item ST130CV N mm3 Cortical Volume (aparc.stats) of RightInsula
#'   \item ST131HS N mm3 Hippocampal Subfields Volume of LeftCA1
#'   \item ST132HS N mm3 Hippocampal Subfields Volume of LeftCA2_3
#'   \item ST133HS N mm3 Hippocampal Subfields Volume of LeftCA4_DG
#'   \item ST134HS N mm3 Hippocampal Subfields Volume of LeftFimbria
#'   \item ST135HS N mm3 Hippocampal Subfields Volume of LeftHippocampalFissure
#'   \item ST136HS N mm3 Hippocampal Subfields Volume of LeftPresubiculum
#'   \item ST137HS N mm3 Hippocampal Subfields Volume of LeftSubiculum
#'   \item ST138HS N mm3 Hippocampal Subfields Volume of LeftTail
#'   \item ST139HS N mm3 Hippocampal Subfields Volume of RightCA1
#'   \item ST140HS N mm3 Hippocampal Subfields Volume of RightCA2_3
#'   \item ST141HS N mm3 Hippocampal Subfields Volume of RightCA4_DG
#'   \item ST142HS N mm3 Hippocampal Subfields Volume of RightFimbria
#'   \item ST143HS N mm3 Hippocampal Subfields Volume of RightHippocampalFissure
#'   \item ST144HS N mm3 Hippocampal Subfields Volume of RightPresubiculum
#'   \item ST145HS N mm3 Hippocampal Subfields Volume of RightSubiculum
#'   \item ST146HS N mm3 Hippocampal Subfields Volume of RightTail
#'   \item ST147SV N mm3 Subcortical Volume (aseg.stats) of LeftCorticalGM
#'   \item ST148SV N mm3 Subcortical Volume (aseg.stats) of RightCorticalGM
#'   \item ST150SV N mm3 Subcortical Volume (aseg.stats) of LeftCorticalWM
#'   \item ST151SV N mm3 Subcortical Volume (aseg.stats) of RightCorticalWM
#'   \item ST152SV N mm3 Subcortical Volume (aseg.stats) of CorticalWM
#'   \item ST153SV N mm3 Subcortical Volume (aseg.stats) of SubcorticalGM
#'   \item ST154SV N mm3 Subcortical Volume (aseg.stats) of TotalGM
#'   \item ST155SV N mm3 Subcortical Volume (aseg.stats) of SupraTentorial
#' }
#'
#' @examples
#' \donotrun{
#' describe(ucsffsl51y1)
#' }
#' @docType data
#' @keywords datasets
#' @name ucsffsl51y1
#' @usage data(ucsffsl51y1)
#' @format A data frame with 1357 rows and 363 variables
NULL

#' Longitudinal FreeSurfer (FreeSurfer Version 4.4)
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID T  Participant roster ID
#'   \item VISCODE T  Visit code
#'   \item VISCODE2 -4 -4 Translated visit code
#'   \item EXAMDATE D  Examination Date
#'   \item VERSION D  
#'   \item FLDSTRENG D  The field strength. 1.5 or 3
#'   \item LONISID T  The LONI study UID for the image processed
#'   \item LONIUID T  The LONI series UID for the image processed.
#'   \item IMAGEUID T  The ImageUID for the image processed.
#'   \item RUNDATE D  
#'   \item STATUS T  
#'   \item BASETP1 N  Whether or not the base image includes a timepoint 1 image.
#'   \item BASETP2 N  Whether or not the base image includes a timepoint 2 image.
#'   \item BASETP3 N  Whether or not the base image includes a timepoint 3 image.
#'   \item BASETP4 N  Whether or not the base image includes a timepoint 4 image.
#'   \item BASETP5 N  Whether or not the base image includes a timepoint 5 image.
#'   \item BASETP6 N  Whether or not the base image includes a timepoint 6 image.
#'   \item BASETP7 N  Whether or not the base image includes a timepoint 7 image.
#'   \item BASETP8 N  Whether or not the base image includes a timepoint 8 image.
#'   \item OVERALLQC T  An overall quality rating. Refer to additional QC variables for Partial rating.
#'   \item TEMPQC T  QC rating of temporal lobe. Fail affects the following regions: LeftTemporalPole (ST60); RightTemporalPole (ST119); LeftFusiform (ST26); RightFusiform (ST85); LeftSuperiorTemporal (ST58); RightSuperiorTemporal (ST117); LeftInferiorTemporal (ST32); RightInferiorTemporal (ST91); LeftMiddleTemporal (ST40); RightMiddleTemporal (ST99)
#'   \item FRONTQC T  QC rating of the frontal lobe. Fail affects the following regions: LeftFrontalPole (ST25); RightFrontalPole (ST84); LeftPrecentral (ST51); RightPrecentral (ST110); LeftSuperiorFrontal (ST56); RightSuperiorFrontal (ST115); LeftCaudalMiddleFrontal (ST15); RightCaudalMiddleFrontal (ST74); LeftRostralMiddleFrontal (ST55); RightRostralMiddleFrontal (ST114); LeftMedialOrbitofrontal (ST39); RightMedialOrbitofrontal (ST98)
#'   \item PARQC T  QC rating of the parietal lobe. Fail affects the following regions: LeftPostcentral (ST49); RightPostcentral (ST108); LeftSuperiorParietal (ST57); RightSuperiorParietal (ST116); LeftSupraMarginal (ST59); RightSupraMarginal (ST118); LeftParacentral (ST43); RightParacentral (ST102); LeftInferiorParietal (ST31); RightInferiorParietal (ST90)
#'   \item INSULAQC T  QC rating of the insula. Fail affects the following regions: LeftInsula (ST129); RightInsula (ST130)
#'   \item OCCQC T  QC rating of the occipital lobe. Fail affects the following regions: LeftLingual (ST38); RightLingual (ST97); LeftLateralOccipital (ST35); RightLateralOccipital (ST94); LeftPericalcarine (ST48); RightPericalcarine (ST107); LeftCuneus (ST23); RightCuneus (ST82)
#'   \item BGQC T  QC rating of the basal ganglia. Fail affects the following regions: LeftPutamen (ST53); RightPutamen (ST112); LeftCaudate (ST16); RightCaudate (ST75); LeftPallidum (ST42); RightPallidum (ST101)
#'   \item CWMQC T  QC rating of the cerebral WM. Fail affects the following regions: LeftCerebralWM (ST20); RightCerebralWM (ST79)
#'   \item VENTQC T  QC rating of the ventricles. Fail affects the following regions: LeftLateralVentricle (ST37); RightLateralVentricle (ST96); LeftInferiorLateralVentricle (ST30); RightInferiorLateralVentricle (ST89); ThirdVentricle (ST127); FourthVentricle (ST9); FifthVentrical (ST8); LeftChoroidPlexus (ST21); RightChoroidPlexus (ST80)
#'   \item ST100SV N mm3 Volume (WM Parcellation) of RightNonWMHypoIntensities
#'   \item ST101SV N mm3 Volume (WM Parcellation) of RightPallidum
#'   \item ST102CV N mm3 Volume (Cortical Parcellation) of RightParacentral
#'   \item ST102SA N mm2 Surface Area of RightParacentral
#'   \item ST102TA N mm Cortical Thickness Average of RightParacentral
#'   \item ST102TS N mm Cortical Thickness Standard Deviation of RightParacentral
#'   \item ST103CV N mm3 Volume (Cortical Parcellation) of RightParahippocampal
#'   \item ST103SA N mm2 Surface Area of RightParahippocampal
#'   \item ST103TA N mm Cortical Thickness Average of RightParahippocampal
#'   \item ST103TS N mm Cortical Thickness Standard Deviation of RightParahippocampal
#'   \item ST104CV N mm3 Volume (Cortical Parcellation) of RightParsOpercularis
#'   \item ST104SA N mm2 Surface Area of RightParsOpercularis
#'   \item ST104TA N mm Cortical Thickness Average of RightParsOpercularis
#'   \item ST104TS N mm Cortical Thickness Standard Deviation of RightParsOpercularis
#'   \item ST105CV N mm3 Volume (Cortical Parcellation) of RightParsOrbitalis
#'   \item ST105SA N mm2 Surface Area of RightParsOrbitalis
#'   \item ST105TA N mm Cortical Thickness Average of RightParsOrbitalis
#'   \item ST105TS N mm Cortical Thickness Standard Deviation of RightParsOrbitalis
#'   \item ST106CV N mm3 Volume (Cortical Parcellation) of RightParsTriangularis
#'   \item ST106SA N mm2 Surface Area of RightParsTriangularis
#'   \item ST106TA N mm Cortical Thickness Average of RightParsTriangularis
#'   \item ST106TS N mm Cortical Thickness Standard Deviation of RightParsTriangularis
#'   \item ST107CV N mm3 Volume (Cortical Parcellation) of RightPericalcarine
#'   \item ST107SA N mm2 Surface Area of RightPericalcarine
#'   \item ST107TA N mm Cortical Thickness Average of RightPericalcarine
#'   \item ST107TS N mm Cortical Thickness Standard Deviation of RightPericalcarine
#'   \item ST108CV N mm3 Volume (Cortical Parcellation) of RightPostcentral
#'   \item ST108SA N mm2 Surface Area of RightPostcentral
#'   \item ST108TA N mm Cortical Thickness Average of RightPostcentral
#'   \item ST108TS N mm Cortical Thickness Standard Deviation of RightPostcentral
#'   \item ST109CV N mm3 Volume (Cortical Parcellation) of RightPosteriorCingulate
#'   \item ST109SA N mm2 Surface Area of RightPosteriorCingulate
#'   \item ST109TA N mm Cortical Thickness Average of RightPosteriorCingulate
#'   \item ST109TS N mm Cortical Thickness Standard Deviation of RightPosteriorCingulate
#'   \item ST10CV N mm3 Volume (Cortical Parcellation) of Icv
#'   \item ST110CV N mm3 Volume (Cortical Parcellation) of RightPrecentral
#'   \item ST110SA N mm2 Surface Area of RightPrecentral
#'   \item ST110TA N mm Cortical Thickness Average of RightPrecentral
#'   \item ST110TS N mm Cortical Thickness Standard Deviation of RightPrecentral
#'   \item ST111CV N mm3 Volume (Cortical Parcellation) of RightPrecuneus
#'   \item ST111SA N mm2 Surface Area of RightPrecuneus
#'   \item ST111TA N mm Cortical Thickness Average of RightPrecuneus
#'   \item ST111TS N mm Cortical Thickness Standard Deviation of RightPrecuneus
#'   \item ST112SV N mm3 Volume (WM Parcellation) of RightPutamen
#'   \item ST113CV N mm3 Volume (Cortical Parcellation) of RightRostralAnteriorCingulate
#'   \item ST113SA N mm2 Surface Area of RightRostralAnteriorCingulate
#'   \item ST113TA N mm Cortical Thickness Average of RightRostralAnteriorCingulate
#'   \item ST113TS N mm Cortical Thickness Standard Deviation of RightRostralAnteriorCingulate
#'   \item ST114CV N mm3 Volume (Cortical Parcellation) of RightRostralMiddleFrontal
#'   \item ST114SA N mm2 Surface Area of RightRostralMiddleFrontal
#'   \item ST114TA N mm Cortical Thickness Average of RightRostralMiddleFrontal
#'   \item ST114TS N mm Cortical Thickness Standard Deviation of RightRostralMiddleFrontal
#'   \item ST115CV N mm3 Volume (Cortical Parcellation) of RightSuperiorFrontal
#'   \item ST115SA N mm2 Surface Area of RightSuperiorFrontal
#'   \item ST115TA N mm Cortical Thickness Average of RightSuperiorFrontal
#'   \item ST115TS N mm Cortical Thickness Standard Deviation of RightSuperiorFrontal
#'   \item ST116CV N mm3 Volume (Cortical Parcellation) of RightSuperiorParietal
#'   \item ST116SA N mm2 Surface Area of RightSuperiorParietal
#'   \item ST116TA N mm Cortical Thickness Average of RightSuperiorParietal
#'   \item ST116TS N mm Cortical Thickness Standard Deviation of RightSuperiorParietal
#'   \item ST117CV N mm3 Volume (Cortical Parcellation) of RightSuperiorTemporal
#'   \item ST117SA N mm2 Surface Area of RightSuperiorTemporal
#'   \item ST117TA N mm Cortical Thickness Average of RightSuperiorTemporal
#'   \item ST117TS N mm Cortical Thickness Standard Deviation of RightSuperiorTemporal
#'   \item ST118CV N mm3 Volume (Cortical Parcellation) of RightSupramarginal
#'   \item ST118SA N mm2 Surface Area of RightSupramarginal
#'   \item ST118TA N mm Cortical Thickness Average of RightSupramarginal
#'   \item ST118TS N mm Cortical Thickness Standard Deviation of RightSupramarginal
#'   \item ST119CV N mm3 Volume (Cortical Parcellation) of RightTemporalPole
#'   \item ST119SA N mm2 Surface Area of RightTemporalPole
#'   \item ST119TA N mm Cortical Thickness Average of RightTemporalPole
#'   \item ST119TS N mm Cortical Thickness Standard Deviation of RightTemporalPole
#'   \item ST11SV N mm3 Volume (WM Parcellation) of LeftAccumbensArea
#'   \item ST120SV N mm3 Volume (WM Parcellation) of RightThalamus
#'   \item ST121CV N mm3 Volume (Cortical Parcellation) of RightTransverseTemporal
#'   \item ST121SA N mm2 Surface Area of RightTransverseTemporal
#'   \item ST121TA N mm Cortical Thickness Average of RightTransverseTemporal
#'   \item ST121TS N mm Cortical Thickness Standard Deviation of RightTransverseTemporal
#'   \item ST122SV N mm3 Volume (WM Parcellation) of RightUndetermined
#'   \item ST123CV N mm3 Volume (Cortical Parcellation) of RightUnknown
#'   \item ST123SA N mm2 Surface Area of RightUnknown
#'   \item ST123TA N mm Cortical Thickness Average of RightUnknown
#'   \item ST123TS N mm Cortical Thickness Standard Deviation of RightUnknown
#'   \item ST124SV N mm3 Volume (WM Parcellation) of RightVentralDC
#'   \item ST125SV N mm3 Volume (WM Parcellation) of RightVessel
#'   \item ST126SV N mm3 Volume (WM Parcellation) of RightWMHypoIntensities
#'   \item ST127SV N mm3 Volume (WM Parcellation) of ThirdVentricle
#'   \item ST128SV N mm3 Volume (WM Parcellation) of WMHypoIntensities
#'   \item ST129CV N mm3 Volume (Cortical Parcellation) of LeftInsula
#'   \item ST129SA N mm2 Surface Area of LeftInsula
#'   \item ST129TA N mm Cortical Thickness Average of LeftInsula
#'   \item ST129TS N mm Cortical Thickness Standard Deviation of LeftInsula
#'   \item ST12SV N mm3 Volume (WM Parcellation) of LeftAmygdala
#'   \item ST130CV N mm3 Volume (Cortical Parcellation) of RightInsula
#'   \item ST130SA N mm2 Surface Area of RightInsula
#'   \item ST130TA N mm Cortical Thickness Average of RightInsula
#'   \item ST130TS N mm Cortical Thickness Standard Deviation of RightInsula
#'   \item ST13CV N mm3 Volume (Cortical Parcellation) of LeftBankssts
#'   \item ST13SA N mm2 Surface Area of LeftBankssts
#'   \item ST13TA N mm Cortical Thickness Average of LeftBankssts
#'   \item ST13TS N mm Cortical Thickness Standard Deviation of LeftBankssts
#'   \item ST14CV N mm3 Volume (Cortical Parcellation) of LeftCaudalAnteriorCingulate
#'   \item ST14SA N mm2 Surface Area of LeftCaudalAnteriorCingulate
#'   \item ST14TA N mm Cortical Thickness Average of LeftCaudalAnteriorCingulate
#'   \item ST14TS N mm Cortical Thickness Standard Deviation of LeftCaudalAnteriorCingulate
#'   \item ST15CV N mm3 Volume (Cortical Parcellation) of LeftCaudalMiddleFrontal
#'   \item ST15SA N mm2 Surface Area of LeftCaudalMiddleFrontal
#'   \item ST15TA N mm Cortical Thickness Average of LeftCaudalMiddleFrontal
#'   \item ST15TS N mm Cortical Thickness Standard Deviation of LeftCaudalMiddleFrontal
#'   \item ST16SV N mm3 Volume (WM Parcellation) of LeftCaudate
#'   \item ST17SV N mm3 Volume (WM Parcellation) of LeftCerebellumCortex
#'   \item ST18SV N mm3 Volume (WM Parcellation) of LeftCerebellumWM
#'   \item ST19SV N mm3 Volume (WM Parcellation) of LeftCerebralCortex
#'   \item ST1SV N mm3 Volume (WM Parcellation) of Brainstem
#'   \item ST20SV N mm3 Volume (WM Parcellation) of LeftCerebralWM
#'   \item ST21SV N mm3 Volume (WM Parcellation) of LeftChoroidPlexus
#'   \item ST22CV N mm3 Volume (Cortical Parcellation) of LeftCorpusCallosum
#'   \item ST22SA N mm2 Surface Area of LeftCorpusCallosum
#'   \item ST22TA N mm Cortical Thickness Average of LeftCorpusCallosum
#'   \item ST22TS N mm Cortical Thickness Standard Deviation of LeftCorpusCallosum
#'   \item ST23CV N mm3 Volume (Cortical Parcellation) of LeftCuneus
#'   \item ST23SA N mm2 Surface Area of LeftCuneus
#'   \item ST23TA N mm Cortical Thickness Average of LeftCuneus
#'   \item ST23TS N mm Cortical Thickness Standard Deviation of LeftCuneus
#'   \item ST24CV N mm3 Volume (Cortical Parcellation) of LeftEntorhinal
#'   \item ST24SA N mm2 Surface Area of LeftEntorhinal
#'   \item ST24TA N mm Cortical Thickness Average of LeftEntorhinal
#'   \item ST24TS N mm Cortical Thickness Standard Deviation of LeftEntorhinal
#'   \item ST25CV N mm3 Volume (Cortical Parcellation) of LeftFrontalPole
#'   \item ST25SA N mm2 Surface Area of LeftFrontalPole
#'   \item ST25TA N mm Cortical Thickness Average of LeftFrontalPole
#'   \item ST25TS N mm Cortical Thickness Standard Deviation of LeftFrontalPole
#'   \item ST26CV N mm3 Volume (Cortical Parcellation) of LeftFusiform
#'   \item ST26SA N mm2 Surface Area of LeftFusiform
#'   \item ST26TA N mm Cortical Thickness Average of LeftFusiform
#'   \item ST26TS N mm Cortical Thickness Standard Deviation of LeftFusiform
#'   \item ST27SA N mm2 Surface Area of LeftHemisphere
#'   \item ST28CV N mm3 Volume (Cortical Parcellation) of LeftHemisphereWM
#'   \item ST29SV N mm3 Volume (WM Parcellation) of LeftHippocampus
#'   \item ST2SV N mm3 Volume (WM Parcellation) of CorpusCallosumAnterior
#'   \item ST30SV N mm3 Volume (WM Parcellation) of LeftInferiorLateralVentricle
#'   \item ST31CV N mm3 Volume (Cortical Parcellation) of LeftInferiorParietal
#'   \item ST31SA N mm2 Surface Area of LeftInferiorParietal
#'   \item ST31TA N mm Cortical Thickness Average of LeftInferiorParietal
#'   \item ST31TS N mm Cortical Thickness Standard Deviation of LeftInferiorParietal
#'   \item ST32CV N mm3 Volume (Cortical Parcellation) of LeftInferiorTemporal
#'   \item ST32SA N mm2 Surface Area of LeftInferiorTemporal
#'   \item ST32TA N mm Cortical Thickness Average of LeftInferiorTemporal
#'   \item ST32TS N mm Cortical Thickness Standard Deviation of LeftInferiorTemporal
#'   \item ST33SV N mm3 Volume (WM Parcellation) of LeftInterior
#'   \item ST34CV N mm3 Volume (Cortical Parcellation) of LeftIsthmusCingulate
#'   \item ST34SA N mm2 Surface Area of LeftIsthmusCingulate
#'   \item ST34TA N mm Cortical Thickness Average of LeftIsthmusCingulate
#'   \item ST34TS N mm Cortical Thickness Standard Deviation of LeftIsthmusCingulate
#'   \item ST35CV N mm3 Volume (Cortical Parcellation) of LeftLateralOccipital
#'   \item ST35SA N mm2 Surface Area of LeftLateralOccipital
#'   \item ST35TA N mm Cortical Thickness Average of LeftLateralOccipital
#'   \item ST35TS N mm Cortical Thickness Standard Deviation of LeftLateralOccipital
#'   \item ST36CV N mm3 Volume (Cortical Parcellation) of LeftLateralOrbitofrontal
#'   \item ST36SA N mm2 Surface Area of LeftLateralOrbitofrontal
#'   \item ST36TA N mm Cortical Thickness Average of LeftLateralOrbitofrontal
#'   \item ST36TS N mm Cortical Thickness Standard Deviation of LeftLateralOrbitofrontal
#'   \item ST37SV N mm3 Volume (WM Parcellation) of LeftLateralVentricle
#'   \item ST38CV N mm3 Volume (Cortical Parcellation) of LeftLingual
#'   \item ST38SA N mm2 Surface Area of LeftLingual
#'   \item ST38TA N mm Cortical Thickness Average of LeftLingual
#'   \item ST38TS N mm Cortical Thickness Standard Deviation of LeftLingual
#'   \item ST39CV N mm3 Volume (Cortical Parcellation) of LeftMedialOrbitofrontal
#'   \item ST39SA N mm2 Surface Area of LeftMedialOrbitofrontal
#'   \item ST39TA N mm Cortical Thickness Average of LeftMedialOrbitofrontal
#'   \item ST39TS N mm Cortical Thickness Standard Deviation of LeftMedialOrbitofrontal
#'   \item ST3SV N mm3 Volume (WM Parcellation) of CorpusCallosumCentral
#'   \item ST40CV N mm3 Volume (Cortical Parcellation) of LeftMiddleTemporal
#'   \item ST40SA N mm2 Surface Area of LeftMiddleTemporal
#'   \item ST40TA N mm Cortical Thickness Average of LeftMiddleTemporal
#'   \item ST40TS N mm Cortical Thickness Standard Deviation of LeftMiddleTemporal
#'   \item ST41SV N mm3 Volume (WM Parcellation) of LeftNonWMHypoIntensities
#'   \item ST42SV N mm3 Volume (WM Parcellation) of LeftPallidum
#'   \item ST43CV N mm3 Volume (Cortical Parcellation) of LeftParacentral
#'   \item ST43SA N mm2 Surface Area of LeftParacentral
#'   \item ST43TA N mm Cortical Thickness Average of LeftParacentral
#'   \item ST43TS N mm Cortical Thickness Standard Deviation of LeftParacentral
#'   \item ST44CV N mm3 Volume (Cortical Parcellation) of LeftParahippocampal
#'   \item ST44SA N mm2 Surface Area of LeftParahippocampal
#'   \item ST44TA N mm Cortical Thickness Average of LeftParahippocampal
#'   \item ST44TS N mm Cortical Thickness Standard Deviation of LeftParahippocampal
#'   \item ST45CV N mm3 Volume (Cortical Parcellation) of LeftParsOpercularis
#'   \item ST45SA N mm2 Surface Area of LeftParsOpercularis
#'   \item ST45TA N mm Cortical Thickness Average of LeftParsOpercularis
#'   \item ST45TS N mm Cortical Thickness Standard Deviation of LeftParsOpercularis
#'   \item ST46CV N mm3 Volume (Cortical Parcellation) of LeftParsOrbitalis
#'   \item ST46SA N mm2 Surface Area of LeftParsOrbitalis
#'   \item ST46TA N mm Cortical Thickness Average of LeftParsOrbitalis
#'   \item ST46TS N mm Cortical Thickness Standard Deviation of LeftParsOrbitalis
#'   \item ST47CV N mm3 Volume (Cortical Parcellation) of LeftParsTriangularis
#'   \item ST47SA N mm2 Surface Area of LeftParsTriangularis
#'   \item ST47TA N mm Cortical Thickness Average of LeftParsTriangularis
#'   \item ST47TS N mm Cortical Thickness Standard Deviation of LeftParsTriangularis
#'   \item ST48CV N mm3 Volume (Cortical Parcellation) of LeftPericalcarine
#'   \item ST48SA N mm2 Surface Area of LeftPericalcarine
#'   \item ST48TA N mm Cortical Thickness Average of LeftPericalcarine
#'   \item ST48TS N mm Cortical Thickness Standard Deviation of LeftPericalcarine
#'   \item ST49CV N mm3 Volume (Cortical Parcellation) of LeftPostcentral
#'   \item ST49SA N mm2 Surface Area of LeftPostcentral
#'   \item ST49TA N mm Cortical Thickness Average of LeftPostcentral
#'   \item ST49TS N mm Cortical Thickness Standard Deviation of LeftPostcentral
#'   \item ST4SV N mm3 Volume (WM Parcellation) of CorpusCallosumMidAnterior
#'   \item ST50CV N mm3 Volume (Cortical Parcellation) of LeftPosteriorCingulate
#'   \item ST50SA N mm2 Surface Area of LeftPosteriorCingulate
#'   \item ST50TA N mm Cortical Thickness Average of LeftPosteriorCingulate
#'   \item ST50TS N mm Cortical Thickness Standard Deviation of LeftPosteriorCingulate
#'   \item ST51CV N mm3 Volume (Cortical Parcellation) of LeftPrecentral
#'   \item ST51SA N mm2 Surface Area of LeftPrecentral
#'   \item ST51TA N mm Cortical Thickness Average of LeftPrecentral
#'   \item ST51TS N mm Cortical Thickness Standard Deviation of LeftPrecentral
#'   \item ST52CV N mm3 Volume (Cortical Parcellation) of LeftPrecuneus
#'   \item ST52SA N mm2 Surface Area of LeftPrecuneus
#'   \item ST52TA N mm Cortical Thickness Average of LeftPrecuneus
#'   \item ST52TS N mm Cortical Thickness Standard Deviation of LeftPrecuneus
#'   \item ST53SV N mm3 Volume (WM Parcellation) of LeftPutamen
#'   \item ST54CV N mm3 Volume (Cortical Parcellation) of LeftRostralAnteriorCingulate
#'   \item ST54SA N mm2 Surface Area of LeftRostralAnteriorCingulate
#'   \item ST54TA N mm Cortical Thickness Average of LeftRostralAnteriorCingulate
#'   \item ST54TS N mm Cortical Thickness Standard Deviation of LeftRostralAnteriorCingulate
#'   \item ST55CV N mm3 Volume (Cortical Parcellation) of LeftRostralMiddleFrontal
#'   \item ST55SA N mm2 Surface Area of LeftRostralMiddleFrontal
#'   \item ST55TA N mm Cortical Thickness Average of LeftRostralMiddleFrontal
#'   \item ST55TS N mm Cortical Thickness Standard Deviation of LeftRostralMiddleFrontal
#'   \item ST56CV N mm3 Volume (Cortical Parcellation) of LeftSuperiorFrontal
#'   \item ST56SA N mm2 Surface Area of LeftSuperiorFrontal
#'   \item ST56TA N mm Cortical Thickness Average of LeftSuperiorFrontal
#'   \item ST56TS N mm Cortical Thickness Standard Deviation of LeftSuperiorFrontal
#'   \item ST57CV N mm3 Volume (Cortical Parcellation) of LeftSuperiorParietal
#'   \item ST57SA N mm2 Surface Area of LeftSuperiorParietal
#'   \item ST57TA N mm Cortical Thickness Average of LeftSuperiorParietal
#'   \item ST57TS N mm Cortical Thickness Standard Deviation of LeftSuperiorParietal
#'   \item ST58CV N mm3 Volume (Cortical Parcellation) of LeftSuperiorTemporal
#'   \item ST58SA N mm2 Surface Area of LeftSuperiorTemporal
#'   \item ST58TA N mm Cortical Thickness Average of LeftSuperiorTemporal
#'   \item ST58TS N mm Cortical Thickness Standard Deviation of LeftSuperiorTemporal
#'   \item ST59CV N mm3 Volume (Cortical Parcellation) of LeftSupramarginal
#'   \item ST59SA N mm2 Surface Area of LeftSupramarginal
#'   \item ST59TA N mm Cortical Thickness Average of LeftSupramarginal
#'   \item ST59TS N mm Cortical Thickness Standard Deviation of LeftSupramarginal
#'   \item ST5SV N mm3 Volume (WM Parcellation) of CorpusCallosumMidPosterior
#'   \item ST60CV N mm3 Volume (Cortical Parcellation) of LeftTemporalPole
#'   \item ST60SA N mm2 Surface Area of LeftTemporalPole
#'   \item ST60TA N mm Cortical Thickness Average of LeftTemporalPole
#'   \item ST60TS N mm Cortical Thickness Standard Deviation of LeftTemporalPole
#'   \item ST61SV N mm3 Volume (WM Parcellation) of LeftThalamus
#'   \item ST62CV N mm3 Volume (Cortical Parcellation) of LeftTransverseTemporal
#'   \item ST62SA N mm2 Surface Area of LeftTransverseTemporal
#'   \item ST62TA N mm Cortical Thickness Average of LeftTransverseTemporal
#'   \item ST62TS N mm Cortical Thickness Standard Deviation of LeftTransverseTemporal
#'   \item ST63SV N mm3 Volume (WM Parcellation) of LeftUndetermined
#'   \item ST64CV N mm3 Volume (Cortical Parcellation) of LeftUnknown
#'   \item ST64SA N mm2 Surface Area of LeftUnknown
#'   \item ST64TA N mm Cortical Thickness Average of LeftUnknown
#'   \item ST64TS N mm Cortical Thickness Standard Deviation of LeftUnknown
#'   \item ST65SV N mm3 Volume (WM Parcellation) of LeftVentralDC
#'   \item ST66SV N mm3 Volume (WM Parcellation) of LeftVessel
#'   \item ST67SV N mm3 Volume (WM Parcellation) of LeftWMHypoIntensities
#'   \item ST68SV N mm3 Volume (WM Parcellation) of NonWMHypoIntensities
#'   \item ST69SV N mm3 Volume (WM Parcellation) of OpticChiasm
#'   \item ST6SV N mm3 Volume (WM Parcellation) of CorpusCallosumPosterior
#'   \item ST70SV N mm3 Volume (WM Parcellation) of RightAccumbensArea
#'   \item ST71SV N mm3 Volume (WM Parcellation) of RightAmygdala
#'   \item ST72CV N mm3 Volume (Cortical Parcellation) of RightBankssts
#'   \item ST72SA N mm2 Surface Area of RightBankssts
#'   \item ST72TA N mm Cortical Thickness Average of RightBankssts
#'   \item ST72TS N mm Cortical Thickness Standard Deviation of RightBankssts
#'   \item ST73CV N mm3 Volume (Cortical Parcellation) of RightCaudalAnteriorCingulate
#'   \item ST73SA N mm2 Surface Area of RightCaudalAnteriorCingulate
#'   \item ST73TA N mm Cortical Thickness Average of RightCaudalAnteriorCingulate
#'   \item ST73TS N mm Cortical Thickness Standard Deviation of RightCaudalAnteriorCingulate
#'   \item ST74CV N mm3 Volume (Cortical Parcellation) of RightCaudalMiddleFrontal
#'   \item ST74SA N mm2 Surface Area of RightCaudalMiddleFrontal
#'   \item ST74TA N mm Cortical Thickness Average of RightCaudalMiddleFrontal
#'   \item ST74TS N mm Cortical Thickness Standard Deviation of RightCaudalMiddleFrontal
#'   \item ST75SV N mm3 Volume (WM Parcellation) of RightCaudate
#'   \item ST76SV N mm3 Volume (WM Parcellation) of RightCerebellumCortex
#'   \item ST77SV N mm3 Volume (WM Parcellation) of RightCerebellumWM
#'   \item ST78SV N mm3 Volume (WM Parcellation) of RightCerebralCortex
#'   \item ST79SV N mm3 Volume (WM Parcellation) of RightCerebralWM
#'   \item ST7SV N mm3 Volume (WM Parcellation) of Csf
#'   \item ST80SV N mm3 Volume (WM Parcellation) of RightChoroidPlexus
#'   \item ST81CV N mm3 Volume (Cortical Parcellation) of RightCorpusCallosum
#'   \item ST81SA N mm2 Surface Area of RightCorpusCallosum
#'   \item ST81TA N mm Cortical Thickness Average of RightCorpusCallosum
#'   \item ST81TS N mm Cortical Thickness Standard Deviation of RightCorpusCallosum
#'   \item ST82CV N mm3 Volume (Cortical Parcellation) of RightCuneus
#'   \item ST82SA N mm2 Surface Area of RightCuneus
#'   \item ST82TA N mm Cortical Thickness Average of RightCuneus
#'   \item ST82TS N mm Cortical Thickness Standard Deviation of RightCuneus
#'   \item ST83CV N mm3 Volume (Cortical Parcellation) of RightEntorhinal
#'   \item ST83SA N mm2 Surface Area of RightEntorhinal
#'   \item ST83TA N mm Cortical Thickness Average of RightEntorhinal
#'   \item ST83TS N mm Cortical Thickness Standard Deviation of RightEntorhinal
#'   \item ST84CV N mm3 Volume (Cortical Parcellation) of RightFrontalPole
#'   \item ST84SA N mm2 Surface Area of RightFrontalPole
#'   \item ST84TA N mm Cortical Thickness Average of RightFrontalPole
#'   \item ST84TS N mm Cortical Thickness Standard Deviation of RightFrontalPole
#'   \item ST85CV N mm3 Volume (Cortical Parcellation) of RightFusiform
#'   \item ST85SA N mm2 Surface Area of RightFusiform
#'   \item ST85TA N mm Cortical Thickness Average of RightFusiform
#'   \item ST85TS N mm Cortical Thickness Standard Deviation of RightFusiform
#'   \item ST86SA N mm2 Surface Area of RightHemisphere
#'   \item ST87CV N mm3 Volume (Cortical Parcellation) of RightHemisphereWM
#'   \item ST88SV N mm3 Volume (WM Parcellation) of RightHippocampus
#'   \item ST89SV N mm3 Volume (WM Parcellation) of RightInferiorLateralVentricle
#'   \item ST8SV N mm3 Volume (WM Parcellation) of FifthVentricle
#'   \item ST90CV N mm3 Volume (Cortical Parcellation) of RightInferiorParietal
#'   \item ST90SA N mm2 Surface Area of RightInferiorParietal
#'   \item ST90TA N mm Cortical Thickness Average of RightInferiorParietal
#'   \item ST90TS N mm Cortical Thickness Standard Deviation of RightInferiorParietal
#'   \item ST91CV N mm3 Volume (Cortical Parcellation) of RightInferiorTemporal
#'   \item ST91SA N mm2 Surface Area of RightInferiorTemporal
#'   \item ST91TA N mm Cortical Thickness Average of RightInferiorTemporal
#'   \item ST91TS N mm Cortical Thickness Standard Deviation of RightInferiorTemporal
#'   \item ST92SV N mm3 Volume (WM Parcellation) of RightInterior
#'   \item ST93CV N mm3 Volume (Cortical Parcellation) of RightIsthmusCingulate
#'   \item ST93SA N mm2 Surface Area of RightIsthmusCingulate
#'   \item ST93TA N mm Cortical Thickness Average of RightIsthmusCingulate
#'   \item ST93TS N mm Cortical Thickness Standard Deviation of RightIsthmusCingulate
#'   \item ST94CV N mm3 Volume (Cortical Parcellation) of RightLateralOccipital
#'   \item ST94SA N mm2 Surface Area of RightLateralOccipital
#'   \item ST94TA N mm Cortical Thickness Average of RightLateralOccipital
#'   \item ST94TS N mm Cortical Thickness Standard Deviation of RightLateralOccipital
#'   \item ST95CV N mm3 Volume (Cortical Parcellation) of RightLateralOrbitofrontal
#'   \item ST95SA N mm2 Surface Area of RightLateralOrbitofrontal
#'   \item ST95TA N mm Cortical Thickness Average of RightLateralOrbitofrontal
#'   \item ST95TS N mm Cortical Thickness Standard Deviation of RightLateralOrbitofrontal
#'   \item ST96SV N mm3 Volume (WM Parcellation) of RightLateralVentricle
#'   \item ST97CV N mm3 Volume (Cortical Parcellation) of RightLingual
#'   \item ST97SA N mm2 Surface Area of RightLingual
#'   \item ST97TA N mm Cortical Thickness Average of RightLingual
#'   \item ST97TS N mm Cortical Thickness Standard Deviation of RightLingual
#'   \item ST98CV N mm3 Volume (Cortical Parcellation) of RightMedialOrbitofrontal
#'   \item ST98SA N mm2 Surface Area of RightMedialOrbitofrontal
#'   \item ST98TA N mm Cortical Thickness Average of RightMedialOrbitofrontal
#'   \item ST98TS N mm Cortical Thickness Standard Deviation of RightMedialOrbitofrontal
#'   \item ST99CV N mm3 Volume (Cortical Parcellation) of RightMiddleTemporal
#'   \item ST99SA N mm2 Surface Area of RightMiddleTemporal
#'   \item ST99TA N mm Cortical Thickness Average of RightMiddleTemporal
#'   \item ST99TS N mm Cortical Thickness Standard Deviation of RightMiddleTemporal
#'   \item ST9SV N mm3 Volume (WM Parcellation) of FourthVentricle
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name ucsffsl
#' @usage data(ucsffsl)
#' @format A data frame with 3572 rows and 374 variables
NULL

#' ADNI-1 3T Cross-Sectional FreeSurfer (5.1)
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/UCSFFSX51_ADNI1_3T/UCSF%20FreeSurfer%20Methods%20and%20QC_OFFICIAL.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item EXAMDATE D  Examination Date
#'   \item VERSION D  
#'   \item LONISID T  The LONI study UID for the image processed
#'   \item LONIUID T  The LONI series UID for the image processed.
#'   \item IMAGEUID T  The ImageUID for the image processed.
#'   \item RUNDATE D  
#'   \item STATUS T  
#'   \item OVERALLQC T  An overall quality rating. Refer to additional QC variables for Partial rating.
#'   \item TEMPQC T  QC rating of temporal lobe. Fail affects the following regions: LeftTemporalPole (ST60); RightTemporalPole (ST119); LeftFusiform (ST26); RightFusiform (ST85); LeftSuperiorTemporal (ST58); RightSuperiorTemporal (ST117); LeftInferiorTemporal (ST32); RightInferiorTemporal (ST91); LeftMiddleTemporal (ST40); RightMiddleTemporal (ST99)
#'   \item FRONTQC T  QC rating of the frontal lobe. Fail affects the following regions: LeftFrontalPole (ST25); RightFrontalPole (ST84); LeftPrecentral (ST51); RightPrecentral (ST110); LeftSuperiorFrontal (ST56); RightSuperiorFrontal (ST115); LeftCaudalMiddleFrontal (ST15); RightCaudalMiddleFrontal (ST74); LeftRostralMiddleFrontal (ST55); RightRostralMiddleFrontal (ST114); LeftMedialOrbitofrontal (ST39); RightMedialOrbitofrontal (ST98)
#'   \item PARQC T  QC rating of the parietal lobe. Fail affects the following regions: LeftPostcentral (ST49); RightPostcentral (ST108); LeftSuperiorParietal (ST57); RightSuperiorParietal (ST116); LeftSupraMarginal (ST59); RightSupraMarginal (ST118); LeftParacentral (ST43); RightParacentral (ST102); LeftInferiorParietal (ST31); RightInferiorParietal (ST90)
#'   \item INSULAQC T  QC rating of the insula. Fail affects the following regions: LeftInsula (ST129); RightInsula (ST130)
#'   \item OCCQC T  QC rating of the occipital lobe. Fail affects the following regions: LeftLingual (ST38); RightLingual (ST97); LeftLateralOccipital (ST35); RightLateralOccipital (ST94); LeftPericalcarine (ST48); RightPericalcarine (ST107); LeftCuneus (ST23); RightCuneus (ST82)
#'   \item BGQC T  QC rating of the basal ganglia. Fail affects the following regions: LeftPutamen (ST53); RightPutamen (ST112); LeftCaudate (ST16); RightCaudate (ST75); LeftPallidum (ST42); RightPallidum (ST101)
#'   \item CWMQC T  QC rating of the cerebral WM. Fail affects the following regions: LeftCerebralWM (ST20); RightCerebralWM (ST79); LeftCorticalWM (ST150); RightCorticalWM (ST151); CorticalWM (ST152); LeftHemisphereWM (ST28); RightHemisphereWM (ST87)
#'   \item VENTQC T  QC rating of the ventricles. Fail affects the following regions: LeftLateralVentricle (ST37); RightLateralVentricle (ST96); LeftInferiorLateralVentricle (ST30); RightInferiorLateralVentricle (ST89); ThirdVentricle (ST127); FourthVentricle (ST9); FifthVentrical (ST8); LeftChoroidPlexus (ST21); RightChoroidPlexus (ST80)
#'   \item LHIPQC T  QC rating of the left hippocampal subfields. Fail affects the following regions: Left CA1 (ST131HS); Left CA2-3 (ST132HS); Left CA4-DG (ST133HS); Left Fimbria (ST134HS); Left Hippocampal Fissure (ST135HS); Left Presubiculum (ST136HS); Left Subiculum (ST137HS); Left Tail (ST138HS) 
#'   \item RHIPQC T  QC rating of the right hippocampal subfields. Fail affects the following regions: Right CA1 (ST139HS); Right CA2-3 (ST140HS); Right CA4-DG (ST141HS); Right Fimbria (ST142HS); Right Hippocampal Fissure (ST143HS); Right Presubiculum (ST144HS); Right Subiculum (ST145HS); Right Tail (ST146HS) 
#'   \item ST100SV N mm3 Volume (aseg.stat) of RightNonWMHypoIntensities
#'   \item ST101SV N mm3 Volume (aseg.stat) of RightPallidum
#'   \item ST102CV N mm3 Volume (aparc.stat) of RightParacentral
#'   \item ST102SA N mm2 Surface Area of RightParacentral
#'   \item ST102TA N mm Cortical Thickness Average of RightParacentral
#'   \item ST102TS N mm Cortical Thickness Standard Deviation of RightParacentral
#'   \item ST103CV N mm3 Volume (aparc.stat) of RightParahippocampal
#'   \item ST103SA N mm2 Surface Area of RightParahippocampal
#'   \item ST103TA N mm Cortical Thickness Average of RightParahippocampal
#'   \item ST103TS N mm Cortical Thickness Standard Deviation of RightParahippocampal
#'   \item ST104CV N mm3 Volume (aparc.stat) of RightParsOpercularis
#'   \item ST104SA N mm2 Surface Area of RightParsOpercularis
#'   \item ST104TA N mm Cortical Thickness Average of RightParsOpercularis
#'   \item ST104TS N mm Cortical Thickness Standard Deviation of RightParsOpercularis
#'   \item ST105CV N mm3 Volume (aparc.stat) of RightParsOrbitalis
#'   \item ST105SA N mm2 Surface Area of RightParsOrbitalis
#'   \item ST105TA N mm Cortical Thickness Average of RightParsOrbitalis
#'   \item ST105TS N mm Cortical Thickness Standard Deviation of RightParsOrbitalis
#'   \item ST106CV N mm3 Volume (aparc.stat) of RightParsTriangularis
#'   \item ST106SA N mm2 Surface Area of RightParsTriangularis
#'   \item ST106TA N mm Cortical Thickness Average of RightParsTriangularis
#'   \item ST106TS N mm Cortical Thickness Standard Deviation of RightParsTriangularis
#'   \item ST107CV N mm3 Volume (aparc.stat) of RightPericalcarine
#'   \item ST107SA N mm2 Surface Area of RightPericalcarine
#'   \item ST107TA N mm Cortical Thickness Average of RightPericalcarine
#'   \item ST107TS N mm Cortical Thickness Standard Deviation of RightPericalcarine
#'   \item ST108CV N mm3 Volume (aparc.stat) of RightPostcentral
#'   \item ST108SA N mm2 Surface Area of RightPostcentral
#'   \item ST108TA N mm Cortical Thickness Average of RightPostcentral
#'   \item ST108TS N mm Cortical Thickness Standard Deviation of RightPostcentral
#'   \item ST109CV N mm3 Volume (aparc.stat) of RightPosteriorCingulate
#'   \item ST109SA N mm2 Surface Area of RightPosteriorCingulate
#'   \item ST109TA N mm Cortical Thickness Average of RightPosteriorCingulate
#'   \item ST109TS N mm Cortical Thickness Standard Deviation of RightPosteriorCingulate
#'   \item ST10CV N mm3 Volume (aparc.stat) of Icv
#'   \item ST110CV N mm3 Volume (aparc.stat) of RightPrecentral
#'   \item ST110SA N mm2 Surface Area of RightPrecentral
#'   \item ST110TA N mm Cortical Thickness Average of RightPrecentral
#'   \item ST110TS N mm Cortical Thickness Standard Deviation of RightPrecentral
#'   \item ST111CV N mm3 Volume (aparc.stat) of RightPrecuneus
#'   \item ST111SA N mm2 Surface Area of RightPrecuneus
#'   \item ST111TA N mm Cortical Thickness Average of RightPrecuneus
#'   \item ST111TS N mm Cortical Thickness Standard Deviation of RightPrecuneus
#'   \item ST112SV N mm3 Volume (aseg.stat) of RightPutamen
#'   \item ST113CV N mm3 Volume (aparc.stat) of RightRostralAnteriorCingulate
#'   \item ST113SA N mm2 Surface Area of RightRostralAnteriorCingulate
#'   \item ST113TA N mm Cortical Thickness Average of RightRostralAnteriorCingulate
#'   \item ST113TS N mm Cortical Thickness Standard Deviation of RightRostralAnteriorCingulate
#'   \item ST114CV N mm3 Volume (aparc.stat) of RightRostralMiddleFrontal
#'   \item ST114SA N mm2 Surface Area of RightRostralMiddleFrontal
#'   \item ST114TA N mm Cortical Thickness Average of RightRostralMiddleFrontal
#'   \item ST114TS N mm Cortical Thickness Standard Deviation of RightRostralMiddleFrontal
#'   \item ST115CV N mm3 Volume (aparc.stat) of RightSuperiorFrontal
#'   \item ST115SA N mm2 Surface Area of RightSuperiorFrontal
#'   \item ST115TA N mm Cortical Thickness Average of RightSuperiorFrontal
#'   \item ST115TS N mm Cortical Thickness Standard Deviation of RightSuperiorFrontal
#'   \item ST116CV N mm3 Volume (aparc.stat) of RightSuperiorParietal
#'   \item ST116SA N mm2 Surface Area of RightSuperiorParietal
#'   \item ST116TA N mm Cortical Thickness Average of RightSuperiorParietal
#'   \item ST116TS N mm Cortical Thickness Standard Deviation of RightSuperiorParietal
#'   \item ST117CV N mm3 Volume (aparc.stat) of RightSuperiorTemporal
#'   \item ST117SA N mm2 Surface Area of RightSuperiorTemporal
#'   \item ST117TA N mm Cortical Thickness Average of RightSuperiorTemporal
#'   \item ST117TS N mm Cortical Thickness Standard Deviation of RightSuperiorTemporal
#'   \item ST118CV N mm3 Volume (aparc.stat) of RightSupramarginal
#'   \item ST118SA N mm2 Surface Area of RightSupramarginal
#'   \item ST118TA N mm Cortical Thickness Average of RightSupramarginal
#'   \item ST118TS N mm Cortical Thickness Standard Deviation of RightSupramarginal
#'   \item ST119CV N mm3 Volume (aparc.stat) of RightTemporalPole
#'   \item ST119SA N mm2 Surface Area of RightTemporalPole
#'   \item ST119TA N mm Cortical Thickness Average of RightTemporalPole
#'   \item ST119TS N mm Cortical Thickness Standard Deviation of RightTemporalPole
#'   \item ST11SV N mm3 Volume (aseg.stat) of LeftAccumbensArea
#'   \item ST120SV N mm3 Volume (aseg.stat) of RightThalamus
#'   \item ST121CV N mm3 Volume (aparc.stat) of RightTransverseTemporal
#'   \item ST121SA N mm2 Surface Area of RightTransverseTemporal
#'   \item ST121TA N mm Cortical Thickness Average of RightTransverseTemporal
#'   \item ST121TS N mm Cortical Thickness Standard Deviation of RightTransverseTemporal
#'   \item ST122SV N mm3 Volume (aseg.stat) of RightUndetermined
#'   \item ST123CV N mm3 Volume (aparc.stat) of RightUnknown
#'   \item ST123SA N mm2 Surface Area of RightUnknown
#'   \item ST123TA N mm Cortical Thickness Average of RightUnknown
#'   \item ST123TS N mm Cortical Thickness Standard Deviation of RightUnknown
#'   \item ST124SV N mm3 Volume (aseg.stat) of RightVentralDC
#'   \item ST125SV N mm3 Volume (aseg.stat) of RightVessel
#'   \item ST126SV N mm3 Volume (aseg.stat) of RightWMHypoIntensities
#'   \item ST127SV N mm3 Volume (aseg.stat) of ThirdVentricle
#'   \item ST128SV N mm3 Volume (aseg.stat) of WMHypoIntensities
#'   \item ST129CV N mm3 Volume (aparc.stat) of LeftInsula
#'   \item ST129SA N mm2 Surface Area of LeftInsula
#'   \item ST129TA N mm Cortical Thickness Average of LeftInsula
#'   \item ST129TS N mm Cortical Thickness Standard Deviation of LeftInsula
#'   \item ST12SV N mm3 Volume (aseg.stat) of LeftAmygdala
#'   \item ST130CV N mm3 Volume (aparc.stat) of RightInsula
#'   \item ST130SA N mm2 Surface Area of RightInsula
#'   \item ST130TA N mm Cortical Thickness Average of RightInsula
#'   \item ST130TS N mm Cortical Thickness Standard Deviation of RightInsula
#'   \item ST13CV N mm3 Volume (aparc.stat) of LeftBankssts
#'   \item ST13SA N mm2 Surface Area of LeftBankssts
#'   \item ST13TA N mm Cortical Thickness Average of LeftBankssts
#'   \item ST13TS N mm Cortical Thickness Standard Deviation of LeftBankssts
#'   \item ST14CV N mm3 Volume (aparc.stat) of LeftCaudalAnteriorCingulate
#'   \item ST14SA N mm2 Surface Area of LeftCaudalAnteriorCingulate
#'   \item ST14TA N mm Cortical Thickness Average of LeftCaudalAnteriorCingulate
#'   \item ST14TS N mm Cortical Thickness Standard Deviation of LeftCaudalAnteriorCingulate
#'   \item ST15CV N mm3 Volume (aparc.stat) of LeftCaudalMiddleFrontal
#'   \item ST15SA N mm2 Surface Area of LeftCaudalMiddleFrontal
#'   \item ST15TA N mm Cortical Thickness Average of LeftCaudalMiddleFrontal
#'   \item ST15TS N mm Cortical Thickness Standard Deviation of LeftCaudalMiddleFrontal
#'   \item ST16SV N mm3 Volume (aseg.stat) of LeftCaudate
#'   \item ST17SV N mm3 Volume (aseg.stat) of LeftCerebellumCortex
#'   \item ST18SV N mm3 Volume (aseg.stat) of LeftCerebellumWM
#'   \item ST19SV N mm3 Volume (aseg.stat) of LeftCerebralCortex
#'   \item ST1SV N mm3 Volume (aseg.stat) of Brainstem
#'   \item ST20SV N mm3 Volume (aseg.stat) of LeftCerebralWM
#'   \item ST21SV N mm3 Volume (aseg.stat) of LeftChoroidPlexus
#'   \item ST22CV N mm3 Volume (aparc.stat) of LeftCorpusCallosum
#'   \item ST22SA N mm2 Surface Area of LeftCorpusCallosum
#'   \item ST22TA N mm Cortical Thickness Average of LeftCorpusCallosum
#'   \item ST22TS N mm Cortical Thickness Standard Deviation of LeftCorpusCallosum
#'   \item ST23CV N mm3 Volume (aparc.stat) of LeftCuneus
#'   \item ST23SA N mm2 Surface Area of LeftCuneus
#'   \item ST23TA N mm Cortical Thickness Average of LeftCuneus
#'   \item ST23TS N mm Cortical Thickness Standard Deviation of LeftCuneus
#'   \item ST24CV N mm3 Volume (aparc.stat) of LeftEntorhinal
#'   \item ST24SA N mm2 Surface Area of LeftEntorhinal
#'   \item ST24TA N mm Cortical Thickness Average of LeftEntorhinal
#'   \item ST24TS N mm Cortical Thickness Standard Deviation of LeftEntorhinal
#'   \item ST25CV N mm3 Volume (aparc.stat) of LeftFrontalPole
#'   \item ST25SA N mm2 Surface Area of LeftFrontalPole
#'   \item ST25TA N mm Cortical Thickness Average of LeftFrontalPole
#'   \item ST25TS N mm Cortical Thickness Standard Deviation of LeftFrontalPole
#'   \item ST26CV N mm3 Volume (aparc.stat) of LeftFusiform
#'   \item ST26SA N mm2 Surface Area of LeftFusiform
#'   \item ST26TA N mm Cortical Thickness Average of LeftFusiform
#'   \item ST26TS N mm Cortical Thickness Standard Deviation of LeftFusiform
#'   \item ST27SA N mm2 Surface Area of LeftHemisphere
#'   \item ST28CV N mm3 Volume (aparc.stat) of LeftHemisphereWM
#'   \item ST28SA N mm2 Surface Area of LeftHemisphereWM
#'   \item ST29SV N mm3 Volume (aseg.stat) of LeftHippocampus
#'   \item ST2SV N mm3 Volume (aseg.stat) of CorpusCallosumAnterior
#'   \item ST30SV N mm3 Volume (aseg.stat) of LeftInferiorLateralVentricle
#'   \item ST31CV N mm3 Volume (aparc.stat) of LeftInferiorParietal
#'   \item ST31SA N mm2 Surface Area of LeftInferiorParietal
#'   \item ST31TA N mm Cortical Thickness Average of LeftInferiorParietal
#'   \item ST31TS N mm Cortical Thickness Standard Deviation of LeftInferiorParietal
#'   \item ST32CV N mm3 Volume (aparc.stat) of LeftInferiorTemporal
#'   \item ST32SA N mm2 Surface Area of LeftInferiorTemporal
#'   \item ST32TA N mm Cortical Thickness Average of LeftInferiorTemporal
#'   \item ST32TS N mm Cortical Thickness Standard Deviation of LeftInferiorTemporal
#'   \item ST33SV N mm3 Volume (aseg.stat) of LeftInterior
#'   \item ST34CV N mm3 Volume (aparc.stat) of LeftIsthmusCingulate
#'   \item ST34SA N mm2 Surface Area of LeftIsthmusCingulate
#'   \item ST34TA N mm Cortical Thickness Average of LeftIsthmusCingulate
#'   \item ST34TS N mm Cortical Thickness Standard Deviation of LeftIsthmusCingulate
#'   \item ST35CV N mm3 Volume (aparc.stat) of LeftLateralOccipital
#'   \item ST35SA N mm2 Surface Area of LeftLateralOccipital
#'   \item ST35TA N mm Cortical Thickness Average of LeftLateralOccipital
#'   \item ST35TS N mm Cortical Thickness Standard Deviation of LeftLateralOccipital
#'   \item ST36CV N mm3 Volume (aparc.stat) of LeftLateralOrbitofrontal
#'   \item ST36SA N mm2 Surface Area of LeftLateralOrbitofrontal
#'   \item ST36TA N mm Cortical Thickness Average of LeftLateralOrbitofrontal
#'   \item ST36TS N mm Cortical Thickness Standard Deviation of LeftLateralOrbitofrontal
#'   \item ST37SV N mm3 Volume (aseg.stat) of LeftLateralVentricle
#'   \item ST38CV N mm3 Volume (aparc.stat) of LeftLingual
#'   \item ST38SA N mm2 Surface Area of LeftLingual
#'   \item ST38TA N mm Cortical Thickness Average of LeftLingual
#'   \item ST38TS N mm Cortical Thickness Standard Deviation of LeftLingual
#'   \item ST39CV N mm3 Volume (aparc.stat) of LeftMedialOrbitofrontal
#'   \item ST39SA N mm2 Surface Area of LeftMedialOrbitofrontal
#'   \item ST39TA N mm Cortical Thickness Average of LeftMedialOrbitofrontal
#'   \item ST39TS N mm Cortical Thickness Standard Deviation of LeftMedialOrbitofrontal
#'   \item ST3SV N mm3 Volume (aseg.stat) of CorpusCallosumCentral
#'   \item ST40CV N mm3 Volume (aparc.stat) of LeftMiddleTemporal
#'   \item ST40SA N mm2 Surface Area of LeftMiddleTemporal
#'   \item ST40TA N mm Cortical Thickness Average of LeftMiddleTemporal
#'   \item ST40TS N mm Cortical Thickness Standard Deviation of LeftMiddleTemporal
#'   \item ST41SV N mm3 Volume (aseg.stat) of LeftNonWMHypoIntensities
#'   \item ST42SV N mm3 Volume (aseg.stat) of LeftPallidum
#'   \item ST43CV N mm3 Volume (aparc.stat) of LeftParacentral
#'   \item ST43SA N mm2 Surface Area of LeftParacentral
#'   \item ST43TA N mm Cortical Thickness Average of LeftParacentral
#'   \item ST43TS N mm Cortical Thickness Standard Deviation of LeftParacentral
#'   \item ST44CV N mm3 Volume (aparc.stat) of LeftParahippocampal
#'   \item ST44SA N mm2 Surface Area of LeftParahippocampal
#'   \item ST44TA N mm Cortical Thickness Average of LeftParahippocampal
#'   \item ST44TS N mm Cortical Thickness Standard Deviation of LeftParahippocampal
#'   \item ST45CV N mm3 Volume (aparc.stat) of LeftParsOpercularis
#'   \item ST45SA N mm2 Surface Area of LeftParsOpercularis
#'   \item ST45TA N mm Cortical Thickness Average of LeftParsOpercularis
#'   \item ST45TS N mm Cortical Thickness Standard Deviation of LeftParsOpercularis
#'   \item ST46CV N mm3 Volume (aparc.stat) of LeftParsOrbitalis
#'   \item ST46SA N mm2 Surface Area of LeftParsOrbitalis
#'   \item ST46TA N mm Cortical Thickness Average of LeftParsOrbitalis
#'   \item ST46TS N mm Cortical Thickness Standard Deviation of LeftParsOrbitalis
#'   \item ST47CV N mm3 Volume (aparc.stat) of LeftParsTriangularis
#'   \item ST47SA N mm2 Surface Area of LeftParsTriangularis
#'   \item ST47TA N mm Cortical Thickness Average of LeftParsTriangularis
#'   \item ST47TS N mm Cortical Thickness Standard Deviation of LeftParsTriangularis
#'   \item ST48CV N mm3 Volume (aparc.stat) of LeftPericalcarine
#'   \item ST48SA N mm2 Surface Area of LeftPericalcarine
#'   \item ST48TA N mm Cortical Thickness Average of LeftPericalcarine
#'   \item ST48TS N mm Cortical Thickness Standard Deviation of LeftPericalcarine
#'   \item ST49CV N mm3 Volume (aparc.stat) of LeftPostcentral
#'   \item ST49SA N mm2 Surface Area of LeftPostcentral
#'   \item ST49TA N mm Cortical Thickness Average of LeftPostcentral
#'   \item ST49TS N mm Cortical Thickness Standard Deviation of LeftPostcentral
#'   \item ST4SV N mm3 Volume (aseg.stat) of CorpusCallosumMidAnterior
#'   \item ST50CV N mm3 Volume (aparc.stat) of LeftPosteriorCingulate
#'   \item ST50SA N mm2 Surface Area of LeftPosteriorCingulate
#'   \item ST50TA N mm Cortical Thickness Average of LeftPosteriorCingulate
#'   \item ST50TS N mm Cortical Thickness Standard Deviation of LeftPosteriorCingulate
#'   \item ST51CV N mm3 Volume (aparc.stat) of LeftPrecentral
#'   \item ST51SA N mm2 Surface Area of LeftPrecentral
#'   \item ST51TA N mm Cortical Thickness Average of LeftPrecentral
#'   \item ST51TS N mm Cortical Thickness Standard Deviation of LeftPrecentral
#'   \item ST52CV N mm3 Volume (aparc.stat) of LeftPrecuneus
#'   \item ST52SA N mm2 Surface Area of LeftPrecuneus
#'   \item ST52TA N mm Cortical Thickness Average of LeftPrecuneus
#'   \item ST52TS N mm Cortical Thickness Standard Deviation of LeftPrecuneus
#'   \item ST53SV N mm3 Volume (aseg.stat) of LeftPutamen
#'   \item ST54CV N mm3 Volume (aparc.stat) of LeftRostralAnteriorCingulate
#'   \item ST54SA N mm2 Surface Area of LeftRostralAnteriorCingulate
#'   \item ST54TA N mm Cortical Thickness Average of LeftRostralAnteriorCingulate
#'   \item ST54TS N mm Cortical Thickness Standard Deviation of LeftRostralAnteriorCingulate
#'   \item ST55CV N mm3 Volume (aparc.stat) of LeftRostralMiddleFrontal
#'   \item ST55SA N mm2 Surface Area of LeftRostralMiddleFrontal
#'   \item ST55TA N mm Cortical Thickness Average of LeftRostralMiddleFrontal
#'   \item ST55TS N mm Cortical Thickness Standard Deviation of LeftRostralMiddleFrontal
#'   \item ST56CV N mm3 Volume (aparc.stat) of LeftSuperiorFrontal
#'   \item ST56SA N mm2 Surface Area of LeftSuperiorFrontal
#'   \item ST56TA N mm Cortical Thickness Average of LeftSuperiorFrontal
#'   \item ST56TS N mm Cortical Thickness Standard Deviation of LeftSuperiorFrontal
#'   \item ST57CV N mm3 Volume (aparc.stat) of LeftSuperiorParietal
#'   \item ST57SA N mm2 Surface Area of LeftSuperiorParietal
#'   \item ST57TA N mm Cortical Thickness Average of LeftSuperiorParietal
#'   \item ST57TS N mm Cortical Thickness Standard Deviation of LeftSuperiorParietal
#'   \item ST58CV N mm3 Volume (aparc.stat) of LeftSuperiorTemporal
#'   \item ST58SA N mm2 Surface Area of LeftSuperiorTemporal
#'   \item ST58TA N mm Cortical Thickness Average of LeftSuperiorTemporal
#'   \item ST58TS N mm Cortical Thickness Standard Deviation of LeftSuperiorTemporal
#'   \item ST59CV N mm3 Volume (aparc.stat) of LeftSupramarginal
#'   \item ST59SA N mm2 Surface Area of LeftSupramarginal
#'   \item ST59TA N mm Cortical Thickness Average of LeftSupramarginal
#'   \item ST59TS N mm Cortical Thickness Standard Deviation of LeftSupramarginal
#'   \item ST5SV N mm3 Volume (aseg.stat) of CorpusCallosumMidPosterior
#'   \item ST60CV N mm3 Volume (aparc.stat) of LeftTemporalPole
#'   \item ST60SA N mm2 Surface Area of LeftTemporalPole
#'   \item ST60TA N mm Cortical Thickness Average of LeftTemporalPole
#'   \item ST60TS N mm Cortical Thickness Standard Deviation of LeftTemporalPole
#'   \item ST61SV N mm3 Volume (aseg.stat) of LeftThalamus
#'   \item ST62CV N mm3 Volume (aparc.stat) of LeftTransverseTemporal
#'   \item ST62SA N mm2 Surface Area of LeftTransverseTemporal
#'   \item ST62TA N mm Cortical Thickness Average of LeftTransverseTemporal
#'   \item ST62TS N mm Cortical Thickness Standard Deviation of LeftTransverseTemporal
#'   \item ST63SV N mm3 Volume (aseg.stat) of LeftUndetermined
#'   \item ST64CV N mm3 Volume (aparc.stat) of LeftUnknown
#'   \item ST64SA N mm2 Surface Area of LeftUnknown
#'   \item ST64TA N mm Cortical Thickness Average of LeftUnknown
#'   \item ST64TS N mm Cortical Thickness Standard Deviation of LeftUnknown
#'   \item ST65SV N mm3 Volume (aseg.stat) of LeftVentralDC
#'   \item ST66SV N mm3 Volume (aseg.stat) of LeftVessel
#'   \item ST67SV N mm3 Volume (aseg.stat) of LeftWMHypoIntensities
#'   \item ST68SV N mm3 Volume (aseg.stat) of NonWMHypoIntensities
#'   \item ST69SV N mm3 Volume (aseg.stat) of OpticChiasm
#'   \item ST6SV N mm3 Volume (aseg.stat) of CorpusCallosumPosterior
#'   \item ST70SV N mm3 Volume (aseg.stat) of RightAccumbensArea
#'   \item ST71SV N mm3 Volume (aseg.stat) of RightAmygdala
#'   \item ST72CV N mm3 Volume (aparc.stat) of RightBankssts
#'   \item ST72SA N mm2 Surface Area of RightBankssts
#'   \item ST72TA N mm Cortical Thickness Average of RightBankssts
#'   \item ST72TS N mm Cortical Thickness Standard Deviation of RightBankssts
#'   \item ST73CV N mm3 Volume (aparc.stat) of RightCaudalAnteriorCingulate
#'   \item ST73SA N mm2 Surface Area of RightCaudalAnteriorCingulate
#'   \item ST73TA N mm Cortical Thickness Average of RightCaudalAnteriorCingulate
#'   \item ST73TS N mm Cortical Thickness Standard Deviation of RightCaudalAnteriorCingulate
#'   \item ST74CV N mm3 Volume (aparc.stat) of RightCaudalMiddleFrontal
#'   \item ST74SA N mm2 Surface Area of RightCaudalMiddleFrontal
#'   \item ST74TA N mm Cortical Thickness Average of RightCaudalMiddleFrontal
#'   \item ST74TS N mm Cortical Thickness Standard Deviation of RightCaudalMiddleFrontal
#'   \item ST75SV N mm3 Volume (aseg.stat) of RightCaudate
#'   \item ST76SV N mm3 Volume (aseg.stat) of RightCerebellumCortex
#'   \item ST77SV N mm3 Volume (aseg.stat) of RightCerebellumWM
#'   \item ST78SV N mm3 Volume (aseg.stat) of RightCerebralCortex
#'   \item ST79SV N mm3 Volume (aseg.stat) of RightCerebralWM
#'   \item ST7SV N mm3 Volume (aseg.stat) of Csf
#'   \item ST80SV N mm3 Volume (aseg.stat) of RightChoroidPlexus
#'   \item ST81CV N mm3 Volume (aparc.stat) of RightCorpusCallosum
#'   \item ST81SA N mm2 Surface Area of RightCorpusCallosum
#'   \item ST81TA N mm Cortical Thickness Average of RightCorpusCallosum
#'   \item ST81TS N mm Cortical Thickness Standard Deviation of RightCorpusCallosum
#'   \item ST82CV N mm3 Volume (aparc.stat) of RightCuneus
#'   \item ST82SA N mm2 Surface Area of RightCuneus
#'   \item ST82TA N mm Cortical Thickness Average of RightCuneus
#'   \item ST82TS N mm Cortical Thickness Standard Deviation of RightCuneus
#'   \item ST83CV N mm3 Volume (aparc.stat) of RightEntorhinal
#'   \item ST83SA N mm2 Surface Area of RightEntorhinal
#'   \item ST83TA N mm Cortical Thickness Average of RightEntorhinal
#'   \item ST83TS N mm Cortical Thickness Standard Deviation of RightEntorhinal
#'   \item ST84CV N mm3 Volume (aparc.stat) of RightFrontalPole
#'   \item ST84SA N mm2 Surface Area of RightFrontalPole
#'   \item ST84TA N mm Cortical Thickness Average of RightFrontalPole
#'   \item ST84TS N mm Cortical Thickness Standard Deviation of RightFrontalPole
#'   \item ST85CV N mm3 Volume (aparc.stat) of RightFusiform
#'   \item ST85SA N mm2 Surface Area of RightFusiform
#'   \item ST85TA N mm Cortical Thickness Average of RightFusiform
#'   \item ST85TS N mm Cortical Thickness Standard Deviation of RightFusiform
#'   \item ST86SA N mm2 Surface Area of RightHemisphere
#'   \item ST87CV N mm3 Volume (aparc.stat) of RightHemisphereWM
#'   \item ST87SA N mm2 Surface Area of RightHemisphereWM
#'   \item ST88SV N mm3 Volume (aseg.stat) of RightHippocampus
#'   \item ST89SV N mm3 Volume (aseg.stat) of RightInferiorLateralVentricle
#'   \item ST8SV N mm3 Volume (aseg.stat) of FifthVentricle
#'   \item ST90CV N mm3 Volume (aparc.stat) of RightInferiorParietal
#'   \item ST90SA N mm2 Surface Area of RightInferiorParietal
#'   \item ST90TA N mm Cortical Thickness Average of RightInferiorParietal
#'   \item ST90TS N mm Cortical Thickness Standard Deviation of RightInferiorParietal
#'   \item ST91CV N mm3 Volume (aparc.stat) of RightInferiorTemporal
#'   \item ST91SA N mm2 Surface Area of RightInferiorTemporal
#'   \item ST91TA N mm Cortical Thickness Average of RightInferiorTemporal
#'   \item ST91TS N mm Cortical Thickness Standard Deviation of RightInferiorTemporal
#'   \item ST92SV N mm3 Volume (aseg.stat) of RightInterior
#'   \item ST93CV N mm3 Volume (aparc.stat) of RightIsthmusCingulate
#'   \item ST93SA N mm2 Surface Area of RightIsthmusCingulate
#'   \item ST93TA N mm Cortical Thickness Average of RightIsthmusCingulate
#'   \item ST93TS N mm Cortical Thickness Standard Deviation of RightIsthmusCingulate
#'   \item ST94CV N mm3 Volume (aparc.stat) of RightLateralOccipital
#'   \item ST94SA N mm2 Surface Area of RightLateralOccipital
#'   \item ST94TA N mm Cortical Thickness Average of RightLateralOccipital
#'   \item ST94TS N mm Cortical Thickness Standard Deviation of RightLateralOccipital
#'   \item ST95CV N mm3 Volume (aparc.stat) of RightLateralOrbitofrontal
#'   \item ST95SA N mm2 Surface Area of RightLateralOrbitofrontal
#'   \item ST95TA N mm Cortical Thickness Average of RightLateralOrbitofrontal
#'   \item ST95TS N mm Cortical Thickness Standard Deviation of RightLateralOrbitofrontal
#'   \item ST96SV N mm3 Volume (aseg.stat) of RightLateralVentricle
#'   \item ST97CV N mm3 Volume (aparc.stat) of RightLingual
#'   \item ST97SA N mm2 Surface Area of RightLingual
#'   \item ST97TA N mm Cortical Thickness Average of RightLingual
#'   \item ST97TS N mm Cortical Thickness Standard Deviation of RightLingual
#'   \item ST98CV N mm3 Volume (aparc.stat) of RightMedialOrbitofrontal
#'   \item ST98SA N mm2 Surface Area of RightMedialOrbitofrontal
#'   \item ST98TA N mm Cortical Thickness Average of RightMedialOrbitofrontal
#'   \item ST98TS N mm Cortical Thickness Standard Deviation of RightMedialOrbitofrontal
#'   \item ST99CV N mm3 Volume (aparc.stat) of RightMiddleTemporal
#'   \item ST99SA N mm2 Surface Area of RightMiddleTemporal
#'   \item ST99TA N mm Cortical Thickness Average of RightMiddleTemporal
#'   \item ST99TS N mm Cortical Thickness Standard Deviation of RightMiddleTemporal
#'   \item ST9SV N mm3 Volume (aseg.stat) of FourthVentricle
#'   \item ST131HS N mm3 Hippocampal Subfields Volume of LeftCA1
#'   \item ST132HS N mm3 Hippocampal Subfields Volume of LeftCA2_3
#'   \item ST133HS N mm3 Hippocampal Subfields Volume of LeftCA4_DG
#'   \item ST134HS N mm3 Hippocampal Subfields Volume of LeftFimbria
#'   \item ST135HS N mm3 Hippocampal Subfields Volume of LeftHippocampalFissure
#'   \item ST136HS N mm3 Hippocampal Subfields Volume of LeftPresubiculum
#'   \item ST137HS N mm3 Hippocampal Subfields Volume of LeftSubiculum
#'   \item ST138HS N mm3 Hippocampal Subfields Volume of LeftTail
#'   \item ST139HS N mm3 Hippocampal Subfields Volume of RightCA1
#'   \item ST140HS N mm3 Hippocampal Subfields Volume of RightCA2_3
#'   \item ST141HS N mm3 Hippocampal Subfields Volume of RightCA4_DG
#'   \item ST142HS N mm3 Hippocampal Subfields Volume of RightFimbria
#'   \item ST143HS N mm3 Hippocampal Subfields Volume of RightHippocampalFissure
#'   \item ST144HS N mm3 Hippocampal Subfields Volume of RightPresubiculum
#'   \item ST145HS N mm3 Hippocampal Subfields Volume of RightSubiculum
#'   \item ST146HS N mm3 Hippocampal Subfields Volume of RightTail
#'   \item ST147SV N mm3 Volume (aseg.stat) of LeftCorticalGM
#'   \item ST148SV N mm3 Volume (aseg.stat) of RightCorticalGM
#'   \item ST149SV N mm3 Volume (aseg.stat) of CorticalGM
#'   \item ST150SV N mm3 Volume (aseg.stat) of LeftCorticalWM
#'   \item ST151SV N mm3 Volume (aseg.stat) of RightCorticalWM
#'   \item ST152SV N mm3 Volume (aseg.stat) of CorticalWM
#'   \item ST153SV N mm3 Volume (aseg.stat) of SubcorticalGM
#'   \item ST154SV N mm3 Volume (aseg.stat) of TotalGM
#'   \item ST155SV N mm3 Volume (aseg.stat) of SupraTentorial
#' }
#'
#' @examples
#' \donotrun{
#' describe(ucsffsx51_adni1_3t)
#' }
#' @docType data
#' @keywords datasets
#' @name ucsffsx51_adni1_3t
#' @usage data(ucsffsx51_adni1_3t)
#' @format A data frame with 485 rows and 394 variables
NULL

#' Cross-Sectional FreeSurfer (5.1)
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/UCSFFSX51/UCSF%20FreeSurfer%20Methods%20and%20QC_OFFICIAL.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item COLPROT -4 -4 Study protocol of data collection
#'   \item RID T  Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item VISCODE2 -4 -4 Translated visit code
#'   \item EXAMDATE D  Examination Date
#'   \item VERSION D  
#'   \item LONISID T  The LONI study UID for the image processed
#'   \item LONIUID T  The LONI series UID for the image processed.
#'   \item IMAGEUID T  The ImageUID for the image processed.
#'   \item IMAGETYPE T  Whether the T1 image was an accelerated T1 or not.
#'   \item RUNDATE D  
#'   \item STATUS T  
#'   \item OVERALLQC T  An overall quality rating. Refer to additional QC variables for Partial rating.
#'   \item TEMPQC T  QC rating of temporal lobe. Fail affects the following regions: LeftTemporalPole (ST60); RightTemporalPole (ST119); LeftFusiform (ST26); RightFusiform (ST85); LeftSuperiorTemporal (ST58); RightSuperiorTemporal (ST117); LeftInferiorTemporal (ST32); RightInferiorTemporal (ST91); LeftMiddleTemporal (ST40); RightMiddleTemporal (ST99)
#'   \item FRONTQC T  QC rating of the frontal lobe. Fail affects the following regions: LeftFrontalPole (ST25); RightFrontalPole (ST84); LeftPrecentral (ST51); RightPrecentral (ST110); LeftSuperiorFrontal (ST56); RightSuperiorFrontal (ST115); LeftCaudalMiddleFrontal (ST15); RightCaudalMiddleFrontal (ST74); LeftRostralMiddleFrontal (ST55); RightRostralMiddleFrontal (ST114); LeftMedialOrbitofrontal (ST39); RightMedialOrbitofrontal (ST98)
#'   \item PARQC T  QC rating of the parietal lobe. Fail affects the following regions: LeftPostcentral (ST49); RightPostcentral (ST108); LeftSuperiorParietal (ST57); RightSuperiorParietal (ST116); LeftSupraMarginal (ST59); RightSupraMarginal (ST118); LeftParacentral (ST43); RightParacentral (ST102); LeftInferiorParietal (ST31); RightInferiorParietal (ST90)
#'   \item INSULAQC T  QC rating of the insula. Fail affects the following regions: LeftInsula (ST129); RightInsula (ST130)
#'   \item OCCQC T  QC rating of the occipital lobe. Fail affects the following regions: LeftLingual (ST38); RightLingual (ST97); LeftLateralOccipital (ST35); RightLateralOccipital (ST94); LeftPericalcarine (ST48); RightPericalcarine (ST107); LeftCuneus (ST23); RightCuneus (ST82)
#'   \item BGQC T  QC rating of the basal ganglia. Fail affects the following regions: LeftPutamen (ST53); RightPutamen (ST112); LeftCaudate (ST16); RightCaudate (ST75); LeftPallidum (ST42); RightPallidum (ST101)
#'   \item CWMQC T  QC rating of the cerebral WM. Fail affects the following regions: LeftCerebralWM (ST20); RightCerebralWM (ST79); LeftCorticalWM (ST150); RightCorticalWM (ST151); CorticalWM (ST152); LeftHemisphereWM (ST28); RightHemisphereWM (ST87)
#'   \item VENTQC T  QC rating of the ventricles. Fail affects the following regions: LeftLateralVentricle (ST37); RightLateralVentricle (ST96); LeftInferiorLateralVentricle (ST30); RightInferiorLateralVentricle (ST89); ThirdVentricle (ST127); FourthVentricle (ST9); FifthVentrical (ST8); LeftChoroidPlexus (ST21); RightChoroidPlexus (ST80)
#'   \item LHIPQC T  QC rating of the left hippocampal subfields. Fail affects the following regions: Left CA1 (ST131HS); Left CA2-3 (ST132HS); Left CA4-DG (ST133HS); Left Fimbria (ST134HS); Left Hippocampal Fissure (ST135HS); Left Presubiculum (ST136HS); Left Subiculum (ST137HS); Left Tail (ST138HS) 
#'   \item RHIPQC T  QC rating of the right hippocampal subfields. Fail affects the following regions: Right CA1 (ST139HS); Right CA2-3 (ST140HS); Right CA4-DG (ST141HS); Right Fimbria (ST142HS); Right Hippocampal Fissure (ST143HS); Right Presubiculum (ST144HS); Right Subiculum (ST145HS); Right Tail (ST146HS) 
#'   \item ST101SV N mm3 Subcortical Volume (aseg.stats) of RightPallidum
#'   \item ST102CV N mm3 Cortical Volume (aparc.stats) of RightParacentral
#'   \item ST102SA N mm2 Surface Area (aparc.stats) of RightParacentral
#'   \item ST102TA N mm Thickness Average (aparc.stats) of RightParacentral
#'   \item ST102TS N mm Thickness Stardard Deviation (aparc.stats) of RightParacentral
#'   \item ST103CV N mm3 Cortical Volume (aparc.stats) of RightParahippocampal
#'   \item ST103SA N mm2 Surface Area (aparc.stats) of RightParahippocampal
#'   \item ST103TA N mm Thickness Average (aparc.stats) of RightParahippocampal
#'   \item ST103TS N mm Thickness Stardard Deviation (aparc.stats) of RightParahippocampal
#'   \item ST104CV N mm3 Cortical Volume (aparc.stats) of RightParsOpercularis
#'   \item ST104SA N mm2 Surface Area (aparc.stats) of RightParsOpercularis
#'   \item ST104TA N mm Thickness Average (aparc.stats) of RightParsOpercularis
#'   \item ST104TS N mm Thickness Stardard Deviation (aparc.stats) of RightParsOpercularis
#'   \item ST105CV N mm3 Cortical Volume (aparc.stats) of RightParsOrbitalis
#'   \item ST105SA N mm2 Surface Area (aparc.stats) of RightParsOrbitalis
#'   \item ST105TA N mm Thickness Average (aparc.stats) of RightParsOrbitalis
#'   \item ST105TS N mm Thickness Stardard Deviation (aparc.stats) of RightParsOrbitalis
#'   \item ST106CV N mm3 Cortical Volume (aparc.stats) of RightParsTriangularis
#'   \item ST106SA N mm2 Surface Area (aparc.stats) of RightParsTriangularis
#'   \item ST106TA N mm Thickness Average (aparc.stats) of RightParsTriangularis
#'   \item ST106TS N mm Thickness Stardard Deviation (aparc.stats) of RightParsTriangularis
#'   \item ST107CV N mm3 Cortical Volume (aparc.stats) of RightPericalcarine
#'   \item ST107SA N mm2 Surface Area (aparc.stats) of RightPericalcarine
#'   \item ST107TA N mm Thickness Average (aparc.stats) of RightPericalcarine
#'   \item ST107TS N mm Thickness Stardard Deviation (aparc.stats) of RightPericalcarine
#'   \item ST108CV N mm3 Cortical Volume (aparc.stats) of RightPostcentral
#'   \item ST108SA N mm2 Surface Area (aparc.stats) of RightPostcentral
#'   \item ST108TA N mm Thickness Average (aparc.stats) of RightPostcentral
#'   \item ST108TS N mm Thickness Stardard Deviation (aparc.stats) of RightPostcentral
#'   \item ST109CV N mm3 Cortical Volume (aparc.stats) of RightPosteriorCingulate
#'   \item ST109SA N mm2 Surface Area (aparc.stats) of RightPosteriorCingulate
#'   \item ST109TA N mm Thickness Average (aparc.stats) of RightPosteriorCingulate
#'   \item ST109TS N mm Thickness Stardard Deviation (aparc.stats) of RightPosteriorCingulate
#'   \item ST10CV N mm3 Cortical Volume (aparc.stats) of Icv
#'   \item ST110CV N mm3 Cortical Volume (aparc.stats) of RightPrecentral
#'   \item ST110SA N mm2 Surface Area (aparc.stats) of RightPrecentral
#'   \item ST110TA N mm Thickness Average (aparc.stats) of RightPrecentral
#'   \item ST110TS N mm Thickness Stardard Deviation (aparc.stats) of RightPrecentral
#'   \item ST111CV N mm3 Cortical Volume (aparc.stats) of RightPrecuneus
#'   \item ST111SA N mm2 Surface Area (aparc.stats) of RightPrecuneus
#'   \item ST111TA N mm Thickness Average (aparc.stats) of RightPrecuneus
#'   \item ST111TS N mm Thickness Stardard Deviation (aparc.stats) of RightPrecuneus
#'   \item ST112SV N mm3 Subcortical Volume (aseg.stats) of RightPutamen
#'   \item ST113CV N mm3 Cortical Volume (aparc.stats) of RightRostralAnteriorCingulate
#'   \item ST113SA N mm2 Surface Area (aparc.stats) of RightRostralAnteriorCingulate
#'   \item ST113TA N mm Thickness Average (aparc.stats) of RightRostralAnteriorCingulate
#'   \item ST113TS N mm Thickness Stardard Deviation (aparc.stats) of RightRostralAnteriorCingulate
#'   \item ST114CV N mm3 Cortical Volume (aparc.stats) of RightRostralMiddleFrontal
#'   \item ST114SA N mm2 Surface Area (aparc.stats) of RightRostralMiddleFrontal
#'   \item ST114TA N mm Thickness Average (aparc.stats) of RightRostralMiddleFrontal
#'   \item ST114TS N mm Thickness Stardard Deviation (aparc.stats) of RightRostralMiddleFrontal
#'   \item ST115CV N mm3 Cortical Volume (aparc.stats) of RightSuperiorFrontal
#'   \item ST115SA N mm2 Surface Area (aparc.stats) of RightSuperiorFrontal
#'   \item ST115TA N mm Thickness Average (aparc.stats) of RightSuperiorFrontal
#'   \item ST115TS N mm Thickness Stardard Deviation (aparc.stats) of RightSuperiorFrontal
#'   \item ST116CV N mm3 Cortical Volume (aparc.stats) of RightSuperiorParietal
#'   \item ST116SA N mm2 Surface Area (aparc.stats) of RightSuperiorParietal
#'   \item ST116TA N mm Thickness Average (aparc.stats) of RightSuperiorParietal
#'   \item ST116TS N mm Thickness Stardard Deviation (aparc.stats) of RightSuperiorParietal
#'   \item ST117CV N mm3 Cortical Volume (aparc.stats) of RightSuperiorTemporal
#'   \item ST117SA N mm2 Surface Area (aparc.stats) of RightSuperiorTemporal
#'   \item ST117TA N mm Thickness Average (aparc.stats) of RightSuperiorTemporal
#'   \item ST117TS N mm Thickness Stardard Deviation (aparc.stats) of RightSuperiorTemporal
#'   \item ST118CV N mm3 Cortical Volume (aparc.stats) of RightSupramarginal
#'   \item ST118SA N mm2 Surface Area (aparc.stats) of RightSupramarginal
#'   \item ST118TA N mm Thickness Average (aparc.stats) of RightSupramarginal
#'   \item ST118TS N mm Thickness Stardard Deviation (aparc.stats) of RightSupramarginal
#'   \item ST119CV N mm3 Cortical Volume (aparc.stats) of RightTemporalPole
#'   \item ST119SA N mm2 Surface Area (aparc.stats) of RightTemporalPole
#'   \item ST119TA N mm Thickness Average (aparc.stats) of RightTemporalPole
#'   \item ST119TS N mm Thickness Stardard Deviation (aparc.stats) of RightTemporalPole
#'   \item ST11SV N mm3 Subcortical Volume (aseg.stats) of LeftAccumbensArea
#'   \item ST120SV N mm3 Subcortical Volume (aseg.stats) of RightThalamus
#'   \item ST121CV N mm3 Cortical Volume (aparc.stats) of RightTransverseTemporal
#'   \item ST121SA N mm2 Surface Area (aparc.stats) of RightTransverseTemporal
#'   \item ST121TA N mm Thickness Average (aparc.stats) of RightTransverseTemporal
#'   \item ST121TS N mm Thickness Stardard Deviation (aparc.stats) of RightTransverseTemporal
#'   \item ST124SV N mm3 Subcortical Volume (aseg.stats) of RightVentralDC
#'   \item ST125SV N mm3 Subcortical Volume (aseg.stats) of RightVessel
#'   \item ST127SV N mm3 Subcortical Volume (aseg.stats) of ThirdVentricle
#'   \item ST128SV N mm3 Subcortical Volume (aseg.stats) of WMHypoIntensities
#'   \item ST129CV N mm3 Cortical Volume (aparc.stats) of LeftInsula
#'   \item ST129SA N mm2 Surface Area (aparc.stats) of LeftInsula
#'   \item ST129TA N mm Thickness Average (aparc.stats) of LeftInsula
#'   \item ST129TS N mm Thickness Stardard Deviation (aparc.stats) of LeftInsula
#'   \item ST12SV N mm3 Subcortical Volume (aseg.stats) of LeftAmygdala
#'   \item ST130CV N mm3 Cortical Volume (aparc.stats) of RightInsula
#'   \item ST130SA N mm2 Surface Area (aparc.stats) of RightInsula
#'   \item ST130TA N mm Thickness Average (aparc.stats) of RightInsula
#'   \item ST130TS N mm Thickness Stardard Deviation (aparc.stats) of RightInsula
#'   \item ST13CV N mm3 Cortical Volume (aparc.stats) of LeftBankssts
#'   \item ST13SA N mm2 Surface Area (aparc.stats) of LeftBankssts
#'   \item ST13TA N mm Thickness Average (aparc.stats) of LeftBankssts
#'   \item ST13TS N mm Thickness Stardard Deviation (aparc.stats) of LeftBankssts
#'   \item ST14CV N mm3 Cortical Volume (aparc.stats) of LeftCaudalAnteriorCingulate
#'   \item ST14SA N mm2 Surface Area (aparc.stats) of LeftCaudalAnteriorCingulate
#'   \item ST14TA N mm Thickness Average (aparc.stats) of LeftCaudalAnteriorCingulate
#'   \item ST14TS N mm Thickness Stardard Deviation (aparc.stats) of LeftCaudalAnteriorCingulate
#'   \item ST15CV N mm3 Cortical Volume (aparc.stats) of LeftCaudalMiddleFrontal
#'   \item ST15SA N mm2 Surface Area (aparc.stats) of LeftCaudalMiddleFrontal
#'   \item ST15TA N mm Thickness Average (aparc.stats) of LeftCaudalMiddleFrontal
#'   \item ST15TS N mm Thickness Stardard Deviation (aparc.stats) of LeftCaudalMiddleFrontal
#'   \item ST16SV N mm3 Subcortical Volume (aseg.stats) of LeftCaudate
#'   \item ST17SV N mm3 Subcortical Volume (aseg.stats) of LeftCerebellumCortex
#'   \item ST18SV N mm3 Subcortical Volume (aseg.stats) of LeftCerebellumWM
#'   \item ST1SV N mm3 Subcortical Volume (aseg.stats) of Brainstem
#'   \item ST21SV N mm3 Subcortical Volume (aseg.stats) of LeftChoroidPlexus
#'   \item ST23CV N mm3 Cortical Volume (aparc.stats) of LeftCuneus
#'   \item ST23SA N mm2 Surface Area (aparc.stats) of LeftCuneus
#'   \item ST23TA N mm Thickness Average (aparc.stats) of LeftCuneus
#'   \item ST23TS N mm Thickness Stardard Deviation (aparc.stats) of LeftCuneus
#'   \item ST24CV N mm3 Cortical Volume (aparc.stats) of LeftEntorhinal
#'   \item ST24SA N mm2 Surface Area (aparc.stats) of LeftEntorhinal
#'   \item ST24TA N mm Thickness Average (aparc.stats) of LeftEntorhinal
#'   \item ST24TS N mm Thickness Stardard Deviation (aparc.stats) of LeftEntorhinal
#'   \item ST25CV N mm3 Cortical Volume (aparc.stats) of LeftFrontalPole
#'   \item ST25SA N mm2 Surface Area (aparc.stats) of LeftFrontalPole
#'   \item ST25TA N mm Thickness Average (aparc.stats) of LeftFrontalPole
#'   \item ST25TS N mm Thickness Stardard Deviation (aparc.stats) of LeftFrontalPole
#'   \item ST26CV N mm3 Cortical Volume (aparc.stats) of LeftFusiform
#'   \item ST26SA N mm2 Surface Area (aparc.stats) of LeftFusiform
#'   \item ST26TA N mm Thickness Average (aparc.stats) of LeftFusiform
#'   \item ST26TS N mm Thickness Stardard Deviation (aparc.stats) of LeftFusiform
#'   \item ST28SA N mm2 Surface Area (aparc.stats) of LeftHemisphereWM
#'   \item ST29SV N mm3 Subcortical Volume (aseg.stats) of LeftHippocampus
#'   \item ST2SV N mm3 Subcortical Volume (aseg.stats) of CorpusCallosumAnterior
#'   \item ST30SV N mm3 Subcortical Volume (aseg.stats) of LeftInferiorLateralVentricle
#'   \item ST31CV N mm3 Cortical Volume (aparc.stats) of LeftInferiorParietal
#'   \item ST31SA N mm2 Surface Area (aparc.stats) of LeftInferiorParietal
#'   \item ST31TA N mm Thickness Average (aparc.stats) of LeftInferiorParietal
#'   \item ST31TS N mm Thickness Stardard Deviation (aparc.stats) of LeftInferiorParietal
#'   \item ST32CV N mm3 Cortical Volume (aparc.stats) of LeftInferiorTemporal
#'   \item ST32SA N mm2 Surface Area (aparc.stats) of LeftInferiorTemporal
#'   \item ST32TA N mm Thickness Average (aparc.stats) of LeftInferiorTemporal
#'   \item ST32TS N mm Thickness Stardard Deviation (aparc.stats) of LeftInferiorTemporal
#'   \item ST34CV N mm3 Cortical Volume (aparc.stats) of LeftIsthmusCingulate
#'   \item ST34SA N mm2 Surface Area (aparc.stats) of LeftIsthmusCingulate
#'   \item ST34TA N mm Thickness Average (aparc.stats) of LeftIsthmusCingulate
#'   \item ST34TS N mm Thickness Stardard Deviation (aparc.stats) of LeftIsthmusCingulate
#'   \item ST35CV N mm3 Cortical Volume (aparc.stats) of LeftLateralOccipital
#'   \item ST35SA N mm2 Surface Area (aparc.stats) of LeftLateralOccipital
#'   \item ST35TA N mm Thickness Average (aparc.stats) of LeftLateralOccipital
#'   \item ST35TS N mm Thickness Stardard Deviation (aparc.stats) of LeftLateralOccipital
#'   \item ST36CV N mm3 Cortical Volume (aparc.stats) of LeftLateralOrbitofrontal
#'   \item ST36SA N mm2 Surface Area (aparc.stats) of LeftLateralOrbitofrontal
#'   \item ST36TA N mm Thickness Average (aparc.stats) of LeftLateralOrbitofrontal
#'   \item ST36TS N mm Thickness Stardard Deviation (aparc.stats) of LeftLateralOrbitofrontal
#'   \item ST37SV N mm3 Subcortical Volume (aseg.stats) of LeftLateralVentricle
#'   \item ST38CV N mm3 Cortical Volume (aparc.stats) of LeftLingual
#'   \item ST38SA N mm2 Surface Area (aparc.stats) of LeftLingual
#'   \item ST38TA N mm Thickness Average (aparc.stats) of LeftLingual
#'   \item ST38TS N mm Thickness Stardard Deviation (aparc.stats) of LeftLingual
#'   \item ST39CV N mm3 Cortical Volume (aparc.stats) of LeftMedialOrbitofrontal
#'   \item ST39SA N mm2 Surface Area (aparc.stats) of LeftMedialOrbitofrontal
#'   \item ST39TA N mm Thickness Average (aparc.stats) of LeftMedialOrbitofrontal
#'   \item ST39TS N mm Thickness Stardard Deviation (aparc.stats) of LeftMedialOrbitofrontal
#'   \item ST3SV N mm3 Subcortical Volume (aseg.stats) of CorpusCallosumCentral
#'   \item ST40CV N mm3 Cortical Volume (aparc.stats) of LeftMiddleTemporal
#'   \item ST40SA N mm2 Surface Area (aparc.stats) of LeftMiddleTemporal
#'   \item ST40TA N mm Thickness Average (aparc.stats) of LeftMiddleTemporal
#'   \item ST40TS N mm Thickness Stardard Deviation (aparc.stats) of LeftMiddleTemporal
#'   \item ST42SV N mm3 Subcortical Volume (aseg.stats) of LeftPallidum
#'   \item ST43CV N mm3 Cortical Volume (aparc.stats) of LeftParacentral
#'   \item ST43SA N mm2 Surface Area (aparc.stats) of LeftParacentral
#'   \item ST43TA N mm Thickness Average (aparc.stats) of LeftParacentral
#'   \item ST43TS N mm Thickness Stardard Deviation (aparc.stats) of LeftParacentral
#'   \item ST44CV N mm3 Cortical Volume (aparc.stats) of LeftParahippocampal
#'   \item ST44SA N mm2 Surface Area (aparc.stats) of LeftParahippocampal
#'   \item ST44TA N mm Thickness Average (aparc.stats) of LeftParahippocampal
#'   \item ST44TS N mm Thickness Stardard Deviation (aparc.stats) of LeftParahippocampal
#'   \item ST45CV N mm3 Cortical Volume (aparc.stats) of LeftParsOpercularis
#'   \item ST45SA N mm2 Surface Area (aparc.stats) of LeftParsOpercularis
#'   \item ST45TA N mm Thickness Average (aparc.stats) of LeftParsOpercularis
#'   \item ST45TS N mm Thickness Stardard Deviation (aparc.stats) of LeftParsOpercularis
#'   \item ST46CV N mm3 Cortical Volume (aparc.stats) of LeftParsOrbitalis
#'   \item ST46SA N mm2 Surface Area (aparc.stats) of LeftParsOrbitalis
#'   \item ST46TA N mm Thickness Average (aparc.stats) of LeftParsOrbitalis
#'   \item ST46TS N mm Thickness Stardard Deviation (aparc.stats) of LeftParsOrbitalis
#'   \item ST47CV N mm3 Cortical Volume (aparc.stats) of LeftParsTriangularis
#'   \item ST47SA N mm2 Surface Area (aparc.stats) of LeftParsTriangularis
#'   \item ST47TA N mm Thickness Average (aparc.stats) of LeftParsTriangularis
#'   \item ST47TS N mm Thickness Stardard Deviation (aparc.stats) of LeftParsTriangularis
#'   \item ST48CV N mm3 Cortical Volume (aparc.stats) of LeftPericalcarine
#'   \item ST48SA N mm2 Surface Area (aparc.stats) of LeftPericalcarine
#'   \item ST48TA N mm Thickness Average (aparc.stats) of LeftPericalcarine
#'   \item ST48TS N mm Thickness Stardard Deviation (aparc.stats) of LeftPericalcarine
#'   \item ST49CV N mm3 Cortical Volume (aparc.stats) of LeftPostcentral
#'   \item ST49SA N mm2 Surface Area (aparc.stats) of LeftPostcentral
#'   \item ST49TA N mm Thickness Average (aparc.stats) of LeftPostcentral
#'   \item ST49TS N mm Thickness Stardard Deviation (aparc.stats) of LeftPostcentral
#'   \item ST4SV N mm3 Subcortical Volume (aseg.stats) of CorpusCallosumMidAnterior
#'   \item ST50CV N mm3 Cortical Volume (aparc.stats) of LeftPosteriorCingulate
#'   \item ST50SA N mm2 Surface Area (aparc.stats) of LeftPosteriorCingulate
#'   \item ST50TA N mm Thickness Average (aparc.stats) of LeftPosteriorCingulate
#'   \item ST50TS N mm Thickness Stardard Deviation (aparc.stats) of LeftPosteriorCingulate
#'   \item ST51CV N mm3 Cortical Volume (aparc.stats) of LeftPrecentral
#'   \item ST51SA N mm2 Surface Area (aparc.stats) of LeftPrecentral
#'   \item ST51TA N mm Thickness Average (aparc.stats) of LeftPrecentral
#'   \item ST51TS N mm Thickness Stardard Deviation (aparc.stats) of LeftPrecentral
#'   \item ST52CV N mm3 Cortical Volume (aparc.stats) of LeftPrecuneus
#'   \item ST52SA N mm2 Surface Area (aparc.stats) of LeftPrecuneus
#'   \item ST52TA N mm Thickness Average (aparc.stats) of LeftPrecuneus
#'   \item ST52TS N mm Thickness Stardard Deviation (aparc.stats) of LeftPrecuneus
#'   \item ST53SV N mm3 Subcortical Volume (aseg.stats) of LeftPutamen
#'   \item ST54CV N mm3 Cortical Volume (aparc.stats) of LeftRostralAnteriorCingulate
#'   \item ST54SA N mm2 Surface Area (aparc.stats) of LeftRostralAnteriorCingulate
#'   \item ST54TA N mm Thickness Average (aparc.stats) of LeftRostralAnteriorCingulate
#'   \item ST54TS N mm Thickness Stardard Deviation (aparc.stats) of LeftRostralAnteriorCingulate
#'   \item ST55CV N mm3 Cortical Volume (aparc.stats) of LeftRostralMiddleFrontal
#'   \item ST55SA N mm2 Surface Area (aparc.stats) of LeftRostralMiddleFrontal
#'   \item ST55TA N mm Thickness Average (aparc.stats) of LeftRostralMiddleFrontal
#'   \item ST55TS N mm Thickness Stardard Deviation (aparc.stats) of LeftRostralMiddleFrontal
#'   \item ST56CV N mm3 Cortical Volume (aparc.stats) of LeftSuperiorFrontal
#'   \item ST56SA N mm2 Surface Area (aparc.stats) of LeftSuperiorFrontal
#'   \item ST56TA N mm Thickness Average (aparc.stats) of LeftSuperiorFrontal
#'   \item ST56TS N mm Thickness Stardard Deviation (aparc.stats) of LeftSuperiorFrontal
#'   \item ST57CV N mm3 Cortical Volume (aparc.stats) of LeftSuperiorParietal
#'   \item ST57SA N mm2 Surface Area (aparc.stats) of LeftSuperiorParietal
#'   \item ST57TA N mm Thickness Average (aparc.stats) of LeftSuperiorParietal
#'   \item ST57TS N mm Thickness Stardard Deviation (aparc.stats) of LeftSuperiorParietal
#'   \item ST58CV N mm3 Cortical Volume (aparc.stats) of LeftSuperiorTemporal
#'   \item ST58SA N mm2 Surface Area (aparc.stats) of LeftSuperiorTemporal
#'   \item ST58TA N mm Thickness Average (aparc.stats) of LeftSuperiorTemporal
#'   \item ST58TS N mm Thickness Stardard Deviation (aparc.stats) of LeftSuperiorTemporal
#'   \item ST59CV N mm3 Cortical Volume (aparc.stats) of LeftSupramarginal
#'   \item ST59SA N mm2 Surface Area (aparc.stats) of LeftSupramarginal
#'   \item ST59TA N mm Thickness Average (aparc.stats) of LeftSupramarginal
#'   \item ST59TS N mm Thickness Stardard Deviation (aparc.stats) of LeftSupramarginal
#'   \item ST5SV N mm3 Subcortical Volume (aseg.stats) of CorpusCallosumMidPosterior
#'   \item ST60CV N mm3 Cortical Volume (aparc.stats) of LeftTemporalPole
#'   \item ST60SA N mm2 Surface Area (aparc.stats) of LeftTemporalPole
#'   \item ST60TA N mm Thickness Average (aparc.stats) of LeftTemporalPole
#'   \item ST60TS N mm Thickness Stardard Deviation (aparc.stats) of LeftTemporalPole
#'   \item ST61SV N mm3 Subcortical Volume (aseg.stats) of LeftThalamus
#'   \item ST62CV N mm3 Cortical Volume (aparc.stats) of LeftTransverseTemporal
#'   \item ST62SA N mm2 Surface Area (aparc.stats) of LeftTransverseTemporal
#'   \item ST62TA N mm Thickness Average (aparc.stats) of LeftTransverseTemporal
#'   \item ST62TS N mm Thickness Stardard Deviation (aparc.stats) of LeftTransverseTemporal
#'   \item ST65SV N mm3 Subcortical Volume (aseg.stats) of LeftVentralDC
#'   \item ST66SV N mm3 Subcortical Volume (aseg.stats) of LeftVessel
#'   \item ST68SV N mm3 Subcortical Volume (aseg.stats) of NonWMHypoIntensities
#'   \item ST69SV N mm3 Subcortical Volume (aseg.stats) of OpticChiasm
#'   \item ST6SV N mm3 Subcortical Volume (aseg.stats) of CorpusCallosumPosterior
#'   \item ST70SV N mm3 Subcortical Volume (aseg.stats) of RightAccumbensArea
#'   \item ST71SV N mm3 Subcortical Volume (aseg.stats) of RightAmygdala
#'   \item ST72CV N mm3 Cortical Volume (aparc.stats) of RightBankssts
#'   \item ST72SA N mm2 Surface Area (aparc.stats) of RightBankssts
#'   \item ST72TA N mm Thickness Average (aparc.stats) of RightBankssts
#'   \item ST72TS N mm Thickness Stardard Deviation (aparc.stats) of RightBankssts
#'   \item ST73CV N mm3 Cortical Volume (aparc.stats) of RightCaudalAnteriorCingulate
#'   \item ST73SA N mm2 Surface Area (aparc.stats) of RightCaudalAnteriorCingulate
#'   \item ST73TA N mm Thickness Average (aparc.stats) of RightCaudalAnteriorCingulate
#'   \item ST73TS N mm Thickness Stardard Deviation (aparc.stats) of RightCaudalAnteriorCingulate
#'   \item ST74CV N mm3 Cortical Volume (aparc.stats) of RightCaudalMiddleFrontal
#'   \item ST74SA N mm2 Surface Area (aparc.stats) of RightCaudalMiddleFrontal
#'   \item ST74TA N mm Thickness Average (aparc.stats) of RightCaudalMiddleFrontal
#'   \item ST74TS N mm Thickness Stardard Deviation (aparc.stats) of RightCaudalMiddleFrontal
#'   \item ST75SV N mm3 Subcortical Volume (aseg.stats) of RightCaudate
#'   \item ST76SV N mm3 Subcortical Volume (aseg.stats) of RightCerebellumCortex
#'   \item ST77SV N mm3 Subcortical Volume (aseg.stats) of RightCerebellumWM
#'   \item ST7SV N mm3 Subcortical Volume (aseg.stats) of Csf
#'   \item ST80SV N mm3 Subcortical Volume (aseg.stats) of RightChoroidPlexus
#'   \item ST82CV N mm3 Cortical Volume (aparc.stats) of RightCuneus
#'   \item ST82SA N mm2 Surface Area (aparc.stats) of RightCuneus
#'   \item ST82TA N mm Thickness Average (aparc.stats) of RightCuneus
#'   \item ST82TS N mm Thickness Stardard Deviation (aparc.stats) of RightCuneus
#'   \item ST83CV N mm3 Cortical Volume (aparc.stats) of RightEntorhinal
#'   \item ST83SA N mm2 Surface Area (aparc.stats) of RightEntorhinal
#'   \item ST83TA N mm Thickness Average (aparc.stats) of RightEntorhinal
#'   \item ST83TS N mm Thickness Stardard Deviation (aparc.stats) of RightEntorhinal
#'   \item ST84CV N mm3 Cortical Volume (aparc.stats) of RightFrontalPole
#'   \item ST84SA N mm2 Surface Area (aparc.stats) of RightFrontalPole
#'   \item ST84TA N mm Thickness Average (aparc.stats) of RightFrontalPole
#'   \item ST84TS N mm Thickness Stardard Deviation (aparc.stats) of RightFrontalPole
#'   \item ST85CV N mm3 Cortical Volume (aparc.stats) of RightFusiform
#'   \item ST85SA N mm2 Surface Area (aparc.stats) of RightFusiform
#'   \item ST85TA N mm Thickness Average (aparc.stats) of RightFusiform
#'   \item ST85TS N mm Thickness Stardard Deviation (aparc.stats) of RightFusiform
#'   \item ST87SA N mm2 Surface Area (aparc.stats) of RightHemisphereWM
#'   \item ST88SV N mm3 Subcortical Volume (aseg.stats) of RightHippocampus
#'   \item ST89SV N mm3 Subcortical Volume (aseg.stats) of RightInferiorLateralVentricle
#'   \item ST8SV N mm3 Subcortical Volume (aseg.stats) of FifthVentricle
#'   \item ST90CV N mm3 Cortical Volume (aparc.stats) of RightInferiorParietal
#'   \item ST90SA N mm2 Surface Area (aparc.stats) of RightInferiorParietal
#'   \item ST90TA N mm Thickness Average (aparc.stats) of RightInferiorParietal
#'   \item ST90TS N mm Thickness Stardard Deviation (aparc.stats) of RightInferiorParietal
#'   \item ST91CV N mm3 Cortical Volume (aparc.stats) of RightInferiorTemporal
#'   \item ST91SA N mm2 Surface Area (aparc.stats) of RightInferiorTemporal
#'   \item ST91TA N mm Thickness Average (aparc.stats) of RightInferiorTemporal
#'   \item ST91TS N mm Thickness Stardard Deviation (aparc.stats) of RightInferiorTemporal
#'   \item ST93CV N mm3 Cortical Volume (aparc.stats) of RightIsthmusCingulate
#'   \item ST93SA N mm2 Surface Area (aparc.stats) of RightIsthmusCingulate
#'   \item ST93TA N mm Thickness Average (aparc.stats) of RightIsthmusCingulate
#'   \item ST93TS N mm Thickness Stardard Deviation (aparc.stats) of RightIsthmusCingulate
#'   \item ST94CV N mm3 Cortical Volume (aparc.stats) of RightLateralOccipital
#'   \item ST94SA N mm2 Surface Area (aparc.stats) of RightLateralOccipital
#'   \item ST94TA N mm Thickness Average (aparc.stats) of RightLateralOccipital
#'   \item ST94TS N mm Thickness Stardard Deviation (aparc.stats) of RightLateralOccipital
#'   \item ST95CV N mm3 Cortical Volume (aparc.stats) of RightLateralOrbitofrontal
#'   \item ST95SA N mm2 Surface Area (aparc.stats) of RightLateralOrbitofrontal
#'   \item ST95TA N mm Thickness Average (aparc.stats) of RightLateralOrbitofrontal
#'   \item ST95TS N mm Thickness Stardard Deviation (aparc.stats) of RightLateralOrbitofrontal
#'   \item ST96SV N mm3 Subcortical Volume (aseg.stats) of RightLateralVentricle
#'   \item ST97CV N mm3 Cortical Volume (aparc.stats) of RightLingual
#'   \item ST97SA N mm2 Surface Area (aparc.stats) of RightLingual
#'   \item ST97TA N mm Thickness Average (aparc.stats) of RightLingual
#'   \item ST97TS N mm Thickness Stardard Deviation (aparc.stats) of RightLingual
#'   \item ST98CV N mm3 Cortical Volume (aparc.stats) of RightMedialOrbitofrontal
#'   \item ST98SA N mm2 Surface Area (aparc.stats) of RightMedialOrbitofrontal
#'   \item ST98TA N mm Thickness Average (aparc.stats) of RightMedialOrbitofrontal
#'   \item ST98TS N mm Thickness Stardard Deviation (aparc.stats) of RightMedialOrbitofrontal
#'   \item ST99CV N mm3 Cortical Volume (aparc.stats) of RightMiddleTemporal
#'   \item ST99SA N mm2 Surface Area (aparc.stats) of RightMiddleTemporal
#'   \item ST99TA N mm Thickness Average (aparc.stats) of RightMiddleTemporal
#'   \item ST99TS N mm Thickness Stardard Deviation (aparc.stats) of RightMiddleTemporal
#'   \item ST9SV N mm3 Subcortical Volume (aseg.stats) of FourthVentricle
#'   \item ST131HS N mm3 Hippocampal Subfields Volume of LeftCA1
#'   \item ST132HS N mm3 Hippocampal Subfields Volume of LeftCA2_3
#'   \item ST133HS N mm3 Hippocampal Subfields Volume of LeftCA4_DG
#'   \item ST134HS N mm3 Hippocampal Subfields Volume of LeftFimbria
#'   \item ST135HS N mm3 Hippocampal Subfields Volume of LeftHippocampalFissure
#'   \item ST136HS N mm3 Hippocampal Subfields Volume of LeftPresubiculum
#'   \item ST137HS N mm3 Hippocampal Subfields Volume of LeftSubiculum
#'   \item ST138HS N mm3 Hippocampal Subfields Volume of LeftTail
#'   \item ST139HS N mm3 Hippocampal Subfields Volume of RightCA1
#'   \item ST140HS N mm3 Hippocampal Subfields Volume of RightCA2_3
#'   \item ST141HS N mm3 Hippocampal Subfields Volume of RightCA4_DG
#'   \item ST142HS N mm3 Hippocampal Subfields Volume of RightFimbria
#'   \item ST143HS N mm3 Hippocampal Subfields Volume of RightHippocampalFissure
#'   \item ST144HS N mm3 Hippocampal Subfields Volume of RightPresubiculum
#'   \item ST145HS N mm3 Hippocampal Subfields Volume of RightSubiculum
#'   \item ST146HS N mm3 Hippocampal Subfields Volume of RightTail
#'   \item ST147SV N mm3 Subcortical Volume (aseg.stats) of LeftCorticalGM
#'   \item ST148SV N mm3 Subcortical Volume (aseg.stats) of RightCorticalGM
#'   \item ST149SV N mm3 Subcortical Volume (aseg.stats) of CorticalGM
#'   \item ST150SV N mm3 Subcortical Volume (aseg.stats) of LeftCorticalWM
#'   \item ST151SV N mm3 Subcortical Volume (aseg.stats) of RightCorticalWM
#'   \item ST152SV N mm3 Subcortical Volume (aseg.stats) of CorticalWM
#'   \item ST153SV N mm3 Subcortical Volume (aseg.stats) of SubcorticalGM
#'   \item ST154SV N mm3 Subcortical Volume (aseg.stats) of TotalGM
#'   \item ST155SV N mm3 Subcortical Volume (aseg.stats) of SupraTentorial
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name ucsffsx51
#' @usage data(ucsffsx51)
#' @format A data frame with 4556 rows and 364 variables
NULL

#' Cross-Sectional FreeSurfer
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID T  Participant roster ID
#'   \item VISCODE T  Visit code
#'   \item EXAMDATE D  Examination Date
#'   \item VERSION D  
#'   \item LONISID T  The LONI study UID for the image processed
#'   \item FLDSTRENG T  The field strength. 1.5 or 3
#'   \item LONIUID T  The LONI series UID for the image processed.
#'   \item IMAGEUID T  The ImageUID for the image processed.
#'   \item RUNDATE D  
#'   \item STATUS T  
#'   \item OVERALLQC T  An overall quality rating. Refer to additional QC variables for Partial rating.
#'   \item TEMPQC T  QC rating of temporal lobe. Fail affects the following regions: LeftTemporalPole (ST60); RightTemporalPole (ST119); LeftFusiform (ST26); RightFusiform (ST85); LeftSuperiorTemporal (ST58); RightSuperiorTemporal (ST117); LeftInferiorTemporal (ST32); RightInferiorTemporal (ST91); LeftMiddleTemporal (ST40); RightMiddleTemporal (ST99)
#'   \item FRONTQC T  QC rating of the frontal lobe. Fail affects the following regions: LeftFrontalPole (ST25); RightFrontalPole (ST84); LeftPrecentral (ST51); RightPrecentral (ST110); LeftSuperiorFrontal (ST56); RightSuperiorFrontal (ST115); LeftCaudalMiddleFrontal (ST15); RightCaudalMiddleFrontal (ST74); LeftRostralMiddleFrontal (ST55); RightRostralMiddleFrontal (ST114); LeftMedialOrbitofrontal (ST39); RightMedialOrbitofrontal (ST98)
#'   \item PARQC T  QC rating of the parietal lobe. Fail affects the following regions: LeftPostcentral (ST49); RightPostcentral (ST108); LeftSuperiorParietal (ST57); RightSuperiorParietal (ST116); LeftSupraMarginal (ST59); RightSupraMarginal (ST118); LeftParacentral (ST43); RightParacentral (ST102); LeftInferiorParietal (ST31); RightInferiorParietal (ST90)
#'   \item INSULAQC T  QC rating of the insula. Fail affects the following regions: LeftInsula (ST129); RightInsula (ST130)
#'   \item OCCQC T  QC rating of the occipital lobe. Fail affects the following regions: LeftLingual (ST38); RightLingual (ST97); LeftLateralOccipital (ST35); RightLateralOccipital (ST94); LeftPericalcarine (ST48); RightPericalcarine (ST107); LeftCuneus (ST23); RightCuneus (ST82)
#'   \item BGQC T  QC rating of the basal ganglia. Fail affects the following regions: LeftPutamen (ST53); RightPutamen (ST112); LeftCaudate (ST16); RightCaudate (ST75); LeftPallidum (ST42); RightPallidum (ST101)
#'   \item CWMQC T  QC rating of the cerebral WM. Fail affects the following regions: LeftCerebralWM (ST20); RightCerebralWM (ST79)
#'   \item VENTQC T  QC rating of the ventricles. Fail affects the following regions: LeftLateralVentricle (ST37); RightLateralVentricle (ST96); LeftInferiorLateralVentricle (ST30); RightInferiorLateralVentricle (ST89); ThirdVentricle (ST127); FourthVentricle (ST9); FifthVentrical (ST8); LeftChoroidPlexus (ST21); RightChoroidPlexus (ST80)
#'   \item ST100SV N mm3 Volume (WM Parcellation) of RightNonWMHypoIntensities
#'   \item ST101SV N mm3 Volume (WM Parcellation) of RightPallidum
#'   \item ST102CV N mm3 Volume (Cortical Parcellation) of RightParacentral
#'   \item ST102SA N mm2 Surface Area of RightParacentral
#'   \item ST102TA N mm Cortical Thickness Average of RightParacentral
#'   \item ST102TS N mm Cortical Thickness Standard Deviation of RightParacentral
#'   \item ST103CV N mm3 Volume (Cortical Parcellation) of RightParahippocampal
#'   \item ST103SA N mm2 Surface Area of RightParahippocampal
#'   \item ST103TA N mm Cortical Thickness Average of RightParahippocampal
#'   \item ST103TS N mm Cortical Thickness Standard Deviation of RightParahippocampal
#'   \item ST104CV N mm3 Volume (Cortical Parcellation) of RightParsOpercularis
#'   \item ST104SA N mm2 Surface Area of RightParsOpercularis
#'   \item ST104TA N mm Cortical Thickness Average of RightParsOpercularis
#'   \item ST104TS N mm Cortical Thickness Standard Deviation of RightParsOpercularis
#'   \item ST105CV N mm3 Volume (Cortical Parcellation) of RightParsOrbitalis
#'   \item ST105SA N mm2 Surface Area of RightParsOrbitalis
#'   \item ST105TA N mm Cortical Thickness Average of RightParsOrbitalis
#'   \item ST105TS N mm Cortical Thickness Standard Deviation of RightParsOrbitalis
#'   \item ST106CV N mm3 Volume (Cortical Parcellation) of RightParsTriangularis
#'   \item ST106SA N mm2 Surface Area of RightParsTriangularis
#'   \item ST106TA N mm Cortical Thickness Average of RightParsTriangularis
#'   \item ST106TS N mm Cortical Thickness Standard Deviation of RightParsTriangularis
#'   \item ST107CV N mm3 Volume (Cortical Parcellation) of RightPericalcarine
#'   \item ST107SA N mm2 Surface Area of RightPericalcarine
#'   \item ST107TA N mm Cortical Thickness Average of RightPericalcarine
#'   \item ST107TS N mm Cortical Thickness Standard Deviation of RightPericalcarine
#'   \item ST108CV N mm3 Volume (Cortical Parcellation) of RightPostcentral
#'   \item ST108SA N mm2 Surface Area of RightPostcentral
#'   \item ST108TA N mm Cortical Thickness Average of RightPostcentral
#'   \item ST108TS N mm Cortical Thickness Standard Deviation of RightPostcentral
#'   \item ST109CV N mm3 Volume (Cortical Parcellation) of RightPosteriorCingulate
#'   \item ST109SA N mm2 Surface Area of RightPosteriorCingulate
#'   \item ST109TA N mm Cortical Thickness Average of RightPosteriorCingulate
#'   \item ST109TS N mm Cortical Thickness Standard Deviation of RightPosteriorCingulate
#'   \item ST10CV N mm3 Volume (Cortical Parcellation) of Icv
#'   \item ST110CV N mm3 Volume (Cortical Parcellation) of RightPrecentral
#'   \item ST110SA N mm2 Surface Area of RightPrecentral
#'   \item ST110TA N mm Cortical Thickness Average of RightPrecentral
#'   \item ST110TS N mm Cortical Thickness Standard Deviation of RightPrecentral
#'   \item ST111CV N mm3 Volume (Cortical Parcellation) of RightPrecuneus
#'   \item ST111SA N mm2 Surface Area of RightPrecuneus
#'   \item ST111TA N mm Cortical Thickness Average of RightPrecuneus
#'   \item ST111TS N mm Cortical Thickness Standard Deviation of RightPrecuneus
#'   \item ST112SV N mm3 Volume (WM Parcellation) of RightPutamen
#'   \item ST113CV N mm3 Volume (Cortical Parcellation) of RightRostralAnteriorCingulate
#'   \item ST113SA N mm2 Surface Area of RightRostralAnteriorCingulate
#'   \item ST113TA N mm Cortical Thickness Average of RightRostralAnteriorCingulate
#'   \item ST113TS N mm Cortical Thickness Standard Deviation of RightRostralAnteriorCingulate
#'   \item ST114CV N mm3 Volume (Cortical Parcellation) of RightRostralMiddleFrontal
#'   \item ST114SA N mm2 Surface Area of RightRostralMiddleFrontal
#'   \item ST114TA N mm Cortical Thickness Average of RightRostralMiddleFrontal
#'   \item ST114TS N mm Cortical Thickness Standard Deviation of RightRostralMiddleFrontal
#'   \item ST115CV N mm3 Volume (Cortical Parcellation) of RightSuperiorFrontal
#'   \item ST115SA N mm2 Surface Area of RightSuperiorFrontal
#'   \item ST115TA N mm Cortical Thickness Average of RightSuperiorFrontal
#'   \item ST115TS N mm Cortical Thickness Standard Deviation of RightSuperiorFrontal
#'   \item ST116CV N mm3 Volume (Cortical Parcellation) of RightSuperiorParietal
#'   \item ST116SA N mm2 Surface Area of RightSuperiorParietal
#'   \item ST116TA N mm Cortical Thickness Average of RightSuperiorParietal
#'   \item ST116TS N mm Cortical Thickness Standard Deviation of RightSuperiorParietal
#'   \item ST117CV N mm3 Volume (Cortical Parcellation) of RightSuperiorTemporal
#'   \item ST117SA N mm2 Surface Area of RightSuperiorTemporal
#'   \item ST117TA N mm Cortical Thickness Average of RightSuperiorTemporal
#'   \item ST117TS N mm Cortical Thickness Standard Deviation of RightSuperiorTemporal
#'   \item ST118CV N mm3 Volume (Cortical Parcellation) of RightSupramarginal
#'   \item ST118SA N mm2 Surface Area of RightSupramarginal
#'   \item ST118TA N mm Cortical Thickness Average of RightSupramarginal
#'   \item ST118TS N mm Cortical Thickness Standard Deviation of RightSupramarginal
#'   \item ST119CV N mm3 Volume (Cortical Parcellation) of RightTemporalPole
#'   \item ST119SA N mm2 Surface Area of RightTemporalPole
#'   \item ST119TA N mm Cortical Thickness Average of RightTemporalPole
#'   \item ST119TS N mm Cortical Thickness Standard Deviation of RightTemporalPole
#'   \item ST11SV N mm3 Volume (WM Parcellation) of LeftAccumbensArea
#'   \item ST120SV N mm3 Volume (WM Parcellation) of RightThalamus
#'   \item ST121CV N mm3 Volume (Cortical Parcellation) of RightTransverseTemporal
#'   \item ST121SA N mm2 Surface Area of RightTransverseTemporal
#'   \item ST121TA N mm Cortical Thickness Average of RightTransverseTemporal
#'   \item ST121TS N mm Cortical Thickness Standard Deviation of RightTransverseTemporal
#'   \item ST122SV N mm3 Volume (WM Parcellation) of RightUndetermined
#'   \item ST123CV N mm3 Volume (Cortical Parcellation) of RightUnknown
#'   \item ST123SA N mm2 Surface Area of RightUnknown
#'   \item ST123TA N mm Cortical Thickness Average of RightUnknown
#'   \item ST123TS N mm Cortical Thickness Standard Deviation of RightUnknown
#'   \item ST124SV N mm3 Volume (WM Parcellation) of RightVentralDC
#'   \item ST125SV N mm3 Volume (WM Parcellation) of RightVessel
#'   \item ST126SV N mm3 Volume (WM Parcellation) of RightWMHypoIntensities
#'   \item ST127SV N mm3 Volume (WM Parcellation) of ThirdVentricle
#'   \item ST128SV N mm3 Volume (WM Parcellation) of WMHypoIntensities
#'   \item ST129CV N mm3 Volume (Cortical Parcellation) of LeftInsula
#'   \item ST129SA N mm2 Surface Area of LeftInsula
#'   \item ST129TA N mm Cortical Thickness Average of LeftInsula
#'   \item ST129TS N mm Cortical Thickness Standard Deviation of LeftInsula
#'   \item ST12SV N mm3 Volume (WM Parcellation) of LeftAmygdala
#'   \item ST130CV N mm3 Volume (Cortical Parcellation) of RightInsula
#'   \item ST130SA N mm2 Surface Area of RightInsula
#'   \item ST130TA N mm Cortical Thickness Average of RightInsula
#'   \item ST130TS N mm Cortical Thickness Standard Deviation of RightInsula
#'   \item ST13CV N mm3 Volume (Cortical Parcellation) of LeftBankssts
#'   \item ST13SA N mm2 Surface Area of LeftBankssts
#'   \item ST13TA N mm Cortical Thickness Average of LeftBankssts
#'   \item ST13TS N mm Cortical Thickness Standard Deviation of LeftBankssts
#'   \item ST14CV N mm3 Volume (Cortical Parcellation) of LeftCaudalAnteriorCingulate
#'   \item ST14SA N mm2 Surface Area of LeftCaudalAnteriorCingulate
#'   \item ST14TA N mm Cortical Thickness Average of LeftCaudalAnteriorCingulate
#'   \item ST14TS N mm Cortical Thickness Standard Deviation of LeftCaudalAnteriorCingulate
#'   \item ST15CV N mm3 Volume (Cortical Parcellation) of LeftCaudalMiddleFrontal
#'   \item ST15SA N mm2 Surface Area of LeftCaudalMiddleFrontal
#'   \item ST15TA N mm Cortical Thickness Average of LeftCaudalMiddleFrontal
#'   \item ST15TS N mm Cortical Thickness Standard Deviation of LeftCaudalMiddleFrontal
#'   \item ST16SV N mm3 Volume (WM Parcellation) of LeftCaudate
#'   \item ST17SV N mm3 Volume (WM Parcellation) of LeftCerebellumCortex
#'   \item ST18SV N mm3 Volume (WM Parcellation) of LeftCerebellumWM
#'   \item ST19SV N mm3 Volume (WM Parcellation) of LeftCerebralCortex
#'   \item ST1SV N mm3 Volume (WM Parcellation) of Brainstem
#'   \item ST20SV N mm3 Volume (WM Parcellation) of LeftCerebralWM
#'   \item ST21SV N mm3 Volume (WM Parcellation) of LeftChoroidPlexus
#'   \item ST22CV N mm3 Volume (Cortical Parcellation) of LeftCorpusCallosum
#'   \item ST22SA N mm2 Surface Area of LeftCorpusCallosum
#'   \item ST22TA N mm Cortical Thickness Average of LeftCorpusCallosum
#'   \item ST22TS N mm Cortical Thickness Standard Deviation of LeftCorpusCallosum
#'   \item ST23CV N mm3 Volume (Cortical Parcellation) of LeftCuneus
#'   \item ST23SA N mm2 Surface Area of LeftCuneus
#'   \item ST23TA N mm Cortical Thickness Average of LeftCuneus
#'   \item ST23TS N mm Cortical Thickness Standard Deviation of LeftCuneus
#'   \item ST24CV N mm3 Volume (Cortical Parcellation) of LeftEntorhinal
#'   \item ST24SA N mm2 Surface Area of LeftEntorhinal
#'   \item ST24TA N mm Cortical Thickness Average of LeftEntorhinal
#'   \item ST24TS N mm Cortical Thickness Standard Deviation of LeftEntorhinal
#'   \item ST25CV N mm3 Volume (Cortical Parcellation) of LeftFrontalPole
#'   \item ST25SA N mm2 Surface Area of LeftFrontalPole
#'   \item ST25TA N mm Cortical Thickness Average of LeftFrontalPole
#'   \item ST25TS N mm Cortical Thickness Standard Deviation of LeftFrontalPole
#'   \item ST26CV N mm3 Volume (Cortical Parcellation) of LeftFusiform
#'   \item ST26SA N mm2 Surface Area of LeftFusiform
#'   \item ST26TA N mm Cortical Thickness Average of LeftFusiform
#'   \item ST26TS N mm Cortical Thickness Standard Deviation of LeftFusiform
#'   \item ST27SA N mm2 Surface Area of LeftHemisphere
#'   \item ST28CV N mm3 Volume (Cortical Parcellation) of LeftHemisphereWM
#'   \item ST29SV N mm3 Volume (WM Parcellation) of LeftHippocampus
#'   \item ST2SV N mm3 Volume (WM Parcellation) of CorpusCallosumAnterior
#'   \item ST30SV N mm3 Volume (WM Parcellation) of LeftInferiorLateralVentricle
#'   \item ST31CV N mm3 Volume (Cortical Parcellation) of LeftInferiorParietal
#'   \item ST31SA N mm2 Surface Area of LeftInferiorParietal
#'   \item ST31TA N mm Cortical Thickness Average of LeftInferiorParietal
#'   \item ST31TS N mm Cortical Thickness Standard Deviation of LeftInferiorParietal
#'   \item ST32CV N mm3 Volume (Cortical Parcellation) of LeftInferiorTemporal
#'   \item ST32SA N mm2 Surface Area of LeftInferiorTemporal
#'   \item ST32TA N mm Cortical Thickness Average of LeftInferiorTemporal
#'   \item ST32TS N mm Cortical Thickness Standard Deviation of LeftInferiorTemporal
#'   \item ST33SV N mm3 Volume (WM Parcellation) of LeftInterior
#'   \item ST34CV N mm3 Volume (Cortical Parcellation) of LeftIsthmusCingulate
#'   \item ST34SA N mm2 Surface Area of LeftIsthmusCingulate
#'   \item ST34TA N mm Cortical Thickness Average of LeftIsthmusCingulate
#'   \item ST34TS N mm Cortical Thickness Standard Deviation of LeftIsthmusCingulate
#'   \item ST35CV N mm3 Volume (Cortical Parcellation) of LeftLateralOccipital
#'   \item ST35SA N mm2 Surface Area of LeftLateralOccipital
#'   \item ST35TA N mm Cortical Thickness Average of LeftLateralOccipital
#'   \item ST35TS N mm Cortical Thickness Standard Deviation of LeftLateralOccipital
#'   \item ST36CV N mm3 Volume (Cortical Parcellation) of LeftLateralOrbitofrontal
#'   \item ST36SA N mm2 Surface Area of LeftLateralOrbitofrontal
#'   \item ST36TA N mm Cortical Thickness Average of LeftLateralOrbitofrontal
#'   \item ST36TS N mm Cortical Thickness Standard Deviation of LeftLateralOrbitofrontal
#'   \item ST37SV N mm3 Volume (WM Parcellation) of LeftLateralVentricle
#'   \item ST38CV N mm3 Volume (Cortical Parcellation) of LeftLingual
#'   \item ST38SA N mm2 Surface Area of LeftLingual
#'   \item ST38TA N mm Cortical Thickness Average of LeftLingual
#'   \item ST38TS N mm Cortical Thickness Standard Deviation of LeftLingual
#'   \item ST39CV N mm3 Volume (Cortical Parcellation) of LeftMedialOrbitofrontal
#'   \item ST39SA N mm2 Surface Area of LeftMedialOrbitofrontal
#'   \item ST39TA N mm Cortical Thickness Average of LeftMedialOrbitofrontal
#'   \item ST39TS N mm Cortical Thickness Standard Deviation of LeftMedialOrbitofrontal
#'   \item ST3SV N mm3 Volume (WM Parcellation) of CorpusCallosumCentral
#'   \item ST40CV N mm3 Volume (Cortical Parcellation) of LeftMiddleTemporal
#'   \item ST40SA N mm2 Surface Area of LeftMiddleTemporal
#'   \item ST40TA N mm Cortical Thickness Average of LeftMiddleTemporal
#'   \item ST40TS N mm Cortical Thickness Standard Deviation of LeftMiddleTemporal
#'   \item ST41SV N mm3 Volume (WM Parcellation) of LeftNonWMHypoIntensities
#'   \item ST42SV N mm3 Volume (WM Parcellation) of LeftPallidum
#'   \item ST43CV N mm3 Volume (Cortical Parcellation) of LeftParacentral
#'   \item ST43SA N mm2 Surface Area of LeftParacentral
#'   \item ST43TA N mm Cortical Thickness Average of LeftParacentral
#'   \item ST43TS N mm Cortical Thickness Standard Deviation of LeftParacentral
#'   \item ST44CV N mm3 Volume (Cortical Parcellation) of LeftParahippocampal
#'   \item ST44SA N mm2 Surface Area of LeftParahippocampal
#'   \item ST44TA N mm Cortical Thickness Average of LeftParahippocampal
#'   \item ST44TS N mm Cortical Thickness Standard Deviation of LeftParahippocampal
#'   \item ST45CV N mm3 Volume (Cortical Parcellation) of LeftParsOpercularis
#'   \item ST45SA N mm2 Surface Area of LeftParsOpercularis
#'   \item ST45TA N mm Cortical Thickness Average of LeftParsOpercularis
#'   \item ST45TS N mm Cortical Thickness Standard Deviation of LeftParsOpercularis
#'   \item ST46CV N mm3 Volume (Cortical Parcellation) of LeftParsOrbitalis
#'   \item ST46SA N mm2 Surface Area of LeftParsOrbitalis
#'   \item ST46TA N mm Cortical Thickness Average of LeftParsOrbitalis
#'   \item ST46TS N mm Cortical Thickness Standard Deviation of LeftParsOrbitalis
#'   \item ST47CV N mm3 Volume (Cortical Parcellation) of LeftParsTriangularis
#'   \item ST47SA N mm2 Surface Area of LeftParsTriangularis
#'   \item ST47TA N mm Cortical Thickness Average of LeftParsTriangularis
#'   \item ST47TS N mm Cortical Thickness Standard Deviation of LeftParsTriangularis
#'   \item ST48CV N mm3 Volume (Cortical Parcellation) of LeftPericalcarine
#'   \item ST48SA N mm2 Surface Area of LeftPericalcarine
#'   \item ST48TA N mm Cortical Thickness Average of LeftPericalcarine
#'   \item ST48TS N mm Cortical Thickness Standard Deviation of LeftPericalcarine
#'   \item ST49CV N mm3 Volume (Cortical Parcellation) of LeftPostcentral
#'   \item ST49SA N mm2 Surface Area of LeftPostcentral
#'   \item ST49TA N mm Cortical Thickness Average of LeftPostcentral
#'   \item ST49TS N mm Cortical Thickness Standard Deviation of LeftPostcentral
#'   \item ST4SV N mm3 Volume (WM Parcellation) of CorpusCallosumMidAnterior
#'   \item ST50CV N mm3 Volume (Cortical Parcellation) of LeftPosteriorCingulate
#'   \item ST50SA N mm2 Surface Area of LeftPosteriorCingulate
#'   \item ST50TA N mm Cortical Thickness Average of LeftPosteriorCingulate
#'   \item ST50TS N mm Cortical Thickness Standard Deviation of LeftPosteriorCingulate
#'   \item ST51CV N mm3 Volume (Cortical Parcellation) of LeftPrecentral
#'   \item ST51SA N mm2 Surface Area of LeftPrecentral
#'   \item ST51TA N mm Cortical Thickness Average of LeftPrecentral
#'   \item ST51TS N mm Cortical Thickness Standard Deviation of LeftPrecentral
#'   \item ST52CV N mm3 Volume (Cortical Parcellation) of LeftPrecuneus
#'   \item ST52SA N mm2 Surface Area of LeftPrecuneus
#'   \item ST52TA N mm Cortical Thickness Average of LeftPrecuneus
#'   \item ST52TS N mm Cortical Thickness Standard Deviation of LeftPrecuneus
#'   \item ST53SV N mm3 Volume (WM Parcellation) of LeftPutamen
#'   \item ST54CV N mm3 Volume (Cortical Parcellation) of LeftRostralAnteriorCingulate
#'   \item ST54SA N mm2 Surface Area of LeftRostralAnteriorCingulate
#'   \item ST54TA N mm Cortical Thickness Average of LeftRostralAnteriorCingulate
#'   \item ST54TS N mm Cortical Thickness Standard Deviation of LeftRostralAnteriorCingulate
#'   \item ST55CV N mm3 Volume (Cortical Parcellation) of LeftRostralMiddleFrontal
#'   \item ST55SA N mm2 Surface Area of LeftRostralMiddleFrontal
#'   \item ST55TA N mm Cortical Thickness Average of LeftRostralMiddleFrontal
#'   \item ST55TS N mm Cortical Thickness Standard Deviation of LeftRostralMiddleFrontal
#'   \item ST56CV N mm3 Volume (Cortical Parcellation) of LeftSuperiorFrontal
#'   \item ST56SA N mm2 Surface Area of LeftSuperiorFrontal
#'   \item ST56TA N mm Cortical Thickness Average of LeftSuperiorFrontal
#'   \item ST56TS N mm Cortical Thickness Standard Deviation of LeftSuperiorFrontal
#'   \item ST57CV N mm3 Volume (Cortical Parcellation) of LeftSuperiorParietal
#'   \item ST57SA N mm2 Surface Area of LeftSuperiorParietal
#'   \item ST57TA N mm Cortical Thickness Average of LeftSuperiorParietal
#'   \item ST57TS N mm Cortical Thickness Standard Deviation of LeftSuperiorParietal
#'   \item ST58CV N mm3 Volume (Cortical Parcellation) of LeftSuperiorTemporal
#'   \item ST58SA N mm2 Surface Area of LeftSuperiorTemporal
#'   \item ST58TA N mm Cortical Thickness Average of LeftSuperiorTemporal
#'   \item ST58TS N mm Cortical Thickness Standard Deviation of LeftSuperiorTemporal
#'   \item ST59CV N mm3 Volume (Cortical Parcellation) of LeftSupramarginal
#'   \item ST59SA N mm2 Surface Area of LeftSupramarginal
#'   \item ST59TA N mm Cortical Thickness Average of LeftSupramarginal
#'   \item ST59TS N mm Cortical Thickness Standard Deviation of LeftSupramarginal
#'   \item ST5SV N mm3 Volume (WM Parcellation) of CorpusCallosumMidPosterior
#'   \item ST60CV N mm3 Volume (Cortical Parcellation) of LeftTemporalPole
#'   \item ST60SA N mm2 Surface Area of LeftTemporalPole
#'   \item ST60TA N mm Cortical Thickness Average of LeftTemporalPole
#'   \item ST60TS N mm Cortical Thickness Standard Deviation of LeftTemporalPole
#'   \item ST61SV N mm3 Volume (WM Parcellation) of LeftThalamus
#'   \item ST62CV N mm3 Volume (Cortical Parcellation) of LeftTransverseTemporal
#'   \item ST62SA N mm2 Surface Area of LeftTransverseTemporal
#'   \item ST62TA N mm Cortical Thickness Average of LeftTransverseTemporal
#'   \item ST62TS N mm Cortical Thickness Standard Deviation of LeftTransverseTemporal
#'   \item ST63SV N mm3 Volume (WM Parcellation) of LeftUndetermined
#'   \item ST64CV N mm3 Volume (Cortical Parcellation) of LeftUnknown
#'   \item ST64SA N mm2 Surface Area of LeftUnknown
#'   \item ST64TA N mm Cortical Thickness Average of LeftUnknown
#'   \item ST64TS N mm Cortical Thickness Standard Deviation of LeftUnknown
#'   \item ST65SV N mm3 Volume (WM Parcellation) of LeftVentralDC
#'   \item ST66SV N mm3 Volume (WM Parcellation) of LeftVessel
#'   \item ST67SV N mm3 Volume (WM Parcellation) of LeftWMHypoIntensities
#'   \item ST68SV N mm3 Volume (WM Parcellation) of NonWMHypoIntensities
#'   \item ST69SV N mm3 Volume (WM Parcellation) of OpticChiasm
#'   \item ST6SV N mm3 Volume (WM Parcellation) of CorpusCallosumPosterior
#'   \item ST70SV N mm3 Volume (WM Parcellation) of RightAccumbensArea
#'   \item ST71SV N mm3 Volume (WM Parcellation) of RightAmygdala
#'   \item ST72CV N mm3 Volume (Cortical Parcellation) of RightBankssts
#'   \item ST72SA N mm2 Surface Area of RightBankssts
#'   \item ST72TA N mm Cortical Thickness Average of RightBankssts
#'   \item ST72TS N mm Cortical Thickness Standard Deviation of RightBankssts
#'   \item ST73CV N mm3 Volume (Cortical Parcellation) of RightCaudalAnteriorCingulate
#'   \item ST73SA N mm2 Surface Area of RightCaudalAnteriorCingulate
#'   \item ST73TA N mm Cortical Thickness Average of RightCaudalAnteriorCingulate
#'   \item ST73TS N mm Cortical Thickness Standard Deviation of RightCaudalAnteriorCingulate
#'   \item ST74CV N mm3 Volume (Cortical Parcellation) of RightCaudalMiddleFrontal
#'   \item ST74SA N mm2 Surface Area of RightCaudalMiddleFrontal
#'   \item ST74TA N mm Cortical Thickness Average of RightCaudalMiddleFrontal
#'   \item ST74TS N mm Cortical Thickness Standard Deviation of RightCaudalMiddleFrontal
#'   \item ST75SV N mm3 Volume (WM Parcellation) of RightCaudate
#'   \item ST76SV N mm3 Volume (WM Parcellation) of RightCerebellumCortex
#'   \item ST77SV N mm3 Volume (WM Parcellation) of RightCerebellumWM
#'   \item ST78SV N mm3 Volume (WM Parcellation) of RightCerebralCortex
#'   \item ST79SV N mm3 Volume (WM Parcellation) of RightCerebralWM
#'   \item ST7SV N mm3 Volume (WM Parcellation) of Csf
#'   \item ST80SV N mm3 Volume (WM Parcellation) of RightChoroidPlexus
#'   \item ST81CV N mm3 Volume (Cortical Parcellation) of RightCorpusCallosum
#'   \item ST81SA N mm2 Surface Area of RightCorpusCallosum
#'   \item ST81TA N mm Cortical Thickness Average of RightCorpusCallosum
#'   \item ST81TS N mm Cortical Thickness Standard Deviation of RightCorpusCallosum
#'   \item ST82CV N mm3 Volume (Cortical Parcellation) of RightCuneus
#'   \item ST82SA N mm2 Surface Area of RightCuneus
#'   \item ST82TA N mm Cortical Thickness Average of RightCuneus
#'   \item ST82TS N mm Cortical Thickness Standard Deviation of RightCuneus
#'   \item ST83CV N mm3 Volume (Cortical Parcellation) of RightEntorhinal
#'   \item ST83SA N mm2 Surface Area of RightEntorhinal
#'   \item ST83TA N mm Cortical Thickness Average of RightEntorhinal
#'   \item ST83TS N mm Cortical Thickness Standard Deviation of RightEntorhinal
#'   \item ST84CV N mm3 Volume (Cortical Parcellation) of RightFrontalPole
#'   \item ST84SA N mm2 Surface Area of RightFrontalPole
#'   \item ST84TA N mm Cortical Thickness Average of RightFrontalPole
#'   \item ST84TS N mm Cortical Thickness Standard Deviation of RightFrontalPole
#'   \item ST85CV N mm3 Volume (Cortical Parcellation) of RightFusiform
#'   \item ST85SA N mm2 Surface Area of RightFusiform
#'   \item ST85TA N mm Cortical Thickness Average of RightFusiform
#'   \item ST85TS N mm Cortical Thickness Standard Deviation of RightFusiform
#'   \item ST86SA N mm2 Surface Area of RightHemisphere
#'   \item ST87CV N mm3 Volume (Cortical Parcellation) of RightHemisphereWM
#'   \item ST88SV N mm3 Volume (WM Parcellation) of RightHippocampus
#'   \item ST89SV N mm3 Volume (WM Parcellation) of RightInferiorLateralVentricle
#'   \item ST8SV N mm3 Volume (WM Parcellation) of FifthVentricle
#'   \item ST90CV N mm3 Volume (Cortical Parcellation) of RightInferiorParietal
#'   \item ST90SA N mm2 Surface Area of RightInferiorParietal
#'   \item ST90TA N mm Cortical Thickness Average of RightInferiorParietal
#'   \item ST90TS N mm Cortical Thickness Standard Deviation of RightInferiorParietal
#'   \item ST91CV N mm3 Volume (Cortical Parcellation) of RightInferiorTemporal
#'   \item ST91SA N mm2 Surface Area of RightInferiorTemporal
#'   \item ST91TA N mm Cortical Thickness Average of RightInferiorTemporal
#'   \item ST91TS N mm Cortical Thickness Standard Deviation of RightInferiorTemporal
#'   \item ST92SV N mm3 Volume (WM Parcellation) of RightInterior
#'   \item ST93CV N mm3 Volume (Cortical Parcellation) of RightIsthmusCingulate
#'   \item ST93SA N mm2 Surface Area of RightIsthmusCingulate
#'   \item ST93TA N mm Cortical Thickness Average of RightIsthmusCingulate
#'   \item ST93TS N mm Cortical Thickness Standard Deviation of RightIsthmusCingulate
#'   \item ST94CV N mm3 Volume (Cortical Parcellation) of RightLateralOccipital
#'   \item ST94SA N mm2 Surface Area of RightLateralOccipital
#'   \item ST94TA N mm Cortical Thickness Average of RightLateralOccipital
#'   \item ST94TS N mm Cortical Thickness Standard Deviation of RightLateralOccipital
#'   \item ST95CV N mm3 Volume (Cortical Parcellation) of RightLateralOrbitofrontal
#'   \item ST95SA N mm2 Surface Area of RightLateralOrbitofrontal
#'   \item ST95TA N mm Cortical Thickness Average of RightLateralOrbitofrontal
#'   \item ST95TS N mm Cortical Thickness Standard Deviation of RightLateralOrbitofrontal
#'   \item ST96SV N mm3 Volume (WM Parcellation) of RightLateralVentricle
#'   \item ST97CV N mm3 Volume (Cortical Parcellation) of RightLingual
#'   \item ST97SA N mm2 Surface Area of RightLingual
#'   \item ST97TA N mm Cortical Thickness Average of RightLingual
#'   \item ST97TS N mm Cortical Thickness Standard Deviation of RightLingual
#'   \item ST98CV N mm3 Volume (Cortical Parcellation) of RightMedialOrbitofrontal
#'   \item ST98SA N mm2 Surface Area of RightMedialOrbitofrontal
#'   \item ST98TA N mm Cortical Thickness Average of RightMedialOrbitofrontal
#'   \item ST98TS N mm Cortical Thickness Standard Deviation of RightMedialOrbitofrontal
#'   \item ST99CV N mm3 Volume (Cortical Parcellation) of RightMiddleTemporal
#'   \item ST99SA N mm2 Surface Area of RightMiddleTemporal
#'   \item ST99TA N mm Cortical Thickness Average of RightMiddleTemporal
#'   \item ST99TS N mm Cortical Thickness Standard Deviation of RightMiddleTemporal
#'   \item ST9SV N mm3 Volume (WM Parcellation) of FourthVentricle
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name ucsffsx
#' @usage data(ucsffsx)
#' @format A data frame with 4486 rows and 366 variables
NULL

#' UCSF SNT Hippocampal Volumes
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/UCSFSNTVOL/UCSFMRI_Analysis.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item RECNO N  
#'   \item EXAMDATE D  Examination Date
#'   \item LONISID T  LONI Study ID
#'   \item LONIUID T  LONI Unique Series ID
#'   \item IMAGEUID T  imageUID
#'   \item FLDSTRENG T  Field Strength
#'   \item SNTDATE D  Date Volume Generated
#'   \item ATLAS T  Name of Atlas Used
#'   \item LEFTHIPPO N mm3 Left Hippocampus Volume
#'   \item RIGHTHIPPO N mm3 Right Hippocampus Volume
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name ucsfsntvol
#' @usage data(ucsfsntvol)
#' @format A data frame with 1881 rows and 15 variables
NULL

#' UPENN Longitudinal Biomarker Data
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/UPENNBIOMK2/ADNI_Biomarker_Core_News_April_2009_2.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N -4 Participant roster ID
#'   \item SITEID N -4 Site ID
#'   \item VISCODE T -4 Visit code
#'   \item USERDATE S -4 Date record created
#'   \item TTAU N -4 -4
#'   \item ABETA142 N -4 -4
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name upennbiomk2
#' @usage data(upennbiomk2)
#' @format A data frame with 834 rows and 7 variables
NULL

#' UPENN Longitudinal Biomarker Data (3 yr)
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/UPENNBIOMK3/ADNI_1_Longitudinal_dataset_overview_12_21_2011_for_ADNI_ADCS_website_upload.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N -4 Participant roster ID
#'   \item SITEID N -4 Site ID
#'   \item VISCODE T -4 Visit code
#'   \item USERDATE S -4 Date record created
#'   \item ABETA N -4 -4
#'   \item TAU N -4 -4
#'   \item PTAU N -4 -4
#'   \item TAUAB N -4 -4
#'   \item PTAUAB N -4 -4
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name upennbiomk3
#' @usage data(upennbiomk3)
#' @format A data frame with 314 rows and 10 variables
NULL

#' UPENN Longitudinal Biomarker Data (4 yr)
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/UPENNBIOMK4/ADNI_1_Longitudinal_dataset_overview_12_21_2011_for_ADNI_ADCS_website_upload.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item LP.DATE D -4 LP Date
#'   \item TAU -4 (pg/mL) TAU
#'   \item ABETA -4 (pg/mL) ABETA
#'   \item PTAU -4 (pg/mL) PTAU
#'   \item TAU.ABETA -4 -4 TAU/ABETA
#'   \item PTAU.ABETA -4 -4 PTAU/ABETA
#'   \item UPDATE.STAMP -4 -4 Update stamp
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name upennbiomk4
#' @usage data(upennbiomk4)
#' @format A data frame with 495 rows and 10 variables
NULL

#' ADNI GO and ADNI 2: first batch analysis of CSF biomarkers
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/UPENNBIOMK5/ADNI-GO+2_analytical_signed_3_6_28_2012.pdf}, \url{https://adni.bitbucket.io/reference/docs/UPENNBIOMK5/ADNI_Methods_Template_Shaw_Trojanowski_6_30_2012.pdf}, \url{https://adni.bitbucket.io/reference/docs/UPENNBIOMK5/ADNI_Methods_Template_Shaw%20Trojanowski%20Corrected%20Anchoring%20of%202012%20dataset%2010%2031%2013.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item VISCODE2 -4 -4 Translated visit code
#'   \item RUNDATE D -4 Run date
#'   \item ABETA -4 pg/mL ABETA
#'   \item TAU -4 pg/mL TAU
#'   \item PTAU -4 pg/mL PTAU
#'   \item ABETA.RAW -4 -4 -4
#'   \item TAU.RAW -4 -4 -4
#'   \item PTAU.RAW -4 -4 -4
#' }
#'
#' @examples
#' \donotrun{
#' describe(upennbiomk5)
#' }
#' @docType data
#' @keywords datasets
#' @name upennbiomk5
#' @usage data(upennbiomk5)
#' @format A data frame with 389 rows and 10 variables
NULL

#' ADNI 2: second batch analysis of CSF biomarkers
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/UPENNBIOMK6/ADNI%20LT2013%20analytical%20signed%20all.pdf}, \url{https://adni.bitbucket.io/reference/docs/UPENNBIOMK6/ADNI_Methods_Shaw%20Trojanowski%20for%202013%20ADNI%20II%207%201%202013.pdf}, \url{https://adni.bitbucket.io/reference/docs/UPENNBIOMK6/ADNI_Methods_Template_Shaw%20Trojanowski%20Corrected%20Anchoring%20of%202012%20dataset%2010%2031%2013.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID   Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item EXAMDATE D  Examination Date
#'   \item RUNDATE D  Run date
#'   \item ABETA  pg/mL ABETA
#'   \item TAU  pg/mL TAU
#'   \item PTAU  pg/mL PTAU
#' }
#'
#' @examples
#' \donotrun{
#' describe(upennbiomk6)
#' }
#' @docType data
#' @keywords datasets
#' @name upennbiomk6
#' @usage data(upennbiomk6)
#' @format A data frame with 692 rows and 8 variables
NULL

#' UPENN-Third batch analysis of CSF biomarkers
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/UPENNBIOMK7/ADNI%20LT2014%20analytical%20signed.pdf}, \url{https://adni.bitbucket.io/reference/docs/UPENNBIOMK7/ADNI_Methods_Template_Shaw%20Trojanowski%20for%202014%20ADNI%20II%206%209%202014.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID   Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item VISCODE2 -4 -4 Translated visit code
#'   \item EXAMDATE D  Examination Date
#'   \item RUNDATE D  Run date
#'   \item ABETA  pg/mL ABETA
#'   \item TAU  pg/mL TAU
#'   \item PTAU  pg/mL PTAU
#'   \item ABETA.RAW  pg/mL ABETA
#'   \item TAU.RAW  pg/mL TAU
#'   \item PTAU.RAW  pg/mL PTAU
#' }
#'
#' @examples
#' \donotrun{
#' describe(upennbiomk7)
#' }
#' @docType data
#' @keywords datasets
#' @name upennbiomk7
#' @usage data(upennbiomk7)
#' @format A data frame with 428 rows and 11 variables
NULL

#' UPENN ADNI2 Fourth Batch Analyses of CSF Biomarkers
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/UPENNBIOMK8/ADNI_Methods_Template_Shaw%20Trojanowski%20for%202015%20ADNI%20II%204%2010%202015.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID   Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item VISCODE2 -4 -4 Translated visit code
#'   \item EXAMDATE D  Examination Date
#'   \item RUNDATE D  Run date
#'   \item ABETA  pg/mL ABETA
#'   \item TAU  pg/mL TAU
#'   \item PTAU  pg/mL PTAU
#'   \item ABETA.RAW  pg/mL ABETA
#'   \item TAU.RAW  pg/mL TAU
#'   \item PTAU.RAW  pg/mL PTAU
#' }
#'
#' @examples
#' \donotrun{
#' describe(upennbiomk8)
#' }
#' @docType data
#' @keywords datasets
#' @name upennbiomk8
#' @usage data(upennbiomk8)
#' @format A data frame with 230 rows and 11 variables
NULL

#' UPENN CSF Biomarkers Elecsys
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/UPENNBIOMK9/ADNI%20METHODS%20doc%20for%20Roche%20Elecsys%20CSF%20immunoassays%20vfinal.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4  Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item VISCODE2 -4 -4 Translated visit code
#'   \item EXAMDATE -4  Examination Date
#'   \item PHASE -4  Study Phase
#'   \item VID -4  Visit ID
#'   \item BARCODE -4  Sample Barcode ID
#'   \item BATCH -4  Analytical batch of results
#'   \item KIT -4  Reagents lot number
#'   \item STDS -4  Calibrators and Quality Controls lot number
#'   \item RUNDATE -4  Date of analytical run
#'   \item ABETA -4 pg/ml Result
#'   \item TAU -4 pg/ml Result
#'   \item PTAU -4 pg/ml Result
#'   \item COMMENT -4  Comment
#' }
#'
#' @examples
#' \donotrun{
#' describe(upennbiomk9)
#' }
#' @docType data
#' @keywords datasets
#' @name upennbiomk9
#' @usage data(upennbiomk9)
#' @format A data frame with 2401 rows and 15 variables
NULL

#' UPENN CSF Biomarker Master
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/UPENNBIOMK_MASTER/ADNI_Methods_Template_Shaw%20Figurski%20Waligorska%20Trojanowski%20overview%20for%20CSF%20Ab1-42%20tau%20and%20ptau181%20AlzBio3%20immunoassay%20datav3%20(5).pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4  Participant roster ID
#'   \item VISCODE -4  Visit code
#'   \item BATCH -4  Name of LONI table, corresponding to analytical batch of results
#'   \item KIT -4  Reagents lot number
#'   \item STDS -4  Calibrators and Quality Controls lot number
#'   \item DRAWDTE -4  Date of CSF draw
#'   \item RUNDATE -4  Date of analytical run
#'   \item ABETA -4 pg/ml Result rescaled to UPENNBIOMK
#'   \item TAU -4 pg/ml Result rescaled to UPENNBIOMK
#'   \item PTAU -4 pg/ml Result rescaled to UPENNBIOMK
#'   \item ABETA_RAW -4 pg/ml Original (raw) result, before rescaling
#'   \item TAU_RAW -4 pg/ml Original (raw) result, before rescaling
#'   \item PTAU_RAW -4 pg/ml Original (raw) result, before rescaling
#' }
#'
#' @examples
#' \donotrun{
#' describe(upennbiomk_master)
#' }
#' @docType data
#' @keywords datasets
#' @name upennbiomk_master
#' @usage data(upennbiomk_master)
#' @format A data frame with 5876 rows and 14 variables
NULL

#' UPENN Biomarker Data
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/UPENNBIOMK/ADNI_Biomarker_Core_News_April_2009_2.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item USERDATE2 S  Date record last updated
#'   \item TAU N  
#'   \item ABETA142 N  
#'   \item PTAU181P N  CSF pTau181p concentration data for BASELINE, YEAR1 and YEAR 2 will bequarantined temporarily due to our discovery that for some individualsamples there appears to be greater analytical variability than shouldbe the case. We are working with the manufacturer of the immunoassayreagents we use for the CSF biomarker measurements, Innogenetics, andhave worked out a procedural change that eliminates this extraneousnoise. Once the retesting analyses are completed the new data will beuploaded with accompanying description.ADNI Biomarker Core laboratory at UPenn
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name upennbiomk
#' @usage data(upennbiomk)
#' @format A data frame with 416 rows and 10 variables
NULL

#' 2D-UPLC tandem mass spectrometry measurement of ABeta1-42, ABeta1-40 and ABeta1-38 in ADNI1 BASELINE CSF
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/UPENNMSMSABETA/ADNI_Methods_Template_Biomarker%20Core%202D%20UPLC%20tandem%20mass%20spectrometry%20analyses%20of%20ADNI1%20BASELINE%20CSF.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID NA  Participant roster ID
#'   \item VISCODE NA  Visit code
#'   \item DRAWDATE NA  Draw date
#'   \item RUNDATE NA  Run date
#'   \item ABETA42 NA pg/mL Amyloid Beta 1-42
#'   \item ABETA40 NA pg/mL Amyloid Beta 1-40
#'   \item ABETA38 NA pg/mL Amyloid Beta 1-38
#' }
#'
#' @examples
#' \donotrun{
#' describe(upennmsmsabeta)
#' }
#' @docType data
#' @keywords datasets
#' @name upennmsmsabeta
#' @usage data(upennmsmsabeta)
#' @format A data frame with 400 rows and 8 variables
NULL

#' UPENN Plasma Biomarker Data
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N NA Participant roster ID
#'   \item VISCODE T NA Visit code
#'   \item AB40 N NA Abeta1-40 result in plasma
#'   \item AB42 N NA Abeta1-42 result in plasma
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name upennplasma
#' @usage data(upennplasma)
#' @format A data frame with 2454 rows and 5 variables
NULL

#' UPENN - Hierarchical Parcellation of MRI Using Multi-atlas Labeling Methods
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/UPENN_ROI_MARS/Multi-atlas_ROI_ADNI_Methods_mod_April2016.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item EXAMDATE -4 -4 Examination Date
#'   \item VERSION -4 -4 -4
#'   \item IMAGE_UID -4 -4 -4
#'   \item RUNDATE -4 -4 -4
#'   \item STATUS -4 -4 -4
#'   \item CBICA_ID -4 -4 -4
#'   \item DATE -4 -4 -4
#'   \item R702 -4 -4 ICV
#'   \item R701 -4 -4 TOTALBRAIN
#'   \item R601 -4 -4 GM
#'   \item R604 -4 -4 WM
#'   \item R606 -4 -4 GM_L
#'   \item R607 -4 -4 WM_L
#'   \item R613 -4 -4 GM_R
#'   \item R614 -4 -4 WM_R
#'   \item R501 -4 -4 CORPUS_CALLOSUM
#'   \item R502 -4 -4 CEREBELLUM
#'   \item R503 -4 -4 DEEP_WM_GM
#'   \item R504 -4 -4 FRONTAL
#'   \item R505 -4 -4 LIMBIC
#'   \item R506 -4 -4 OCCIPITAL
#'   \item R507 -4 -4 PARIETAL
#'   \item R508 -4 -4 TEMPORAL
#'   \item R509 -4 -4 VENTRICLE
#'   \item R510 -4 -4 CEREBELLUM_L
#'   \item R511 -4 -4 DEEP_WM_GM_L
#'   \item R512 -4 -4 FRONTAL_L
#'   \item R513 -4 -4 LIMBIC_L
#'   \item R514 -4 -4 OCCIPITAL_L
#'   \item R515 -4 -4 PARIETAL_L
#'   \item R516 -4 -4 TEMPORAL_L
#'   \item R517 -4 -4 VENTRICLE_L
#'   \item R518 -4 -4 CEREBELLUM_R
#'   \item R519 -4 -4 DEEP_WM_GM_R
#'   \item R520 -4 -4 FRONTAL_R
#'   \item R521 -4 -4 LIMBIC_R
#'   \item R522 -4 -4 OCCIPITAL_R
#'   \item R523 -4 -4 PARIETAL_R
#'   \item R524 -4 -4 TEMPORAL_R
#'   \item R525 -4 -4 VENTRICLE_R
#'   \item R401 -4 -4 BASAL_GANGLIA
#'   \item R402 -4 -4 DEEP_GM
#'   \item R403 -4 -4 DEEP_WM
#'   \item R404 -4 -4 FRONTAL_GM
#'   \item R405 -4 -4 FRONTAL_WM
#'   \item R406 -4 -4 LIMBIC_GM
#'   \item R407 -4 -4 OCCIPITAL_GM
#'   \item R408 -4 -4 OCCIPITAL_WM
#'   \item R409 -4 -4 PARIETAL_GM
#'   \item R410 -4 -4 PARIETAL_WM
#'   \item R411 -4 -4 TEMPORAL_GM
#'   \item R412 -4 -4 TEMPORAL_WM
#'   \item R413 -4 -4 BASAL_GANGLIA_L
#'   \item R414 -4 -4 DEEP_GM_L
#'   \item R415 -4 -4 DEEP_WM_L
#'   \item R416 -4 -4 FRONTAL_GM_L
#'   \item R417 -4 -4 FRONTAL_WM_L
#'   \item R418 -4 -4 LIMBIC_GM_L
#'   \item R419 -4 -4 OCCIPITAL_GM_L
#'   \item R420 -4 -4 OCCIPITAL_WM_L
#'   \item R421 -4 -4 PARIETAL_GM_L
#'   \item R422 -4 -4 PARIETAL_WM_L
#'   \item R423 -4 -4 TEMPORAL_GM_L
#'   \item R424 -4 -4 TEMPORAL_WM_L
#'   \item R425 -4 -4 BASAL_GANGLIA_R
#'   \item R426 -4 -4 DEEP_GM_R
#'   \item R427 -4 -4 DEEP_WM_R
#'   \item R428 -4 -4 FRONTAL_GM_R
#'   \item R429 -4 -4 FRONTAL_WM_R
#'   \item R430 -4 -4 LIMBIC_GM_R
#'   \item R431 -4 -4 OCCIPITAL_GM_R
#'   \item R432 -4 -4 OCCIPITAL_WM_R
#'   \item R433 -4 -4 PARIETAL_GM_R
#'   \item R434 -4 -4 PARIETAL_WM_R
#'   \item R435 -4 -4 TEMPORAL_GM_R
#'   \item R436 -4 -4 TEMPORAL_WM_R
#'   \item R301 -4 -4 FRONTAL_INFERIOR_GM
#'   \item R302 -4 -4 FRONTAL_INSULAR_GM
#'   \item R303 -4 -4 FRONTAL_LATERAL_GM
#'   \item R304 -4 -4 FRONTAL_MEDIAL_GM
#'   \item R305 -4 -4 FRONTAL_OPERCULAR_GM
#'   \item R306 -4 -4 LIMBIC_CINGULATE_GM
#'   \item R307 -4 -4 LIMBIC_MEDIALTEMPORAL_GM
#'   \item R308 -4 -4 OCCIPITAL_INFERIOR_GM
#'   \item R309 -4 -4 OCCIPITAL_LATERAL_GM
#'   \item R310 -4 -4 OCCIPITAL_MEDIAL_GM
#'   \item R311 -4 -4 PARIETAL_LATERAL_GM
#'   \item R312 -4 -4 PARIETAL_MEDIAL_GM
#'   \item R313 -4 -4 TEMPORAL_INFERIOR_GM
#'   \item R314 -4 -4 TEMPORAL_LATERAL_GM
#'   \item R315 -4 -4 TEMPORAL_SUPRATEMPORAL_GM
#'   \item R316 -4 -4 FRONTAL_INFERIOR_GM_L
#'   \item R317 -4 -4 FRONTAL_INSULAR_GM_L
#'   \item R318 -4 -4 FRONTAL_LATERAL_GM_L
#'   \item R319 -4 -4 FRONTAL_MEDIAL_GM_L
#'   \item R320 -4 -4 FRONTAL_OPERCULAR_GM_L
#'   \item R321 -4 -4 LIMBIC_CINGULATE_GM_L
#'   \item R322 -4 -4 LIMBIC_MEDIALTEMPORAL_GM_L
#'   \item R323 -4 -4 OCCIPITAL_INFERIOR_GM_L
#'   \item R324 -4 -4 OCCIPITAL_LATERAL_GM_L
#'   \item R325 -4 -4 OCCIPITAL_MEDIAL_GM_L
#'   \item R326 -4 -4 PARIETAL_LATERAL_GM_L
#'   \item R327 -4 -4 PARIETAL_MEDIAL_GM_L
#'   \item R328 -4 -4 TEMPORAL_INFERIOR_GM_L
#'   \item R329 -4 -4 TEMPORAL_LATERAL_GM_L
#'   \item R330 -4 -4 TEMPORAL_SUPRATEMPORAL_GM_L
#'   \item R331 -4 -4 FRONTAL_INFERIOR_GM_R
#'   \item R332 -4 -4 FRONTAL_INSULAR_GM_R
#'   \item R333 -4 -4 FRONTAL_LATERAL_GM_R
#'   \item R334 -4 -4 FRONTAL_MEDIAL_GM_R
#'   \item R335 -4 -4 FRONTAL_OPERCULAR_GM_R
#'   \item R336 -4 -4 LIMBIC_CINGULATE_GM_R
#'   \item R337 -4 -4 LIMBIC_MEDIALTEMPORAL_GM_R
#'   \item R338 -4 -4 OCCIPITAL_INFERIOR_GM_R
#'   \item R339 -4 -4 OCCIPITAL_LATERAL_GM_R
#'   \item R340 -4 -4 OCCIPITAL_MEDIAL_GM_R
#'   \item R341 -4 -4 PARIETAL_LATERAL_GM_R
#'   \item R342 -4 -4 PARIETAL_MEDIAL_GM_R
#'   \item R343 -4 -4 TEMPORAL_INFERIOR_GM_R
#'   \item R344 -4 -4 TEMPORAL_LATERAL_GM_R
#'   \item R345 -4 -4 TEMPORAL_SUPRATEMPORAL_GM_R
#'   \item R4 -4 -4 3rd Ventricle
#'   \item R11 -4 -4 4th Ventricle
#'   \item R23 -4 -4 Right Accumbens Area
#'   \item R30 -4 -4 Left Accumbens Area
#'   \item R31 -4 -4 Right Amygdala
#'   \item R32 -4 -4 Left Amygdala
#'   \item R35 -4 -4 Brain Stem
#'   \item R36 -4 -4 Right Caudate
#'   \item R37 -4 -4 Left Caudate
#'   \item R38 -4 -4 Right Cerebellum Exterior
#'   \item R39 -4 -4 Left Cerebellum Exterior
#'   \item R40 -4 -4 Right Cerebellum White Matter
#'   \item R41 -4 -4 Left Cerebellum White Matter
#'   \item R47 -4 -4 Right Hippocampus
#'   \item R48 -4 -4 Left Hippocampus
#'   \item R49 -4 -4 Right Inf Lat Vent
#'   \item R50 -4 -4 Left Inf Lat Vent
#'   \item R51 -4 -4 Right Lateral Ventricle
#'   \item R52 -4 -4 Left Lateral Ventricle
#'   \item R55 -4 -4 Right Pallidum
#'   \item R56 -4 -4 Left Pallidum
#'   \item R57 -4 -4 Right Putamen
#'   \item R58 -4 -4 Left Putamen
#'   \item R59 -4 -4 Right Thalamus Proper
#'   \item R60 -4 -4 Left Thalamus Proper
#'   \item R61 -4 -4 Right Ventral DC
#'   \item R62 -4 -4 Left Ventral DC
#'   \item R71 -4 -4 Cerebellar Vermal Lobules I-V
#'   \item R72 -4 -4 Cerebellar Vermal Lobules VI-VII
#'   \item R73 -4 -4 Cerebellar Vermal Lobules VIII-X
#'   \item R75 -4 -4 Left Basal Forebrain
#'   \item R76 -4 -4 Right Basal Forebrain
#'   \item R81 -4 -4 frontal lobe WM right
#'   \item R82 -4 -4 frontal lobe WM left
#'   \item R83 -4 -4 occipital lobe WM right
#'   \item R84 -4 -4 occipital lobe WM left
#'   \item R85 -4 -4 parietal lobe WM right
#'   \item R86 -4 -4 parietal lobe WM left
#'   \item R87 -4 -4 temporal lobe WM right
#'   \item R88 -4 -4 temporal lobe WM left
#'   \item R89 -4 -4 fornix right
#'   \item R90 -4 -4 fornix left
#'   \item R91 -4 -4 anterior limb of internal capsule right
#'   \item R92 -4 -4 anterior limb of internal capsule left
#'   \item R93 -4 -4 posterior limb of internal capsule inc. cerebral peduncle right
#'   \item R94 -4 -4 posterior limb of internal capsule inc. cerebral peduncle left
#'   \item R95 -4 -4 corpus callosum
#'   \item R100 -4 -4 Right ACgG  anterior cingulate gyrus
#'   \item R101 -4 -4 Left ACgG  anterior cingulate gyrus
#'   \item R102 -4 -4 Right AIns  anterior insula
#'   \item R103 -4 -4 Left AIns  anterior insula
#'   \item R104 -4 -4 Right AOrG  anterior orbital gyrus
#'   \item R105 -4 -4 Left AOrG  anterior orbital gyrus
#'   \item R106 -4 -4 Right AnG   angular gyrus
#'   \item R107 -4 -4 Left AnG   angular gyrus
#'   \item R108 -4 -4 Right Calc  calcarine cortex
#'   \item R109 -4 -4 Left Calc  calcarine cortex
#'   \item R112 -4 -4 Right CO    central operculum
#'   \item R113 -4 -4 Left CO    central operculum
#'   \item R114 -4 -4 Right Cun   cuneus
#'   \item R115 -4 -4 Left Cun   cuneus
#'   \item R116 -4 -4 Right Ent   entorhinal area
#'   \item R117 -4 -4 Left Ent   entorhinal area
#'   \item R118 -4 -4 Right FO    frontal operculum
#'   \item R119 -4 -4 Left FO    frontal operculum
#'   \item R120 -4 -4 Right FRP   frontal pole
#'   \item R121 -4 -4 Left FRP   frontal pole
#'   \item R122 -4 -4 Right FuG   fusiform gyrus
#'   \item R123 -4 -4 Left FuG   fusiform gyrus
#'   \item R124 -4 -4 Right GRe   gyrus rectus
#'   \item R125 -4 -4 Left GRe   gyrus rectus
#'   \item R128 -4 -4 Right IOG   inferior occipital gyrus
#'   \item R129 -4 -4 Left IOG   inferior occipital gyrus
#'   \item R132 -4 -4 Right ITG   inferior temporal gyrus
#'   \item R133 -4 -4 Left ITG   inferior temporal gyrus
#'   \item R134 -4 -4 Right LiG   lingual gyrus
#'   \item R135 -4 -4 Left LiG   lingual gyrus
#'   \item R136 -4 -4 Right LOrG  lateral orbital gyrus
#'   \item R137 -4 -4 Left LOrG  lateral orbital gyrus
#'   \item R138 -4 -4 Right MCgG  middle cingulate gyrus
#'   \item R139 -4 -4 Left MCgG  middle cingulate gyrus
#'   \item R140 -4 -4 Right MFC   medial frontal cortex
#'   \item R141 -4 -4 Left MFC   medial frontal cortex
#'   \item R142 -4 -4 Right MFG   middle frontal gyrus
#'   \item R143 -4 -4 Left MFG   middle frontal gyrus
#'   \item R144 -4 -4 Right MOG   middle occipital gyrus
#'   \item R145 -4 -4 Left MOG   middle occipital gyrus
#'   \item R146 -4 -4 Right MOrG  medial orbital gyrus
#'   \item R147 -4 -4 Left MOrG  medial orbital gyrus
#'   \item R148 -4 -4 Right MPoG  postcentral gyrus medial segment
#'   \item R149 -4 -4 Left MPoG  postcentral gyrus medial segment
#'   \item R150 -4 -4 Right MPrG  precentral gyrus medial segment
#'   \item R151 -4 -4 Left MPrG  precentral gyrus medial segment
#'   \item R152 -4 -4 Right MSFG  superior frontal gyrus medial segment
#'   \item R153 -4 -4 Left MSFG  superior frontal gyrus medial segment
#'   \item R154 -4 -4 Right MTG   middle temporal gyrus
#'   \item R155 -4 -4 Left MTG   middle temporal gyrus
#'   \item R156 -4 -4 Right OCP   occipital pole
#'   \item R157 -4 -4 Left OCP   occipital pole
#'   \item R160 -4 -4 Right OFuG  occipital fusiform gyrus
#'   \item R161 -4 -4 Left OFuG  occipital fusiform gyrus
#'   \item R162 -4 -4 Right OpIFG opercular part of the inferior frontal gyrus
#'   \item R163 -4 -4 Left OpIFG opercular part of the inferior frontal gyrus
#'   \item R164 -4 -4 Right OrIFG orbital part of the inferior frontal gyrus
#'   \item R165 -4 -4 Left OrIFG orbital part of the inferior frontal gyrus
#'   \item R166 -4 -4 Right PCgG  posterior cingulate gyrus
#'   \item R167 -4 -4 Left PCgG  posterior cingulate gyrus
#'   \item R168 -4 -4 Right PCu   precuneus
#'   \item R169 -4 -4 Left PCu   precuneus
#'   \item R170 -4 -4 Right PHG   parahippocampal gyrus
#'   \item R171 -4 -4 Left PHG   parahippocampal gyrus
#'   \item R172 -4 -4 Right PIns  posterior insula
#'   \item R173 -4 -4 Left PIns  posterior insula
#'   \item R174 -4 -4 Right PO    parietal operculum
#'   \item R175 -4 -4 Left PO    parietal operculum
#'   \item R176 -4 -4 Right PoG   postcentral gyrus
#'   \item R177 -4 -4 Left PoG   postcentral gyrus
#'   \item R178 -4 -4 Right POrG  posterior orbital gyrus
#'   \item R179 -4 -4 Left POrG  posterior orbital gyrus
#'   \item R180 -4 -4 Right PP    planum polare
#'   \item R181 -4 -4 Left PP    planum polare
#'   \item R182 -4 -4 Right PrG   precentral gyrus
#'   \item R183 -4 -4 Left PrG   precentral gyrus
#'   \item R184 -4 -4 Right PT    planum temporale
#'   \item R185 -4 -4 Left PT    planum temporale
#'   \item R186 -4 -4 Right SCA   subcallosal area
#'   \item R187 -4 -4 Left SCA   subcallosal area
#'   \item R190 -4 -4 Right SFG   superior frontal gyrus
#'   \item R191 -4 -4 Left SFG   superior frontal gyrus
#'   \item R192 -4 -4 Right SMC   supplementary motor cortex
#'   \item R193 -4 -4 Left SMC   supplementary motor cortex
#'   \item R194 -4 -4 Right SMG   supramarginal gyrus
#'   \item R195 -4 -4 Left SMG   supramarginal gyrus
#'   \item R196 -4 -4 Right SOG   superior occipital gyrus
#'   \item R197 -4 -4 Left SOG   superior occipital gyrus
#'   \item R198 -4 -4 Right SPL   superior parietal lobule
#'   \item R199 -4 -4 Left SPL   superior parietal lobule
#'   \item R200 -4 -4 Right STG   superior temporal gyrus
#'   \item R201 -4 -4 Left STG   superior temporal gyrus
#'   \item R202 -4 -4 Right TMP   temporal pole
#'   \item R203 -4 -4 Left TMP   temporal pole
#'   \item R204 -4 -4 Right TrIFG triangular part of the inferior frontal gyrus
#'   \item R205 -4 -4 Left TrIFG triangular part of the inferior frontal gyrus
#'   \item R206 -4 -4 Right TTG   transverse temporal gyrus
#'   \item R207 -4 -4 Left TTG   transverse temporal gyrus
#' }
#'
#' @examples
#' \donotrun{
#' describe(upenn_roi_mars)
#' }
#' @docType data
#' @keywords datasets
#' @name upenn_roi_mars
#' @usage data(upenn_roi_mars)
#' @format A data frame with 840 rows and 269 variables
NULL

#' Spatial Pattern of Abnormalities for Recognition of Early AD (SPARE-AD). C. Davatzikos. U. Penn.
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/UPENNSPARE_AD/ADNI1_SPARE_AD.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item EXAMDATE -4 -4 Examination Date
#'   \item VERSION -4 -4 Version Date
#'   \item IMAGE_UID -4 -4 
#'   \item RUNDATE -4 -4 
#'   \item STATUS -4 -4 
#'   \item CBICA_ID -4 -4 Subject ID used at CBICA
#'   \item DATE -4 -4 
#'   \item TrueLabel -4 -4 Diagnostic Group
#'   \item SPARE_AD -4 -4 Spatial Pattern of Abnormalities for Recognition of Early AD (SPARE-AD)
#' }
#'
#' @examples
#' \donotrun{
#' describe(upennspare_ad)
#' }
#' @docType data
#' @keywords datasets
#' @name upennspare_ad
#' @usage data(upennspare_ad)
#' @format A data frame with 840 rows and 12 variables
NULL

#' Spatial Pattern of Abnormalities for Recognition of Early MCI to AD conversion (SPARE-MCI). C. Davatzikos. U. Penn.
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/UPENNSPARE_MCI/ADNI1_SPARE_MCI.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item EXAMDATE -4 -4 Examination Date
#'   \item VERSION -4 -4 Version Date
#'   \item IMAGE_UID -4 -4 
#'   \item RUNDATE -4 -4 
#'   \item STATUS -4 -4 
#'   \item CBICA_ID -4 -4 Subject ID used at CBICA
#'   \item DATE -4 -4 
#'   \item TimeToConversion -4 -4 Time to Conversion from MCI to AD
#'   \item TrueLabel -4 -4 Diagnostic Group (LS - Long term Stable, SC - Short Converter)
#'   \item SPARE_MCI -4 -4 Spatial Pattern of Abnormalities for Recognition of Early MCI to AD conversion (SPARE-MCI)
#' }
#'
#' @examples
#' \donotrun{
#' describe(upennspare_mci)
#' }
#' @docType data
#' @keywords datasets
#' @name upennspare_mci
#' @usage data(upennspare_mci)
#' @format A data frame with 330 rows and 13 variables
NULL

#' UU PET Analysis (Norman Foster)
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/UUCACIR/ADNI_UUCACIR_Methods_20120305.pdf}, \url{https://adni.bitbucket.io/reference/docs/UUCACIR/UUCACIR%20-%20PET%20Numeric%20Summaries%20Methods_08_10_15.pdf}, \url{https://adni.bitbucket.io/reference/docs/UUCACIR/UUCACIR%20-%20PET%20Numeric%20Summaries%20Methods-2016-Jul-08.pdf}, \url{https://adni.bitbucket.io/reference/docs/UUCACIR/UUtah_Analysis.pdf}, \url{https://adni.bitbucket.io/reference/docs/UUCACIR/UUtah%20Description%20of%20Data%20on%20LONI.pdf}, \url{https://adni.bitbucket.io/reference/docs/UUCACIR/UUtah%20-%20PET%20Numeric%20Summaries%20Methods_20130307.pdf}, \url{https://adni.bitbucket.io/reference/docs/UUCACIR/UUtah%20-%20PET%20Numeric%20Summaries%20Methods.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item VISCODE2 -4 -4 Translated visit code
#'   \item EXAMDATE D  Examination Date
#'   \item IMAGEUID T  ImageUID
#'   \item PETTYPE T  Type of PET scan
#'   \item REFCTRLPOP T  Control population used for comparison
#'   \item REFREGION T  Region used for normalization
#'   \item AVEREF N  Average value of reference region
#'   \item AVEASSOC N  Average frontal, parietal and temporal cortices, norm to reference region
#'   \item AVEFRONT N  Average frontal cortex, norm to reference region
#'   \item X2SDSIGPXL N pixels Number of pixels with Zscores in the range [2, 3) SD
#'   \item X3SDSIGPXL N pixels Number of pixels with Zscores  in the range  [3, inf) SD
#'   \item SUMZ2 N  Sum of pixels with Zscores in the range [2, inf) SD
#'   \item SUMZ3 N  Sum of pixels with Zscores in the range [3, inf) SD
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name uucacir
#' @usage data(uucacir)
#' @format A data frame with 1822 rows and 15 variables
NULL

#' Crane Lab (UW) Neuropsych Summary Scores
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/UWNPSYCHSUM/ADNI_Methods_UWNPSYCHSUM.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N NA Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item VISCODE2 -4 -4 Translated visit code
#'   \item USERDATE -4 -4 Date record created
#'   \item EXAMDATE T NA Examination Date
#'   \item PHASE -4 -4 -4
#'   \item ADNI_MEM -4 -4 -4
#'   \item ADNI_EF -4 -4 -4
#' }
#'
#' @examples
#' \donotrun{
#' describe(uwnpsychsum)
#' }
#' @docType data
#' @keywords datasets
#' @name uwnpsychsum
#' @usage data(uwnpsychsum)
#' @format A data frame with 9344 rows and 8 variables
NULL

#' University of Western Ontario (Bartha Lab) Ventricular Volumes
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item RECNO N  
#'   \item EXAMDATE D mmddyyyy Examination Date
#'   \item IMAGEUID N  
#'   \item VENTVOL N cm3 Segmented Ventricular Volume
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name uwovent
#' @usage data(uwovent)
#' @format A data frame with 2207 rows and 9 variables
NULL

#' Protocol Deviations Log
#'
#'
#'
#'
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N NA Participant roster ID
#'   \item SITEID N NA Site ID
#'   \item VISCODE T NA Visit code
#'   \item USERDATE S NA Date record created
#'   \item USERDATE2 S NA Date record last updated
#'   \item RECNO N NA 
#'   \item VIOTYPE N NA Deviation applies to: (check one)
#'   \item VIODES N NA Please select the most appropriate description: (check one)
#'   \item VIODESO T NA If Other specify:
#'   \item INEXNUM T NA If Inclusion/Exclusion Criteria: Item number
#'   \item IRB N NA Was IRB informed of Protocol Deviation?
#'   \item IRBDATE D NA If yes, indicate date reported:
#'   \item RIGHTS N NA Have the rights, safety or well-being of participant been compromised?
#'   \item EVENTDES T NA Description of Event
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name violog
#' @usage data(violog)
#' @format A data frame with 4008 rows and 16 variables
NULL

#' Vital Signs
#'
#'
#'
#' @author \email{adni-data@googlegroups.com}
#'
#'
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID N  Participant roster ID
#'   \item SITEID N  Site ID
#'   \item VISCODE T  Visit code
#'   \item USERDATE S  Date record created
#'   \item EXAMDATE D  Examination Date
#'   \item VSWEIGHT N  1a. Weight
#'   \item VSWTUNIT N  1b. Weight Units
#'   \item VSHEIGHT N  2a. Height
#'   \item VSHTUNIT N  2b. Height Units
#'   \item VSBPSYS N  Systolic - mmHg
#'   \item VSBPDIA N  Diastolic - mmHg
#'   \item VSPULSE N  4. Seated Pulse Rate (per minute)
#'   \item VSRESP N  5. Respirations (per minute)
#'   \item VSTEMP N  6a. Temperature
#'   \item VSTMPSRC N  6b. Temperature Source
#'   \item VSTMPUNT N  6c. Temperature Units
#'   \item VSCOMM T  7. Comments regarding vital signs:
#'   \item USERDATE2 S  Date record last updated
#' }
#'
#' @examples
#' 
#' @docType data
#' @keywords datasets
#' @name vitals
#' @usage data(vitals)
#' @format A data frame with 12115 rows and 20 variables
NULL

#' CSF Hemoglobin ELISA and PS129 Luminex Assays (Zhang Lab, University of Washington)
#'
#'
#'
#'
#'
#' @seealso  \url{https://adni.bitbucket.io/reference/docs/ZHANG/UW%20-%20Zhang%20Lab,%20CSF%20Hgb_v160914.pdf}, \url{https://adni.bitbucket.io/reference/docs/ZHANG/UW%20-%20Zhang%20Lab,%20CSF%20ps129_v160914.pdf}
#'
#'
#' A dataset with variables as follows:
#'
#' \itemize{
#'   \item RID -4 -4 Participant roster ID
#'   \item VISCODE -4 -4 Visit code
#'   \item VISCODE2 -4 -4 Translated visit code
#'   \item EXAMDATE -4 -4 Examination Date
#'   \item BOX_POS -4  Aliquot position in shipping box
#'   \item VOLUME -4  aliquot volume
#'   \item SHIPMENT -4  Respository shipment identifier
#'   \item RUNDATE_ASYN -4  Date of alpha-synuclein assay
#'   \item FINAL_ASYN -4 ng/ml Final reported concentration of alpha-synuclein
#'   \item RUNDATE_PS129 -4  Date of ps129 assay
#'   \item FINAL_PS129 -4 ng/ml Final reported concentration of ps129
#'   \item RUNDATE_HGB -4  Date of hemoglobin assay
#'   \item FINAL_HGB -4 ng/ml Final reported concentration of hemoglobin
#' }
#'
#' @examples
#' \donotrun{
#' describe(zhang)
#' }
#' @docType data
#' @keywords datasets
#' @name zhang
#' @usage data(zhang)
#' @format A data frame with 805 rows and 13 variables
NULL

