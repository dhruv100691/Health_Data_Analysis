#' ADNIMERGE: Clinical and biomarker data from the Alzheimer's Disease Neuroimaging Initiative (ADNI)
#' 
#' @name ADNIMERGE-package
#' @docType package
#' @author ATRI Biostatistics
#' @seealso \code{\url{https://groups.google.com/forum/#!forum/adni-data}}
#' @keywords package
NULL